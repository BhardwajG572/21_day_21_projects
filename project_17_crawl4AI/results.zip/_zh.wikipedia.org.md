[跳转到内容](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5#bodyContent)
主菜单
主菜单
移至侧栏 隐藏
导航 
  * [首页](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "访问首页 \[z\]")
  * [分类索引](https://zh.wikipedia.org/wiki/Wikipedia:%E5%88%86%E7%B1%BB%E7%B4%A2%E5%BC%95 "以分类索引搜寻中文维基百科")
  * [特色内容](https://zh.wikipedia.org/wiki/Portal:%E7%89%B9%E8%89%B2%E5%85%A7%E5%AE%B9 "查看中文维基百科的特色内容")
  * [新闻动态](https://zh.wikipedia.org/wiki/Portal:%E6%96%B0%E8%81%9E%E5%8B%95%E6%85%8B "提供当前新闻事件的背景资料")
  * [最近更改](https://zh.wikipedia.org/wiki/Special:RecentChanges "列出维基百科中的最近修改 \[r\]")
  * [随机条目](https://zh.wikipedia.org/wiki/Special:Random "随机载入一个页面 \[x\]")


帮助 
  * [帮助](https://zh.wikipedia.org/wiki/Help:%E7%9B%AE%E5%BD%95 "寻求帮助")
  * [维基社群](https://zh.wikipedia.org/wiki/Wikipedia:%E7%A4%BE%E7%BE%A4%E9%A6%96%E9%A1%B5 "关于本计划、你可以做什么、应该如何做")
  * [方针与指引](https://zh.wikipedia.org/wiki/Wikipedia:%E6%96%B9%E9%87%9D%E8%88%87%E6%8C%87%E5%BC%95 "查看维基百科的方针和指引")
  * [互助客栈](https://zh.wikipedia.org/wiki/Wikipedia:%E4%BA%92%E5%8A%A9%E5%AE%A2%E6%A0%88 "参与维基百科社群的讨论")
  * [知识问答](https://zh.wikipedia.org/wiki/Wikipedia:%E7%9F%A5%E8%AF%86%E9%97%AE%E7%AD%94 "解答任何与维基百科无关的问题的地方")
  * [字词转换](https://zh.wikipedia.org/wiki/Wikipedia:%E5%AD%97%E8%AF%8D%E8%BD%AC%E6%8D%A2 "提出字词转换请求")
  * [IRC即时聊天](https://zh.wikipedia.org/wiki/Wikipedia:IRC%E8%81%8A%E5%A4%A9%E9%A2%91%E9%81%93)
  * [联络我们](https://zh.wikipedia.org/wiki/Wikipedia:%E8%81%94%E7%BB%9C%E6%88%91%E4%BB%AC "如何联络维基百科")
  * [关于维基百科](https://zh.wikipedia.org/wiki/Wikipedia:%E5%85%B3%E4%BA%8E "查看维基百科的简介")
  * [特殊页面](https://zh.wikipedia.org/wiki/Special:SpecialPages)


[ ![](https://zh.wikipedia.org/static/images/icons/wikipedia.png) ![维基百科](https://zh.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-zh.svg) ![自由的百科全书](https://zh.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-zh.svg) ](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5)
[搜索 ](https://zh.wikipedia.org/wiki/Special:Search "搜索维基百科 \[f\]")
搜索
外观
  * [资助维基百科](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=zh.wikipedia.org&uselang=zh)
  * [创建账号](https://zh.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=Wikipedia%3A%E9%A6%96%E9%A1%B5 "我们推荐您创建账号并登录，但这不是强制性的")
  * [登录](https://zh.wikipedia.org/w/index.php?title=Special:UserLogin&returnto=Wikipedia%3A%E9%A6%96%E9%A1%B5 "建议你登录，尽管并非必须。 \[o\]")


个人工具
  * [资助维基百科](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=zh.wikipedia.org&uselang=zh)
  * [创建账号](https://zh.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=Wikipedia%3A%E9%A6%96%E9%A1%B5 "我们推荐您创建账号并登录，但这不是强制性的")
  * [登录](https://zh.wikipedia.org/w/index.php?title=Special:UserLogin&returnto=Wikipedia%3A%E9%A6%96%E9%A1%B5 "建议你登录，尽管并非必须。 \[o\]")


#  维基百科:首页
  * [首页](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "查看维基计划页面 \[c\]")
  * [讨论](https://zh.wikipedia.org/wiki/Wikipedia_talk:%E9%A6%96%E9%A1%B5 "关于此页面的讨论 \[t\]")


不转换
  * [不转换](https://zh.wikipedia.org/zh/Wikipedia:%E9%A6%96%E9%A1%B5)
  * [简体](https://zh.wikipedia.org/zh-hans/Wikipedia:%E9%A6%96%E9%A1%B5)
  * [繁體](https://zh.wikipedia.org/zh-hant/Wikipedia:%E9%A6%96%E9%A1%B5)
  * [大陆简体](https://zh.wikipedia.org/zh-cn/Wikipedia:%E9%A6%96%E9%A1%B5)
  * [香港繁體](https://zh.wikipedia.org/zh-hk/Wikipedia:%E9%A6%96%E9%A1%B5)
  * [澳門繁體](https://zh.wikipedia.org/zh-mo/Wikipedia:%E9%A6%96%E9%A1%B5)
  * [大马简体](https://zh.wikipedia.org/zh-my/Wikipedia:%E9%A6%96%E9%A1%B5)
  * [新加坡简体](https://zh.wikipedia.org/zh-sg/Wikipedia:%E9%A6%96%E9%A1%B5)
  * [臺灣正體](https://zh.wikipedia.org/zh-tw/Wikipedia:%E9%A6%96%E9%A1%B5)


  * [阅读](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5)
  * [查看源代码](https://zh.wikipedia.org/w/index.php?title=Wikipedia:%E9%A6%96%E9%A1%B5&action=edit "该页面已被保护。你可以查看该页源码。 \[e\]")
  * [查看历史](https://zh.wikipedia.org/w/index.php?title=Wikipedia:%E9%A6%96%E9%A1%B5&action=history "本页面的早前版本。 \[h\]")


工具
工具
移至侧栏 隐藏
操作 
  * [阅读](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5)
  * [查看源代码](https://zh.wikipedia.org/w/index.php?title=Wikipedia:%E9%A6%96%E9%A1%B5&action=edit)
  * [查看历史](https://zh.wikipedia.org/w/index.php?title=Wikipedia:%E9%A6%96%E9%A1%B5&action=history)


常规 
  * [链入页面](https://zh.wikipedia.org/wiki/Special:WhatLinksHere/Wikipedia:%E9%A6%96%E9%A1%B5 "列出所有与本页相链的页面 \[j\]")
  * [相关更改](https://zh.wikipedia.org/wiki/Special:RecentChangesLinked/Wikipedia:%E9%A6%96%E9%A1%B5 "页面链出所有页面的更改 \[k\]")
  * [上传文件](https://zh.wikipedia.org/wiki/Project:%E4%B8%8A%E4%BC%A0 "上传图像或多媒体文件 \[u\]")
  * [固定链接](https://zh.wikipedia.org/w/index.php?title=Wikipedia:%E9%A6%96%E9%A1%B5&oldid=89302078 "此页面该修订版本的固定链接")
  * [页面信息](https://zh.wikipedia.org/w/index.php?title=Wikipedia:%E9%A6%96%E9%A1%B5&action=info "关于此页面的更多信息")
  * [获取短链接](https://zh.wikipedia.org/w/index.php?title=Special:UrlShortener&url=https%3A%2F%2Fzh.wikipedia.org%2Fwiki%2FWikipedia%3A%25E9%25A6%2596%25E9%25A1%25B5)
  * [下载二维码](https://zh.wikipedia.org/w/index.php?title=Special:QrCode&url=https%3A%2F%2Fzh.wikipedia.org%2Fwiki%2FWikipedia%3A%25E9%25A6%2596%25E9%25A1%25B5)


打印/导出 
  * [下载为PDF](https://zh.wikipedia.org/w/index.php?title=Special:DownloadAsPdf&page=Wikipedia%3A%E9%A6%96%E9%A1%B5&action=show-download-screen)
  * [打印页面](javascript:print\(\); "本页面的可打印版本 \[p\]")


在其他项目中 
  * [维基共享资源](https://commons.wikimedia.org/wiki/Main_Page)
  * [维基媒体基金会](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [元维基](https://meta.wikimedia.org/wiki/Main_Page)
  * [维基媒体拓展](https://outreach.wikimedia.org/wiki/Main_Page)
  * [多语言维基文库](https://wikisource.org/wiki/Main_Page)
  * [维基物种](https://species.wikimedia.org/wiki/Main_Page)
  * [维基教科书](https://zh.wikibooks.org/wiki/Wikibooks:%E9%A6%96%E9%A1%B5)
  * [维基数据](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [维基新闻](https://zh.wikinews.org/wiki/Wikinews:%E9%A6%96%E9%A1%B5)
  * [维基语录](https://zh.wikiquote.org/wiki/Wikiquote:%E9%A6%96%E9%A1%B5)
  * [维基文库](https://zh.wikisource.org/wiki/Wikisource:%E9%A6%96%E9%A1%B5)
  * [维基学院](https://zh.wikiversity.org/wiki/Wikiversity:%E9%A6%96%E9%A1%B5)
  * [维基导游](https://zh.wikivoyage.org/wiki/%E9%A6%96%E9%A1%B5)
  * [维基词典](https://zh.wiktionary.org/wiki/Wiktionary:%E9%A6%96%E9%A1%B5)
  * [维基数据项目](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "链接到连接的数据仓库项目 \[g\]")


外观
移至侧栏 隐藏
维基百科，自由的百科全书
# [维基百科](https://zh.wikipedia.org/wiki/Wikipedia:%E5%85%B3%E4%BA%8E "Wikipedia:关于")
海納百川，有容乃大  
[人人可編輯](https://zh.wikipedia.org/wiki/Wikipedia:%E6%AC%A2%E8%BF%8E "Wikipedia:欢迎")的[自由](https://zh.wikipedia.org/wiki/%E8%87%AA%E7%94%B1%E5%85%A7%E5%AE%B9 "自由內容")百科全書
已有[1,503,166](https://zh.wikipedia.org/wiki/Special:Statistics "Special:Statistics")篇[條目](https://zh.wikipedia.org/wiki/Wikipedia:%E4%BB%80%E4%B9%88%E6%98%AF%E6%9D%A1%E7%9B%AE "Wikipedia:什么是条目")
[分类](https://zh.wikipedia.org/wiki/Wikipedia:%E5%88%86%E9%A1%9E%E7%B4%A2%E5%BC%95 "Wikipedia:分類索引") | [主题](https://zh.wikipedia.org/wiki/Portal:%E9%A6%96%E9%A0%81 "Portal:首頁") | [求助](https://zh.wikipedia.org/wiki/Wikipedia:%E4%BA%92%E5%8A%A9%E5%AE%A2%E6%A0%88/%E6%B1%82%E5%8A%A9 "Wikipedia:互助客栈/求助")  
---|---|---  
[入门](https://zh.wikipedia.org/wiki/Wikipedia:%E6%96%B0%E6%89%8B%E5%85%A5%E9%96%80/%E4%B8%BB%E9%A0%81 "Wikipedia:新手入門/主頁") | [沙盒](https://zh.wikipedia.org/wiki/Wikipedia:%E6%B2%99%E7%9B%92 "Wikipedia:沙盒") | [捐款](https://zh.wikipedia.org/wiki/Wikipedia:%E8%81%94%E7%BB%9C%E6%88%91%E4%BB%AC/%E6%8D%90%E8%B5%A0%E8%80%85 "Wikipedia:联络我们/捐赠者")  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Japanese_Crest_mitu_Tomoe_1.svg/250px-Japanese_Crest_mitu_Tomoe_1.svg.png)](https://zh.wikipedia.org/wiki/File:Japanese_Crest_mitu_Tomoe_1.svg)
**[西園寺家](https://zh.wikipedia.org/wiki/%E8%A5%BF%E5%9C%92%E5%AF%BA%E5%AE%B6 "西園寺家")** 是[日本](https://zh.wikipedia.org/wiki/%E6%97%A5%E6%9C%AC "日本")的一個[公家](https://zh.wikipedia.org/wiki/%E5%85%AC%E5%AE%B6 "公家")，本姓[藤原](https://zh.wikipedia.org/wiki/%E8%97%A4%E5%8E%9F%E6%B0%8F "藤原氏")[朝臣](https://zh.wikipedia.org/wiki/%E5%85%AB%E8%89%B2%E5%A7%93 "八色姓")，為神別[氏族](https://zh.wikipedia.org/wiki/%E6%B0%8F%E6%97%8F "氏族")，[家格](https://zh.wikipedia.org/wiki/%E5%AE%B6%E6%A0%BC "家格")為[清华家](https://zh.wikipedia.org/wiki/%E6%B8%85%E5%8D%8E%E5%AE%B6 "清华家")，[家紋](https://zh.wikipedia.org/wiki/%E5%AE%B6%E7%B4%8B "家紋")為左三巴，家業為[琵琶](https://zh.wikipedia.org/wiki/%E7%90%B5%E7%90%B6_\(%E6%97%A5%E6%9C%AC\) "琵琶 \(日本\)")。西園寺家來自[藤原北家](https://zh.wikipedia.org/wiki/%E8%97%A4%E5%8E%9F%E5%8C%97%E5%AE%B6 "藤原北家")閑院流，是[藤原鎌足](https://zh.wikipedia.org/wiki/%E8%97%A4%E5%8E%9F%E9%8E%8C%E8%B6%B3 "藤原鎌足")十世孫[太政大臣](https://zh.wikipedia.org/wiki/%E5%A4%AA%E6%94%BF%E5%A4%A7%E8%87%A3 "太政大臣")藤原公季五世孫權[中纳言](https://zh.wikipedia.org/wiki/%E4%B8%AD%E7%BA%B3%E8%A8%80 "中纳言")藤原通季的後裔。藤原通季的曾孫[西園寺公經](https://zh.wikipedia.org/wiki/%E8%A5%BF%E5%9C%92%E5%AF%BA%E5%85%AC%E7%B6%93 "西園寺公經")在[承久之亂](https://zh.wikipedia.org/wiki/%E6%89%BF%E4%B9%85%E4%B9%8B%E4%BA%82 "承久之亂")爆發時站台[北條氏](https://zh.wikipedia.org/wiki/%E5%8C%97%E6%A2%9D%E6%B0%8F "北條氏")，由此取得[镰仓幕府](https://zh.wikipedia.org/wiki/%E9%95%B0%E4%BB%93%E5%B9%95%E5%BA%9C "镰仓幕府")的信任，此後更成為西園寺家首位成為太政大臣的當主，自此西園寺家權勢日盛。 
  * [其他典範條目](https://zh.wikipedia.org/wiki/Wikipedia:%E5%85%B8%E8%8C%83%E6%9D%A1%E7%9B%AE "Wikipedia:典范条目")：[1998年太平洋颶風季](https://zh.wikipedia.org/wiki/1998%E5%B9%B4%E5%A4%AA%E5%B9%B3%E6%B4%8B%E9%A2%B6%E9%A2%A8%E5%AD%A3 "1998年太平洋颶風季")－[斯科特诉桑福德案](https://zh.wikipedia.org/wiki/%E6%96%AF%E7%A7%91%E7%89%B9%E8%AF%89%E6%A1%91%E7%A6%8F%E5%BE%B7%E6%A1%88 "斯科特诉桑福德案")－[气旋哈利](https://zh.wikipedia.org/wiki/%E6%B0%94%E6%97%8B%E5%93%88%E5%88%A9 "气旋哈利")
  * [其他特色列表](https://zh.wikipedia.org/wiki/Wikipedia:%E7%89%B9%E8%89%B2%E5%88%97%E8%A1%A8 "Wikipedia:特色列表")：[香港行車隧道列表](https://zh.wikipedia.org/wiki/%E9%A6%99%E6%B8%AF%E8%A1%8C%E8%BB%8A%E9%9A%A7%E9%81%93%E5%88%97%E8%A1%A8 "香港行車隧道列表")－[立陶宛世界遗产名录](https://zh.wikipedia.org/wiki/%E7%AB%8B%E9%99%B6%E5%AE%9B%E4%B8%96%E7%95%8C%E9%81%97%E4%BA%A7%E5%90%8D%E5%BD%95 "立陶宛世界遗产名录")－[肯塔基州城市列表](https://zh.wikipedia.org/wiki/%E8%82%AF%E5%A1%94%E5%9F%BA%E5%B7%9E%E5%9F%8E%E5%B8%82%E5%88%97%E8%A1%A8 "肯塔基州城市列表")


  * [典范条目](https://zh.wikipedia.org/wiki/Wikipedia:%E5%85%B8%E8%8C%83%E6%9D%A1%E7%9B%AE "Wikipedia:典范条目")（[候选](https://zh.wikipedia.org/wiki/Wikipedia:%E5%85%B8%E8%8C%83%E6%9D%A1%E7%9B%AE%E8%AF%84%E9%80%89 "Wikipedia:典范条目评选")）
  * [特色列表](https://zh.wikipedia.org/wiki/Wikipedia:%E7%89%B9%E8%89%B2%E5%88%97%E8%A1%A8 "Wikipedia:特色列表")（[候选](https://zh.wikipedia.org/wiki/Wikipedia:%E7%89%B9%E8%89%B2%E5%88%97%E8%A1%A8%E8%AF%84%E9%80%89 "Wikipedia:特色列表评选")）
  * [存档](https://zh.wikipedia.org/wiki/Wikipedia:%E5%85%B8%E8%8C%83%E6%9D%A1%E7%9B%AE/%E5%AD%98%E6%A1%A3 "Wikipedia:典范条目/存档")


[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/TD_Centre_View_from_Yonge_and_King.JPG/120px-TD_Centre_View_from_Yonge_and_King.JPG)](https://zh.wikipedia.org/wiki/File:TD_Centre_View_from_Yonge_and_King.JPG)
  * **[哪位法國國王](https://zh.wikipedia.org/wiki/%E4%BA%A8%E5%88%A9%E4%BA%8C%E4%B8%96_\(%E6%B3%95%E5%85%B0%E8%A5%BF\) "亨利二世 \(法兰西\)")** 在[馬上比武](https://zh.wikipedia.org/wiki/%E9%A6%AC%E4%B8%8A%E6%AF%94%E6%AD%A6 "馬上比武")大會親自上陣，意外被斷矛碎片擊中眼睛身亡？
  * **[哪位拜占庭将领](https://zh.wikipedia.org/wiki/%E6%96%AF%E5%9F%BA%E6%B3%B0%E4%BA%BA%E5%AE%89%E5%BE%B7%E7%83%88 "斯基泰人安德烈")** 出身斯拉夫人，得以担任拜占庭军总司令？
  * [法國國家足球隊](https://zh.wikipedia.org/wiki/%E6%B3%95%E5%9C%8B%E5%9C%8B%E5%AE%B6%E8%B6%B3%E7%90%83%E9%9A%8A "法國國家足球隊")球員[德西雷·杜埃](https://zh.wikipedia.org/wiki/%E5%BE%B7%E8%A5%BF%E9%9B%B7%C2%B7%E6%9D%9C%E5%9F%83 "德西雷·杜埃")的[**哪位直系親屬**](https://zh.wikipedia.org/wiki/%E5%8F%A4%E6%8B%89%C2%B7%E6%9D%9C%E7%88%BE "古拉·杜爾")代表[科特迪瓦國家足球隊](https://zh.wikipedia.org/wiki/%E7%A7%91%E7%89%B9%E8%BF%AA%E7%93%A6%E5%9C%8B%E5%AE%B6%E8%B6%B3%E7%90%83%E9%9A%8A "科特迪瓦國家足球隊")出戰國際賽？
  * 法軍在**[哪場會戰](https://zh.wikipedia.org/wiki/%E8%B5%AB%E5%B8%8C%E6%96%BD%E5%A1%94%E7%89%B9%E4%B9%8B%E6%88%B0 "赫希施塔特之戰")** 中試圖包圍敵軍，卻因敵軍撤退信號與己方進攻信號相同，致一支部隊過早進攻，錯失全殲敵軍的機會？
  * 根据2022年的统计数据，法国[奥莱龙岛](https://zh.wikipedia.org/wiki/%E5%A5%A5%E8%8E%B1%E9%BE%99%E5%B2%9B "奥莱龙岛")人口数量最多的是[**哪个市镇**](https://zh.wikipedia.org/wiki/%E5%9C%A3%E7%9A%AE%E5%9F%83%E5%B0%94%E5%A4%9A%E8%8E%B1%E9%BE%99 "圣皮埃尔多莱龙")？
  * **[哪位律師](https://zh.wikipedia.org/wiki/%E5%8A%A0%E9%87%8C%C2%B7%E9%9C%8D%E4%BC%8A "加里·霍伊")** 為了證明辦公室的窗戶很堅固，而往大樓窗戶猛撞，然後墜樓身亡？（圖）


  * [候选](https://zh.wikipedia.org/wiki/Wikipedia:%E6%96%B0%E6%9D%A1%E7%9B%AE%E6%8E%A8%E8%8D%90/%E5%80%99%E9%80%89 "Wikipedia:新条目推荐/候选")
  * [存档](https://zh.wikipedia.org/wiki/Wikipedia:%E6%96%B0%E6%9D%A1%E7%9B%AE%E6%8E%A8%E8%8D%90 "Wikipedia:新条目推荐")
  * [更多新条目](https://zh.wikipedia.org/wiki/Special:NewPages "Special:NewPages")


[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/U-32_IWM_HU_1011.jpg/120px-U-32_IWM_HU_1011.jpg)](https://zh.wikipedia.org/wiki/File:U-32_IWM_HU_1011.jpg)
**[U-32号潜艇](https://zh.wikipedia.org/wiki/U-32%E5%8F%B7%E6%BD%9C%E8%89%87_\(1937%E5%B9%B4\) "U-32号潜艇 \(1937年\)")** 是[纳粹德国](https://zh.wikipedia.org/wiki/%E7%BA%B3%E7%B2%B9%E5%BE%B7%E5%9B%BD "纳粹德国")[战争海军](https://zh.wikipedia.org/wiki/%E6%88%B0%E7%88%AD%E6%B5%B7%E8%BB%8D "戰爭海軍")建造的十艘[VII-A型](https://zh.wikipedia.org/wiki/VII%E7%B4%9A%E6%BD%9B%E8%89%87 "VII級潛艇")近岸[潜艇](https://zh.wikipedia.org/wiki/%E6%BD%9C%E8%89%87 "潜艇")（或称[U艇](https://zh.wikipedia.org/wiki/U%E8%89%87 "U艇")）之一。它由[不来梅](https://zh.wikipedia.org/wiki/%E4%B8%8D%E6%9D%A5%E6%A2%85 "不来梅")的[威悉船厂](https://zh.wikipedia.org/wiki/%E5%A8%81%E6%82%89%E8%88%B9%E5%8E%82 "威悉船厂")承建，于1937年2月25日[下水](https://zh.wikipedia.org/wiki/%E8%88%B9%E8%88%B6%E4%B8%8B%E6%B0%B4 "船舶下水")，至同年4月15日交付使用。[第二次世界大战](https://zh.wikipedia.org/wiki/%E7%AC%AC%E4%BA%8C%E6%AC%A1%E4%B8%96%E7%95%8C%E5%A4%A7%E6%88%98 "第二次世界大战")期间，该艇曾执行过九次巡逻作战，共击沉20艘、击伤5艘[同盟国](https://zh.wikipedia.org/wiki/%E5%90%8C%E7%9B%9F%E5%9C%8B_\(%E7%AC%AC%E4%BA%8C%E6%AC%A1%E4%B8%96%E7%95%8C%E5%A4%A7%E6%88%B0\) "同盟國 \(第二次世界大戰\)")或[中立国](https://zh.wikipedia.org/wiki/%E4%B8%AD%E7%AB%8B%E5%9B%BD "中立国")舰船，累积总吨位达157,110吨。1940年10月30日，U-32号在爱尔兰西北部的[北大西洋](https://zh.wikipedia.org/wiki/%E5%8C%97%E5%A4%A7%E8%A5%BF%E6%B4%8B "北大西洋")遭英国[驱逐舰](https://zh.wikipedia.org/wiki/%E9%A9%B1%E9%80%90%E8%88%B0 "驱逐舰")收割者号和高地人号投掷的[深水炸弹](https://zh.wikipedia.org/wiki/%E6%B7%B1%E6%B0%B4%E7%82%B8%E5%BC%B9 "深水炸弹")击沉，造成9人阵亡，33人幸存。 
  * [其他優良條目](https://zh.wikipedia.org/wiki/Wikipedia:%E4%BC%98%E8%89%AF%E6%9D%A1%E7%9B%AE "Wikipedia:优良条目")：[祈理士](https://zh.wikipedia.org/wiki/%E7%A5%88%E7%90%86%E5%A3%AB "祈理士")－[超级马力欧银河2](https://zh.wikipedia.org/wiki/%E8%B6%85%E7%BA%A7%E9%A9%AC%E5%8A%9B%E6%AC%A7%E9%93%B6%E6%B2%B32 "超级马力欧银河2")－[林子豐](https://zh.wikipedia.org/wiki/%E6%9E%97%E5%AD%90%E8%B1%90 "林子豐")


  * [優良條目](https://zh.wikipedia.org/wiki/Wikipedia:%E4%BC%98%E8%89%AF%E6%9D%A1%E7%9B%AE "Wikipedia:优良条目")（[候选](https://zh.wikipedia.org/wiki/Wikipedia:%E5%84%AA%E8%89%AF%E6%A2%9D%E7%9B%AE%E8%A9%95%E9%81%B8 "Wikipedia:優良條目評選")）
  * [存档](https://zh.wikipedia.org/wiki/Wikipedia:%E4%BC%98%E8%89%AF%E6%9D%A1%E7%9B%AE/%E5%AD%98%E6%A1%A3 "Wikipedia:优良条目/存档")


  * [![受到三相神敬拜的賢时母（Bhadrakali）水彩畫作，約1660-70年間完成。印度教會在十胜节慶祝女神消滅邪惡，換算西元為今日。](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg/500px-Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)](https://zh.wikipedia.org/wiki/File:Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg "受到三相神敬拜的賢时母（Bhadrakali）水彩畫作，約1660-70年間完成。印度教會在十胜节慶祝女神消滅邪惡，換算西元為今日。")
受到[三相神](https://zh.wikipedia.org/wiki/%E4%B8%89%E7%9B%B8%E7%A5%9E "三相神")敬拜的賢时母（Bhadrakali）水彩畫作，約1660-70年間完成。[印度教](https://zh.wikipedia.org/wiki/%E5%8D%B0%E5%BA%A6%E6%95%99 "印度教")會在[十胜节](https://zh.wikipedia.org/wiki/%E5%8D%81%E8%83%9C%E8%8A%82 "十胜节")慶祝女神消滅邪惡，換算西元為今日。


  * [特色圖片](https://zh.wikipedia.org/wiki/Wikipedia:%E7%89%B9%E8%89%B2%E5%9B%BE%E7%89%87 "Wikipedia:特色图片")（[候選](https://zh.wikipedia.org/wiki/Wikipedia:%E7%89%B9%E8%89%B2%E5%9C%96%E7%89%87%E8%A9%95%E9%81%B8 "Wikipedia:特色圖片評選")）
  * [更多每日圖片](https://zh.wikipedia.org/wiki/Wikipedia:%E6%AF%8F%E6%97%A5%E5%9B%BE%E7%89%87 "Wikipedia:每日图片")


[![颱風博羅依](https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Bualoi_2025-09-28_0729Z.jpg/120px-Bualoi_2025-09-28_0729Z.jpg)](https://zh.wikipedia.org/wiki/File:Bualoi_2025-09-28_0729Z.jpg "颱風博羅依")颱風博羅依
  * 英國[動物學家](https://zh.wikipedia.org/wiki/%E5%8A%A8%E7%89%A9%E5%AD%A6 "动物学")**[珍·古道尔](https://zh.wikipedia.org/wiki/%E7%8F%8D%C2%B7%E5%8F%A4%E9%81%93%E5%B0%94 "珍·古道尔")** 逝世，終年91歲。
  * 菲律賓[宿霧省](https://zh.wikipedia.org/wiki/%E5%AE%BF%E9%9C%A7%E7%9C%81 "宿霧省")境內[米沙鄢群島](https://zh.wikipedia.org/wiki/%E7%B1%B3%E6%B2%99%E9%84%A2%E7%BE%A4%E5%B3%B6 "米沙鄢群島")附近發生**[M W 6.9级地震](https://zh.wikipedia.org/wiki/2025%E5%B9%B4%E5%AE%BF%E9%9C%A7%E5%9C%B0%E9%9C%87 "2025年宿霧地震")**，造成至少72人死亡、290餘人受傷。
  * **[颱風博羅依](https://zh.wikipedia.org/wiki/%E9%A2%B1%E9%A2%A8%E5%8D%9A%E7%BE%85%E4%BE%9D_\(2025%E5%B9%B4\) "颱風博羅依 \(2025年\)")** （图）侵襲菲律賓及越南等地，造成至少49人死亡、139人受傷，另有35人失蹤。
  * [摩尔多瓦总统](https://zh.wikipedia.org/wiki/%E6%91%A9%E5%B0%94%E5%A4%9A%E7%93%A6%E6%80%BB%E7%BB%9F "摩尔多瓦总统")[瑪雅·桑杜](https://zh.wikipedia.org/wiki/%E7%91%AA%E9%9B%85%C2%B7%E6%A1%91%E6%9D%9C "瑪雅·桑杜")領導的[行动和团结党](https://zh.wikipedia.org/wiki/%E8%A1%8C%E5%8A%A8%E5%92%8C%E5%9B%A2%E7%BB%93%E5%85%9A "行动和团结党")在該國**[议会选举](https://zh.wikipedia.org/wiki/2025%E5%B9%B4%E6%91%A9%E7%88%BE%E5%A4%9A%E7%93%A6%E8%AD%B0%E6%9C%83%E9%81%B8%E8%88%89 "2025年摩爾多瓦議會選舉")** 获得过半数席次。
  * 印度[泰米尔纳德邦](https://zh.wikipedia.org/wiki/%E6%B3%B0%E7%B1%B3%E5%B0%94%E7%BA%B3%E5%BE%B7%E9%82%A6 "泰米尔纳德邦")[卡鲁尔](https://zh.wikipedia.org/wiki/%E5%8D%A1%E9%B2%81%E5%B0%94 "卡鲁尔")一處政治集会发生**[踩踏事故](https://zh.wikipedia.org/wiki/2025%E5%B9%B4%E5%8D%A1%E9%AD%AF%E7%88%BE%E8%B8%A9%E8%B8%8F%E4%BA%8B%E6%95%85 "2025年卡魯爾踩踏事故")** ，造成至少41人死亡、80餘人受伤。


  * **[正在发生](https://zh.wikipedia.org/wiki/Portal:%E6%96%B0%E8%81%9E%E5%8B%95%E6%85%8B "Portal:新聞動態")** ：[俄羅斯入侵烏克蘭](https://zh.wikipedia.org/wiki/%E4%BF%84%E7%BE%85%E6%96%AF%E5%85%A5%E4%BE%B5%E7%83%8F%E5%85%8B%E8%98%AD "俄羅斯入侵烏克蘭")（[過程](https://zh.wikipedia.org/wiki/%E4%BF%84%E7%BE%85%E6%96%AF%E5%85%A5%E4%BE%B5%E7%83%8F%E5%85%8B%E8%98%AD%E9%81%8E%E7%A8%8B "俄羅斯入侵烏克蘭過程")－[和平談判](https://zh.wikipedia.org/wiki/2022%E5%B9%B4%E8%87%B3%E4%BB%8A%E7%9A%84%E4%BF%84%E4%B9%8C%E5%92%8C%E5%B9%B3%E8%B0%88%E5%88%A4 "2022年至今的俄乌和平谈判")）－[加沙戰爭](https://zh.wikipedia.org/wiki/%E5%8A%A0%E6%B2%99%E6%88%B0%E7%88%AD "加沙戰爭")－[柬泰边境争端](https://zh.wikipedia.org/wiki/2025%E5%B9%B4%E6%9F%AC%E6%B3%B0%E8%BE%B9%E5%A2%83%E4%BA%89%E7%AB%AF "2025年柬泰边境争端")


  * **[最近逝世](https://zh.wikipedia.org/wiki/2025%E5%B9%B410%E6%9C%88%E9%80%9D%E4%B8%96%E4%BA%BA%E7%89%A9%E5%88%97%E8%A1%A8 "2025年10月逝世人物列表")** ：[珍·古道尔](https://zh.wikipedia.org/wiki/%E7%8F%8D%C2%B7%E5%8F%A4%E9%81%93%E5%B0%94 "珍·古道尔")－[羅素·納爾遜](https://zh.wikipedia.org/wiki/%E7%BE%85%E7%B4%A0%C2%B7%E7%B4%8D%E7%88%BE%E9%81%9C "羅素·納爾遜")－[張俊雄](https://zh.wikipedia.org/wiki/%E5%BC%B5%E4%BF%8A%E9%9B%84 "張俊雄")－[程建人](https://zh.wikipedia.org/wiki/%E7%A8%8B%E5%BB%BA%E4%BA%BA "程建人")－[孟席斯·坎貝爾](https://zh.wikipedia.org/wiki/%E5%AD%9F%E5%B8%AD%E6%96%AF%C2%B7%E5%9D%8E%E8%B2%9D%E7%88%BE "孟席斯·坎貝爾")


  * [候選](https://zh.wikipedia.org/wiki/Wikipedia:%E6%96%B0%E9%97%BB%E5%8A%A8%E6%80%81%E5%80%99%E9%80%89 "Wikipedia:新闻动态候选")
  * [維基新聞](https://zh.wikinews.org/wiki/Wikinews:%E9%A6%96%E9%A1%B5 "n:Wikinews:首页")
  * [讣闻](https://zh.wikipedia.org/wiki/Portal:%E8%AE%A3%E9%97%BB "Portal:讣闻")
  * [更多新闻](https://zh.wikipedia.org/wiki/Portal:%E6%96%B0%E8%81%9E%E5%8B%95%E6%85%8B "Portal:新聞動態")


[10月2日](https://zh.wikipedia.org/wiki/10%E6%9C%882%E6%97%A5 "10月2日")：[國際非暴力日](https://zh.wikipedia.org/wiki/%E5%9C%8B%E9%9A%9B%E9%9D%9E%E6%9A%B4%E5%8A%9B%E6%97%A5 "國際非暴力日")、[幾內亞](https://zh.wikipedia.org/wiki/%E5%B9%BE%E5%85%A7%E4%BA%9E "幾內亞")[獨立日](https://zh.wikipedia.org/wiki/%E7%8D%A8%E7%AB%8B%E6%97%A5 "獨立日")（[1958年](https://zh.wikipedia.org/wiki/1958%E5%B9%B4 "1958年")） 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Jacques_Cartier_1851-1852_%28cropped%29.jpg/120px-Jacques_Cartier_1851-1852_%28cropped%29.jpg)](https://zh.wikipedia.org/wiki/File:Jacques_Cartier_1851-1852_\(cropped\).jpg) [1187年](https://zh.wikipedia.org/wiki/1187%E5%B9%B4 "1187年")
    埃及蘇丹**[薩拉丁](https://zh.wikipedia.org/wiki/%E8%96%A9%E6%8B%89%E4%B8%81 "薩拉丁")** 率領[埃宥比王朝](https://zh.wikipedia.org/wiki/%E5%9F%83%E5%AE%A5%E6%AF%94%E7%8E%8B%E6%9C%9D "埃宥比王朝")軍隊收復被[耶路撒冷王國](https://zh.wikipedia.org/wiki/%E8%80%B6%E8%B7%AF%E6%92%92%E5%86%B7%E7%8E%8B%E5%9C%8B "耶路撒冷王國")統領88年的[耶路撒冷](https://zh.wikipedia.org/wiki/%E8%80%B6%E8%B7%AF%E6%92%92%E5%86%B7 "耶路撒冷")。 [1535年](https://zh.wikipedia.org/wiki/1535%E5%B9%B4 "1535年")
    法國探險家**[雅克·卡蒂埃](https://zh.wikipedia.org/wiki/%E9%9B%85%E5%85%8B%C2%B7%E5%8D%A1%E8%92%82%E4%BA%9E "雅克·卡蒂亞")** （圖）沿著北美[聖羅倫斯河](https://zh.wikipedia.org/wiki/%E8%81%96%E7%BE%85%E5%80%AB%E6%96%AF%E6%B2%B3 "聖羅倫斯河")航行，到達現在加拿大[蒙特婁島](https://zh.wikipedia.org/wiki/%E8%92%99%E7%89%B9%E5%A9%81%E5%B3%B6 "蒙特婁島")一帶。 [1835年](https://zh.wikipedia.org/wiki/1835%E5%B9%B4 "1835年")
    墨西哥軍隊與[德克薩斯民兵](https://zh.wikipedia.org/wiki/%E5%BE%B7%E5%85%8B%E8%96%A9%E6%96%AF%E4%BA%BA "德克薩斯人")在[墨屬德克薩斯](https://zh.wikipedia.org/wiki/%E5%A2%A8%E5%B1%9E%E5%BE%B7%E5%85%8B%E8%90%A8%E6%96%AF "墨属德克萨斯")[岡薩雷斯](https://zh.wikipedia.org/wiki/%E5%86%88%E8%90%A8%E9%9B%B7%E6%96%AF_\(%E5%BE%97%E5%85%8B%E8%90%A8%E6%96%AF%E5%B7%9E\) "冈萨雷斯 \(得克萨斯州\)")發生**[衝突](https://zh.wikipedia.org/wiki/%E5%86%88%E8%90%A8%E9%9B%B7%E6%96%AF%E4%B9%8B%E6%88%98 "冈萨雷斯之战")** ，[德克薩斯革命](https://zh.wikipedia.org/wiki/%E5%BE%B7%E5%85%8B%E8%96%A9%E6%96%AF%E9%9D%A9%E5%91%BD "德克薩斯革命")爆發。 [1941年](https://zh.wikipedia.org/wiki/1941%E5%B9%B4 "1941年")
     [納粹德國](https://zh.wikipedia.org/wiki/%E7%B4%8D%E7%B2%B9%E5%BE%B7%E5%9C%8B "納粹德國")[國防軍](https://zh.wikipedia.org/wiki/%E5%BE%B7%E6%84%8F%E5%BF%97%E5%9C%8B%E9%98%B2%E8%BB%8D "德意志國防軍")向[蘇聯](https://zh.wikipedia.org/wiki/%E8%98%87%E8%81%AF "蘇聯")首都[莫斯科](https://zh.wikipedia.org/wiki/%E8%8E%AB%E6%96%AF%E7%A7%91 "莫斯科")發動大規模攻勢，**[莫斯科戰役](https://zh.wikipedia.org/wiki/%E8%8E%AB%E6%96%AF%E7%A7%91%E6%88%B0%E5%BD%B9 "莫斯科戰役")** 爆發。 [1950年](https://zh.wikipedia.org/wiki/1950%E5%B9%B4 "1950年")
    美國漫畫家[查尔斯·舒尔茨](https://zh.wikipedia.org/wiki/%E6%9F%A5%E7%88%BE%E6%96%AF%C2%B7%E8%88%92%E8%8C%B2 "查爾斯·舒茲")開始連載以[史努比](https://zh.wikipedia.org/wiki/%E5%8F%B2%E5%8A%AA%E6%AF%94 "史努比")、[查理·布朗](https://zh.wikipedia.org/wiki/%E6%9F%A5%E7%90%86%C2%B7%E5%B8%83%E6%9C%97 "查理·布朗")為主角的系列漫畫《**[花生](https://zh.wikipedia.org/wiki/%E8%8A%B1%E7%94%9F%E6%BC%AB%E7%95%AB "花生漫畫")** 》。
  * [存档](https://zh.wikipedia.org/wiki/Wikipedia:%E5%8E%86%E5%8F%B2%E4%B8%8A%E7%9A%84%E4%BB%8A%E5%A4%A9 "Wikipedia:历史上的今天")
  * [更多历史事件](https://zh.wikipedia.org/wiki/10%E6%9C%882%E6%97%A5 "10月2日")


  * [風林火山](https://zh.wikipedia.org/wiki/%E9%A2%A8%E6%9E%97%E7%81%AB%E5%B1%B1_\(2025%E5%B9%B4%E9%9B%BB%E5%BD%B1\) "風林火山 \(2025年電影\)")
  * [巨塔之后](https://zh.wikipedia.org/wiki/%E5%B7%A8%E5%A1%94%E4%B9%8B%E5%90%8E "巨塔之后")
  * [于朦胧](https://zh.wikipedia.org/wiki/%E4%BA%8E%E6%9C%A6%E8%83%A7 "于朦胧")
  * [暴君的廚師](https://zh.wikipedia.org/wiki/%E6%9A%B4%E5%90%9B%E7%9A%84%E5%BB%9A%E5%B8%AB "暴君的廚師")
  * [鏈鋸人](https://zh.wikipedia.org/wiki/%E9%8F%88%E9%8B%B8%E4%BA%BA "鏈鋸人")
  * [吳宜樺](https://zh.wikipedia.org/wiki/%E5%90%B3%E5%AE%9C%E6%A8%BA "吳宜樺")
  * [今際之國的闖關者](https://zh.wikipedia.org/wiki/%E4%BB%8A%E9%9A%9B%E4%B9%8B%E5%9C%8B%E7%9A%84%E9%97%96%E9%97%9C%E8%80%85_\(%E9%9B%BB%E8%A6%96%E5%8A%87\) "今際之國的闖關者 \(電視劇\)")
  * [绝命法官](https://zh.wikipedia.org/wiki/%E7%BB%9D%E5%91%BD%E6%B3%95%E5%AE%98 "绝命法官")
  * [于朦朧墜樓案](https://zh.wikipedia.org/wiki/%E4%BA%8E%E6%9C%A6%E6%9C%A7%E5%A2%9C%E6%A8%93%E6%A1%88 "于朦朧墜樓案")
  * [季連成](https://zh.wikipedia.org/wiki/%E5%AD%A3%E9%80%A3%E6%88%90 "季連成")


  * [更多動態熱門](https://zh.wikipedia.org/wiki/Wikipedia:%E5%8A%A8%E6%80%81%E7%83%AD%E9%97%A8 "Wikipedia:动态热门")


[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Applications-office.svg/70px-Applications-office.svg.png)](https://zh.wikipedia.org/wiki/File:Applications-office.svg)
**[维基百科](https://zh.wikipedia.org/wiki/Wikipedia:%E5%85%B3%E4%BA%8E "Wikipedia:关于")** 是一个[多语言](https://zh.wikipedia.org/wiki/Wikipedia:%E7%BB%B4%E5%9F%BA%E7%99%BE%E7%A7%91%E8%AF%AD%E8%A8%80%E5%88%97%E8%A1%A8 "Wikipedia:维基百科语言列表")、[内容自由](https://zh.wikipedia.org/wiki/Wikipedia:%E8%91%97%E4%BD%9C%E6%9D%83%E4%BF%A1%E6%81%AF "Wikipedia:著作权信息")、[任何人都能参与](https://zh.wikipedia.org/wiki/Wikipedia:%E8%AA%B0%E5%9C%A8%E5%AF%AB%E7%B6%AD%E5%9F%BA%E7%99%BE%E7%A7%91 "Wikipedia:誰在寫維基百科")的协作计划，其目标是建立一个完整、准确且中立的百科全书。 
中文维基百科的成长依靠您的参与，無論是[创建新条目](https://zh.wikipedia.org/wiki/Help:%E5%88%9B%E5%BB%BA%E6%96%B0%E6%9D%A1%E7%9B%AE "Help:创建新条目")、[编辑现有条目](https://zh.wikipedia.org/wiki/Help:%E7%BC%96%E8%BE%91%E9%A1%B5%E9%9D%A2 "Help:编辑页面")，或者[为条目增加插图](https://zh.wikipedia.org/wiki/Help:%E5%9B%BE%E5%83%8F "Help:图像")，您都可以为维基百科作出贡献。 
[开始参与维基百科](https://zh.wikipedia.org/wiki/Wikipedia:%E5%8F%83%E8%88%87%E8%B2%A2%E7%8D%BB "Wikipedia:參與貢獻")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Dialog-information_on.svg/70px-Dialog-information_on.svg.png)](https://zh.wikipedia.org/wiki/File:Dialog-information_on.svg)
[著作权信息](https://zh.wikipedia.org/wiki/Wikipedia:%E7%89%88%E6%AC%8A%E4%BF%A1%E6%81%AF "Wikipedia:版權信息")：我們根據[知识共享 署名-相同方式共享 4.0協議](https://zh.wikipedia.org/wiki/Wikipedia:CC "Wikipedia:CC")開放版權，人人可以自由發佈、链接和編輯，包括您貢獻的所有內容。 
  * [移动访问](https://zh.wikipedia.org/wiki/Wikipedia:%E8%A1%8C%E5%8B%95%E5%AD%98%E5%8F%96 "Wikipedia:行動存取")
  * [站点新闻](https://zh.wikipedia.org/wiki/Wikipedia:%E5%AE%A3%E5%91%8A "Wikipedia:宣告")
  * [联络我们](https://zh.wikipedia.org/wiki/Wikipedia:%E8%81%94%E7%BB%9C%E6%88%91%E4%BB%AC "Wikipedia:联络我们")
  * [RSS](https://zh.wikipedia.org/wiki/Wikipedia:%E8%81%94%E5%90%88%E4%BE%9B%E7%A8%BF "Wikipedia:联合供稿")
  * [Guestbook](https://zh.wikipedia.org/wiki/Wikipedia_talk:Guestbook_for_non-Chinese_speakers "Wikipedia talk:Guestbook for non-Chinese speakers")

| 
  * [谁在撰写](https://zh.wikipedia.org/wiki/Wikipedia:%E8%AA%B0%E5%9C%A8%E5%AF%AB%E7%B6%AD%E5%9F%BA%E7%99%BE%E7%A7%91 "Wikipedia:誰在寫維基百科")
  * [五大支柱](https://zh.wikipedia.org/wiki/Wikipedia:%E4%BA%94%E5%A4%A7%E6%94%AF%E6%9F%B1 "Wikipedia:五大支柱")
  * [常见问题](https://zh.wikipedia.org/wiki/Wikipedia:%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98%E8%A7%A3%E7%AD%94 "Wikipedia:常见问题解答")
  * [常见誤解](https://zh.wikipedia.org/wiki/Wikipedia:%E7%BB%B4%E5%9F%BA%E7%99%BE%E7%A7%91%E4%B8%8D%E6%98%AF%E4%BB%80%E4%B9%88 "Wikipedia:维基百科不是什么")
  * [简要规则集](https://zh.wikipedia.org/wiki/Wikipedia:%E7%AE%80%E8%A6%81%E8%A7%84%E5%88%99%E9%9B%86 "Wikipedia:简要规则集")

| 
  * [备忘单](https://zh.wikipedia.org/wiki/Wikipedia:%E5%82%99%E5%BF%98%E5%96%AE "Wikipedia:備忘單")
  * [版权守则](https://zh.wikipedia.org/wiki/Wikipedia:%E7%89%88%E6%9D%83%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98%E8%A7%A3%E7%AD%94 "Wikipedia:版权常见问题解答")
  * [格式手冊](https://zh.wikipedia.org/wiki/Wikipedia:%E6%A0%BC%E5%BC%8F%E6%89%8B%E5%86%8C "Wikipedia:格式手册")
  * [版面指南](https://zh.wikipedia.org/wiki/Wikipedia:%E6%A0%BC%E5%BC%8F%E6%89%8B%E5%86%8A/%E7%89%88%E9%9D%A2%E4%BD%88%E5%B1%80 "Wikipedia:格式手冊/版面佈局")
  * [术语表](https://zh.wikipedia.org/wiki/Wikipedia:%E6%9C%AF%E8%AF%AD%E8%A1%A8 "Wikipedia:术语表")

  
---|---|---  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8b/Wikimedia-logo_black.svg/60px-Wikimedia-logo_black.svg.png)
**维基百科** 由非营利组织[维基媒体基金会](https://foundation.wikimedia.org/wiki/%E9%A6%96%E9%A1%B5 "wikimedia:首页")运作。基金会旗下尚有其他数个多语言、内容开放的维基计划：
[![维基词典](https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Wiktprintable_without_text_zh.svg/40px-Wiktprintable_without_text_zh.svg.png)](https://zh.wiktionary.org/wiki/ "维基词典")维基词典 |  [**维基词典**](https://zh.wiktionary.org/wiki/ "wikt:")  
多语言字词典 |  [![维基文库](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://zh.wikisource.org/wiki/ "维基文库")维基文库 |  [**维基文库**](https://zh.wikisource.org/wiki/ "s:")  
自由内容的图书馆 |  [![维基语录](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://zh.wikiquote.org/wiki/ "维基语录")维基语录 |  [**维基语录**](https://zh.wikiquote.org/wiki/ "q:")  
名人名言的集锦 |  [![维基教科书](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://zh.wikibooks.org/wiki/ "维基教科书")维基教科书 |  [**维基教科书**](https://zh.wikibooks.org/wiki/ "b:")  
自由的教科书和手册  
---|---|---|---|---|---|---|---  
[![维基新闻](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://zh.wikinews.org/wiki/ "维基新闻")维基新闻 |  [**维基新闻**](https://zh.wikinews.org/wiki/ "n:")  
自由的新闻源 |  [![维基物种](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/%E9%A6%96%E9%A1%B5 "维基物种")维基物种 |  [**维基物种**](https://species.wikimedia.org/wiki/%E9%A6%96%E9%A1%B5 "wikispecies:首页")  
物种目录 |  [![维基导游](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://zh.wikivoyage.org/wiki/%E9%A6%96%E9%A1%B5 "维基导游") |  [**维基导游**](https://zh.wikivoyage.org/wiki/ "voy:")  
自由的旅行指南 |  [![维基学院](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/40px-Wikiversity_logo_2017.svg.png)](https://zh.wikiversity.org/wiki/Wikiversity:%E9%A6%96%E9%A1%B5 "维基学院")维基学院 |  [**维基学院**](https://zh.wikiversity.org/wiki/ "v:")  
自由的研习社群  
[![维基共享资源](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/%E9%A6%96%E9%A1%B5 "维基共享资源")维基共享资源 |  [**维基共享资源**](https://commons.wikimedia.org/wiki/%E9%A6%96%E9%A1%B5 "commons:首页")  
自由的多媒体资料库 |  [![维基数据](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/Wikidata:%E9%A6%96%E9%A0%81 "维基数据") |  [**维基数据**](https://www.wikidata.org/wiki/Wikidata:%E9%A6%96%E9%A1%B5 "d:Wikidata:首页")  
自由的知识库 |  [![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/MediaWiki/zh "MediaWiki")MediaWiki |  [**MediaWiki**](https://www.mediawiki.org/wiki/MediaWiki/zh "mw:MediaWiki/zh")  
Wiki软件开发 |  [![元维基](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/%E9%A6%96%E9%A1%B5 "元维基")元维基 |  [**元维基**](https://meta.wikimedia.org/wiki/%E9%A6%96%E9%A1%B5 "m:首页")  
协调各维基计划  
检索自“[https://zh.wikipedia.org/w/index.php?title=Wikipedia:首页&oldid=89302078](https://zh.wikipedia.org/w/index.php?title=Wikipedia:%E9%A6%96%E9%A1%B5&oldid=89302078)”
353种语言
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – 阿法尔语")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – 阿布哈西亚语")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – 亚齐语")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – 阿迪格语")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – 南非荷兰语")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – 瑞士德语")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – 南阿尔泰语")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – 阿姆哈拉语")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – 阿拉贡语")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – 古英语")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – 奥博洛语")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – 昂加语")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – 阿拉伯语")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – 阿拉米语")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – 摩洛哥阿拉伯文")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – 埃及阿拉伯文")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – 阿萨姆语")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – 阿斯图里亚斯语")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – 阿提卡米克语")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – 阿瓦尔语")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – 科塔瓦文")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – 阿瓦德语")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – 艾马拉语")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – 阿塞拜疆语")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – 巴什基尔语")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – 巴厘语")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – 巴伐利亞文")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – 薩莫吉希亞文")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – 巴塔克托巴文")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – 白俄罗斯语")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – 貝塔維文")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница – 保加利亚语")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – 比斯拉马语")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – 班亞爾文")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – 班巴拉语")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – 孟加拉语")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – 藏语")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – 比什奴普萊利亞文")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – 布列塔尼语")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – 波斯尼亚语")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – 布吉语")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – 加泰罗尼亚语")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – 车臣语")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – 宿务语")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – 查莫罗语")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – 乔克托语")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – 切罗基语")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – 夏延语")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – 中库尔德语")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – 科西嘉语")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – 克里语")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – 克里米亚鞑靼语")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana – 捷克语")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – 卡舒比语")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – 教会斯拉夫语")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – 楚瓦什语")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – 威尔士语")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside – 丹麦语")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – 德语")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – 丁卡语")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – 下索布语")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – 中部杜順文")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – 迪维希语")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – 宗卡语")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – 埃维语")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – 希腊语")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – 英语")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – 世界语")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – 西班牙语")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht – 爱沙尼亚语")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala – 巴斯克语")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – 埃斯特雷馬杜拉文")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – 波斯语")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – 芳蒂语")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – 富拉语")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – 芬兰语")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – 佛羅文")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – 斐济语")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – 法罗语")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – 丰语")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal – 法语")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – 法蘭克-普羅旺斯文")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – 北弗里西亚语")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – 弗留利语")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – 西弗里西亚语")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – 爱尔兰语")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – 加告兹语")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – 赣语")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – 苏格兰盖尔语")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – 加利西亚语")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – 吉拉基文")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – 瓜拉尼语")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – 哥伦打洛语")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – 哥特语")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – 古吉拉特语")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – 瓦尤文")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – 弗拉弗拉文")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – 马恩语")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – 豪萨语")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – 客家语")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – 夏威夷语")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – 希伯来语")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – 印地语")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – 斐濟印地文")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – 希里莫图语")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – 克罗地亚语")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – 上索布语")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – 海地克里奥尔语")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – 匈牙利语")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ – 亚美尼亚语")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – 赫雷罗语")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – 国际语")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – 伊班语")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama – 印度尼西亚语")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – 国际文字（E）")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – 伊博语")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – 伊努皮克语")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – 伊洛卡诺语")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – 印古什语")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – 伊多语")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – 冰岛语")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – 意大利语")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – 因纽特语")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – 日语")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – 牙買加克里奧爾英文")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – 逻辑语")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – 爪哇语")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – 格鲁吉亚语")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – 卡拉卡尔帕克语")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – 卡拜尔语")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – 卡巴尔德语")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – 卡塔布语")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – 刚果语")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – 吉库尤语")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – 宽亚玛语")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – 哈萨克语")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – 格陵兰语")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – 高棉语")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – 卡纳达语")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – 韩语")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – 科米-彼尔米亚克语")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – 卡努里语")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – 卡拉恰伊巴尔卡尔语")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – 克什米尔语")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – 科隆语")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – 库尔德语")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – 科米语")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – 康沃尔语")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – 柯尔克孜语")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima – 拉丁语")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – 拉迪诺语")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – 卢森堡语")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – 列兹金语")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – 新共同語言")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – 卢干达语")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – 林堡语")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – 利古里亚语")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – 拉定语")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – 伦巴第语")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – 林加拉语")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – 老挝语")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – 北卢尔语")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – 立陶宛语")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – 拉特加萊文")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – 拉脱维亚语")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – 马都拉语")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – 迈蒂利语")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – 莫克沙语")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – 马拉加斯语")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – 马绍尔语")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – 毛利语")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – 米南佳保语")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – 马其顿语")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – 马拉雅拉姆语")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – 蒙古语")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – 曼尼普尔语")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – 莫西语")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – 马拉地语")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – 西馬里文")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – 马来语")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – 马耳他语")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – 克里克语")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – 米兰德斯语")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – 缅甸语")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – 厄尔兹亚语")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – 马赞德兰语")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – 那不勒斯语")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – 低地德语")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – 低萨克森语")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – 尼泊尔语")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – 尼瓦尔语")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – 恩东加语")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – 尼亚斯语")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina – 荷兰语")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – 挪威尼诺斯克语")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – 书面挪威语")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – 諾維亞文")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – 西非书面文字")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – 南恩德贝勒语")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – 北索托语")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – 纳瓦霍语")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – 齐切瓦语")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – 奥克语")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – 奥罗莫语")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – 奥里亚语")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – 奥塞梯语")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – 旁遮普语")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – 邦阿西南语")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – 邦板牙语")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – 帕皮阿门托语")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – 庇卡底文")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – 尼日利亚皮钦语")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – 賓夕法尼亞德文")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – 普法爾茨德文")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – 巴利语")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – 波兰语")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – 皮埃蒙特文")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – 旁狄希臘文")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – 普什图语")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – 葡萄牙语")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – 克丘亚语")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – 罗曼什语")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – 隆迪语")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – 罗马尼亚语")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – 阿罗马尼亚语")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – 俄语")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – 盧森尼亞文")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – 卢旺达语")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – 梵语")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – 萨哈语")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – 桑塔利语")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – 萨丁语")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – 西西里语")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – 苏格兰语")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – 信德语")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – 北方萨米语")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – 桑戈语")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – 塞尔维亚-克罗地亚语")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – 希尔哈语")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – 掸语")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – 僧伽罗语")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – 斯洛伐克语")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – 色莱基语")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – 斯洛文尼亚语")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – 萨摩亚语")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – 伊纳里萨米语")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – 绍纳语")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – 索马里语")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – 阿尔巴尼亚语")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – 塞尔维亚语")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – 苏里南汤加语")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – 斯瓦蒂语")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – 南索托语")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – 沙特菲士蘭文")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – 巽他语")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – 瑞典语")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – 斯瓦希里语")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – 西里西亚语")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – 泰米尔语")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – 圖盧文")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – 泰卢固语")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – 德顿语")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – 塔吉克语")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – 泰语")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – 提格利尼亚语")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – 提格雷语")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – 土库曼语")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – 他加禄语")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – 塔里什文")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – 茨瓦纳语")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – 汤加语")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – 托克皮辛语")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – 土耳其语")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – 赛德克语")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – 聪加语")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – 鞑靼语")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – 通布卡语")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – 契维语")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – 塔希提语")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – 图瓦语")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – 乌德穆尔特语")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – 维吾尔语")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – 乌克兰语")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – 乌尔都语")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – 乌兹别克语")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – 文达语")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – 威尼斯语")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – 维普森语")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – 越南语")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – 西佛蘭德文")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – 沃拉普克语")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – 瓦隆语")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – 瓦瑞语")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – 沃洛夫语")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – 吴语")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – 卡尔梅克语")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – 科萨语")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – 明格列爾文")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – 意第绪语")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – 约鲁巴语")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – 壮语")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – 西蘭文")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – 标准摩洛哥塔马塞特语")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – 文言文")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – 闽南语")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – 粤语")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – 祖鲁语")


[编辑链接](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "编辑跨语言链接")
  * 本页面最后修订于2025年9月27日 (星期六) 01:13。
  * 本站的全部文字在[知识共享 署名-相同方式共享 4.0协议](https://zh.wikipedia.org/wiki/Wikipedia:CC_BY-SA_4.0%E5%8D%8F%E8%AE%AE%E6%96%87%E6%9C%AC "Wikipedia:CC BY-SA 4.0协议文本")之条款下提供，附加条款亦可能应用。（请参阅[使用条款](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use)）  
Wikipedia®和维基百科标志是[维基媒体基金会](https://wikimediafoundation.org)的注册商标；维基™是维基媒体基金会的商标。  
维基媒体基金会是按美国国內稅收法501(c)(3)登记的[非营利慈善机构](https://donate.wikimedia.org/wiki/Special:MyLanguage/Tax_deductibility)。  



  * [隐私政策](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [关于维基百科](https://zh.wikipedia.org/wiki/Wikipedia:%E5%85%B3%E4%BA%8E)
  * [免责声明](https://zh.wikipedia.org/wiki/Wikipedia:%E5%85%8D%E8%B4%A3%E5%A3%B0%E6%98%8E)
  * [行为准则](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [开发者](https://developer.wikimedia.org)
  * [统计](https://stats.wikimedia.org/#/zh.wikipedia.org)
  * [Cookie声明](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [手机版视图](https://zh.m.wikipedia.org/w/index.php?title=Wikipedia:%E9%A6%96%E9%A1%B5&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://zh.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://zh.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


搜索
搜索
维基百科:首页
[](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5) [](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5) [](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5) [](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5) [](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5) [](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5) [](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5) [](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5)
353种语言 [添加话题 ](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5)
