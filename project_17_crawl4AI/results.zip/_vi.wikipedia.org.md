[Bước tới nội dung](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh#bodyContent)
Trình đơn chính
Trình đơn chính
chuyển sang thanh bên ẩn
Điều hướng 
  * [Trang Chính](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Xem trang chính \[z\]")
  * [Nội dung chọn lọc](https://vi.wikipedia.org/wiki/C%E1%BB%95ng_th%C3%B4ng_tin:N%E1%BB%99i_dung_ch%E1%BB%8Dn_l%E1%BB%8Dc)
  * [Bài viết ngẫu nhiên](https://vi.wikipedia.org/wiki/%C4%90%E1%BA%B7c_bi%E1%BB%87t:Ng%E1%BA%ABu_nhi%C3%AAn "Xem trang ngẫu nhiên \[x\]")
  * [Thay đổi gần đây](https://vi.wikipedia.org/wiki/%C4%90%E1%BA%B7c_bi%E1%BB%87t:Thay_%C4%91%E1%BB%95i_g%E1%BA%A7n_%C4%91%C3%A2y "Danh sách thay đổi gần đây trong wiki \[r\]")
  * [Báo lỗi nội dung](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A1o_l%E1%BB%97i_b%C3%A0i_vi%E1%BA%BFt)


Tương tác 
  * [Hướng dẫn](https://vi.wikipedia.org/wiki/Wikipedia:S%C3%A1ch_h%C6%B0%E1%BB%9Bng_d%E1%BA%ABn)
  * [Giới thiệu Wikipedia](https://vi.wikipedia.org/wiki/Wikipedia:Gi%E1%BB%9Bi_thi%E1%BB%87u)
  * [Cộng đồng](https://vi.wikipedia.org/wiki/Wikipedia:C%E1%BB%99ng_%C4%91%E1%BB%93ng "Giới thiệu dự án, cách sử dụng và tìm kiếm thông tin ở đây")
  * [Thảo luận chung](https://vi.wikipedia.org/wiki/Wikipedia:Th%E1%BA%A3o_lu%E1%BA%ADn)
  * [Giúp sử dụng](https://vi.wikipedia.org/wiki/Wikipedia:Gi%C3%BAp_s%E1%BB%AD_d%E1%BB%A5ng_Wikipedia)
  * [Liên lạc](https://vi.wikipedia.org/wiki/Wikipedia:Li%C3%AAn_l%E1%BA%A1c)
  * [Tải lên tập tin](https://vi.wikipedia.org/wiki/Wikipedia:Tr%C3%ACnh_t%E1%BA%A3i_l%C3%AAn_t%E1%BA%ADp_tin)


[ ![](https://vi.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://vi.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![Bách khoa toàn thư mở](https://vi.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-vi.svg) ](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh)
[Tìm kiếm ](https://vi.wikipedia.org/wiki/%C4%90%E1%BA%B7c_bi%E1%BB%87t:T%C3%ACm_ki%E1%BA%BFm "Tìm kiếm Wikipedia \[f\]")
Tìm kiếm
Giao diện
  * [Quyên góp](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=vi.wikipedia.org&uselang=vi)
  * [Tạo tài khoản](https://vi.wikipedia.org/w/index.php?title=%C4%90%E1%BA%B7c_bi%E1%BB%87t:M%E1%BB%9F_t%C3%A0i_kho%E1%BA%A3n&returnto=Trang+Ch%C3%ADnh "Bạn được khuyến khích mở tài khoản và đăng nhập; tuy nhiên, không bắt buộc phải có tài khoản")
  * [Đăng nhập](https://vi.wikipedia.org/w/index.php?title=%C4%90%E1%BA%B7c_bi%E1%BB%87t:%C4%90%C4%83ng_nh%E1%BA%ADp&returnto=Trang+Ch%C3%ADnh "Đăng nhập sẽ có lợi hơn, tuy nhiên không bắt buộc. \[o\]")


Công cụ cá nhân
  * [Quyên góp](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=vi.wikipedia.org&uselang=vi)
  * [Tạo tài khoản](https://vi.wikipedia.org/w/index.php?title=%C4%90%E1%BA%B7c_bi%E1%BB%87t:M%E1%BB%9F_t%C3%A0i_kho%E1%BA%A3n&returnto=Trang+Ch%C3%ADnh "Bạn được khuyến khích mở tài khoản và đăng nhập; tuy nhiên, không bắt buộc phải có tài khoản")
  * [Đăng nhập](https://vi.wikipedia.org/w/index.php?title=%C4%90%E1%BA%B7c_bi%E1%BB%87t:%C4%90%C4%83ng_nh%E1%BA%ADp&returnto=Trang+Ch%C3%ADnh "Đăng nhập sẽ có lợi hơn, tuy nhiên không bắt buộc. \[o\]")


# Trang Chính
  * [Trang Chính](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Xem bài viết \[c\]")
  * [Thảo luận](https://vi.wikipedia.org/wiki/Th%E1%BA%A3o_lu%E1%BA%ADn:Trang_Ch%C3%ADnh "Thảo luận về trang này \[t\]")


Tiếng Việt
  * [Đọc](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh)
  * [Xem mã nguồn](https://vi.wikipedia.org/w/index.php?title=Trang_Ch%C3%ADnh&action=edit "Trang này được khóa. Bạn có thể xem mã nguồn. \[e\]")
  * [Xem lịch sử](https://vi.wikipedia.org/w/index.php?title=Trang_Ch%C3%ADnh&action=history "Các phiên bản cũ của trang này \[h\]")


Công cụ
Công cụ
chuyển sang thanh bên ẩn
Tác vụ 
  * [Đọc](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh)
  * [Xem mã nguồn](https://vi.wikipedia.org/w/index.php?title=Trang_Ch%C3%ADnh&action=edit)
  * [Xem lịch sử](https://vi.wikipedia.org/w/index.php?title=Trang_Ch%C3%ADnh&action=history)


Chung 
  * [Các liên kết đến đây](https://vi.wikipedia.org/wiki/%C4%90%E1%BA%B7c_bi%E1%BB%87t:Li%C3%AAn_k%E1%BA%BFt_%C4%91%E1%BA%BFn_%C4%91%C3%A2y/Trang_Ch%C3%ADnh "Các trang liên kết đến đây \[j\]")
  * [Thay đổi liên quan](https://vi.wikipedia.org/wiki/%C4%90%E1%BA%B7c_bi%E1%BB%87t:Thay_%C4%91%E1%BB%95i_li%C3%AAn_quan/Trang_Ch%C3%ADnh "Thay đổi gần đây của các trang liên kết đến đây \[k\]")
  * [Liên kết thường trực](https://vi.wikipedia.org/w/index.php?title=Trang_Ch%C3%ADnh&oldid=71381665 "Liên kết thường trực đến phiên bản này của trang")
  * [Thông tin trang](https://vi.wikipedia.org/w/index.php?title=Trang_Ch%C3%ADnh&action=info "Thêm chi tiết về trang này")
  * [Trích dẫn trang này](https://vi.wikipedia.org/w/index.php?title=%C4%90%E1%BA%B7c_bi%E1%BB%87t:Tr%C3%ADch_d%E1%BA%ABn&page=Trang_Ch%C3%ADnh&id=71381665&wpFormIdentifier=titleform "Hướng dẫn cách trích dẫn trang này")
  * [Tạo URL rút gọn](https://vi.wikipedia.org/w/index.php?title=%C4%90%E1%BA%B7c_bi%E1%BB%87t:UrlShortener&url=https%3A%2F%2Fvi.wikipedia.org%2Fwiki%2FTrang_Ch%25C3%25ADnh)
  * [Tải mã QR](https://vi.wikipedia.org/w/index.php?title=%C4%90%E1%BA%B7c_bi%E1%BB%87t:QrCode&url=https%3A%2F%2Fvi.wikipedia.org%2Fwiki%2FTrang_Ch%25C3%25ADnh)


In và xuất 
  * [Tạo một quyển sách](https://vi.wikipedia.org/w/index.php?title=%C4%90%E1%BA%B7c_bi%E1%BB%87t:S%C3%A1ch&bookcmd=book_creator&referer=Trang+Ch%C3%ADnh)
  * [Tải dưới dạng PDF](https://vi.wikipedia.org/w/index.php?title=%C4%90%E1%BA%B7c_bi%E1%BB%87t:DownloadAsPdf&page=Trang_Ch%C3%ADnh&action=show-download-screen)
  * [Bản để in ra](https://vi.wikipedia.org/w/index.php?title=Trang_Ch%C3%ADnh&printable=yes "Bản để in ra của trang \[p\]")


Tại dự án khác 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Wikisource đa ngôn ngữ](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikibooks](https://vi.wikibooks.org/wiki/Trang_Ch%C3%ADnh)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikiquote](https://vi.wikiquote.org/wiki/Trang_Ch%C3%ADnh)
  * [Wikisource](https://vi.wikisource.org/wiki/Trang_Ch%C3%ADnh)
  * [Wikivoyage](https://vi.wikivoyage.org/wiki/Trang_Ch%C3%ADnh)
  * [Wiktionary](https://vi.wiktionary.org/wiki/Wiktionary:Trang_Ch%C3%ADnh)
  * [Khoản mục Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Liên kết đến khoản mục kết nối trong kho dữ liệu \[g\]")


Giao diện
chuyển sang thanh bên ẩn
Bách khoa toàn thư mở Wikipedia
#  Wikipedia tiếng Việt
Bạn chính là tác giả của Wikipedia
**[1.296.348](https://vi.wikipedia.org/wiki/%C4%90%E1%BA%B7c_bi%E1%BB%87t:Th%E1%BB%91ng_k%C3%AA "Đặc biệt:Thống kê")** bài viết và **[1.007.525](https://vi.wikipedia.org/wiki/Wikipedia:T%E1%BA%A1i_sao_n%C3%AAn_t%E1%BA%A1o_m%E1%BB%99t_t%C3%A0i_kho%E1%BA%A3n%3F "Wikipedia:Tại sao nên tạo một tài khoản?")** thành viên
  * [Tạo bài](https://vi.wikipedia.org/wiki/Wikipedia:Thu%E1%BA%ADt_s%C4%A9_b%C3%A0i_vi%E1%BA%BFt "Wikipedia:Thuật sĩ bài viết")
  * [Sửa bài](https://vi.wikipedia.org/wiki/Tr%E1%BB%A3_gi%C3%BAp:S%E1%BB%ADa_%C4%91%E1%BB%95i "Trợ giúp:Sửa đổi")
  * [Tải hình](https://vi.wikipedia.org/wiki/Tr%E1%BB%A3_gi%C3%BAp:T%E1%BA%A3i_t%E1%BA%ADp_tin_l%C3%AAn "Trợ giúp:Tải tập tin lên")
  * [Quy tắc](https://vi.wikipedia.org/wiki/Wikipedia:B%E1%BB%99_quy_t%E1%BA%AFc_gi%E1%BA%A3n_l%C6%B0%E1%BB%A3c "Wikipedia:Bộ quy tắc giản lược")
  * [Đặt câu hỏi](https://vi.wikipedia.org/wiki/Wikipedia:C%C3%A2u_h%E1%BB%8Fi "Wikipedia:Câu hỏi")


**Bài viết:**
  * [Tra cứu](https://vi.wikipedia.org/wiki/%C4%90%E1%BA%B7c_bi%E1%BB%87t:M%E1%BB%8Di_b%C3%A0i/A "Đặc biệt:Mọi bài/A")
  * [Bài mới](https://vi.wikipedia.org/wiki/%C4%90%E1%BA%B7c_bi%E1%BB%87t:Trang_m%E1%BB%9Bi "Đặc biệt:Trang mới")
  * [Hỏi đáp](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A0n_tham_kh%E1%BA%A3o "Wikipedia:Bàn tham khảo")
  * [Thỉnh cầu](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A0i_th%E1%BB%89nh_c%E1%BA%A7u "Wikipedia:Bài thỉnh cầu")
  * [Thư viện](https://vi.wikipedia.org/wiki/Wikipedia:Th%C6%B0_vi%E1%BB%87n_Wikipedia "Wikipedia:Thư viện Wikipedia")


**Trợ giúp:**
  * [FAQ](https://vi.wikipedia.org/wiki/Wikipedia:C%C3%A2u_h%E1%BB%8Fi_th%C6%B0%E1%BB%9Dng_g%E1%BA%B7p "Wikipedia:Câu hỏi thường gặp")
  * [Giúp đỡ](https://vi.wikipedia.org/wiki/Wikipedia:Gi%C3%BAp_s%E1%BB%AD_d%E1%BB%A5ng_Wikipedia "Wikipedia:Giúp sử dụng Wikipedia")
  * [Hướng dẫn](https://vi.wikipedia.org/wiki/Wikipedia:S%C3%A1ch_h%C6%B0%E1%BB%9Bng_d%E1%BA%ABn "Wikipedia:Sách hướng dẫn")
  * [Chỗ thử](https://vi.wikipedia.org/wiki/Tr%E1%BB%A3_gi%C3%BAp:Ch%E1%BB%97_th%E1%BB%AD "Trợ giúp:Chỗ thử")
  * [Guestbook](https://vi.wikipedia.org/wiki/Wikipedia:Guestbook_for_non-Vietnamese_speakers "Wikipedia:Guestbook for non-Vietnamese speakers")


## [Bài viết chọn lọc](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A0i_vi%E1%BA%BFt_ch%E1%BB%8Dn_l%E1%BB%8Dc "Wikipedia:Bài viết chọn lọc")
[![Eminem và Rihanna biểu diễn "Love the Way You Lie" tại E3 2010](https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Eminem_and_Rihanna_in_Love_the_Way_You_Lie1.jpg/330px-Eminem_and_Rihanna_in_Love_the_Way_You_Lie1.jpg)](https://vi.wikipedia.org/wiki/T%E1%BA%ADp_tin:Eminem_and_Rihanna_in_Love_the_Way_You_Lie1.jpg "Eminem và Rihanna biểu diễn "Love the Way You Lie" tại E3 2010")
"**[Love the Way You Lie](https://vi.wikipedia.org/wiki/Love_the_Way_You_Lie "Love the Way You Lie")** " là một bài hát của nam [rapper](https://vi.wikipedia.org/wiki/Rap "Rap") người Mỹ [Eminem](https://vi.wikipedia.org/wiki/Eminem "Eminem") hợp tác cùng với nữ ca sĩ người Barbados [Rihanna](https://vi.wikipedia.org/wiki/Rihanna "Rihanna") nằm trong album phòng thu thứ bảy _Recovery_ (2010) của Eminem. Ca-nhạc sĩ [Skylar Grey](https://vi.wikipedia.org/wiki/Skylar_Grey "Skylar Grey") đã sáng tác và [thu thử](https://vi.wikipedia.org/wiki/Demo_\(nh%E1%BA%A1c\) "Demo \(nhạc\)") bài hát cùng nhà sản xuất [Alex da Kid](https://vi.wikipedia.org/wiki/Alex_da_Kid "Alex da Kid") nhờ cảm hứng từ bản thân có mối quan hệ lãng mạn đầy thô thiển với [ngành công nghiệp âm nhạc](https://vi.wikipedia.org/wiki/Ng%C3%A0nh_c%C3%B4ng_nghi%E1%BB%87p_%C3%A2m_nh%E1%BA%A1c "Ngành công nghiệp âm nhạc"). Eminem đã viết các phân khúc và lựa chọn Rihanna hát phần điệp khúc. Hai người đã có màn hợp tác ăn ý với nhau nhờ vào chuyện tình đầy trắc trở trong quá khứ của họ. "Love the Way You Lie" được thu âm vào các buổi làm việc tại Ferndale, Michigan và Dublin, Ireland. Đây là một bản nhạc hip hop [ballad](https://vi.wikipedia.org/wiki/Ballad "Ballad") [tiết tấu vừa phải](https://vi.wikipedia.org/wiki/Nh%E1%BB%8Bp_%C4%91%E1%BB%99 "Nhịp độ") đan xen với [pop](https://vi.wikipedia.org/wiki/Nh%E1%BA%A1c_pop "Nhạc pop"), được phối khí bằng các nhạc cụ guitar, dương cầm và vĩ cầm. [ **[Đọc tiếp](https://vi.wikipedia.org/wiki/Love_the_Way_You_Lie "Love the Way You Lie")** ]
Mới chọn: _[Rewrite](https://vi.wikipedia.org/wiki/Rewrite "Rewrite")_ **·** [Robert Pattinson](https://vi.wikipedia.org/wiki/Robert_Pattinson "Robert Pattinson") **·** [Lịch sử Công giáo Việt Nam (1975–1990)](https://vi.wikipedia.org/wiki/L%E1%BB%8Bch_s%E1%BB%AD_C%C3%B4ng_gi%C3%A1o_Vi%E1%BB%87t_Nam_\(1975%E2%80%931990\) "Lịch sử Công giáo Việt Nam \(1975–1990\)")
  * [Lưu trữ](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A0i_vi%E1%BA%BFt_ch%E1%BB%8Dn_l%E1%BB%8Dc/2025 "Wikipedia:Bài viết chọn lọc/2025")
  * [Thêm bài viết chọn lọc](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A0i_vi%E1%BA%BFt_ch%E1%BB%8Dn_l%E1%BB%8Dc "Wikipedia:Bài viết chọn lọc")
  * [Ứng cử viên](https://vi.wikipedia.org/wiki/Wikipedia:%E1%BB%A8ng_c%E1%BB%AD_vi%C3%AAn_b%C3%A0i_vi%E1%BA%BFt_ch%E1%BB%8Dn_l%E1%BB%8Dc "Wikipedia:Ứng cử viên bài viết chọn lọc")


## [Bài viết tốt](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A0i_vi%E1%BA%BFt_t%E1%BB%91t "Wikipedia:Bài viết tốt")
**[Kurosaki Ichigo](https://vi.wikipedia.org/wiki/Kurosaki_Ichigo "Kurosaki Ichigo")** là một nhân vật hư cấu trong loạt [manga](https://vi.wikipedia.org/wiki/Manga "Manga") _[Bleach](https://vi.wikipedia.org/wiki/Bleach "Bleach")_ và các tác phẩm chuyển thể từ bộ truyện này do [Kubo Taito](https://vi.wikipedia.org/wiki/Kubo_Taito "Kubo Taito") tạo ra. Cậu là nhân vật chính của bộ truyện và nhận được sức mạnh của [Shinigami](https://vi.wikipedia.org/wiki/Danh_s%C3%A1ch_nh%C3%A2n_v%E1%BA%ADt_trong_Bleach#Shinigami "Danh sách nhân vật trong Bleach") sau khi gặp gỡ [Kuchiki Rukia](https://vi.wikipedia.org/wiki/Kuchiki_Rukia "Kuchiki Rukia"), một Shinigami được giao nhiệm vụ tuần tra Thị trấn hư cấu Karakura. Tác dụng phụ là Rukia bị mất hết sức mạnh, nhờ đó Ichigo thay thế cô nhận nhiệm vụ chiến đấu với những linh hồn ma quỷ (được gọi là [Hollow](https://vi.wikipedia.org/wiki/Danh_s%C3%A1ch_nh%C3%A2n_v%E1%BA%ADt_trong_Bleach#Hollow "Danh sách nhân vật trong Bleach")) và đưa những linh hồn hoàn toàn chưa bị vấy bẩn tới một chiều không gian gọi là [Linh Giới](https://vi.wikipedia.org/wiki/Danh_s%C3%A1ch_Shinigami_c%E1%BB%A7a_Bleach "Danh sách Shinigami của Bleach") (Soul Society). Ichigo xuất hiện trong nhiều phương tiện truyền thông sau khi bộ manga ra mắt, kể cả bộ anime truyền hình, bốn bộ anime điện ảnh, hai bộ [OVA](https://vi.wikipedia.org/wiki/OVA "OVA"), nhạc kịch rock, một số [trò chơi video](https://vi.wikipedia.org/wiki/Tr%C3%B2_ch%C6%A1i_video "Trò chơi video"), [light novel](https://vi.wikipedia.org/wiki/Light_novel "Light novel") và phần phim điện ảnh người đóng (2018). [ **[Đọc tiếp](https://vi.wikipedia.org/wiki/Kurosaki_Ichigo "Kurosaki Ichigo")** ]
Mới chọn: [VinFast President](https://vi.wikipedia.org/wiki/VinFast_President "VinFast President") **·** _[Stay Up Late](https://vi.wikipedia.org/wiki/Stay_Up_Late "Stay Up Late")_ **·** [We choose to go to the Moon](https://vi.wikipedia.org/wiki/We_choose_to_go_to_the_Moon "We choose to go to the Moon")
  * [Lưu trữ](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A0i_vi%E1%BA%BFt_t%E1%BB%91t/2025 "Wikipedia:Bài viết tốt/2025")
  * [Thêm bài viết tốt](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A0i_vi%E1%BA%BFt_t%E1%BB%91t "Wikipedia:Bài viết tốt")
  * [Ứng cử viên](https://vi.wikipedia.org/wiki/Wikipedia:%E1%BB%A8ng_c%E1%BB%AD_vi%C3%AAn_b%C3%A0i_vi%E1%BA%BFt_t%E1%BB%91t "Wikipedia:Ứng cử viên bài viết tốt")


## [Danh sách chọn lọc](https://vi.wikipedia.org/wiki/Wikipedia:Danh_s%C3%A1ch_ch%E1%BB%8Dn_l%E1%BB%8Dc "Wikipedia:Danh sách chọn lọc")
[![Thành viên chính thức của ASEAN \(màu xanh dương đậm\)](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/ASEAN_member_states.svg/330px-ASEAN_member_states.svg.png)](https://vi.wikipedia.org/wiki/T%E1%BA%ADp_tin:ASEAN_member_states.svg "Thành viên chính thức của ASEAN \(màu xanh dương đậm\)")
**[Hiệp hội các quốc gia Đông Nam Á](https://vi.wikipedia.org/wiki/Danh_s%C3%A1ch_qu%E1%BB%91c_gia_th%C3%A0nh_vi%C3%AAn_ASEAN "Danh sách quốc gia thành viên ASEAN")** (ASEAN) là tổ chức liên kết của khu vực [Đông Nam Á](https://vi.wikipedia.org/wiki/%C4%90%C3%B4ng_Nam_%C3%81 "Đông Nam Á"), được tạo dựng với mục tiêu thúc đẩy tăng trưởng kinh tế, ủng hộ hòa bình khu vực, và phát triển văn hóa giữa các thành viên. ASEAN được thành lập vào ngày 8 tháng 8 năm 1967 với năm quốc gia thành viên đầu tiên là: [Thái Lan](https://vi.wikipedia.org/wiki/Th%C3%A1i_Lan "Thái Lan"), [Indonesia](https://vi.wikipedia.org/wiki/Indonesia "Indonesia"), [Malaysia](https://vi.wikipedia.org/wiki/Malaysia "Malaysia"), [Philippines](https://vi.wikipedia.org/wiki/Philippines "Philippines") và [Singapore](https://vi.wikipedia.org/wiki/Singapore "Singapore"). Hiện tại, tổ chức này đã kết nạp hầu hết các quốc gia Đông Nam Á làm thành viên. Hai quốc gia bày tỏ ý muốn gia nhập ASEAN là [Papua New Guinea](https://vi.wikipedia.org/wiki/Papua_New_Guinea "Papua New Guinea") và [Đông Timor](https://vi.wikipedia.org/wiki/%C4%90%C3%B4ng_Timor "Đông Timor") hiện đang giữ vai trò quan sát viên. Trong tuyên bố ngày 11 tháng 11 năm 2022, ASEAN đã nhất trí về nguyên tắc để kết nạp Đông Timor vào ASEAN và trở thành thành viên thứ 11 của khối. [ **[Đọc tiếp](https://vi.wikipedia.org/wiki/Danh_s%C3%A1ch_qu%E1%BB%91c_gia_th%C3%A0nh_vi%C3%AAn_ASEAN "Danh sách quốc gia thành viên ASEAN")** ]
Mới chọn: [Danh sách loài họ Chồn hôi](https://vi.wikipedia.org/wiki/Danh_s%C3%A1ch_lo%C3%A0i_h%E1%BB%8D_Ch%E1%BB%93n_h%C3%B4i "Danh sách loài họ Chồn hôi") **·** [Danh sách cầu tại Paris](https://vi.wikipedia.org/wiki/Danh_s%C3%A1ch_c%E1%BA%A7u_t%E1%BA%A1i_Paris "Danh sách cầu tại Paris") **·** [Danh sách loài họ Chó](https://vi.wikipedia.org/wiki/Danh_s%C3%A1ch_lo%C3%A0i_h%E1%BB%8D_Ch%C3%B3 "Danh sách loài họ Chó")
  * [Lưu trữ](https://vi.wikipedia.org/wiki/Wikipedia:Danh_s%C3%A1ch_ch%E1%BB%8Dn_l%E1%BB%8Dc/2025 "Wikipedia:Danh sách chọn lọc/2025")
  * [Thêm danh sách chọn lọc](https://vi.wikipedia.org/wiki/Wikipedia:Danh_s%C3%A1ch_ch%E1%BB%8Dn_l%E1%BB%8Dc "Wikipedia:Danh sách chọn lọc")
  * [Ứng cử viên](https://vi.wikipedia.org/wiki/Wikipedia:%E1%BB%A8ng_c%E1%BB%AD_vi%C3%AAn_danh_s%C3%A1ch_ch%E1%BB%8Dn_l%E1%BB%8Dc "Wikipedia:Ứng cử viên danh sách chọn lọc")


## [Hình ảnh chọn lọc](https://vi.wikipedia.org/wiki/Wikipedia:H%C3%ACnh_%E1%BA%A3nh_ch%E1%BB%8Dn_l%E1%BB%8Dc "Wikipedia:Hình ảnh chọn lọc")
[![Đền thờ Athena ở Paestum, Ý, được xây dựng vào khoảng năm 500 TCN. Đây là ngôi đền Hy Lạp cổ đầu tiên kết hợp hai phong cách kiến trúc: Doric \(cột thanh mảnh, diềm mái trang trí\) và Ionic \(hàng cột với đầu cột chạm khắc tinh xảo\). Ảnh: Diego Delso](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Paestum%2C_Italia%2C_2023-03-26%2C_DD_66-68_HDR.jpg/960px-Paestum%2C_Italia%2C_2023-03-26%2C_DD_66-68_HDR.jpg)](https://vi.wikipedia.org/wiki/T%E1%BA%ADp_tin:Paestum,_Italia,_2023-03-26,_DD_66-68_HDR.jpg "Đền thờ Athena ở Paestum, Ý, được xây dựng vào khoảng năm 500 TCN. Đây là ngôi đền Hy Lạp cổ đầu tiên kết hợp hai phong cách kiến trúc: Doric \(cột thanh mảnh, diềm mái trang trí\) và Ionic \(hàng cột với đầu cột chạm khắc tinh xảo\). Ảnh: Diego Delso")
Đền thờ Athena ở [Paestum](https://vi.wikipedia.org/wiki/Paestum "Paestum"), [Ý](https://vi.wikipedia.org/wiki/%C3%9D "Ý"), được xây dựng vào khoảng năm 500 TCN. Đây là ngôi đền [Hy Lạp cổ](https://vi.wikipedia.org/wiki/Hy_L%E1%BA%A1p_c%E1%BB%95 "Hy Lạp cổ") đầu tiên kết hợp hai phong cách kiến trúc: Doric (cột thanh mảnh, diềm mái trang trí) và Ionic (hàng cột với đầu cột chạm khắc tinh xảo).  
Ảnh: Diego Delso
  * [Lưu trữ](https://vi.wikipedia.org/wiki/Wikipedia:H%C3%ACnh_%E1%BA%A3nh_ch%E1%BB%8Dn_l%E1%BB%8Dc/2025/10 "Wikipedia:Hình ảnh chọn lọc/2025/10")
  * [Thêm hình ảnh chọn lọc](https://vi.wikipedia.org/wiki/Wikipedia:H%C3%ACnh_%E1%BA%A3nh_ch%E1%BB%8Dn_l%E1%BB%8Dc "Wikipedia:Hình ảnh chọn lọc")
  * [Cập nhật](https://vi.wikipedia.org/wiki/Wikipedia:H%C3%ACnh_%E1%BA%A3nh_ch%E1%BB%8Dn_l%E1%BB%8Dc/C%E1%BA%ADp_nh%E1%BA%ADt "Wikipedia:Hình ảnh chọn lọc/Cập nhật")


## [Bạn có biết](https://vi.wikipedia.org/wiki/Wikipedia:B%E1%BA%A1n_c%C3%B3_bi%E1%BA%BFt "Wikipedia:Bạn có biết")
[![Thực hành thiền tại Thái Lan](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/POP_House_Meditaiton_Center_Thailand%2C_Khlong_Luang_%2C_Thailand_%28Unsplash%29.jpg/330px-POP_House_Meditaiton_Center_Thailand%2C_Khlong_Luang_%2C_Thailand_%28Unsplash%29.jpg)](https://vi.wikipedia.org/wiki/T%E1%BA%ADp_tin:POP_House_Meditaiton_Center_Thailand,_Khlong_Luang_,_Thailand_\(Unsplash\).jpg "Thực hành thiền tại Thái Lan")
  * …bằng cách làm tê liệt [cảm xúc](https://vi.wikipedia.org/wiki/C%E1%BA%A3m_x%C3%BAc "Cảm xúc"), **[thiền](https://vi.wikipedia.org/wiki/T%C3%A1c_d%E1%BB%A5ng_c%E1%BB%A7a_thi%E1%BB%81n_%C4%91%E1%BB%8Bnh "Tác dụng của thiền định")** có thể khiến người thực hành trở nên bình thản nhưng vô cảm?
  * … _**[Tôi là ngôi sao](https://vi.wikipedia.org/wiki/T%C3%B4i_l%C3%A0_ng%C3%B4i_sao "Tôi là ngôi sao")**_ là tác phẩm đầu tiên trong lịch sử phim ảnh Việt Nam xảy ra kiện tụng giữa đạo diễn, [diễn viên](https://vi.wikipedia.org/wiki/Thanh_H%E1%BA%B1ng "Thanh Hằng") và [nhà sản xuất](https://vi.wikipedia.org/wiki/HKFilm "HKFilm") trong cùng một đoàn phim?
  * …**[Nguyễn Kim Thản](https://vi.wikipedia.org/wiki/Nguy%E1%BB%85n_Kim_Th%E1%BA%A3n "Nguyễn Kim Thản")** là người duy nhất làm Tổng biên tập đầu tiên cho hai tạp chí cùng chuyên ngành?
  * …tên gọi của **[chùa Chrôi Tưm Chắs](https://vi.wikipedia.org/wiki/Ch%C3%B9a_Chr%C3%B4i_T%C6%B0m_Ch%E1%BA%AFs "Chùa Chrôi Tưm Chắs")** bắt nguồn từ [tiếng Khmer](https://vi.wikipedia.org/wiki/Ti%E1%BA%BFng_Khmer "Tiếng Khmer"), nghĩa là "song song," do vị trí ngôi chùa trước kia nằm trên hai giồng đất cát chạy song song?
  * …**[Ngô Điền](https://vi.wikipedia.org/wiki/Ng%C3%B4_%C4%90i%E1%BB%81n "Ngô Điền")** là [nhà ngoại giao Việt Nam](https://vi.wikipedia.org/wiki/Quan_h%E1%BB%87_ngo%E1%BA%A1i_giao_c%E1%BB%A7a_Vi%E1%BB%87t_Nam "Quan hệ ngoại giao của Việt Nam") có thời gian công tác tại [Campuchia](https://vi.wikipedia.org/wiki/Quan_h%E1%BB%87_Campuchia_%E2%80%93_Vi%E1%BB%87t_Nam "Quan hệ Campuchia – Việt Nam") lâu nhất, trong đó có 12 năm làm [đại sứ](https://vi.wikipedia.org/wiki/%C4%90%E1%BA%A1i_s%E1%BB%A9 "Đại sứ")?


_Từ những[bài viết mới](https://vi.wikipedia.org/wiki/%C4%90%E1%BA%B7c_bi%E1%BB%87t:Trang_m%E1%BB%9Bi "Đặc biệt:Trang mới") của Wikipedia_
  * [Lưu trữ](https://vi.wikipedia.org/wiki/Wikipedia:B%E1%BA%A1n_c%C3%B3_bi%E1%BA%BFt/2025 "Wikipedia:Bạn có biết/2025")
  * [Bắt đầu viết bài mới](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A0i_vi%E1%BA%BFt_%C4%91%E1%BA%A7u_ti%C3%AAn_c%E1%BB%A7a_b%E1%BA%A1n "Wikipedia:Bài viết đầu tiên của bạn")
  * [Cập nhật](https://vi.wikipedia.org/wiki/Th%E1%BA%A3o_lu%E1%BA%ADn_Wikipedia:B%E1%BA%A1n_c%C3%B3_bi%E1%BA%BFt/2025/Tu%E1%BA%A7n_41 "Thảo luận Wikipedia:Bạn có biết/2025/Tuần 41")


## [Ngày này năm xưa](https://vi.wikipedia.org/wiki/Wikipedia:Ng%C3%A0y_n%C3%A0y_n%C4%83m_x%C6%B0a "Wikipedia:Ngày này năm xưa")
[![Tuyến đường sắt xuyên Đông Dương](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Headed_south_to_Hanoi.jpg/500px-Headed_south_to_Hanoi.jpg)](https://vi.wikipedia.org/wiki/T%E1%BA%ADp_tin:Headed_south_to_Hanoi.jpg "Tuyến đường sắt xuyên Đông Dương")
**[2 tháng 10](https://vi.wikipedia.org/wiki/2_th%C3%A1ng_10 "2 tháng 10")** : **[Ngày quốc tế bất bạo động](https://vi.wikipedia.org/wiki/Ng%C3%A0y_qu%E1%BB%91c_t%E1%BA%BF_b%E1%BA%A5t_b%E1%BA%A1o_%C4%91%E1%BB%99ng "Ngày quốc tế bất bạo động")** ; Sinh nhật [Gandhi](https://vi.wikipedia.org/wiki/Mahatma_Gandhi "Mahatma Gandhi") (_Gandhi Jayanti_) tại Ấn Độ. 
  * [945](https://vi.wikipedia.org/wiki/945 "945") – Quân [Nam Đường](https://vi.wikipedia.org/wiki/Nam_%C4%90%C6%B0%E1%BB%9Dng "Nam Đường") chiếm được kinh thành Kiến châu của [Mân](https://vi.wikipedia.org/wiki/M%C3%A2n_\(Th%E1%BA%ADp_qu%E1%BB%91c\) "Mân \(Thập quốc\)"), Hoàng đế Mân **[Vương Diên Chính](https://vi.wikipedia.org/wiki/V%C6%B0%C6%A1ng_Di%C3%AAn_Ch%C3%ADnh "Vương Diên Chính")** đầu hàng.
  * [1535](https://vi.wikipedia.org/wiki/1535 "1535") – Nhà thám hiểm người Pháp [Jacques Cartier](https://vi.wikipedia.org/wiki/Jacques_Cartier "Jacques Cartier") đi ngược dòng [sông Saint-Laurent](https://vi.wikipedia.org/wiki/S%C3%B4ng_Saint_Lawrence "Sông Saint Lawrence") tới một làng của người Iroquois mà nay thuộc **[Montréal](https://vi.wikipedia.org/wiki/Montr%C3%A9al "Montréal")** , Canada.
  * [1936](https://vi.wikipedia.org/wiki/1936 "1936") – Khánh thành **[tuyến đường sắt xuyên Đông Dương](https://vi.wikipedia.org/wiki/%C4%90%C6%B0%E1%BB%9Dng_s%E1%BA%AFt_Vi%E1%BB%87t_Nam "Đường sắt Việt Nam")** _(hình)_ nối giữa [Hà Nội](https://vi.wikipedia.org/wiki/H%C3%A0_N%E1%BB%99i "Hà Nội") và [Sài Gòn](https://vi.wikipedia.org/wiki/S%C3%A0i_G%C3%B2n "Sài Gòn"), được người Pháp xây dựng từ năm 1898.
  * [1941](https://vi.wikipedia.org/wiki/1941 "1941") – [Chiến tranh thế giới thứ hai](https://vi.wikipedia.org/wiki/Chi%E1%BA%BFn_tranh_th%E1%BA%BF_gi%E1%BB%9Bi_th%E1%BB%A9_hai "Chiến tranh thế giới thứ hai"): Quân đội [Đức](https://vi.wikipedia.org/wiki/%C4%90%E1%BB%A9c_Qu%E1%BB%91c_X%C3%A3 "Đức Quốc Xã") bắt đầu tiến hành một cuộc **[tiến công tổng lực](https://vi.wikipedia.org/wiki/Tr%E1%BA%ADn_Moskva_\(1941\) "Trận Moskva \(1941\)")** nhằm vào thủ đô [Moskva](https://vi.wikipedia.org/wiki/Moskva "Moskva") của [Liên Xô](https://vi.wikipedia.org/wiki/Li%C3%AAn_X%C3%B4 "Liên Xô").
  * [2018](https://vi.wikipedia.org/wiki/2018 "2018") – Nhà báo **[Jamal Khashoggi](https://vi.wikipedia.org/wiki/Jamal_Khashoggi "Jamal Khashoggi")** của _[The Washington Post](https://vi.wikipedia.org/wiki/The_Washington_Post "The Washington Post")_ bị ám sát trong Lãnh sự quán Ả Rập Xê Út tại [Istanbul](https://vi.wikipedia.org/wiki/Istanbul "Istanbul"), Thổ Nhĩ Kỳ.


  * [Lưu trữ](https://vi.wikipedia.org/wiki/Wikipedia:Ng%C3%A0y_n%C3%A0y_n%C4%83m_x%C6%B0a "Wikipedia:Ngày này năm xưa")
  * [Cập nhật](https://vi.wikipedia.org/wiki/Wikipedia:Ng%C3%A0y_n%C3%A0y_n%C4%83m_x%C6%B0a/10/02 "Wikipedia:Ngày này năm xưa/10/02")
  * [Danh sách ngày kỷ niệm lịch sử](https://vi.wikipedia.org/wiki/Danh_s%C3%A1ch_ng%C3%A0y_k%E1%BB%B7_ni%E1%BB%87m_l%E1%BB%8Bch_s%E1%BB%AD "Danh sách ngày kỷ niệm lịch sử")


## [Các lĩnh vực](https://vi.wikipedia.org/wiki/Wikipedia:Ch%E1%BB%A7_%C4%91%E1%BB%81 "Wikipedia:Chủ đề")
[Khoa học tự nhiên](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Khoa_h%E1%BB%8Dc_t%E1%BB%B1_nhi%C3%AAn "Thể loại:Khoa học tự nhiên")
  * [Địa chất học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:%C4%90%E1%BB%8Ba_ch%E1%BA%A5t_h%E1%BB%8Dc "Thể loại:Địa chất học")
  * [Địa lý học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:%C4%90%E1%BB%8Ba_l%C3%BD_h%E1%BB%8Dc "Thể loại:Địa lý học")
  * [Hóa học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:H%C3%B3a_h%E1%BB%8Dc "Thể loại:Hóa học")
  * [Khoa học máy tính](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Khoa_h%E1%BB%8Dc_m%C3%A1y_t%C3%ADnh "Thể loại:Khoa học máy tính")
  * [Logic](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Logic "Thể loại:Logic")
  * [Sinh học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Sinh_h%E1%BB%8Dc "Thể loại:Sinh học")
  * [Thiên văn học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Thi%C3%AAn_v%C4%83n_h%E1%BB%8Dc "Thể loại:Thiên văn học")
  * [Toán học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:To%C3%A1n_h%E1%BB%8Dc "Thể loại:Toán học")
  * [Vật lý học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:V%E1%BA%ADt_l%C3%BD_h%E1%BB%8Dc "Thể loại:Vật lý học")
  * [Y học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Y_h%E1%BB%8Dc "Thể loại:Y học")


[Khoa học xã hội](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Khoa_h%E1%BB%8Dc_x%C3%A3_h%E1%BB%99i "Thể loại:Khoa học xã hội")
  * [Chính trị học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Ch%C3%ADnh_tr%E1%BB%8B_h%E1%BB%8Dc "Thể loại:Chính trị học")
  * [Giáo dục](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Gi%C3%A1o_d%E1%BB%A5c "Thể loại:Giáo dục")
  * [Kinh tế học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Kinh_t%E1%BA%BF_h%E1%BB%8Dc "Thể loại:Kinh tế học")
  * [Lịch sử](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:L%E1%BB%8Bch_s%E1%BB%AD "Thể loại:Lịch sử")
  * [Luật pháp](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Lu%E1%BA%ADt_ph%C3%A1p "Thể loại:Luật pháp")
  * [Ngôn ngữ học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Ng%C3%B4n_ng%E1%BB%AF_h%E1%BB%8Dc "Thể loại:Ngôn ngữ học")
  * [Nhân chủng học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Nh%C3%A2n_ch%E1%BB%A7ng_h%E1%BB%8Dc "Thể loại:Nhân chủng học")
  * [Tâm lý học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:T%C3%A2m_l%C3%BD_h%E1%BB%8Dc "Thể loại:Tâm lý học")
  * [Thần học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Th%E1%BA%A7n_h%E1%BB%8Dc "Thể loại:Thần học")
  * [Triết học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Tri%E1%BA%BFt_h%E1%BB%8Dc "Thể loại:Triết học")
  * [Xã hội học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:X%C3%A3_h%E1%BB%99i_h%E1%BB%8Dc "Thể loại:Xã hội học")


[Kỹ thuật](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:K%E1%BB%B9_thu%E1%BA%ADt "Thể loại:Kỹ thuật")
  * [Công nghiệp](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:C%C3%B4ng_nghi%E1%BB%87p "Thể loại:Công nghiệp")
  * [Cơ học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:C%C6%A1_h%E1%BB%8Dc "Thể loại:Cơ học")
  * [Điện tử học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:%C4%90i%E1%BB%87n_t%E1%BB%AD_h%E1%BB%8Dc "Thể loại:Điện tử học")
  * [Giao thông](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Giao_th%C3%B4ng "Thể loại:Giao thông")
  * [Kiến trúc](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Ki%E1%BA%BFn_tr%C3%BAc "Thể loại:Kiến trúc")
  * [Năng lượng](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:N%C4%83ng_l%C6%B0%E1%BB%A3ng "Thể loại:Năng lượng")
  * [Người máy](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Robot "Thể loại:Robot")
  * [Nông nghiệp](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:N%C3%B4ng_nghi%E1%BB%87p "Thể loại:Nông nghiệp")
  * [Quân sự](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Qu%C3%A2n_s%E1%BB%B1 "Thể loại:Quân sự")
  * [Y tế](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Y_t%E1%BA%BF "Thể loại:Y tế")


[Văn hóa](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:V%C4%83n_h%C3%B3a "Thể loại:Văn hóa")
  * [Âm nhạc](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:%C3%82m_nh%E1%BA%A1c "Thể loại:Âm nhạc")
  * [Chính trị](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Ch%C3%ADnh_tr%E1%BB%8B "Thể loại:Chính trị")
  * [Du lịch](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Du_l%E1%BB%8Bch "Thể loại:Du lịch")
  * [Điện ảnh](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:%C4%90i%E1%BB%87n_%E1%BA%A3nh "Thể loại:Điện ảnh")
  * [Giải trí](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Gi%E1%BA%A3i_tr%C3%AD "Thể loại:Giải trí")
  * [Vũ đạo](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:V%C5%A9_%C4%91%E1%BA%A1o "Thể loại:Vũ đạo")
  * [Nghệ thuật](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Ngh%E1%BB%87_thu%E1%BA%ADt "Thể loại:Nghệ thuật")
  * [Phong tục tập quán](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Phong_t%E1%BB%A5c_t%E1%BA%ADp_qu%C3%A1n "Thể loại:Phong tục tập quán")
  * [Thần thoại](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Th%E1%BA%A7n_tho%E1%BA%A1i "Thể loại:Thần thoại")
  * [Thể thao](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Th%E1%BB%83_thao "Thể loại:Thể thao")
  * [Thời trang](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Th%E1%BB%9Di_trang "Thể loại:Thời trang")
  * [Tôn giáo](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:T%C3%B4n_gi%C3%A1o "Thể loại:Tôn giáo")
  * [Văn học](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:V%C4%83n_h%E1%BB%8Dc "Thể loại:Văn học")


  * [Danh sách cổng thông tin](https://vi.wikipedia.org/wiki/Wikipedia:Danh_s%C3%A1ch_c%E1%BB%95ng_th%C3%B4ng_tin "Wikipedia:Danh sách cổng thông tin")
  * [Dự án Wikipedia](https://vi.wikipedia.org/wiki/Wikipedia:D%E1%BB%B1_%C3%A1n "Wikipedia:Dự án")


## [Cải thiện nội dung](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Qu%E1%BA%A3n_l%C3%BD_Wikipedia "Thể loại:Quản lý Wikipedia")
[481 bài có đề mục cần mở rộng](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:B%C3%A0i_c%C3%B3_%C4%91%E1%BB%81_m%E1%BB%A5c_c%E1%BA%A7n_m%E1%BB%9F_r%E1%BB%99ng "Thể loại:Bài có đề mục cần mở rộng")
[2.357 bài cần biên tập lại](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:Trang_c%E1%BA%A7n_%C4%91%C6%B0%E1%BB%A3c_bi%C3%AAn_t%E1%BA%ADp_l%E1%BA%A1i "Thể loại:Trang cần được biên tập lại")
[9 bài chất lượng kém](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:B%C3%A0i_ch%E1%BA%A5t_l%C6%B0%E1%BB%A3ng_k%C3%A9m "Thể loại:Bài chất lượng kém")
[725 bài lỗi thời](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:B%C3%A0i_l%E1%BB%97i_th%E1%BB%9Di "Thể loại:Bài lỗi thời")
[1.103 bài dịch chất lượng kém](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:B%C3%A0i_d%E1%BB%8Bch_c%C3%B3_ch%E1%BA%A5t_l%C6%B0%E1%BB%A3ng_k%C3%A9m "Thể loại:Bài dịch có chất lượng kém")
[672 bài có nguồn không tin cậy](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:B%C3%A0i_thi%E1%BA%BFu_ngu%E1%BB%93n_tham_kh%E1%BA%A3o_%C4%91%C3%A1ng_tin_c%E1%BA%ADy "Thể loại:Bài thiếu nguồn tham khảo đáng tin cậy")
[33 bài cần hợp nhất](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:B%C3%A0i_c%E1%BA%A7n_h%E1%BB%A3p_nh%E1%BA%A5t "Thể loại:Bài cần hợp nhất")
[115 bài có nghiên cứu chưa công bố](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:B%C3%A0i_vi%E1%BA%BFt_c%C3%B3_th%E1%BB%83_ch%E1%BB%A9a_%C4%91%E1%BB%B1ng_nghi%C3%AAn_c%E1%BB%A9u_ch%C6%B0a_%C4%91%C6%B0%E1%BB%A3c_c%C3%B4ng_b%E1%BB%91 "Thể loại:Bài viết có thể chứa đựng nghiên cứu chưa được công bố")
[3.385 bài cần wiki hóa](https://vi.wikipedia.org/wiki/Th%E1%BB%83_lo%E1%BA%A1i:T%E1%BA%A5t_c%E1%BA%A3_b%C3%A0i_vi%E1%BA%BFt_c%E1%BA%A7n_%C4%91%C6%B0%E1%BB%A3c_wiki_h%C3%B3a "Thể loại:Tất cả bài viết cần được wiki hóa")
Tham gia Wikipedia
**[Wikipedia](https://vi.wikipedia.org/wiki/Wikipedia:Gi%E1%BB%9Bi_thi%E1%BB%87u "Wikipedia:Giới thiệu")** là dự án bách khoa toàn thư [mở](https://vi.wikipedia.org/wiki/Wikipedia:Quy%E1%BB%81n_t%C3%A1c_gi%E1%BA%A3 "Wikipedia:Quyền tác giả"), [đa ngôn ngữ](https://vi.wikipedia.org/wiki/Wikipedia:Phi%C3%AAn_b%E1%BA%A3n_ng%C3%B4n_ng%E1%BB%AF "Wikipedia:Phiên bản ngôn ngữ") mà [mọi người](https://vi.wikipedia.org/wiki/Wikipedia:Ai_vi%E1%BA%BFt_Wikipedia%3F "Wikipedia:Ai viết Wikipedia?") đều có thể tham gia đóng góp. Mục tiêu của Wikipedia là xây dựng một bách khoa toàn thư hoàn chỉnh, chính xác và trung lập. 
Sự phát triển của Wikipedia tiếng Việt phụ thuộc vào sự tham gia của bạn. Dù là [tạo một bài mới](https://vi.wikipedia.org/wiki/Wikipedia:B%C3%A0i_vi%E1%BA%BFt_%C4%91%E1%BA%A7u_ti%C3%AAn_c%E1%BB%A7a_b%E1%BA%A1n "Wikipedia:Bài viết đầu tiên của bạn"), [thêm nội dung](https://vi.wikipedia.org/wiki/Tr%E1%BB%A3_gi%C3%BAp:S%E1%BB%ADa_%C4%91%E1%BB%95i "Trợ giúp:Sửa đổi"), sửa lỗi chính tả hay bổ sung hình ảnh minh họa, thì bạn cũng đã góp phần xây dựng để Wikipedia tiếng Việt ngày một phát triển. 
[Tham gia](https://vi.wikipedia.org/wiki/Wikipedia:Ch%C3%A0o_m%E1%BB%ABng_ng%C6%B0%E1%BB%9Di_m%E1%BB%9Bi_%C4%91%E1%BA%BFn "Wikipedia:Chào mừng người mới đến")
  * [Quản lý Wikipedia](https://vi.wikipedia.org/wiki/Wikipedia:Qu%E1%BA%A3n_l%C3%BD_Wikipedia "Wikipedia:Quản lý Wikipedia")
  * [Liên hệ bảo quản viên](https://vi.wikipedia.org/wiki/Wikipedia:Tin_nh%E1%BA%AFn_cho_b%E1%BA%A3o_qu%E1%BA%A3n_vi%C3%AAn "Wikipedia:Tin nhắn cho bảo quản viên")


![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Notification-icon-Wikipedia-logo.svg/48px-Notification-icon-Wikipedia-logo.svg.png)
1.000.000+ bài
  * [Anh (_English_)](https://en.wikipedia.org/wiki/Main_Page "en:Main Page")
  * [Ả Rập (العربية‬)](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9 "ar:الصفحة الرئيسية")
  * [Ba Lan (_Polski_)](https://pl.wikipedia.org/wiki/Strona_g%C5%82%C3%B3wna "pl:Strona główna")
  * [Bồ Đào Nha (_Português_)](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "pt:Wikipédia:Página principal")
  * [Đức (_Deutsch_)](https://de.wikipedia.org/wiki/Hauptseite "de:Hauptseite")
  * [Hà Lan (_Nederlands_)](https://nl.wikipedia.org/wiki/Hoofdpagina "nl:Hoofdpagina")
  * [Nga (Русский)](https://ru.wikipedia.org/wiki/%D0%91%D0%B0%D0%B7%D0%BE%D0%B2%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%82%D1%8C%D1%8F "ru:Базовая статья")
  * [Nhật (日本語)](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "ja:メインページ")
  * [Pháp (_Français_)](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "fr:Wikipédia:Accueil principal")
  * [Tây Ban Nha (_Español_)](https://es.wikipedia.org/wiki/Wikipedia:Portada "es:Wikipedia:Portada")
  * [Thụy Điển (_Svenska_)](https://sv.wikipedia.org/wiki/Portal:Huvudsida "sv:Portal:Huvudsida")
  * [Trung (中文)](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "zh:Wikipedia:首页")
  * [Ukraina (Українська)](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "uk:Головна сторінка")
  * **Việt**
  * [Ý (_Italiano_)](https://it.wikipedia.org/wiki/Pagina_principale "it:Pagina principale")


250.000+ bài
  * [Ba Tư (فارسی)](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%E2%80%8C%DB%8C_%D8%A7%D8%B5%D9%84%DB%8C "fa:صفحه‌ی اصلی")
  * [Basque (_Euskara_)](https://eu.wikipedia.org/wiki/Azala "eu:Azala")
  * [Bulgaria (Български)](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "bg:Начална страница")
  * [Catalunya (_Català_)](https://ca.wikipedia.org/wiki/Portada "ca:Portada")
  * [Đan Mạch (_Dansk_)](https://da.wikipedia.org/wiki/Forside "da:Forside")
  * [Hàn (한국어)](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "ko:위키백과:대문")
  * [Hebrew (עברית)](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "he:עמוד ראשי")
  * [Hungary (_Magyar_)](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "hu:Kezdőlap")
  * [Indonesia (_Bahasa Indonesia_)](https://id.wikipedia.org/wiki/Halaman_Utama "id:Halaman Utama")
  * [Malaysia (_Bahasa Melayu_)](https://ms.wikipedia.org/wiki/Laman_Utama "ms:Laman Utama")
  * [Mân Nam (_Bân-lâm-gú_)](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "zh-min-nan:Thâu-ia̍h")
  * [Na Uy (_Bokmål_)](https://no.wikipedia.org/wiki/Hovedside "no:Hovedside")
  * [Phần Lan (_Suomi_)](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "fi:Wikipedia:Etusivu")
  * [Quốc tế ngữ (_Esperanto_)](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "eo:Vikipedio:Ĉefpaĝo")
  * [România (_Română_)](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "ro:Pagina principală")
  * [Séc (_Česky_)](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "cs:Hlavní strana")
  * [Serbia (Српски)](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "sr:Главна страна")
  * [Serbia-Croatia (_Srpskohrvatski_)](https://sh.wikipedia.org/wiki/Glavna_stranica "sh:Glavna stranica")
  * [Thổ Nhĩ Kỳ (_Türkçe_)](https://tr.wikipedia.org/wiki/Ana_Sayfa "tr:Ana Sayfa")


50.000+ bài
  * [Anh đơn giản (_Simple English_)](https://simple.wikipedia.org/wiki/Main_Page "simple:Main Page")
  * [Albania (_Shqip_)](https://sq.wikipedia.org/wiki/Faqja_kryesore "sq:Faqja kryesore")
  * [Asturias (_Asturianu_)](https://ast.wikipedia.org/wiki/Portada "ast:Portada")
  * [Bosnia (_Bosanski_)](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "bs:Početna strana")
  * [Croatia (_Hrvatski_)](https://hr.wikipedia.org/wiki/Glavna_stranica "hr:Glavna stranica")
  * [Estonia (_Eesti_)](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "et:Vikipeedia:Esileht")
  * [Galicia (_Galego_)](https://gl.wikipedia.org/wiki/Portada "gl:Portada")
  * [Hy Lạp (Ελληνικά)](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "el:Πύλη:Κύρια")
  * [Latvia (_Latviešu_)](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "lv:Sākumlapa")
  * [Litva (_Lietuvių_)](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "lt:Pagrindinis puslapis")
  * [Macedonia (Македонски)](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "mk:Главна страница")
  * [Malayalam (മലയാളം)](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "ml:പ്രധാന താൾ")
  * [Na Uy (_Nynorsk_)](https://nn.wikipedia.org/wiki/Hovudside "nn:Hovudside")
  * [Slovak (_Slovenčina_)](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "sk:Hlavná stránka")
  * [Slovenia (_Slovenščina_)](https://sl.wikipedia.org/wiki/Glavna_stran "sl:Glavna stran")
  * [Thái (ไทย)](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "th:หน้าหลัก")


![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8b/Wikimedia-logo_black.svg/60px-Wikimedia-logo_black.svg.png)
##  [Wikimedia Foundation](https://wikimediafoundation.org/ "foundationsite:"), một tổ chức phi lợi nhuận cũng đồng thời điều hành nhiều [dự án](https://wikimediafoundation.org/our-work/wikimedia-projects/ "foundationsite:our-work/wikimedia-projects/") khác. Các dự án này hoặc là đa ngôn ngữ hoặc đã có phiên bản tiếng Việt.
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/Notification-icon-Wikibooks-logo.svg/48px-Notification-icon-Wikibooks-logo.svg.png)[_Wikibooks_ Tủ sách giáo khoa mở](https://vi.wikibooks.org/wiki/ "b:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Notification-icon-Wikinews-logo.svg/48px-Notification-icon-Wikinews-logo.svg.png)[_Wikinews_ Nguồn tin tức mở](https://vi.wikinews.org/wiki/ "n:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Notification-icon-Wikiquote.svg/48px-Notification-icon-Wikiquote.svg.png)[_Wikiquote_ Bộ sưu tập danh ngôn](https://vi.wikiquote.org/wiki/ "q:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Notification-icon-Wikisource-logo.svg/48px-Notification-icon-Wikisource-logo.svg.png)[_Wikisource_ Văn thư lưu trữ mở](https://vi.wikisource.org/wiki/ "s:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Notification-icon-Wiktionary-logo.svg/48px-Notification-icon-Wiktionary-logo.svg.png)[_Wiktionary_ Từ điển mở](https://vi.wiktionary.org/wiki/ "wikt:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Notification-icon-Wikivoyage-logo.svg/48px-Notification-icon-Wikivoyage-logo.svg.png)[_Wikivoyage_ Cẩm nang du lịch mở](https://vi.wikivoyage.org/wiki/ "voy:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Notification-icon-Commons-logo.svg/48px-Notification-icon-Commons-logo.svg.png)[_Commons_ Kho tư liệu chung](https://commons.wikimedia.org/wiki/Trang_Ch%C3%ADnh "c:Trang Chính")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Notification-icon-Wikispecies-logo.svg/48px-Notification-icon-Wikispecies-logo.svg.png)[_Wikispecies_ Danh mục các loài](https://species.wikimedia.org/wiki/Trang_Ch%C3%ADnh "species:Trang Chính")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Notification-icon-Wikiversity-logo.svg/48px-Notification-icon-Wikiversity-logo.svg.png)[_Wikiversity_ Học liệu mở](https://beta.wikiversity.org/wiki/Trang_Ch%C3%ADnh "betawikiversity:Trang Chính")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Notification-icon-Wikidata-logo.svg/48px-Notification-icon-Wikidata-logo.svg.png)[_Wikidata_ Cơ sở kiến thức chung](https://www.wikidata.org/wiki/Wikidata:Trang_Ch%C3%ADnh "d:Wikidata:Trang Chính")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/MediaWiki-2020-small-icon.svg/48px-MediaWiki-2020-small-icon.svg.png)[_MediaWiki_ Phần mềm wiki](https://www.mediawiki.org/wiki/Special:MyLanguage/MediaWiki "mw:Special:MyLanguage/MediaWiki")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Notification-icon-Meta-logo.svg/48px-Notification-icon-Meta-logo.svg.png)[_Meta-Wiki_ Cộng đồng Wikimedia](https://meta.wikimedia.org/wiki/Special:MyLanguage/Main_Page "m:Special:MyLanguage/Main Page")


Lấy từ “[https://vi.wikipedia.org/w/index.php?title=Trang_Chính&oldid=71381665](https://vi.wikipedia.org/w/index.php?title=Trang_Ch%C3%ADnh&oldid=71381665)”
47 ngôn ngữ
  * [العربية](https://ar.wikipedia.org/wiki/ "Tiếng Ả Rập")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "Tiếng Indonesia")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "Tiếng Mã Lai")
  * [বাংলা](https://bn.wikipedia.org/wiki/ "Tiếng Bangla")
  * [Bosanski](https://bs.wikipedia.org/wiki/ "Tiếng Bosnia")
  * [Български](https://bg.wikipedia.org/wiki/ "Tiếng Bulgaria")
  * [Català](https://ca.wikipedia.org/wiki/ "Tiếng Catalan")
  * [Čeština](https://cs.wikipedia.org/wiki/ "Tiếng Séc")
  * [Dansk](https://da.wikipedia.org/wiki/ "Tiếng Đan Mạch")
  * [Deutsch](https://de.wikipedia.org/wiki/ "Tiếng Đức")
  * [Eesti](https://et.wikipedia.org/wiki/ "Tiếng Estonia")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "Tiếng Hy Lạp")
  * [English](https://en.wikipedia.org/wiki/ "Tiếng Anh")
  * [Español](https://es.wikipedia.org/wiki/ "Tiếng Tây Ban Nha")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "Tiếng Quốc Tế Ngữ")
  * [Euskara](https://eu.wikipedia.org/wiki/ "Tiếng Basque")
  * [فارسی](https://fa.wikipedia.org/wiki/ "Tiếng Ba Tư")
  * [Français](https://fr.wikipedia.org/wiki/ "Tiếng Pháp")
  * [Galego](https://gl.wikipedia.org/wiki/ "Tiếng Galician")
  * [한국어](https://ko.wikipedia.org/wiki/ "Tiếng Hàn")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "Tiếng Croatia")
  * [Italiano](https://it.wikipedia.org/wiki/ "Tiếng Italy")
  * [עברית](https://he.wikipedia.org/wiki/ "Tiếng Do Thái")
  * [ქართული](https://ka.wikipedia.org/wiki/ "Tiếng Georgia")
  * [Latviešu](https://lv.wikipedia.org/wiki/ "Tiếng Latvia")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "Tiếng Litva")
  * [Magyar](https://hu.wikipedia.org/wiki/ "Tiếng Hungary")
  * [Македонски](https://mk.wikipedia.org/wiki/ "Tiếng Macedonia")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "Tiếng Hà Lan")
  * [日本語](https://ja.wikipedia.org/wiki/ "Tiếng Nhật")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "Tiếng Na Uy \(Bokmål\)")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "Tiếng Na Uy \(Nynorsk\)")
  * [Polski](https://pl.wikipedia.org/wiki/ "Tiếng Ba Lan")
  * [Português](https://pt.wikipedia.org/wiki/ "Tiếng Bồ Đào Nha")
  * [Română](https://ro.wikipedia.org/wiki/ "Tiếng Romania")
  * [Русский](https://ru.wikipedia.org/wiki/ "Tiếng Nga")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "Tiếng Slovak")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "Tiếng Slovenia")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "Tiếng Serbia")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "Tiếng Serbo-Croatia")
  * [Suomi](https://fi.wikipedia.org/wiki/ "Tiếng Phần Lan")
  * [Svenska](https://sv.wikipedia.org/wiki/ "Tiếng Thụy Điển")
  * [ไทย](https://th.wikipedia.org/wiki/ "Tiếng Thái")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "Tiếng Thổ Nhĩ Kỳ")
  * [Українська](https://uk.wikipedia.org/wiki/ "Tiếng Ukraina")
  * [中文](https://zh.wikipedia.org/wiki/ "Tiếng Trung")


  * Trang này được sửa đổi lần cuối vào ngày 18 tháng 5 năm 2024, 14:31.
  * Văn bản được phát hành theo [Giấy phép Creative Commons Ghi công–Chia sẻ tương tự](https://vi.wikipedia.org/wiki/Wikipedia:Nguy%C3%AAn_v%C4%83n_Gi%E1%BA%A5y_ph%C3%A9p_Creative_Commons_Ghi_c%C3%B4ng%E2%80%93Chia_s%E1%BA%BB_t%C6%B0%C6%A1ng_t%E1%BB%B1_phi%C3%AAn_b%E1%BA%A3n_4.0_Qu%E1%BB%91c_t%E1%BA%BF "Wikipedia:Nguyên văn Giấy phép Creative Commons Ghi công–Chia sẻ tương tự phiên bản 4.0 Quốc tế"); có thể áp dụng điều khoản bổ sung. Với việc sử dụng trang web này, bạn chấp nhận [Điều khoản Sử dụng](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use/vi) và [Quy định quyền riêng tư](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy/vi). Wikipedia® là thương hiệu đã đăng ký của [Wikimedia Foundation, Inc.](https://www.wikimediafoundation.org/), một tổ chức phi lợi nhuận.


  * [Chính sách quyền riêng tư](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Giới thiệu Wikipedia](https://vi.wikipedia.org/wiki/Wikipedia:Gi%E1%BB%9Bi_thi%E1%BB%87u)
  * [Lời phủ nhận](https://vi.wikipedia.org/wiki/Wikipedia:Ph%E1%BB%A7_nh%E1%BA%ADn_chung)
  * [Bộ Quy tắc Ứng xử Chung](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Lập trình viên](https://developer.wikimedia.org)
  * [Thống kê](https://stats.wikimedia.org/#/vi.wikipedia.org)
  * [Tuyên bố về cookie](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Phiên bản di động](https://vi.m.wikipedia.org/w/index.php?title=Trang_Ch%C3%ADnh&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://vi.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://vi.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Tìm kiếm
Tìm kiếm
Trang Chính
[](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh) [](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh) [](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh) [](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh) [](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh) [](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh) [](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh) [](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh)
47 ngôn ngữ [Thêm đề tài ](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh)
