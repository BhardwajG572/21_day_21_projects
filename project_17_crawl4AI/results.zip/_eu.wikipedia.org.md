[Edukira joan](https://eu.wikipedia.org/wiki/Azala#bodyContent)
Menu nagusia
Menu nagusia
mugitu alboko barrara ezkutatu
Nabigazioa 
  * [Azala](https://eu.wikipedia.org/wiki/Azala "Azala bisitatu \[alt-z\]")
  * [Txikipedia](https://eu.wikipedia.org/wiki/Txikipedia:Azala)
  * [Ikusgela](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela)
  * [Txokoa](https://eu.wikipedia.org/wiki/Wikipedia:Txokoa "Proiektuaren inguruan, zer egin dezakezu, non aurkitu nahi duzuna")
  * [Aldaketa berriak](https://eu.wikipedia.org/wiki/Berezi:AzkenAldaketak "Wikiko azken aldaketen zerrenda. \[alt-r\]")
  * [Ausazko orria](https://eu.wikipedia.org/wiki/Berezi:Ausazkoa "Ausazko orrialde bat kargatu \[alt-x\]")
  * [Laguntza](https://eu.wikipedia.org/wiki/Laguntza:Sarrera "Aurkitzeko lekua.")
  * [Orri bereziak](https://eu.wikipedia.org/wiki/Berezi:OrrialdeBereziak)


[ ![](https://eu.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://eu.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![Entziklopedia askea](https://eu.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-eu.svg) ](https://eu.wikipedia.org/wiki/Azala)
[Bilatu ](https://eu.wikipedia.org/wiki/Berezi:Bilatu "Wikipedia\(e\)n bilatu \[alt-f\]")
Bilatu
Itxura
Itxura
mugitu alboko barrara ezkutatu
Testua
  * Txikia
Arrunta
Handia

Orrialde honek letra-tamaina txikia erabiltzen du beti
Zabalera
  * Arrunta
Zabala

The content is as wide as possible for your browser window.
Kolorea (beta)
  * Automatikoa
Argia
Iluna

Orrialde hau modu argian dago beti.
  * [Dohaintza egin](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=eu.wikipedia.org&uselang=eu)
  * [Sortu kontua](https://eu.wikipedia.org/w/index.php?title=Berezi:KontuaSortu&returnto=Azala "Kontu bat sortu eta horrekin saioa hastea eskatu nahi genizuke; ez da ezinbestekoa, ordea.")
  * [Hasi saioa](https://eu.wikipedia.org/w/index.php?title=Berezi:SaioaHasi&returnto=Azala "Izen ematera gonbidatzen zaitugu. \[alt-o\]")


Tresna pertsonalak
  * [Dohaintza egin](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=eu.wikipedia.org&uselang=eu)
  * [Sortu kontua](https://eu.wikipedia.org/w/index.php?title=Berezi:KontuaSortu&returnto=Azala "Kontu bat sortu eta horrekin saioa hastea eskatu nahi genizuke; ez da ezinbestekoa, ordea.")
  * [Hasi saioa](https://eu.wikipedia.org/w/index.php?title=Berezi:SaioaHasi&returnto=Azala "Izen ematera gonbidatzen zaitugu. \[alt-o\]")


# Ongi etorri Wikipediara
353 hizkuntza
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – afarera")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – abkhaziera")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – acehnera")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – adigera")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – afrikaansa")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – Suitzako alemana")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – hegoaldeko altaiera")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – amharera")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – aragoiera")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – Old English")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – oboloera")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – angikera")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – arabiera")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – Aramaic")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – Moroccan Arabic")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – Egyptian Arabic")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – assamera")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – asturiera")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – atikamekwera")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – avarera")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – awadhiera")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – aimara")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – azerbaijanera")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – baxkirera")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – baliera")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – Bavarian")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – Samogitian")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – bielorrusiera")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – Betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница – bulgariera")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – bislama")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – bambarera")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – bengalera")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – tibetera")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – bretoiera")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – bosniera")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – buginera")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – katalana")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – txetxenera")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – cebuanoera")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – txamorroera")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – txoktawera")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – txerokiera")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – txeieneera")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – erdialdeko kurduera")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – korsikera")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – Cree")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – Crimean Tatar")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana – txekiera")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – Kashubian")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – elizako eslaviera")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – txuvaxera")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – galesa")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside – daniera")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – alemana")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – Dinka")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – behe-sorabiera")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – Central Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – dhivehia")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – dzongkha")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – eweera")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – greziera")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – ingelesa")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – esperantoa")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – gaztelania")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht – estoniera")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – Extremaduran")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – persiera")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – Fanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – fula")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – finlandiera")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – Võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – fijiera")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – faroera")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – fonera")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal – frantsesa")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – Arpitan")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – iparraldeko frisiera")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – friulera")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – mendebaldeko frisiera")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – irlandera")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – gagauzera")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – Gan")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – Eskoziako gaelikoa")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – galiziera")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – Gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – guaraniera")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – gorontaloera")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – Gothic")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – gujaratera")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – Wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – manxera")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – hausa")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – Hakka Chinese")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – hawaiiera")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – hebreera")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – hindia")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – Fiji Hindi")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – Hiri Motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – kroaziera")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – goi-sorabiera")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Haitiko kreolera")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – hungariera")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ – armeniera")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – hereroera")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – interlingua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – ibanera")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama – indonesiera")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – interlinguea")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – igboera")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – Inupiaq")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – ilocanoera")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – ingushera")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – idoa")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – islandiera")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – italiera")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – inuitera")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – japoniera")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – Jamaican Creole English")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – lojbana")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – javera")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – georgiera")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – Kara-Kalpak")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – kabiliera")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – kabardiera")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – tyapa")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – kikongoa")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – kikuyuera")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – kuanyama")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – kazakhera")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – groenlandiera")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – khemerera")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – kannada")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – koreera")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – komi-permyakera")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – kanuriera")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – karachayera-balkarera")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – kaxmirera")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – koloniera")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – kurduera")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – komiera")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – kornubiera")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – kirgizera")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima – latina")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – ladinoa")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – luxenburgera")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – lezginera")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – luganda")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – limburgera")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – liguriera")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – lombardiera")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – lingala")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – laosera")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – iparraldeko lurera")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – lituaniera")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – Latgalian")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – letoniera")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – madurera")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – maithilia")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – mokxera")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – malgaxea")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – marshallera")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – maoriera")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – minangkabauera")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – mazedoniera")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – malabarera")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – mongoliera")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – manipurera")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – mossiera")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – marathera")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – Western Mari")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – malaysiera")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – maltera")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – muscogeera")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – mirandesa")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – birmaniera")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – erziera")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – mazandarandera")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – napoliera")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – behe-alemana")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – behe-saxoiera")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – nepalera")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – newarera")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – ndonga")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – niasera")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina – nederlandera")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – nynorsk \(norvegiera\)")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – bokmål \(norvegiera\)")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – Novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – n’koera")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – hegoaldeko ndebeleera")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – pediera")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – navajoera")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – chewera")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – okzitaniera")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – oromoera")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – oriya")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – osetiera")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – punjabera")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – pangasinanera")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – pampangera")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – papiamentoa")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – Picard")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – Nigeriako pidgina")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – Pennsylvania German")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – Palatine German")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – Pali")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – poloniera")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – Piedmontese")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – Pontic")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – paxtunera")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – portugesa")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – kitxua")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – erretorromaniera")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – rundiera")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – errumaniera")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – aromaniera")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – errusiera")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – Rusyn")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – kinyaruanda")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – sanskritoa")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – sakhera")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – santalera")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – sardiniera")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – siziliera")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – eskoziera")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – sindhia")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – iparraldeko samiera")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – sangoa")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – serbokroaziera")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – tachelhita")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – shanera")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – sinhala")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – eslovakiera")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – esloveniera")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – samoera")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – Inariko samiera")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – shonera")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – somaliera")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – albaniera")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – serbiera")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – sranan tongoa")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – swatiera")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – hegoaldeko sothoera")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – Saterland Frisian")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – sundanera")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – suediera")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – swahilia")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – silesiera")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – tamilera")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – Tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – telugua")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – tetuma")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – tajikera")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – thailandiera")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – tigrinyera")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – tigreera")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – turkmenera")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – tagaloa")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – Talysh")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – tswanera")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – tongera")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – tok pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – turkiera")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – tarokoera")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – tsongera")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – tatarera")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – tumbukera")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – twia")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – tahitiera")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – tuvera")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – udmurtera")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – uigurrera")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – ukrainera")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – urdua")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – uzbekera")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – vendera")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – veneziera")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – Veps")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – vietnamera")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – West Flemish")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – volapük")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – valoniera")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – warayera")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – wolofera")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – wu txinera")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – kalmykera")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – xhosera")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – Mingrelian")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – yiddisha")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – jorubera")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – zhuangera")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – Zeelandic")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – amazigera estandarra")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 – txinera")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – Literary Chinese")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – Minnan")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – kantonera")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – zuluera")


[Aldatu loturak](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Aldatu hizkuntzen arteko loturak")
  * [Azala](https://eu.wikipedia.org/wiki/Azala "Eduki orrialdea ikusi \[alt-c\]")
  * [Eztabaida](https://eu.wikipedia.org/wiki/Eztabaida:Azala "Artikuluari buruzko eztabaida \[alt-t\]")
  * [Txikipedia](https://eu.wikipedia.org/wiki/Txikipedia:Azala "Txikipediako bertsioa ikusi \[alt-3\]")


euskara
  * [Irakurri](https://eu.wikipedia.org/wiki/Azala)
  * [Kodea ikusi](https://eu.wikipedia.org/w/index.php?title=Azala&action=edit "Artikulu hau babesturik dago. Bere kodea soilik ikus dezakezu. \[alt-e\]")
  * [Ikusi historia](https://eu.wikipedia.org/w/index.php?title=Azala&action=history "Artikulu honen aurreko bertsioak. \[alt-h\]")


Tresnak
Tresnak
mugitu alboko barrara ezkutatu
Ekintzak 
  * [Irakurri](https://eu.wikipedia.org/wiki/Azala)
  * [Kodea ikusi](https://eu.wikipedia.org/w/index.php?title=Azala&action=edit)
  * [Ikusi historia](https://eu.wikipedia.org/w/index.php?title=Azala&action=history)


Orokorra 
  * [Honanzko esteka duten orriak](https://eu.wikipedia.org/wiki/Berezi:ZerkLotzenDuHona/Azala "Orri honetaranzko esteka duten wiki orri guztien zerrenda \[alt-j\]")
  * [Lotutako orrietako aldaketak](https://eu.wikipedia.org/wiki/Berezi:RecentChangesLinked/Azala "Orri honetatik esteka duten orrietako azken aldaketak \[alt-k\]")
  * [Fitxategia igo](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=eu "Irudiak edo media fitxategiak igo \[alt-u\]")
  * [Lotura iraunkorra](https://eu.wikipedia.org/w/index.php?title=Azala&oldid=9807453 "Orriaren bertsio honetaranzko esteka iraunkorra")
  * [Orri honen datuak](https://eu.wikipedia.org/w/index.php?title=Azala&action=info "Orrialde honi buruzko informazio gehiago")
  * [Artikulu hau aipatu](https://eu.wikipedia.org/w/index.php?title=Berezi:CiteThisPage&page=Azala&id=9807453&wpFormIdentifier=titleform "Orri honen aipua egiteko moduari buruzko informazioa")
  * [URL laburra lortu](https://eu.wikipedia.org/w/index.php?title=Berezi:UrlShortener&url=https%3A%2F%2Feu.wikipedia.org%2Fwiki%2FAzala)
  * [QR kodea jaitsi](https://eu.wikipedia.org/w/index.php?title=Berezi:QrCode&url=https%3A%2F%2Feu.wikipedia.org%2Fwiki%2FAzala)
  * [Aldatu hizkuntzen arteko loturak](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Aldatu hizkuntzen arteko loturak")


Inprimatu/esportatu 
  * [Liburu bat sortu](https://eu.wikipedia.org/w/index.php?title=Berezi:Book&bookcmd=book_creator&referer=Azala)
  * [Deskargatu PDF formatuan](https://eu.wikipedia.org/w/index.php?title=Berezi:DownloadAsPdf&page=Azala&action=show-download-screen)
  * [Inprimatzeko bertsioa](https://eu.wikipedia.org/w/index.php?title=Azala&printable=yes "Orrialde honen bertsio inprimagarria \[alt-p\]")


Beste proiektuetan 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikiespezieak](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikiliburuak](https://eu.wikibooks.org/wiki/Azala)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikiesanak](https://eu.wikiquote.org/wiki/Azala)
  * [Wikiteka](https://eu.wikisource.org/wiki/Azala)
  * [Wiktionary](https://eu.wiktionary.org/wiki/Azala)
  * [Wikidata itema](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Datuen biltegi elementu batera lotuta \[alt-g\]")


Kalitate neurketa [![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/AIGA_information.svg/20px-AIGA_information.svg.png)](https://eu.wikipedia.org/wiki/Laguntza:ORES "Laguntza:ORES"): ![Zirriborro-motako artikulua](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Symbol_stub_class.svg/20px-Symbol_stub_class.svg.png) ([0.15](https://ores.wikimedia.org/v3/scores/euwiki/9807453/articlequality)) 
Wikipedia, Entziklopedia askea
[2025eko](https://eu.wikipedia.org/wiki/2025 "2025") [urriaren 2a](https://eu.wikipedia.org/wiki/Urriaren_2 "Urriaren 2") da eta **[472.811](https://eu.wikipedia.org/wiki/Berezi:Estatistikak "Berezi:Estatistikak")** artikulu ditugu [euskaraz](https://eu.wikipedia.org/wiki/Euskara "Euskara").   
**Zuk** ere **hobetu** dezakezun entziklopedia askea da hau. [Lagundu nahi duzu?](https://eu.wikipedia.org/wiki/Laguntza:Sarrera "Laguntza:Sarrera")
###  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Cscr-featured.svg/20px-Cscr-featured.svg.png)](https://eu.wikipedia.org/wiki/Fitxategi:Cscr-featured.svg) Aste honetan nabarmen ([artikulua bozkatu](https://eu.wikipedia.org/wiki/Wikipedia:Bozketak/Kalitatezko_artikuluak "Wikipedia:Bozketak/Kalitatezko artikuluak"))
[![](https://upload.wikimedia.org/wikipedia/commons/7/7f/%C3%89tienne_Polverel_-_Navarre_-_XI_%281789%29.png)](https://eu.wikipedia.org/wiki/Foruen_amaiera_Ipar_Euskal_Herrian "Foruen amaiera Ipar Euskal Herrian")
### [Foruen amaiera Ipar Euskal Herrian](https://eu.wikipedia.org/wiki/Foruen_amaiera_Ipar_Euskal_Herrian "Foruen amaiera Ipar Euskal Herrian")
**Foruen amaiera Ipar Euskal Herrian** bertako erakunde publiko eta lege sistemaren bukaera izan zen [Frantziako Iraultzaren](https://eu.wikipedia.org/wiki/Frantziako_Iraultza "Frantziako Iraultza") aldian (1789-1795). Euskal autogobernua frantses tropak Euskal Herrira heldu zirenean desegin zen eraginkorki, [Konbentzioaren Gerran](https://eu.wikipedia.org/wiki/Konbentzioaren_Gerra "Konbentzioaren Gerra") kokatuta, herritarren kontrako izua zabalduz [Lapurdin](https://eu.wikipedia.org/wiki/Lapurdi "Lapurdi"). 
#### Aurreko asteetan...
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/San_Sebastian_Kursaal_Festival.jpg/250px-San_Sebastian_Kursaal_Festival.jpg)](https://eu.wikipedia.org/wiki/Donostiako_Zinemaldia "Donostiako Zinemaldia")
### [Donostiako Zinemaldia](https://eu.wikipedia.org/wiki/Donostiako_Zinemaldia "Donostiako Zinemaldia")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Map_of_NATO_chronological.gif/250px-Map_of_NATO_chronological.gif)](https://eu.wikipedia.org/wiki/NATOren_zabalpena "NATOren zabalpena")
### [NATOren zabalpena](https://eu.wikipedia.org/wiki/NATOren_zabalpena "NATOren zabalpena")
### Komunitatea
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Circle-icons-compose.svg/250px-Circle-icons-compose.svg.png)](https://eu.wikipedia.org/wiki/Atari:Hezkuntza "Atari:Hezkuntza")
### [Hezkuntza ataria](https://eu.wikipedia.org/wiki/Atari:Hezkuntza "Atari:Hezkuntza")
Hezkuntzan aritzeko baliabideak eta proposamenak
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Wikikasi_logo_borobila.png/250px-Wikikasi_logo_borobila.png)](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Wikikasi "Atari:Hezkuntza/Wikikasi")
### [Wikikasi](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Wikikasi "Atari:Hezkuntza/Wikikasi")
Wikipedia darabilten ikas-egoerak
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Euskal_Herriko_historia_100_objektutan_-_logo_borobila.png/250px-Euskal_Herriko_historia_100_objektutan_-_logo_borobila.png)](https://eu.wikipedia.org/wiki/Atari:Ondarea/Euskal_Herriko_historia_100_objektutan "Atari:Ondarea/Euskal Herriko historia 100 objektutan")
### [Euskal Herriko historia 100 objektutan](https://eu.wikipedia.org/wiki/Atari:Ondarea/Euskal_Herriko_historia_100_objektutan "Atari:Ondarea/Euskal Herriko historia 100 objektutan")
Museoekin lantzen ari garen ekimen handia
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Circle-icons-booklet-woman.svg/250px-Circle-icons-booklet-woman.svg.png)](https://eu.wikipedia.org/wiki/Wikiproiektu:30.000_emakume "Wikiproiektu:30.000 emakume")
### [30.000 emakume](https://eu.wikipedia.org/wiki/Wikiproiektu:30.000_emakume "Wikiproiektu:30.000 emakume")
Wikipediara emakume gehiago gehitzeko baliabideak
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Circle-icons-check.svg/250px-Circle-icons-check.svg.png)](https://eu.wikipedia.org/wiki/Wikiproiektu:Wikipedia_guztiek_izan_beharreko_1.000_artikuluen_zerrenda "Wikiproiektu:Wikipedia guztiek izan beharreko 1.000 artikuluen zerrenda")
### [Oinarrizko 1.000](https://eu.wikipedia.org/wiki/Wikiproiektu:Wikipedia_guztiek_izan_beharreko_1.000_artikuluen_zerrenda "Wikiproiektu:Wikipedia guztiek izan beharreko 1.000 artikuluen zerrenda")
Wikipedia guztiek izan beharrekoak hobetzeko proiektua
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Circle-icons-support.svg/250px-Circle-icons-support.svg.png)](https://eu.wikipedia.org/wiki/Laguntza:Sarrera "Laguntza:Sarrera")
### [Laguntza](https://eu.wikipedia.org/wiki/Laguntza:Sarrera "Laguntza:Sarrera")
Wikipedian aritzeko oinarrizko laguntza
###  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Ikusgela-logoa.png/40px-Ikusgela-logoa.png)](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela "Atari:Hezkuntza/Ikusgela") [Ikusgela](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela "Atari:Hezkuntza/Ikusgela")
[](https://eu.wikipedia.org/wiki/Fitxategi:Ikusgela_-_Positibismoa.webm "Erreproduzitu bideoa")Duration: 8 minutes and 37 seconds.8:37Azpitituluak eskuragarri.CC[Filosofia](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela#Filosofia "Atari:Hezkuntza/Ikusgela")
**[Positibismoa](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela/Positibismoa "Atari:Hezkuntza/Ikusgela/Positibismoa")**
Positibismoa ulertzeko gakoak. 
[](https://eu.wikipedia.org/wiki/Fitxategi:Espezie_inbaditzaileak.webm "Erreproduzitu bideoa")
[Ingurumena](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela#Ingurumena "Atari:Hezkuntza/Ikusgela")   
**[Espezie inbaditzaileak](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela/Espezie_inbaditzaile "Atari:Hezkuntza/Ikusgela/Espezie inbaditzaile")**
[](https://eu.wikipedia.org/wiki/Fitxategi:Ikusgela-Euskal_hezkuntza.webm "Erreproduzitu bideoa")[Euskal kultura](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela#Euskal_kultura "Atari:Hezkuntza/Ikusgela")  
**[Euskal hezkuntza](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela/Euskal_hezkuntza "Atari:Hezkuntza/Ikusgela/Euskal hezkuntza")**
[](https://eu.wikipedia.org/wiki/Fitxategi:Ikusgela-Metabertsoa.webm "Erreproduzitu bideoa")
[Erronka digitalak](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela#Erronka_digitalak "Atari:Hezkuntza/Ikusgela")   
**[Metabertsoa](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela/Metabertsoa "Atari:Hezkuntza/Ikusgela/Metabertsoa")**
[](https://eu.wikipedia.org/wiki/Fitxategi:Ikusgela-Zergatik_zabaltzen_dira_metalak_berotzen_direnean%3F.webm "Erreproduzitu bideoa")[ZGDG](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela#ZGDG "Atari:Hezkuntza/Ikusgela")  
**[Zergatik zabaltzen dira metalak berotzen direnean?](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela/Zergatik_zabaltzen_dira_metalak_berotzen_direnean "Atari:Hezkuntza/Ikusgela/Zergatik zabaltzen dira metalak berotzen direnean")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Add.svg/20px-Add.svg.png)](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela "Atari:Hezkuntza/Ikusgela") [Bideo gehiago...](https://eu.wikipedia.org/wiki/Atari:Hezkuntza/Ikusgela "Atari:Hezkuntza/Ikusgela")
* * *
[2025eko](https://eu.wikipedia.org/wiki/2025 "2025") [urriaren 2a](https://eu.wikipedia.org/wiki/Urriaren_2 "Urriaren 2")
[Indarkeriarik Ezaren Nazioarteko Eguna](https://eu.wikipedia.org/wiki/Indarkeriarik_Ezaren_Nazioarteko_Eguna "Indarkeriarik Ezaren Nazioarteko Eguna")
[![Saladin I.a](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Folio_from_The_book_of_knowledge_of_ingenious_mechanical_devices_%281354_copy%29._Part_of_a_water_clock_%28detail%29.jpg/120px-Folio_from_The_book_of_knowledge_of_ingenious_mechanical_devices_%281354_copy%29._Part_of_a_water_clock_%28detail%29.jpg)](https://eu.wikipedia.org/wiki/Fitxategi:Folio_from_The_book_of_knowledge_of_ingenious_mechanical_devices_\(1354_copy\)._Part_of_a_water_clock_\(detail\).jpg "Saladin I.a")Saladin I.a
  * [1187](https://eu.wikipedia.org/wiki/1187 "1187") - [Saladin](https://eu.wikipedia.org/wiki/Saladin "Saladin") agintari musulmanak (_irudian_) [Jerusalem](https://eu.wikipedia.org/wiki/Jerusalem "Jerusalem") hartu zuen, [gurutzatuak](https://eu.wikipedia.org/wiki/Gurutzadak "Gurutzadak") 88 urtez hiriaren jabe izan ondoren.
  * [1869](https://eu.wikipedia.org/wiki/1869 "1869") - [Mahatma Gandhi](https://eu.wikipedia.org/wiki/Mahatma_Gandhi "Mahatma Gandhi") jaio zen (h. [1948](https://eu.wikipedia.org/wiki/1948 "1948")).
  * [1904](https://eu.wikipedia.org/wiki/1904 "1904") - [Graham Greene](https://eu.wikipedia.org/wiki/Graham_Greene "Graham Greene") britainiar nobelista jaio zen.
  * [1928](https://eu.wikipedia.org/wiki/1928 "1928") - [Josemaría Escrivá](https://eu.wikipedia.org/wiki/Josemar%C3%ADa_Escriv%C3%A1 "Josemaría Escrivá") aragoitarrak [Opus Dei](https://eu.wikipedia.org/wiki/Opus_Dei "Opus Dei") ordena laiko [katolikoa](https://eu.wikipedia.org/wiki/Katoliko "Katoliko") sortu zen.
  * [1958](https://eu.wikipedia.org/wiki/1958 "1958") - [Gineak](https://eu.wikipedia.org/wiki/Ginea "Ginea") independentzia lortu zuen [Frantziatik](https://eu.wikipedia.org/wiki/Frantzia "Frantzia").


### Eguneko irudia
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg/250px-Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)](https://eu.wikipedia.org/wiki/Fitxategi:Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg "Fitxategi:Goddess Bhadrakali Worshipped by the Gods- from a tantric Devi series - Google Art Project.jpg")
1660-1670 inguruko [Pahari margolan](https://commons.wikimedia.org/wiki/c:Category:Pahari_painting "c:c:Category:Pahari painting") bat [Basholin](https://commons.wikimedia.org/wiki/c:Category:Basholi "c:c:Category:Basholi"), [Indian](https://commons.wikimedia.org/wiki/eu:India "c:eu:India"), [Bhadrakali](https://commons.wikimedia.org/wiki/c:Category:Bhadrakali "c:c:Category:Bhadrakali") jainkosa irudikatzen duena, gurtzen dituelarik [Tri-murti](https://commons.wikimedia.org/wiki/eu:Tri-murti "c:eu:Tri-murti") Hinduismoaren hiru jainko nagusiak: [Brahma](https://commons.wikimedia.org/wiki/eu:Brahma "c:eu:Brahma") sortzailea, [Vishnu](https://commons.wikimedia.org/wiki/en:Vishnu "c:en:Vishnu") zaindaria eta [Shiva](https://commons.wikimedia.org/wiki/en:Shiva "c:en:Shiva") suntsitzailea, hura baretu nahirik [Mahiṣāsura](https://commons.wikimedia.org/wiki/c:Category:Mahi%E1%B9%A3%C4%81sura "c:c:Category:Mahiṣāsura") deabrua erail ostean, hura ezin baitute hil ez beste jainkoek ez gizakiek. Haren garaipena hinduek ospatzen dute jainkoak deabruaren gainean izandako garaipentzat [Vijayadashamiren](https://commons.wikimedia.org/wiki/c:Category:Vijayadashami "c:c:Category:Vijayadashami") egunean, gaur.
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/HD%40DH.nrw_Fragezeichen_2.svg/60px-HD%40DH.nrw_Fragezeichen_2.svg.png)](https://eu.wikipedia.org/wiki/Fitxategi:HD@DH.nrw_Fragezeichen_2.svg) **Ba al zenekien?**  
[J. R. R. Tolkien](https://eu.wikipedia.org/wiki/J._R._R._Tolkien "J. R. R. Tolkien") ingeles idazleak bere _[Eraztunen Jauna](https://eu.wikipedia.org/wiki/Eraztunen_Jauna "Eraztunen Jauna")_ eta _[Silmarillion](https://eu.wikipedia.org/wiki/Silmarillion "Silmarillion")_ eleberrietan agertzen diren [elfo](https://eu.wikipedia.org/wiki/Elfo "Elfo") izakientzako [quenya](https://eu.wikipedia.org/w/index.php?title=Quenya&action=edit&redlink=1 "Quenya \(sortu gabe\)") eta [sindarin](https://eu.wikipedia.org/wiki/Sindarin "Sindarin") izeneko hizkuntzak asmatu zituela? Eta lehenbiziko hizkuntza garatzeko [alfabeto errunikoaz](https://eu.wikipedia.org/wiki/Alfabeto_erruniko "Alfabeto erruniko") eta [antzinako ingelesaz](https://eu.wikipedia.org/wiki/Antzinako_ingeles "Antzinako ingeles") baliatu zela eta bigarren hizkuntza sortzeko [galeseraren](https://eu.wikipedia.org/wiki/Galesera "Galesera") fonetikan oinarritu zela? 
### Hilberriak
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Roland_Bertranne_%281971%29.jpg/250px-Roland_Bertranne_%281971%29.jpg)](https://eu.wikipedia.org/wiki/Roland_Bertranne "Roland Bertranne")
[Roland Bertranne](https://eu.wikipedia.org/wiki/Roland_Bertranne "Roland Bertranne")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Jane_Goodall_2010_%28cropped%29.jpg/250px-Jane_Goodall_2010_%28cropped%29.jpg)](https://eu.wikipedia.org/wiki/Jane_Goodall "Jane Goodall")
[Jane Goodall](https://eu.wikipedia.org/wiki/Jane_Goodall "Jane Goodall")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/03/Sem_imagem.jpg/250px-Sem_imagem.jpg)](https://eu.wikipedia.org/wiki/Stefano_Casagranda "Stefano Casagranda")
[Stefano Casagranda](https://eu.wikipedia.org/wiki/Stefano_Casagranda "Stefano Casagranda")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Pablo_Guerrero_2009.jpg/250px-Pablo_Guerrero_2009.jpg)](https://eu.wikipedia.org/wiki/Pablo_Guerrero "Pablo Guerrero")
[Pablo Guerrero](https://eu.wikipedia.org/wiki/Pablo_Guerrero "Pablo Guerrero")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Jorgen_Leth.jpg/250px-Jorgen_Leth.jpg)](https://eu.wikipedia.org/wiki/J%C3%B8rgen_Leth "Jørgen Leth")
[Jørgen Leth](https://eu.wikipedia.org/wiki/J%C3%B8rgen_Leth "Jørgen Leth")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/Jos%C3%A9_Araquist%C3%A1in_1962.jpg/250px-Jos%C3%A9_Araquist%C3%A1in_1962.jpg)](https://eu.wikipedia.org/wiki/Jose_Arakistain "Jose Arakistain")
[Jose Arakistain](https://eu.wikipedia.org/wiki/Jose_Arakistain "Jose Arakistain")
[Eskuz gaurkotu](https://listeria.toolforge.org/index.php?action=update&lang=eu&page=Azala)
### Albisteak
![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/Batuz_aldatu_hitzarmena_-_Donostia_%282025%29.jpg/250px-Batuz_aldatu_hitzarmena_-_Donostia_%282025%29.jpg)
[2025eko](https://eu.wikipedia.org/wiki/2025 "2025") [irailaren 26a](https://eu.wikipedia.org/wiki/Irailaren_26 "Irailaren 26")
["Batuz aldatu" euskararen aldeko itun soziopolitikoa](https://eu.wikipedia.org/wiki/Batuz_Aldatu,_Hizkuntza-politiketan_eragiteko_adostasun_soziala "Batuz Aldatu, Hizkuntza-politiketan eragiteko adostasun soziala") proposatzeko batzarra egin da [Gipuzkoako Zientzia eta Teknologia Parkean](https://eu.wikipedia.org/wiki/Gipuzkoako_Zientzia_eta_Teknologia_Parkea "Gipuzkoako Zientzia eta Teknologia Parkea"), 100dik gora gizarte eragileren atxikimenduaz.
![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Ibaitik_itsasora_-_Etorbidea_Zubia_%282025%29_5.jpg/250px-Ibaitik_itsasora_-_Etorbidea_Zubia_%282025%29_5.jpg)
[2025eko](https://eu.wikipedia.org/wiki/2025 "2025") [irailaren 20a](https://eu.wikipedia.org/wiki/Irailaren_20 "Irailaren 20")
[Hendaiako](https://eu.wikipedia.org/wiki/Hendaia "Hendaia") [Zokoburun](https://eu.wikipedia.org/wiki/Sokoburu "Sokoburu") amaitu da «Ibaitik itsasora» [Israelek](https://eu.wikipedia.org/wiki/Israel "Israel") [Palestinan daraman genozidioaren](https://eu.wikipedia.org/wiki/2023-2025eko_Israel-Palestina_gatazka "2023-2025eko Israel-Palestina gatazka") kontrako martxa. Hamar egunez, [Tuteratik](https://eu.wikipedia.org/wiki/Tutera "Tutera") itsasoraino [Euskal Herria](https://eu.wikipedia.org/wiki/Euskal_Herria "Euskal Herria") zeharkatu du.
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Aroztegia%2C_auzipetuak_%282025%29.jpg/250px-Aroztegia%2C_auzipetuak_%282025%29.jpg)](https://eu.wikipedia.org/wiki/Zerrenda:Euskara_erabiltzeko_eskubidearen_kontrako_neurriak "Zerrenda:Euskara erabiltzeko eskubidearen kontrako neurriak")
[2025eko](https://eu.wikipedia.org/wiki/2025 "2025") [irailaren 19a](https://eu.wikipedia.org/wiki/Irailaren_19 "Irailaren 19")
[Nafarroako Justizia Auzitegi Nagusiak](https://eu.wikipedia.org/wiki/Nafarroako_Auzitegi_Nagusia "Nafarroako Auzitegi Nagusia") [Aroztegia auziari](https://eu.wikipedia.org/wiki/Aroztegia_\(proiektua\) "Aroztegia \(proiektua\)") buruzko sententzia eman du: ez ditu protestariak «talde kriminal»eko kidetzat hartu, eta ez dute jasoko espetxe zigorrik; bai, ordea, isunak.
![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Bayonne-Centre_historique-20130811.jpg/250px-Bayonne-Centre_historique-20130811.jpg)
[2025eko](https://eu.wikipedia.org/wiki/2025 "2025") [irailaren 18a](https://eu.wikipedia.org/wiki/Irailaren_18 "Irailaren 18")
[Greba egun orokorra](https://eu.wikipedia.org/wiki/Greba_orokorra "Greba orokorra") deitu dute gaurko [Ipar Euskal Herrian](https://eu.wikipedia.org/wiki/Ipar_Euskal_Herria "Ipar Euskal Herria"), [Frantzian](https://eu.wikipedia.org/wiki/Frantzia "Frantzia") bezala, [Emmanuel Macron](https://eu.wikipedia.org/wiki/Emmanuel_Macron "Emmanuel Macron") presidentearen murrizketa politiken kontra. 4.000 pertsona bildu dira protestan [Baionan](https://eu.wikipedia.org/wiki/Baiona "Baiona").
### Esploratu
####  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/Compass-noun-project.svg/40px-Compass-noun-project.svg.png)](https://eu.wikipedia.org/wiki/Fitxategi:Compass-noun-project.svg) Hurbil dituzunak
### Zure inguruko lekuak
Zuregandik gertu dauden Wikipediako artikulu interesgarriak irakur ditzakezu
Gertuko orriak erakutsi
####  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/Bootstrap_fire.svg/24px-Bootstrap_fire.svg.png)](https://eu.wikipedia.org/wiki/Fitxategi:Bootstrap_fire.svg) Irakurrienak
[Aner PeritzZarauzko bertsolaria](https://eu.wikipedia.org/wiki/Aner_Peritz)[Ane Ibarzabaltelebista aurkezlea](https://eu.wikipedia.org/wiki/Ane_Ibarzabal)[Ainhoa Agirreazaldegieuskal bertsolaria](https://eu.wikipedia.org/wiki/Ainhoa_Agirreazaldegi)[Euskarazko Wikipedia (webgunea)Wikipediaren euskarazko bertsioa](https://eu.wikipedia.org/wiki/Euskarazko_Wikipedia_\(webgunea\))[Txikipedia8-13 urteko ikasleentzako entziklopedia, euskarazko wikipediaren antzekoa eta honekin mihiztatua](https://eu.wikipedia.org/wiki/Txikipedia)[The Untouchables (filma)](https://eu.wikipedia.org/wiki/The_Untouchables_\(filma\))[Jane Goodall](https://eu.wikipedia.org/wiki/Jane_Goodall)[Ivanoe Bonomi](https://eu.wikipedia.org/wiki/Ivanoe_Bonomi)[Euskaraeuskaldunen hizkuntza](https://eu.wikipedia.org/wiki/Euskara)[Euskal HerriaEuropako herrialdea, historikoki euskaldunen eta euskararen lurraldea dena](https://eu.wikipedia.org/wiki/Euskal_Herria)
### Komunitatea
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Circle-icons-compose.svg/20px-Circle-icons-compose.svg.png)](https://eu.wikipedia.org/wiki/Atari:Hezkuntza "Atari:Hezkuntza") **[Hezkuntza ataria](https://eu.wikipedia.org/wiki/Atari:Hezkuntza "Atari:Hezkuntza")** [![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Circle-icons-chat.svg/20px-Circle-icons-chat.svg.png)](https://eu.wikipedia.org/wiki/Atari:Hezkuntza "Atari:Hezkuntza") **[Txokoa](https://eu.wikipedia.org/wiki/Wikipedia:Txokoa "Wikipedia:Txokoa")** [![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Circle-icons-rainbow-flag.svg/20px-Circle-icons-rainbow-flag.svg.png)](https://eu.wikipedia.org/wiki/) **LGBT biografiak** hobetzeko eztabaida [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Circle-icons-booklet-woman.svg/20px-Circle-icons-booklet-woman.svg.png)](https://eu.wikipedia.org/wiki/Wikiproiektu:30.000emakume "Wikiproiektu:30.000emakume") **[30.000 emakume](https://eu.wikipedia.org/wiki/Wikiproiektu:30.000_emakume "Wikiproiektu:30.000 emakume")** [![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Circle-icons-check.svg/20px-Circle-icons-check.svg.png)](https://eu.wikipedia.org/wiki/Wikiproiektu:Wikipedia_guztiek_izan_beharreko_1.000_artikuluen_zerrenda "Wikiproiektu:Wikipedia guztiek izan beharreko 1.000 artikuluen zerrenda") **[Oinarrizko 1.000](https://eu.wikipedia.org/wiki/Wikiproiektu:Wikipedia_guztiek_izan_beharreko_1.000_artikuluen_zerrenda "Wikiproiektu:Wikipedia guztiek izan beharreko 1.000 artikuluen zerrenda")** [![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Circle-icons-support.svg/20px-Circle-icons-support.svg.png)](https://eu.wikipedia.org/wiki/Laguntza:Sarrera "Laguntza:Sarrera") **[Laguntza](https://eu.wikipedia.org/wiki/Laguntza:Sarrera "Laguntza:Sarrera")**
### Wikimediaren beste proiektuak
[![Commons](https://upload.wikimedia.org/wikipedia/commons/9/9d/Commons-logo-31px.png)](https://commons.wikimedia.org/wiki/Azala "Commons") |  **[Commons](https://commons.wikimedia.org/wiki/Azala)**   
Irudiak eta multimedia  |  [![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/ "MediaWiki") |  **[MediaWiki](https://mediawiki.org/)**   
Wiki software garapena  |  [![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/b/bc/Meta-logo-35px.png)](https://meta.wikimedia.org/wiki/Azala "Meta-Wiki") |  **[Meta-Wiki](https://meta.wikimedia.org/wiki/Azala)**   
Proiektuen koordinazioa   
---|---|---|---|---|---  
[![Wikialbisteak](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://incubator.wikimedia.org/wiki/Wn/eu/Azala "Wikialbisteak") |  **[Wikialbisteak](https://incubator.wikimedia.org/wiki/Wn/eu/Azala)**   
Albiste libreak  |  [![Wikibertsitatea](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/60px-Wikiversity-logo.svg.png)](https://eu.wikiversity.org/wiki/ "Wikibertsitatea") |  **[Wikibertsitatea](https://en.wikiversity.org/)**   
Ikasketa baliabideak  |  [![Wikibidaiak](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://incubator.wikimedia.org/wiki/Wy/eu/Azala "Wikibidaiak") |  **[Wikibidaiak](https://incubator.wikimedia.org/wiki/Wy/eu/Azala)**   
Bidaiak eta txangoak   
[![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "Wikidata") |  **[Wikidata](https://www.wikidata.org/)**   
Datu-base askea  |  [![Wikiesanak](https://upload.wikimedia.org/wikipedia/commons/4/46/Wikiquote-logo-51px.png)](https://eu.wikiquote.org/wiki/Azala "Wikiesanak") |  **[Wikiesanak](https://eu.wikiquote.org/wiki/Azala)**   
Esanak  |  [![Wikiliburuak](https://upload.wikimedia.org/wikipedia/commons/7/7f/Wikibooks-logo-35px.png)](https://eu.wikibooks.org/wiki/ "Wikiliburuak") |  **[Wikiliburuak](https://eu.wikibooks.org/wiki/Azala)**   
Ikasliburu eta eskuliburuak   
[![Wikispezieak](https://upload.wikimedia.org/wikipedia/commons/b/bf/Wikispecies-logo-35px.png)](https://species.wikimedia.org/wiki/Azala "Wikispezieak") |  **[Wikispezieak](https://species.wikimedia.org/wiki/Azala)**   
Espezieen gidaliburua  |  [![Wikiteka](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Wikisource-logo.png/40px-Wikisource-logo.png)](https://eu.wikisource.org/wiki/Azala "Wikiteka") |  **[Wikiteka](https://eu.wikisource.org/wiki/Azala)**   
Jatorrizko dokumentuak  |  [![Wikiztegia](https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wiktionary-logo-eu.png/40px-Wiktionary-logo-eu.png)](https://eu.wiktionary.org/wiki/Azala "Wikiztegia") |  **[Wikiztegia](https://eu.wiktionary.org/wiki/Azala)**   
Hiztegia sinonimoekin   
"[https://eu.wikipedia.org/w/index.php?title=Azala&oldid=9807453](https://eu.wikipedia.org/w/index.php?title=Azala&oldid=9807453)"(e)tik eskuratuta
[Kategoriak](https://eu.wikipedia.org/wiki/Berezi:Kategoriak "Berezi:Kategoriak"): 
  * [Azala](https://eu.wikipedia.org/wiki/Kategoria:Azala "Kategoria:Azala")
  * [Euskal Wikipediako albisteak](https://eu.wikipedia.org/wiki/Kategoria:Euskal_Wikipediako_albisteak "Kategoria:Euskal Wikipediako albisteak")


  * Orriaren azken aldaketa: 29 maiatza 2024, 17:37.
  * Testua [Creative Commons Aitortu-PartekatuBerdin 4.0 lizentziari](https://creativecommons.org/licenses/by-sa/4.0/deed.eu) jarraituz erabil daiteke; baliteke beste klausularen batzuk ere aplikatu behar izatea. Xehetasunen berri izateko, ikus [erabilera-baldintzak](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use).


  * [Pribazitate politika](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Wikipediari buruz](https://eu.wikipedia.org/wiki/Laguntza:Wikipediari_buruz)
  * [Lege oharra](https://eu.wikipedia.org/wiki/Wikipedia:Erantzukizunen_mugaketa_orokorra)
  * [Jokabide Kodea](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Garatzaileak](https://developer.wikimedia.org)
  * [Estatistikak](https://stats.wikimedia.org/#/eu.wikipedia.org)
  * [Cookie adierazpena](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Mugikorreko bista](https://eu.m.wikipedia.org/w/index.php?title=Azala&mobileaction=toggle_view_mobile)
  * [Aldatu aurrebistaren ezarpenak](https://eu.wikipedia.org/wiki/Azala)


  * [![Wikimedia Foundation](https://eu.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://eu.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Bilatu
Bilatu
Ongi etorri Wikipediara
[](https://eu.wikipedia.org/wiki/Azala) [](https://eu.wikipedia.org/wiki/Azala) [](https://eu.wikipedia.org/wiki/Azala) [](https://eu.wikipedia.org/wiki/Azala) [](https://eu.wikipedia.org/wiki/Azala) [](https://eu.wikipedia.org/wiki/Azala) [](https://eu.wikipedia.org/wiki/Azala) [](https://eu.wikipedia.org/wiki/Azala)
353 hizkuntza [Gehitu atala ](https://eu.wikipedia.org/wiki/Azala)
