[Naar inhoud springen](https://nl.wikipedia.org/wiki/Hoofdpagina#bodyContent)
Hoofdmenu
Hoofdmenu
naar zijbalk verplaatsen verbergen
Navigatie 
  * [Hoofdpagina](https://nl.wikipedia.org/wiki/Hoofdpagina "Naar de hoofdpagina gaan \[z\]")
  * [Vind een artikel](https://nl.wikipedia.org/wiki/Portaal:Navigatie)
  * [Vandaag](https://nl.wikipedia.org/wiki/1_oktober)
  * [Etalage](https://nl.wikipedia.org/wiki/Wikipedia:Etalage)
  * [Categorieën](https://nl.wikipedia.org/wiki/Categorie:Alles)
  * [Recente wijzigingen](https://nl.wikipedia.org/wiki/Speciaal:RecenteWijzigingen "Een lijst met recente wijzigingen in deze wiki. \[r\]")
  * [Nieuwe artikelen](https://nl.wikipedia.org/wiki/Speciaal:NieuwePaginas)
  * [Willekeurige pagina](https://nl.wikipedia.org/wiki/Speciaal:Willekeurig "Een willekeurige pagina bekijken \[x\]")
  * [Speciale pagina's](https://nl.wikipedia.org/wiki/Speciaal:SpecialePaginas)


Informatie 
  * [Gebruikersportaal](https://nl.wikipedia.org/wiki/Portaal:Gebruikersportaal "Informatie over het project: wat u kunt doen, waar u dingen kunt vinden")
  * [Snelcursus](https://nl.wikipedia.org/wiki/Wikipedia:Snelcursus)
  * [Hulp en contact](https://nl.wikipedia.org/wiki/Portaal:Hulp_en_beheer "Hulpinformatie over deze wiki")


[ ![](https://nl.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://nl.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![de vrije encyclopedie](https://nl.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-nl.svg) ](https://nl.wikipedia.org/wiki/Hoofdpagina)
[Zoeken ](https://nl.wikipedia.org/wiki/Speciaal:Zoeken "Doorzoek Wikipedia \[f\]")
Zoeken
Uiterlijk
  * [Doneren](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=nl.wikipedia.org&uselang=nl)
  * [Account aanmaken](https://nl.wikipedia.org/w/index.php?title=Speciaal:GebruikerAanmaken&returnto=Hoofdpagina "Registreer u vooral en meld u aan. Dit is echter niet verplicht.")
  * [Aanmelden](https://nl.wikipedia.org/w/index.php?title=Speciaal:Aanmelden&returnto=Hoofdpagina "U wordt van harte uitgenodigd om aan te melden, maar dit is niet verplicht \[o\]")


Persoonlijke hulpmiddelen
  * [Doneren](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=nl.wikipedia.org&uselang=nl)
  * [Account aanmaken](https://nl.wikipedia.org/w/index.php?title=Speciaal:GebruikerAanmaken&returnto=Hoofdpagina "Registreer u vooral en meld u aan. Dit is echter niet verplicht.")
  * [Aanmelden](https://nl.wikipedia.org/w/index.php?title=Speciaal:Aanmelden&returnto=Hoofdpagina "U wordt van harte uitgenodigd om aan te melden, maar dit is niet verplicht \[o\]")


[sluiten]
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Plaatjesalbum_Verkade_met_titel_%E2%80%9CDe_bloemen_en_haar_vrienden%E2%80%9D_door_Jac.P._Thijsse%2C_objectnr_78964.JPG/120px-Plaatjesalbum_Verkade_met_titel_%E2%80%9CDe_bloemen_en_haar_vrienden%E2%80%9D_door_Jac.P._Thijsse%2C_objectnr_78964.JPG)](https://nl.wikipedia.org/wiki/Bestand:Plaatjesalbum_Verkade_met_titel_%E2%80%9CDe_bloemen_en_haar_vrienden%E2%80%9D_door_Jac.P._Thijsse,_objectnr_78964.JPG) | 
### [_Natuurlijk_ - Maand van de Geschiedenis 2025](https://nl.wikipedia.org/wiki/Wikipedia:Wikiproject/Schrijfweek/Natuurlijk "Wikipedia:Wikiproject/Schrijfweek/Natuurlijk")
Doe in oktober mee aan [**de schrijfmaand**](https://nl.wikipedia.org/wiki/Wikipedia:Wikiproject/Schrijfweek/Natuurlijk "Wikipedia:Wikiproject/Schrijfweek/Natuurlijk").   
---|---  
# Hoofdpagina
  * [Hoofdpagina](https://nl.wikipedia.org/wiki/Hoofdpagina "Inhoudspagina bekijken \[c\]")
  * [Overleg](https://nl.wikipedia.org/wiki/Overleg:Hoofdpagina "Overleg over deze pagina \[t\]")


Nederlands
  * [Lezen](https://nl.wikipedia.org/wiki/Hoofdpagina)
  * [Brontekst bekijken](https://nl.wikipedia.org/w/index.php?title=Hoofdpagina&action=edit "Deze pagina is beveiligd.
U kunt wel de broncode bekijken. \[e\]")
  * [Geschiedenis weergeven](https://nl.wikipedia.org/w/index.php?title=Hoofdpagina&action=history "Eerdere versies van deze pagina \[h\]")


Hulpmiddelen
Hulpmiddelen
naar zijbalk verplaatsen verbergen
Handelingen 
  * [Lezen](https://nl.wikipedia.org/wiki/Hoofdpagina)
  * [Brontekst bekijken](https://nl.wikipedia.org/w/index.php?title=Hoofdpagina&action=edit)
  * [Geschiedenis weergeven](https://nl.wikipedia.org/w/index.php?title=Hoofdpagina&action=history)


Algemeen 
  * [Links naar deze pagina](https://nl.wikipedia.org/wiki/Speciaal:VerwijzingenNaarHier/Hoofdpagina "Lijst met alle pagina's die naar deze pagina verwijzen \[j\]")
  * [Gerelateerde wijzigingen](https://nl.wikipedia.org/wiki/Speciaal:RecenteWijzigingenGelinkt/Hoofdpagina "Recente wijzigingen in pagina's waar deze pagina naar verwijst \[k\]")
  * [Bestand uploaden](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=nl "Bestanden uploaden \[u\]")
  * [Permanente koppeling](https://nl.wikipedia.org/w/index.php?title=Hoofdpagina&oldid=68315324 "Permanente koppeling naar deze versie van deze pagina")
  * [Paginagegevens](https://nl.wikipedia.org/w/index.php?title=Hoofdpagina&action=info "Meer informatie over deze pagina")
  * [Deze pagina citeren](https://nl.wikipedia.org/w/index.php?title=Speciaal:Citeren&page=Hoofdpagina&id=68315324&wpFormIdentifier=titleform "Informatie over hoe u deze pagina kunt citeren")
  * [Verkorte URL verkrijgen](https://nl.wikipedia.org/w/index.php?title=Speciaal:UrlShortener&url=https%3A%2F%2Fnl.wikipedia.org%2Fwiki%2FHoofdpagina)
  * [QR-code downloaden](https://nl.wikipedia.org/w/index.php?title=Speciaal:QrCode&url=https%3A%2F%2Fnl.wikipedia.org%2Fwiki%2FHoofdpagina)


Afdrukken/exporteren 
  * [Boek aanmaken](https://nl.wikipedia.org/w/index.php?title=Speciaal:Boek&bookcmd=book_creator&referer=Hoofdpagina)
  * [Downloaden als PDF](https://nl.wikipedia.org/w/index.php?title=Speciaal:DownloadAsPdf&page=Hoofdpagina&action=show-download-screen)
  * [Afdrukversie](https://nl.wikipedia.org/w/index.php?title=Hoofdpagina&printable=yes "Printvriendelijke versie van deze pagina \[p\]")


In andere projecten 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia-voorlichting](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Meertalige Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikibooks](https://nl.wikibooks.org/wiki/Hoofdpagina)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifuncties](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikinieuws](https://nl.wikinews.org/wiki/Wikinieuws:Hoofdpagina)
  * [Wikiquote](https://nl.wikiquote.org/wiki/Hoofdpagina)
  * [Wikisource](https://nl.wikisource.org/wiki/Hoofdpagina)
  * [Wikivoyage](https://nl.wikivoyage.org/wiki/Hoofdpagina)
  * [WikiWoordenboek](https://nl.wiktionary.org/wiki/WikiWoordenboek:Hoofdpagina)
  * [Wikidata-item](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Koppeling naar item in verbonden gegevensrepository \[g\]")


Uiterlijk
naar zijbalk verplaatsen verbergen
Uit Wikipedia, de vrije encyclopedie
[Welkom](https://nl.wikipedia.org/wiki/Wikipedia:Welkom_voor_nieuwkomers "Wikipedia:Welkom voor nieuwkomers") op Wikipedia De vrije encyclopedie |  Aantal artikelen: **2.198.335** Aantal actieve gebruikers: **8.929** Portaal van de week: **[Seychellen](https://nl.wikipedia.org/wiki/Portaal:Seychellen "Portaal:Seychellen")**  
---|---  
[Biologie](https://nl.wikipedia.org/wiki/Portaal:Biologie "Portaal:Biologie") |  [Geschiedenis](https://nl.wikipedia.org/wiki/Portaal:Geschiedenis "Portaal:Geschiedenis") |  [Kunst & Cultuur](https://nl.wikipedia.org/wiki/Portaal:Kunst_%26_Cultuur "Portaal:Kunst & Cultuur") |  [Landen & Volken](https://nl.wikipedia.org/wiki/Portaal:Landen_%26_Volken "Portaal:Landen & Volken") |  [Mens & Maatschappij](https://nl.wikipedia.org/wiki/Portaal:Mens_%26_Maatschappij "Portaal:Mens & Maatschappij") |  [Politiek](https://nl.wikipedia.org/wiki/Portaal:Politiek "Portaal:Politiek") |  [Religie](https://nl.wikipedia.org/wiki/Portaal:Religie "Portaal:Religie") |  [Sport](https://nl.wikipedia.org/wiki/Portaal:Sport "Portaal:Sport") |  [Taal](https://nl.wikipedia.org/wiki/Portaal:Taal "Portaal:Taal") |  [Wetenschap & Technologie](https://nl.wikipedia.org/wiki/Portaal:Wetenschap_%26_Technologie "Portaal:Wetenschap & Technologie")  
---|---|---|---|---|---|---|---|---|---  
## [Uitgelicht](https://nl.wikipedia.org/wiki/Wikipedia:Uitgelicht "Wikipedia:Uitgelicht")
[![Brieflezende vrouw in het blauw van Vermeer](https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/Vermeer%2C_Johannes_-_Woman_reading_a_letter_-_ca._1662-1663.jpg/120px-Vermeer%2C_Johannes_-_Woman_reading_a_letter_-_ca._1662-1663.jpg)](https://nl.wikipedia.org/wiki/Bestand:Vermeer,_Johannes_-_Woman_reading_a_letter_-_ca._1662-1663.jpg "Brieflezende vrouw in het blauw van Vermeer") [Johannes Vermeer](https://nl.wikipedia.org/wiki/Johannes_Vermeer "Johannes Vermeer") Johannes Vermeer (gedoopt te [Delft](https://nl.wikipedia.org/wiki/Delft "Delft"), [31 oktober](https://nl.wikipedia.org/wiki/31_oktober "31 oktober") [1632](https://nl.wikipedia.org/wiki/1632 "1632") – begraven aldaar, [15 december](https://nl.wikipedia.org/wiki/15_december "15 december") [1675](https://nl.wikipedia.org/wiki/1675 "1675")) is een van de beroemdste [Nederlandse](https://nl.wikipedia.org/wiki/Nederland "Nederland") [kunstschilders](https://nl.wikipedia.org/wiki/Schilderkunst "Schilderkunst") uit de [Gouden Eeuw](https://nl.wikipedia.org/wiki/Gouden_Eeuw_\(Nederland\) "Gouden Eeuw \(Nederland\)"). Vermeer had een voorkeur voor tijdloze, ingetogen momenten. Hij blijft raadselachtig vanwege de onnavolgbare kleurstelling en het verbijsterende lichtgehalte.  Vermeers schilderijen, meestal [genrestukken](https://nl.wikipedia.org/wiki/Genrestuk "Genrestuk") en een paar [historiestukken](https://nl.wikipedia.org/wiki/Historieschilderkunst "Historieschilderkunst"), [allegorieën](https://nl.wikipedia.org/wiki/Allegorie_\(beeldende_kunst\) "Allegorie \(beeldende kunst\)") en [stadsgezichten](https://nl.wikipedia.org/wiki/Stadsgezicht "Stadsgezicht"), onderscheiden zich door een subtiel kleurgebruik en een ideale [compositie](https://nl.wikipedia.org/wiki/Compositie_\(beeldende_kunst\) "Compositie \(beeldende kunst\)"). Hij gebruikte soms dure [pigmenten](https://nl.wikipedia.org/wiki/Pigment "Pigment") en had een grote voorkeur voor [ultramarijn](https://nl.wikipedia.org/wiki/Ultramarijn "Ultramarijn") en [loodtingeel](https://nl.wikipedia.org/wiki/Loodtingeel "Loodtingeel"). _([Lees verder](https://nl.wikipedia.org/wiki/Johannes_Vermeer "Johannes Vermeer"))_ | 
## [Etalage](https://nl.wikipedia.org/wiki/Wikipedia:Etalage "Wikipedia:Etalage")
|  **[Johan Helmich Roman](https://nl.wikipedia.org/wiki/Johan_Helmich_Roman "Johan Helmich Roman")**  
---  
**[Georgius Macropedius](https://nl.wikipedia.org/wiki/Georgius_Macropedius "Georgius Macropedius")**  
**[New York (stad)](https://nl.wikipedia.org/wiki/New_York_\(stad\) "New York \(stad\)")**  
**[Kelenken](https://nl.wikipedia.org/wiki/Kelenken "Kelenken")**  
**[Operatie Overlord](https://nl.wikipedia.org/wiki/Operatie_Overlord "Operatie Overlord")**  
**[Paus Julius II](https://nl.wikipedia.org/wiki/Paus_Julius_II "Paus Julius II")**  
**[Chinese schilderkunst](https://nl.wikipedia.org/wiki/Chinese_schilderkunst "Chinese schilderkunst")**  
**[Iowaklasse](https://nl.wikipedia.org/wiki/Iowaklasse "Iowaklasse")**  
## [Over Wikipedia](https://nl.wikipedia.org/wiki/Wikipedia "Wikipedia")
Wikipedia is een [online encyclopedie](https://nl.wikipedia.org/wiki/Internetencyclopedie "Internetencyclopedie") die ernaar streeft om in alle erkende talen informatie te bieden die [objectief](https://nl.wikipedia.org/wiki/Wikipedia:Neutraal_standpunt "Wikipedia:Neutraal standpunt"), [verifieerbaar](https://nl.wikipedia.org/wiki/Wikipedia:Verifieerbaarheid "Wikipedia:Verifieerbaarheid") en [vrij herbruikbaar](https://nl.wikipedia.org/wiki/Wikipedia:Auteursrechten "Wikipedia:Auteursrechten") is. Het project is gebaseerd op [vijf basisprincipes](https://nl.wikipedia.org/wiki/Wikipedia:Vijf_zuilen "Wikipedia:Vijf zuilen"). De [Nederlandstalige versie](https://nl.wikipedia.org/wiki/Nederlandstalige_Wikipedia "Nederlandstalige Wikipedia") startte op 19 juni 2001 en is met meer dan 2,1 miljoen artikelen de op vijf na grootste van circa 345 taalversies.  De encyclopedie is vrij bewerkbaar. Dat houdt in dat iedereen tekst en afbeeldingen kan toevoegen of aanpassen, met inachtneming van de [basisregels](https://nl.wikipedia.org/wiki/Portaal:Hulp_en_beheer/Regels_en_richtlijnen "Portaal:Hulp en beheer/Regels en richtlijnen"). Voor de bewerkers zijn er diverse [hulppagina's](https://nl.wikipedia.org/wiki/Portaal:Hulp_en_beheer "Portaal:Hulp en beheer") beschikbaar. Er is ook een [snelcursus](https://nl.wikipedia.org/wiki/Wikipedia:Snelcursus "Wikipedia:Snelcursus") voor nieuwelingen. Zaken uitproberen kan in de [zandbak](https://nl.wikipedia.org/wiki/Wikipedia:Zandbak "Wikipedia:Zandbak") en vragen kunnen gesteld worden bij de [helpdesk](https://nl.wikipedia.org/wiki/Help:Helpdesk "Help:Helpdesk"). Voor privacyvragen kunt u [hier terecht](https://nl.wikipedia.org/wiki/Wikipedia:Privacy "Wikipedia:Privacy").   
## [Wist je dat ...](https://nl.wikipedia.org/wiki/Wikipedia:Wist_je_dat "Wikipedia:Wist je dat")
[![Doerians](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Durio_zibeth_F_070202_138_malw.jpg/120px-Durio_zibeth_F_070202_138_malw.jpg)](https://nl.wikipedia.org/wiki/Bestand:Durio_zibeth_F_070202_138_malw.jpg "Doerians")
  * ... **[doerians](https://nl.wikipedia.org/wiki/Doerian "Doerian")** gelden als lekkernij, hoewel ze enorm stinken? 
  * ... de [Sint Servaasbrug](https://nl.wikipedia.org/wiki/Sint_Servaasbrug "Sint Servaasbrug") (1280-1298) de [Romeinse brug van Maastricht](https://nl.wikipedia.org/wiki/Romeinse_brug_van_Maastricht "Romeinse brug van Maastricht") verving die er iets noordelijker sinds het begin van de jaartelling had gestaan? 
  * ... sprekers van de [Scandinavische talen](https://nl.wikipedia.org/wiki/Noord-Germaanse_talen "Noord-Germaanse talen") van het vasteland nog geen drie minuten met elkaar kunnen praten zonder een [Nedersaksisch](https://nl.wikipedia.org/wiki/Nedersaksisch "Nedersaksisch") [leenwoord](https://nl.wikipedia.org/wiki/Leenwoord "Leenwoord") te gebruiken? 
  * ... [Ann Burton](https://nl.wikipedia.org/wiki/Ann_Burton "Ann Burton") als Nederlandse jazzzangeres al begin jaren 1970 succes had in [Japan](https://nl.wikipedia.org/wiki/Japan_\(hoofdbetekenis\) "Japan \(hoofdbetekenis\)")? 
  * ... voetballer [Robin van Persie](https://nl.wikipedia.org/wiki/Robin_van_Persie "Robin van Persie") al op vijfjarige leeftijd werd aangenomen bij [Excelsior](https://nl.wikipedia.org/wiki/SBV_Excelsior "SBV Excelsior"), terwijl zes jaar de minimumleeftijd was? 

| 
## [Afbeelding](https://commons.wikimedia.org/wiki/commons:Afbeelding_van_de_dag "commons:commons:Afbeelding van de dag")
[![Ronde vleermuisvis \(Platax orbicularis\)](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Pez_murci%C3%A9lago_orbicular_%28Platax_orbicularis%29%2C_mar_Rojo%2C_Egipto%2C_2023-04-19%2C_DD_01.jpg/250px-Pez_murci%C3%A9lago_orbicular_%28Platax_orbicularis%29%2C_mar_Rojo%2C_Egipto%2C_2023-04-19%2C_DD_01.jpg)](https://nl.wikipedia.org/wiki/Bestand:Pez_murci%C3%A9lago_orbicular_\(Platax_orbicularis\),_mar_Rojo,_Egipto,_2023-04-19,_DD_01.jpg "Ronde vleermuisvis \(Platax orbicularis\)") [Ronde vleermuisvis](https://nl.wikipedia.org/wiki/Ronde_vleermuisvis "Ronde vleermuisvis") (_Platax orbicularis_)  
---|---  
## [Actueel](https://nl.wikipedia.org/wiki/Portaal:In_het_nieuws "Portaal:In het nieuws")
[![Afbeelding](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/2022_Russian_invasion_of_Ukraine.svg/langnl-120px-2022_Russian_invasion_of_Ukraine.svg.png)](https://nl.wikipedia.org/wiki/Bestand:2022_Russian_invasion_of_Ukraine.svg "Afbeelding") [Russische invasie van Oekraïne sinds 2022](https://nl.wikipedia.org/wiki/Russische_invasie_van_Oekra%C3%AFne_sinds_2022 "Russische invasie van Oekraïne sinds 2022") De Russische invasie van Oekraïne is een aanvalsoorlog die begon op 24 februari 2022, toen [Rusland](https://nl.wikipedia.org/wiki/Rusland "Rusland") buurland [Oekraïne](https://nl.wikipedia.org/wiki/Oekra%C3%AFne "Oekraïne") vanuit meerdere kanten binnenviel in een grote escalatie van de [Russisch-Oekraïense Oorlog](https://nl.wikipedia.org/wiki/Russisch-Oekra%C3%AFense_Oorlog "Russisch-Oekraïense Oorlog") die sinds 2014 gaande is. _([Lees verder](https://nl.wikipedia.org/wiki/Russische_invasie_van_Oekra%C3%AFne_sinds_2022 "Russische invasie van Oekraïne sinds 2022"))_ | 
## [Recent overleden](https://nl.wikipedia.org/wiki/Lijst_van_personen_overleden_in_oktober_2025 "Lijst van personen overleden in oktober 2025")
|  [1 okt](https://nl.wikipedia.org/wiki/1_oktober "1 oktober") |  [Jane Goodall](https://nl.wikipedia.org/wiki/Jane_Goodall "Jane Goodall") (91), Brits antropologe en biologe   
---|---  
[1 okt](https://nl.wikipedia.org/wiki/1_oktober "1 oktober") |  [Eric De Rop](https://nl.wikipedia.org/wiki/Eric_De_Rop "Eric De Rop") (73), Belgisch striptekenaar   
[30 sep](https://nl.wikipedia.org/wiki/30_september "30 september") |  [Cor Vos](https://nl.wikipedia.org/wiki/Cor_Vos_\(fotograaf\) "Cor Vos \(fotograaf\)") (77), Nederlands fotograaf   
[30 sep](https://nl.wikipedia.org/wiki/30_september "30 september") |  [Robert ('bOb') Van Reeth](https://nl.wikipedia.org/wiki/BOb_Van_Reeth "BOb Van Reeth") (82), Belgisch architect   
[29 sep](https://nl.wikipedia.org/wiki/29_september "29 september") |  [Jørgen Leth](https://nl.wikipedia.org/wiki/J%C3%B8rgen_Leth "Jørgen Leth") (88), Deens journalist, filmregisseur en wielercommentator   
## [In het nieuws](https://nl.wikipedia.org/wiki/Portaal:In_het_nieuws "Portaal:In het nieuws")  
---  
|  [29 sep](https://nl.wikipedia.org/wiki/29_september "29 september") |  [PAS wint Moldavische parlementsverkiezingen](https://nl.wikipedia.org/wiki/Moldavi%C3%AB_\(land\)#Politiek "Moldavië \(land\)")  
Bij de [parlementsverkiezingen](https://nl.wikipedia.org/wiki/Parlement "Parlement") in Moldavië behoudt de pro-Europese Partij van Actie en Solidariteit (PAS) de absolute meerderheid.   
---|---  
|  [23 sep](https://nl.wikipedia.org/wiki/23_september "23 september") |  [Mali, Niger en Burkina Faso verlaten ICC](https://nl.wikipedia.org/wiki/Internationaal_Strafhof "Internationaal Strafhof")  
De West-Afrikaanse landen [Mali](https://nl.wikipedia.org/wiki/Mali "Mali"), [Niger](https://nl.wikipedia.org/wiki/Niger_\(land\) "Niger \(land\)") en [Burkina Faso](https://nl.wikipedia.org/wiki/Burkina_Faso "Burkina Faso") maken in een gezamenlijke verklaring bekend zich te zullen terugtrekken uit het Internationaal Strafhof. Ze zien het instituut als een vertegenwoordiging van het [neokolonialisme](https://nl.wikipedia.org/wiki/Neokolonialisme "Neokolonialisme") en vinden ook dat de rechtspraak er op selectieve gronden gebeurt.   
---|---  
|  [22 sep](https://nl.wikipedia.org/wiki/22_september "22 september") |  [_Jimmy Kimmel Live!_ weer op televisie](https://nl.wikipedia.org/wiki/Jimmy_Kimmel_Live!#Tijdelijke_stopzetting_na_de_moord_op_Charlie_Kirk "Jimmy Kimmel Live!")  
[The Walt Disney Company](https://nl.wikipedia.org/wiki/The_Walt_Disney_Company "The Walt Disney Company"), het moederbedrijf van [ABC](https://nl.wikipedia.org/wiki/American_Broadcasting_Company "American Broadcasting Company"), komt terug op de beslissing om de talkshow _Jimmy Kimmel Live!_ van de buis te halen, en kondigt aan dat [Jimmy Kimmel](https://nl.wikipedia.org/wiki/Jimmy_Kimmel "Jimmy Kimmel") terugkeert op 24 september. De stopzetting na de dreiging van de chef van de overheidsdienst [FCC](https://nl.wikipedia.org/wiki/Federal_Communications_Commission "Federal Communications Commission") werd gezien als [censuur](https://nl.wikipedia.org/wiki/Censuur_\(informatie\) "Censuur \(informatie\)") waarna vele abonnees hun abonnement opzegden en er via sociale media werd opgeroepen hetzelfde te doen.   
---|---  
## [1 oktober in de geschiedenis](https://nl.wikipedia.org/wiki/1_oktober "1 oktober")  
---  
|  [1890](https://nl.wikipedia.org/wiki/1890 "1890") |  [Yosemite National Park](https://nl.wikipedia.org/wiki/Yosemite_National_Park "Yosemite National Park")  
Oprichting van het [Yosemite National Park](https://nl.wikipedia.org/wiki/Yosemite_National_Park "Yosemite National Park") in [Californië](https://nl.wikipedia.org/wiki/Californi%C3%AB_\(hoofdbetekenis\) "Californië \(hoofdbetekenis\)").   
---|---  
|  [1924](https://nl.wikipedia.org/wiki/1924 "1924") |  [Eerste KLM vlucht naar Nederlands-Indië](https://nl.wikipedia.org/wiki/Eerste_KLM_vlucht_naar_Nederlands-Indi%C3%AB "Eerste KLM vlucht naar Nederlands-Indië")  
Een [Fokker F.VII](https://nl.wikipedia.org/wiki/Fokker_F.VII "Fokker F.VII") vertrekt van Schiphol voor de eerste [KLM](https://nl.wikipedia.org/wiki/Koninklijke_Luchtvaart_Maatschappij "Koninklijke Luchtvaart Maatschappij") vlucht naar [Batavia](https://nl.wikipedia.org/wiki/Batavia_\(Nederlands-Indi%C3%AB\) "Batavia \(Nederlands-Indië\)").   
---|---  
|  [1949](https://nl.wikipedia.org/wiki/1949 "1949") |  [Geschiedenis van China](https://nl.wikipedia.org/wiki/Geschiedenis_van_China "Geschiedenis van China")  
[Mao Zedong](https://nl.wikipedia.org/wiki/Mao_Zedong "Mao Zedong") roept de [Volksrepubliek China](https://nl.wikipedia.org/wiki/Volksrepubliek_China "Volksrepubliek China") uit.   
---|---  
## [Zusterprojecten](https://nl.wikipedia.org/wiki/Wikimedia_Foundation "Wikimedia Foundation")
Wikipedia is onderdeel van de [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home "wikimedia:Home"), een [non-profitorganisatie](https://nl.wikipedia.org/wiki/Non-profit "Non-profit"), en heeft diverse zusterprojecten die ook van de wikisoftware gebruikmaken: [![Wikinieuws](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Wikinews-logo.png/40px-Wikinews-logo.png)](https://nl.wikipedia.org/wiki/Bestand:Wikinews-logo.png "Wikinieuws") **[Wikinieuws](https://nl.wikinews.org/wiki/Wikinieuws:Hoofdpagina "n:Wikinieuws:Hoofdpagina")**  
 _Vrije nieuwsbron_ [![WikiWoordenboek](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Wiktionary-logo.svg "WikiWoordenboek") **[WikiWoordenboek](https://en.wiktionary.org/wiki/nl:Hoofdpagina "wiktionary:nl:Hoofdpagina")**  
 _Vrij woordenboek_ [![Wikibooks](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Wikibooks-logo.svg "Wikibooks") **[Wikibooks](https://en.wikibooks.org/wiki/nl:Hoofdpagina "wikibooks:nl:Hoofdpagina")**  
 _Handleidingen & vrije boeken_ [![Wikisource](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Wikisource-logo.svg "Wikisource") **[Wikisource](https://en.wikisource.org/wiki/nl:Hoofdpagina "wikisource:nl:Hoofdpagina")**  
 _Vrije bibliotheek_ [![Wikiquote](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Wikiquote-logo.svg "Wikiquote") **[Wikiquote](https://en.wikiquote.org/wiki/nl:Hoofdpagina "wikiquote:nl:Hoofdpagina")**  
 _Citaten & spreekwoorden_ [![Wikispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Wikispecies-logo.svg "Wikispecies") **[Wikispecies](https://species.wikimedia.org/wiki/Hoofdpagina "species:Hoofdpagina")**  
 _Catalogus van levende wezens_ [![Wikiversity](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Wikiversity-logo.svg "Wikiversity") **[Wikiversity](https://en.wikiversity.org/wiki/Wikiversity:Main_Page "wikiversity:Wikiversity:Main Page")**  
 _Vrije onderwijsprojecten_ [![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Wikivoyage-Logo-v3-icon.svg "Wikivoyage") **[Wikivoyage](https://nl.wikivoyage.org/wiki/Hoofdpagina "voy:Hoofdpagina")**  
 _Vrije, wereldwijde reisgids_ [![Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Commons-logo.svg "Commons") **[Commons](https://commons.wikimedia.org/wiki/Hoofdpagina "commons:Hoofdpagina")**  
 _Vrije media_ [![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Wikidata-logo.svg "Wikidata") **[Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page "d:Wikidata:Main Page")**  
 _Vrije database_ [![Wikifuncties](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Wikifunctions-logo.svg/40px-Wikifunctions-logo.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Wikifunctions-logo.svg "Wikifuncties") **[Wikifuncties](https://www.wikifunctions.org/wiki/ "f:")**  
 _Bibliotheek met codefuncties_ [![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://nl.wikipedia.org/wiki/Bestand:Wikimedia_Community_Logo.svg "Meta-Wiki") **[Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page/nl "m:Main Page/nl")**  
 _Coördinatie_ [![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://nl.wikipedia.org/wiki/Bestand:MediaWiki-2020-icon.svg "MediaWiki") **[MediaWiki](https://www.mediawiki.org/wiki/MediaWiki "mw:MediaWiki")**  
 _Ontwikkeling wiki-software_  
---  
[Perscontact](https://nl.wikipedia.org/wiki/Wikipedia:Pers "Wikipedia:Pers") • [Publiekscontact](https://nl.wikipedia.org/wiki/Portaal:Hulp_en_beheer "Portaal:Hulp en beheer") • [Statistieken](https://nl.wikipedia.org/wiki/Wikipedia:Statistieken "Wikipedia:Statistieken")
Overgenomen van "[https://nl.wikipedia.org/w/index.php?title=Hoofdpagina&oldid=68315324](https://nl.wikipedia.org/w/index.php?title=Hoofdpagina&oldid=68315324)"
[Categorie](https://nl.wikipedia.org/wiki/Categorie:Alles "Categorie:Alles"): 
  * [Alles](https://nl.wikipedia.org/wiki/Categorie:Alles "Categorie:Alles")


353 talen
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – Afar")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – Abchazisch")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – Atjehs")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – Adygees")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – Afrikaans")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – Zwitserduits")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – Zuid-Altaïsch")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – Amhaars")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – Aragonees")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – Oudengels")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – Obolo")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – Angika")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – Arabisch")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – Aramees")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – Marokkaans Arabisch")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – Egyptisch Arabisch")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – Assamees")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – Asturisch")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – Atikamekw")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – Avarisch")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – Awadhi")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – Aymara")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – Azerbeidzjaans")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – Basjkiers")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Balinees")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – Beiers")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – Samogitisch")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarussisch")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – Bataviaans")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница – Bulgaars")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – Bislama")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – Bambara")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – Bengaals")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – Tibetaans")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – Bretons")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – Bosnisch")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – Buginees")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – Catalaans")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – Tsjetsjeens")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – Cebuano")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – Chamorro")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – Choctaw")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – Cherokee")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – Cheyenne")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – Soranî")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – Corsicaans")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – Cree")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – Krim-Tataars")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana – Tsjechisch")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – Kasjoebisch")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – Kerkslavisch")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – Tsjoevasjisch")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – Welsh")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside – Deens")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – Duits")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – Dinka")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – Nedersorbisch")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – Divehi")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – Dzongkha")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – Ewe")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – Grieks")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – Engels")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – Esperanto")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – Spaans")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht – Estisch")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala – Baskisch")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – Extremeens")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – Perzisch")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – Fanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – Fulah")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – Fins")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – Võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – Fijisch")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – Faeröers")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – Fon")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal – Frans")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – Arpitaans")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – Noord-Fries")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – Friulisch")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – Fries")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – Iers")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – Gagaoezisch")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – Ganyu")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – Schots-Gaelisch")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – Galicisch")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – Gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – Guaraní")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – Gorontalo")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – Gothisch")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – Gujarati")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – Wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – Gurune")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – Manx")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – Hausa")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – Hakka")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – Hawaïaans")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – Hebreeuws")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – Hindi")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – Fijisch Hindi")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – Hiri Motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – Kroatisch")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – Oppersorbisch")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Haïtiaans Creools")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – Hongaars")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ – Armeens")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – Herero")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – Interlingua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – Iban")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama – Indonesisch")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – Interlingue")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – Igbo")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – Inupiaq")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – Iloko")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – Ingoesjetisch")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – Ido")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – IJslands")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – Italiaans")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – Inuktitut")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – Japans")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – Jamaicaans Creools")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – Lojban")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – Javaans")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – Georgisch")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – Karakalpaks")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – Kabylisch")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – Kabardisch")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – Tyap")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – Kongo")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – Gikuyu")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – Kuanyama")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – Kazachs")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – Groenlands")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – Khmer")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – Kannada")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – Koreaans")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – Komi-Permjaaks")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – Kanuri")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – Karatsjaj-Balkarisch")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – Kasjmiri")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – Kölsch")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – Koerdisch")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – Komi")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – Cornish")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – Kirgizisch")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima – Latijn")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – Ladino")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – Luxemburgs")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – Lezgisch")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – Luganda")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – Limburgs")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – Ligurisch")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – Lombardisch")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – Lingala")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – Laotiaans")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – Noordelijk Luri")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – Litouws")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – Letgaals")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – Lets")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – Madoerees")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – Maithili")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – Moksja")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – Malagassisch")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – Marshallees")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – Maori")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – Minangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – Macedonisch")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – Malayalam")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – Mongools")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – Meitei")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – Mossi")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – Marathi")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – West-Mari")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – Maleis")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – Maltees")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – Creek")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – Mirandees")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – Birmaans")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – Erzja")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – Mazanderani")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – Napolitaans")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – Nedersaksisch")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – Nederduits")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – Nepalees")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – Newari")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – Ndonga")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – Nias")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – Noors - Nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – Noors - Bokmål")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – Novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – N’Ko")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – Zuid-Ndbele")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – Noord-Sotho")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – Navajo")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – Nyanja")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – Occitaans")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – Afaan Oromo")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – Odia")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – Ossetisch")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – Punjabi")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – Pangasinan")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – Pampanga")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – Papiaments")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – Picardisch")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – Nigeriaans Pidgin")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – Pennsylvania-Duits")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – Paltsisch")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – Pali")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – Pools")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – Piëmontees")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – Pontisch")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – Pasjtoe")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – Portugees")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – Quechua")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – Reto-Romaans")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – Kirundi")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – Roemeens")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – Aroemeens")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – Russisch")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – Roetheens")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – Kinyarwanda")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – Sanskriet")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – Jakoets")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – Santali")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – Sardijns")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – Siciliaans")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – Schots")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – Sindhi")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – Noord-Samisch")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – Sango")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – Servo-Kroatisch")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – Tashelhiyt")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – Shan")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – Singalees")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – Slowaaks")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – Sloveens")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – Samoaans")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – Inari-Samisch")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – Shona")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – Somalisch")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – Albanees")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – Servisch")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – Sranantongo")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – Swazi")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – Zuid-Sotho")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – Saterfries")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – Soendanees")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – Zweeds")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – Swahili")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – Silezisch")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – Tamil")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – Tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – Telugu")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – Tetun")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – Tadzjieks")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – Thai")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – Tigrinya")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – Tigre")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – Turkmeens")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – Tagalog")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – Talysh")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – Tswana")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – Tongaans")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – Tok Pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – Turks")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – Taroko")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – Tsonga")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – Tataars")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – Toemboeka")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – Twi")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – Tahitiaans")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – Toevaans")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – Oedmoerts")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – Oeigoers")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – Oekraïens")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – Urdu")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – Oezbeeks")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – Venda")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – Venetiaans")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – Wepsisch")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – Vietnamees")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – West-Vlaams")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – Volapük")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – Waals")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – Waray")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – Wolof")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – Wuyu")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – Kalmuks")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – Xhosa")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – Mingreels")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – Jiddisch")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – Yoruba")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – Zhuang")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – Zeeuws")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – Standaard Marokkaanse Tamazight")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 – Chinees")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – Klassiek Chinees")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – Minnanyu")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – Kantonees")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – Zoeloe")


[Koppelingen bewerken](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Taalkoppelingen bewerken")
  * Deze pagina is voor het laatst bewerkt op 30 okt 2024 om 10:13.
  * De tekst is beschikbaar onder de licentie [Creative Commons Naamsvermelding/Gelijk delen](https://creativecommons.org/licenses/by-sa/4.0/deed.nl), er kunnen aanvullende voorwaarden van toepassing zijn. Zie de [gebruiksvoorwaarden](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use/nl) voor meer informatie.  
Wikipedia® is een geregistreerd handelsmerk van de [Wikimedia Foundation, Inc.](https://www.wikimediafoundation.org), een organisatie zonder winstoogmerk.


  * [Privacybeleid](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Over Wikipedia](https://nl.wikipedia.org/wiki/Wikipedia)
  * [Voorbehoud](https://nl.wikipedia.org/wiki/Wikipedia:Algemeen_voorbehoud)
  * [Gedragscode](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Ontwikkelaars](https://developer.wikimedia.org)
  * [Statistieken](https://stats.wikimedia.org/#/nl.wikipedia.org)
  * [Cookieverklaring](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Mobiele weergave](https://nl.m.wikipedia.org/w/index.php?title=Hoofdpagina&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://nl.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://nl.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Zoeken
Zoeken
Hoofdpagina
[](https://nl.wikipedia.org/wiki/Hoofdpagina) [](https://nl.wikipedia.org/wiki/Hoofdpagina) [](https://nl.wikipedia.org/wiki/Hoofdpagina) [](https://nl.wikipedia.org/wiki/Hoofdpagina) [](https://nl.wikipedia.org/wiki/Hoofdpagina) [](https://nl.wikipedia.org/wiki/Hoofdpagina) [](https://nl.wikipedia.org/wiki/Hoofdpagina) [](https://nl.wikipedia.org/wiki/Hoofdpagina)
353 talen [Onderwerp toevoegen ](https://nl.wikipedia.org/wiki/Hoofdpagina)
