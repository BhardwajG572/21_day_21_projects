[Vés al contingut](https://ca.wikipedia.org/wiki/Portada#bodyContent)
Menú principal
Menú principal
mou a la barra lateral amaga
Navegació 
  * [Portada](https://ca.wikipedia.org/wiki/Portada "Visiteu la pàgina principal \[z\]")
  * [Article a l'atzar](https://ca.wikipedia.org/wiki/Especial:Article_aleatori "Carrega una pàgina a l’atzar \[x\]")
  * [Articles de qualitat](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Articles_de_qualitat)
  * [Pàgines especials](https://ca.wikipedia.org/wiki/Especial:P%C3%A0gines_especials)


Comunitat 
  * [Portal viquipedista](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Portal "Sobre el projecte, què podeu fer, on trobareu les coses")
  * [Agenda d'actes](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Trobades)
  * [Canvis recents](https://ca.wikipedia.org/wiki/Especial:Canvis_recents "Una llista dels canvis recents al wiki \[r\]")
  * [La taverna](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:La_taverna)
  * [Contacte](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Contacte)
  * [Xat](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Canals_IRC)
  * [Ajuda](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Ajuda "El lloc per a saber més coses")


[ ![](https://ca.wikipedia.org/static/images/icons/wikipedia.png) ![Viquipèdia](https://ca.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-ca.svg) ![l'Enciclopèdia Lliure](https://ca.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-ca.svg) ](https://ca.wikipedia.org/wiki/Portada)
[Cerca ](https://ca.wikipedia.org/wiki/Especial:Cerca "Cerca a la Viquipèdia \[f\]")
Cerca
Aparença
  * [Donatius](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ca.wikipedia.org&uselang=ca)
  * [Crea un compte](https://ca.wikipedia.org/w/index.php?title=Especial:Crea_compte&returnto=Portada "Us animem a crear un compte i iniciar una sessió, encara que no és obligatori")
  * [Inicia la sessió](https://ca.wikipedia.org/w/index.php?title=Especial:Registre_i_entrada&returnto=Portada "Us animem a registrar-vos, però no és obligatori \[o\]")


Eines personals
  * [Donatius](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ca.wikipedia.org&uselang=ca)
  * [Crea un compte](https://ca.wikipedia.org/w/index.php?title=Especial:Crea_compte&returnto=Portada "Us animem a crear un compte i iniciar una sessió, encara que no és obligatori")
  * [Inicia la sessió](https://ca.wikipedia.org/w/index.php?title=Especial:Registre_i_entrada&returnto=Portada "Us animem a registrar-vos, però no és obligatori \[o\]")


# Portada
  * [Portada](https://ca.wikipedia.org/wiki/Portada "Vegeu el contingut de la pàgina \[c\]")
  * [Discussió](https://ca.wikipedia.org/wiki/Discussi%C3%B3:Portada "Discussió sobre el contingut d'aquesta pàgina \[t\]")


català
  * [Mostra](https://ca.wikipedia.org/wiki/Portada)
  * [Mostra el codi](https://ca.wikipedia.org/w/index.php?title=Portada&action=edit "Aquesta pàgina està protegida.
Podeu veure'n el codi font. \[e\]")
  * [Mostra l'historial](https://ca.wikipedia.org/w/index.php?title=Portada&action=history "Versions antigues d'aquesta pàgina \[h\]")


Eines
Eines
mou a la barra lateral amaga
Accions 
  * [Mostra](https://ca.wikipedia.org/wiki/Portada)
  * [Mostra el codi](https://ca.wikipedia.org/w/index.php?title=Portada&action=edit)
  * [Mostra l'historial](https://ca.wikipedia.org/w/index.php?title=Portada&action=history)


General 
  * [Què hi enllaça](https://ca.wikipedia.org/wiki/Especial:Enlla%C3%A7os/Portada "Una llista de totes les pàgines wiki que enllacen amb aquesta \[j\]")
  * [Canvis relacionats](https://ca.wikipedia.org/wiki/Especial:Seguiment/Portada "Canvis recents a pàgines enllaçades des d'aquesta pàgina \[k\]")
  * [Enllaç permanent](https://ca.wikipedia.org/w/index.php?title=Portada&oldid=34514349 "Enllaç permanent a aquesta revisió de la pàgina")
  * [Informació de la pàgina](https://ca.wikipedia.org/w/index.php?title=Portada&action=info "Més informació sobre aquesta pàgina")
  * [Citau aquest article](https://ca.wikipedia.org/w/index.php?title=Especial:Citau&page=Portada&id=34514349&wpFormIdentifier=titleform "Informació sobre com citar aquesta pàgina")
  * [Obtén una URL abreujada](https://ca.wikipedia.org/w/index.php?title=Especial:UrlShortener&url=https%3A%2F%2Fca.wikipedia.org%2Fwiki%2FPortada)
  * [Descarrega el codi QR](https://ca.wikipedia.org/w/index.php?title=Especial:QrCode&url=https%3A%2F%2Fca.wikipedia.org%2Fwiki%2FPortada)


Imprimeix/exporta 
  * [Crea un llibre](https://ca.wikipedia.org/w/index.php?title=Especial:Llibre&bookcmd=book_creator&referer=Portada)
  * [Baixa com a PDF](https://ca.wikipedia.org/w/index.php?title=Especial:DownloadAsPdf&page=Portada&action=show-download-screen)
  * [Versió per a impressora](https://ca.wikipedia.org/w/index.php?title=Portada&printable=yes "Versió per a impressió d'aquesta pàgina \[p\]")


En altres projectes 
  * [Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Sensibilizacion Wikimèdia](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Viquiespècies](https://species.wikimedia.org/wiki/Main_Page)
  * [Viquillibres](https://ca.wikibooks.org/wiki/Portada)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Viquinotícies](https://ca.wikinews.org/wiki/Portada)
  * [Viquidites](https://ca.wikiquote.org/wiki/Portada)
  * [Viquitexts](https://ca.wikisource.org/wiki/P%C3%A0gina_principal)
  * [Viccionari](https://ca.wiktionary.org/wiki/Viccionari:Portada)
  * [Element a Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Enllaç a l'element del repositori de dades connectat \[g\]")


Aparença
mou a la barra lateral amaga
De la Viquipèdia, l'enciclopèdia lliure
**Viquipèdia**  
L'enciclopèdia lliure que tothom pot editar.  
[781.750](https://ca.wikipedia.org/wiki/Especial:Estad%C3%ADstiques "Especial:Estadístiques") articles  
2.019 participants actius  

[Col·labora-hi](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Introducci%C3%B3 "Viquipèdia:Introducció")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8b/Wikipedia-logo-blank.svg/500px-Wikipedia-logo-blank.svg.png)
Viquipèdia  
L'enciclopèdia lliure que tothom pot editar
**[781.750](https://ca.wikipedia.org/wiki/Especial:Estad%C3%ADstiques "Especial:Estadístiques")****articles**  
2.019 participants actius 
[Col·labora-hi](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Introducci%C3%B3 "Viquipèdia:Introducció") |  [Article a l'atzar](https://ca.wikipedia.org/wiki/Especial:Article_aleatori "Especial:Article aleatori")  
---|---  
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Portrait_Gandhi.jpg/1700px-Portrait_Gandhi.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Portrait_Gandhi.jpg)
Article del dia
[Mohandas Gandhi](https://ca.wikipedia.org/wiki/Mohandas_Gandhi "Mohandas Gandhi")
[Mohandas Karamchand Gandhi](https://ca.wikipedia.org/wiki/Mohandas_Gandhi "Mohandas Gandhi") ([2 d'octubre](https://ca.wikipedia.org/wiki/2_d%27octubre "2 d'octubre") de [1869](https://ca.wikipedia.org/wiki/1869 "1869") – [30 de gener](https://ca.wikipedia.org/wiki/30_de_gener "30 de gener") de [1948](https://ca.wikipedia.org/wiki/1948 "1948")) va ser un pensador i polític indi. Se'l coneix amb el sobrenom de Mahatma o Mahatma Gandhi. Fou un dels pares de la independència de la nació índia i la desaparició del [Raj Britànic](https://ca.wikipedia.org/wiki/Raj_Brit%C3%A0nic "Raj Britànic") mitjançant l'ús de la no violència. [- Vegeu informació sobre la imatge](https://ca.wikipedia.org/wiki/Fitxer:MKGandhi.jpg "Fitxer:MKGandhi.jpg")
## [Mohandas Gandhi](https://ca.wikipedia.org/wiki/Mohandas_Gandhi "Mohandas Gandhi")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Portrait_Gandhi.jpg/120px-Portrait_Gandhi.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Portrait_Gandhi.jpg)
[Mohandas Karamchand Gandhi](https://ca.wikipedia.org/wiki/Mohandas_Gandhi "Mohandas Gandhi") ([2 d'octubre](https://ca.wikipedia.org/wiki/2_d%27octubre "2 d'octubre") de [1869](https://ca.wikipedia.org/wiki/1869 "1869") – [30 de gener](https://ca.wikipedia.org/wiki/30_de_gener "30 de gener") de [1948](https://ca.wikipedia.org/wiki/1948 "1948")) va ser un pensador i polític indi. Se'l coneix amb el sobrenom de Mahatma o Mahatma Gandhi. Fou un dels pares de la independència de la nació índia i la desaparició del [Raj Britànic](https://ca.wikipedia.org/wiki/Raj_Brit%C3%A0nic "Raj Britànic") mitjançant l'ús de la no violència. 
  

  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Vista_de_l%E2%80%99Alguer.jpg/1700px-Vista_de_l%E2%80%99Alguer.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Vista_de_l%E2%80%99Alguer.jpg)
Imatge del dia
[Catapulta](https://ca.wikipedia.org/wiki/Catapulta "Catapulta") de la muralla de l'Hospital amb lo campanil de la [Catedral de l'Alguer](https://ca.wikipedia.org/wiki/Catedral_de_l%27Alguer "Catedral de l'Alguer") al fondo. [- Vegeu informació sobre la imatge](https://ca.wikipedia.org/wiki/Fitxer:Vista_de_l%E2%80%99Alguer.jpg "Fitxer:Vista de l’Alguer.jpg")
## Imatge del dia
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Vista_de_l%E2%80%99Alguer.jpg/250px-Vista_de_l%E2%80%99Alguer.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Vista_de_l%E2%80%99Alguer.jpg)
[Catapulta](https://ca.wikipedia.org/wiki/Catapulta "Catapulta") de la muralla de l'Hospital amb lo campanil de la [Catedral de l'Alguer](https://ca.wikipedia.org/wiki/Catedral_de_l%27Alguer "Catedral de l'Alguer") al fondo. 
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Viquiprojecte_articles_absents_%28portada%29.jpg/1700px-Viquiprojecte_articles_absents_%28portada%29.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Viquiprojecte_articles_absents_\(portada\).jpg)
Projecte destacat
[Articles absents](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Coordinaci%C3%B3_de_concursos_i_viquiprojectes "Viquipèdia:Coordinació de concursos i viquiprojectes")
Hi ha articles clau en més d'una vintena de Viquipèdies en altres idiomes, però encara absents en català. [Ajuda'ns a reduir aquesta llista](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Coordinaci%C3%B3_de_concursos_i_viquiprojectes "Viquipèdia:Coordinació de concursos i viquiprojectes") i a tenir-los també presents i amb una qualitat digna en la nostra llengua!  
([Informació de la imatge](https://ca.wikipedia.org/wiki/Fitxer:Viquiprojecte_articles_absents_\(portada\).jpg "Fitxer:Viquiprojecte articles absents \(portada\).jpg"))
## Projecte destacat: [Articles absents](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Coordinaci%C3%B3_de_concursos_i_viquiprojectes "Viquipèdia:Coordinació de concursos i viquiprojectes")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Viquiprojecte_articles_absents_%28portada%29.jpg/250px-Viquiprojecte_articles_absents_%28portada%29.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Viquiprojecte_articles_absents_\(portada\).jpg)
Hi ha articles clau en més d'una vintena de Viquipèdies en altres idiomes, però encara absents en català. [Ajuda'ns a reduir aquesta llista](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Coordinaci%C3%B3_de_concursos_i_viquiprojectes "Viquipèdia:Coordinació de concursos i viquiprojectes") i a tenir-los també presents i amb una qualitat digna en la nostra llengua!  
([Informació de la imatge](https://ca.wikipedia.org/wiki/Fitxer:Viquiprojecte_articles_absents_\(portada\).jpg "Fitxer:Viquiprojecte articles absents \(portada\).jpg"))
  

  



[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Portrait_Gandhi.jpg/1700px-Portrait_Gandhi.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Portrait_Gandhi.jpg)
Article del dia
[Mohandas Gandhi](https://ca.wikipedia.org/wiki/Mohandas_Gandhi "Mohandas Gandhi")
[Mohandas Karamchand Gandhi](https://ca.wikipedia.org/wiki/Mohandas_Gandhi "Mohandas Gandhi") ([2 d'octubre](https://ca.wikipedia.org/wiki/2_d%27octubre "2 d'octubre") de [1869](https://ca.wikipedia.org/wiki/1869 "1869") – [30 de gener](https://ca.wikipedia.org/wiki/30_de_gener "30 de gener") de [1948](https://ca.wikipedia.org/wiki/1948 "1948")) va ser un pensador i polític indi. Se'l coneix amb el sobrenom de Mahatma o Mahatma Gandhi. Fou un dels pares de la independència de la nació índia i la desaparició del [Raj Britànic](https://ca.wikipedia.org/wiki/Raj_Brit%C3%A0nic "Raj Britànic") mitjançant l'ús de la no violència. [- Vegeu informació sobre la imatge](https://ca.wikipedia.org/wiki/Fitxer:MKGandhi.jpg "Fitxer:MKGandhi.jpg")
## [Mohandas Gandhi](https://ca.wikipedia.org/wiki/Mohandas_Gandhi "Mohandas Gandhi")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Portrait_Gandhi.jpg/120px-Portrait_Gandhi.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Portrait_Gandhi.jpg)
[Mohandas Karamchand Gandhi](https://ca.wikipedia.org/wiki/Mohandas_Gandhi "Mohandas Gandhi") ([2 d'octubre](https://ca.wikipedia.org/wiki/2_d%27octubre "2 d'octubre") de [1869](https://ca.wikipedia.org/wiki/1869 "1869") – [30 de gener](https://ca.wikipedia.org/wiki/30_de_gener "30 de gener") de [1948](https://ca.wikipedia.org/wiki/1948 "1948")) va ser un pensador i polític indi. Se'l coneix amb el sobrenom de Mahatma o Mahatma Gandhi. Fou un dels pares de la independència de la nació índia i la desaparició del [Raj Britànic](https://ca.wikipedia.org/wiki/Raj_Brit%C3%A0nic "Raj Britànic") mitjançant l'ús de la no violència. 
  

  

[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Vista_de_l%E2%80%99Alguer.jpg/1700px-Vista_de_l%E2%80%99Alguer.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Vista_de_l%E2%80%99Alguer.jpg)
Imatge del dia
[Catapulta](https://ca.wikipedia.org/wiki/Catapulta "Catapulta") de la muralla de l'Hospital amb lo campanil de la [Catedral de l'Alguer](https://ca.wikipedia.org/wiki/Catedral_de_l%27Alguer "Catedral de l'Alguer") al fondo. [- Vegeu informació sobre la imatge](https://ca.wikipedia.org/wiki/Fitxer:Vista_de_l%E2%80%99Alguer.jpg "Fitxer:Vista de l’Alguer.jpg")
## Imatge del dia
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Vista_de_l%E2%80%99Alguer.jpg/250px-Vista_de_l%E2%80%99Alguer.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Vista_de_l%E2%80%99Alguer.jpg)
[Catapulta](https://ca.wikipedia.org/wiki/Catapulta "Catapulta") de la muralla de l'Hospital amb lo campanil de la [Catedral de l'Alguer](https://ca.wikipedia.org/wiki/Catedral_de_l%27Alguer "Catedral de l'Alguer") al fondo. 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Viquiprojecte_articles_absents_%28portada%29.jpg/1700px-Viquiprojecte_articles_absents_%28portada%29.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Viquiprojecte_articles_absents_\(portada\).jpg)
Projecte destacat
[Articles absents](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Coordinaci%C3%B3_de_concursos_i_viquiprojectes "Viquipèdia:Coordinació de concursos i viquiprojectes")
Hi ha articles clau en més d'una vintena de Viquipèdies en altres idiomes, però encara absents en català. [Ajuda'ns a reduir aquesta llista](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Coordinaci%C3%B3_de_concursos_i_viquiprojectes "Viquipèdia:Coordinació de concursos i viquiprojectes") i a tenir-los també presents i amb una qualitat digna en la nostra llengua!  
([Informació de la imatge](https://ca.wikipedia.org/wiki/Fitxer:Viquiprojecte_articles_absents_\(portada\).jpg "Fitxer:Viquiprojecte articles absents \(portada\).jpg"))
## Projecte destacat: [Articles absents](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Coordinaci%C3%B3_de_concursos_i_viquiprojectes "Viquipèdia:Coordinació de concursos i viquiprojectes")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Viquiprojecte_articles_absents_%28portada%29.jpg/250px-Viquiprojecte_articles_absents_%28portada%29.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Viquiprojecte_articles_absents_\(portada\).jpg)
Hi ha articles clau en més d'una vintena de Viquipèdies en altres idiomes, però encara absents en català. [Ajuda'ns a reduir aquesta llista](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Coordinaci%C3%B3_de_concursos_i_viquiprojectes "Viquipèdia:Coordinació de concursos i viquiprojectes") i a tenir-los també presents i amb una qualitat digna en la nostra llengua!  
([Informació de la imatge](https://ca.wikipedia.org/wiki/Fitxer:Viquiprojecte_articles_absents_\(portada\).jpg "Fitxer:Viquiprojecte articles absents \(portada\).jpg"))
  

  

1 d'octubre
* * *
La **[Global Sumud Flotilla](https://ca.wikipedia.org/wiki/Global_Sumud_Flotilla "Global Sumud Flotilla")** és interceptada per les **[Forces de Defensa d'Israel](https://ca.wikipedia.org/wiki/Forces_de_Defensa_d%27Israel "Forces de Defensa d'Israel")** a la [mar Mediterrània](https://ca.wikipedia.org/wiki/Mar_Mediterr%C3%A0nia "Mar Mediterrània") abans d'arribar a la [Franja de Gaza](https://ca.wikipedia.org/wiki/Franja_de_Gaza "Franja de Gaza"). 
  

28 de setembre
* * *
S'envia una alerta d'emergència **[ES-Alert](https://ca.wikipedia.org/wiki/Alerta_d%27emerg%C3%A8ncies_al_m%C3%B2bil_de_la_Uni%C3%B3_Europea "Alerta d'emergències al mòbil de la Unió Europea")** als telèfons de les demarcacions de [València](https://ca.wikipedia.org/wiki/Prov%C3%ADncia_de_Val%C3%A8ncia "Província de València"), [Castelló](https://ca.wikipedia.org/wiki/Prov%C3%ADncia_de_Castell%C3%B3 "Província de Castelló") i [Terres de l'Ebre](https://ca.wikipedia.org/wiki/Terres_de_l%27Ebre "Terres de l'Ebre") per risc d'**[inundacions](https://ca.wikipedia.org/wiki/Inundaci%C3%B3 "Inundació")** als respectius [litorals](https://ca.wikipedia.org/wiki/Litoral "Litoral"), 11 mesos després de la [gota freda de l'Horta Sud](https://ca.wikipedia.org/wiki/Gota_freda_de_2024_al_Pa%C3%ADs_Valenci%C3%A0 "Gota freda de 2024 al País Valencià"). 
  

28 de setembre
* * *
S'inaugura el **[pont del canyó de Huajiang](https://ca.wikipedia.org/wiki/Pont_del_cany%C3%B3_de_Huajiang "Pont del canyó de Huajiang")** , un [pont penjant](https://ca.wikipedia.org/wiki/Pont_penjant "Pont penjant") de la [província xinesa](https://ca.wikipedia.org/wiki/Prov%C3%ADncies_de_la_Xina "Províncies de la Xina") de **[Guizhou](https://ca.wikipedia.org/wiki/Guizhou "Guizhou")** , el més alt del món. 
  

25 de setembre
* * *
L'espluguina **[Paula Blasi](https://ca.wikipedia.org/wiki/Paula_Blasi_Cairol "Paula Blasi Cairol")** guanya la medalla de bronze en el **[campionat del món en ruta sub-23](https://ca.wikipedia.org/wiki/Campionats_del_m%C3%B3n_de_ciclisme_en_ruta_de_2025 "Campionats del món de ciclisme en ruta de 2025")**. 
  

[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Arbcom_ru_editing.svg/20px-Arbcom_ru_editing.svg.png)](https://ca.wikipedia.org/wiki/Plantilla:Portada600k/actualitat "Plantilla:Portada600k/actualitat")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Huajiang_Canyon_Bridge1.JPG/1500px-Huajiang_Canyon_Bridge1.JPG)](https://ca.wikipedia.org/wiki/Fitxer:Huajiang_Canyon_Bridge1.JPG)
Pont de Huajiang
[Defuncions recents](https://ca.wikipedia.org/wiki/Viquiprojecte:Wikidata/Defuncions_recents "Viquiprojecte:Wikidata/Defuncions recents"): [José Araquistáin](https://ca.wikipedia.org/wiki/Jos%C3%A9_Araquist%C3%A1in_Arrieta "José Araquistáin Arrieta") · [Martin Neary](https://ca.wikipedia.org/wiki/Martin_Neary "Martin Neary") · [Lucian Mureşan](https://ca.wikipedia.org/wiki/Lucian_Mure%C5%9Fan "Lucian Mureşan") · [Assata Shakur](https://ca.wikipedia.org/wiki/Assata_Shakur "Assata Shakur")
  

  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Jane_Goodall_HK.jpg/1500px-Jane_Goodall_HK.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Jane_Goodall_HK.jpg)
[Jane Goodall](https://ca.wikipedia.org/wiki/Jane_Goodall "Jane Goodall")
[Dame Valerie Jane Goodall](https://ca.wikipedia.org/wiki/Jane_Goodall "Jane Goodall") [PhD](https://ca.wikipedia.org/wiki/PhD "PhD"), [DBE](https://ca.wikipedia.org/wiki/DBE "DBE"), nascuda **Valerie Jane Morris-Goodall** ([Londres](https://ca.wikipedia.org/wiki/Londres "Londres"), [Anglaterra](https://ca.wikipedia.org/wiki/Anglaterra "Anglaterra"), [3 d'abril](https://ca.wikipedia.org/wiki/3_d%27abril "3 d'abril") de [1934](https://ca.wikipedia.org/wiki/1934 "1934") - [1 d'octubre](https://ca.wikipedia.org/wiki/1_d%27octubre "1 d'octubre") de [2025](https://ca.wikipedia.org/wiki/2025 "2025") ) va ser una [primatòloga](https://ca.wikipedia.org/wiki/Primatologia "Primatologia") i [antropòloga](https://ca.wikipedia.org/wiki/Antrop%C3%B2leg "Antropòleg") anglesa. Era considerada la principal experta en [ximpanzés](https://ca.wikipedia.org/wiki/Ximpanz%C3%A9s "Ximpanzés"), després de més de seixanta anys estudiant les interaccions socials i familiars dels ximpanzés salvatges. El 1960 Goodall va anar per primera vegada al [Parc Nacional de Gombe Stream](https://ca.wikipedia.org/wiki/Parc_Nacional_de_Gombe_Stream "Parc Nacional de Gombe Stream") a [Tanzània](https://ca.wikipedia.org/wiki/Tanz%C3%A0nia "Tanzània"), on va presenciar comportaments semblants als humans entre els ximpanzés, inclosos conflictes. 
[(Informació sobre la imatge)](https://ca.wikipedia.org/wiki/Fitxer:Jane_Goodall_HK.jpg "Fitxer:Jane Goodall HK.jpg")
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Global_Sumud_Flotilla_Barcelona_20250831_19.jpg/1500px-Global_Sumud_Flotilla_Barcelona_20250831_19.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Global_Sumud_Flotilla_Barcelona_20250831_19.jpg)
[Ana Alcalde](https://ca.wikipedia.org/wiki/Ana_Alcalde "Ana Alcalde")
[Ana Alcalde](https://ca.wikipedia.org/wiki/Ana_Alcalde "Ana Alcalde") ([Granada](https://ca.wikipedia.org/wiki/Granada "Granada"), [1979](https://ca.wikipedia.org/wiki/1979 "1979")), també coneguda com **Hanan** , és una treballadora social, influenciadora i activista que forma part de la [Global Sumud Flotilla](https://ca.wikipedia.org/wiki/Global_Sumud_Flotilla "Global Sumud Flotilla"). 
[(Informació sobre la imatge)](https://ca.wikipedia.org/wiki/Fitxer:Global_Sumud_Flotilla_Barcelona_20250831_19.jpg "Fitxer:Global Sumud Flotilla Barcelona 20250831 19.jpg")
  * [![](https://upload.wikimedia.org/wikipedia/commons/f/f2/Papeleta_Referendum_2017.png)](https://ca.wikipedia.org/wiki/Fitxer:Papeleta_Referendum_2017.png)
[Referèndum sobre la independència de Catalunya de 2017](https://ca.wikipedia.org/wiki/Refer%C3%A8ndum_sobre_la_independ%C3%A8ncia_de_Catalunya_de_2017 "Referèndum sobre la independència de Catalunya de 2017")
El **referèndum sobre la[independència de Catalunya](https://ca.wikipedia.org/wiki/Independentisme_catal%C3%A0 "Independentisme català")** (oficialment **Referèndum d'Autodeterminació de Catalunya** , conegut pel [numerònim](https://ca.wikipedia.org/wiki/Numer%C3%B2nim "Numerònim") **1-O**) és un [referèndum](https://ca.wikipedia.org/wiki/Refer%C3%A8ndum "Referèndum") d'autodeterminació no vinculant que fou celebrat l'[1 d'octubre](https://ca.wikipedia.org/wiki/1_d%27octubre "1 d'octubre") de [2017](https://ca.wikipedia.org/wiki/2017 "2017"). 
[(Informació sobre la imatge)](https://ca.wikipedia.org/wiki/Fitxer:Papeleta_Referendum_2017.png "Fitxer:Papeleta Referendum 2017.png")
  * [![](https://upload.wikimedia.org/wikipedia/commons/8/80/Karte_Suedosteuropa_03_01.png)](https://ca.wikipedia.org/wiki/Fitxer:Karte_Suedosteuropa_03_01.png)
[Balcans](https://ca.wikipedia.org/wiki/Balcans "Balcans")
Els [Balcans](https://ca.wikipedia.org/wiki/Balcans "Balcans") és el nom històric i geogràfic que s'utilitza per a designar el sud-est d'[Europa](https://ca.wikipedia.org/wiki/Europa "Europa") (vegeu més avall la secció _[Definició política actual](https://ca.wikipedia.org/wiki/Portada#Definici%C3%B3_pol%C3%ADtica_actual)_). La regió té una àrea total de 470.000 km² i una població de prop de 53 milions d'habitants. 
[(Informació sobre la imatge)](https://ca.wikipedia.org/wiki/Fitxer:Karte_Suedosteuropa_03_01.png "Fitxer:Karte Suedosteuropa 03 01.png")


Tendències
  

Avui fa 40 anys
Mor [Rock Hudson](https://ca.wikipedia.org/wiki/Rock_Hudson "Rock Hudson"), actor estatunidenc (n. [1925](https://ca.wikipedia.org/wiki/1925 "1925")).
Avui fa 75 anys
[Charles M. Schulz](https://ca.wikipedia.org/wiki/Charles_Monroe_Schulz "Charles Monroe Schulz") publica per primer cop la tira dels _[Peanuts](https://ca.wikipedia.org/wiki/Peanuts "Peanuts")_ , amb els famosos [Charlie Brown](https://ca.wikipedia.org/wiki/Charlie_Brown "Charlie Brown") i el seu gos [Snoopy](https://ca.wikipedia.org/wiki/Snoopy "Snoopy").
Avui fa 80 anys
Neix [Don McLean](https://ca.wikipedia.org/wiki/Don_McLean "Don McLean"), cantautor americà, conegut per la cançó _[American Pie](https://ca.wikipedia.org/wiki/American_Pie_\(can%C3%A7%C3%B3\) "American Pie \(cançó\)")_.
Avui fa 225 anys
Neix [Nat Turner](https://ca.wikipedia.org/wiki/Nat_Turner "Nat Turner"), esclau [afroamericà](https://ca.wikipedia.org/wiki/Negres_americans "Negres americans") que va liderar un aixecament dels seus i va ser [executat](https://ca.wikipedia.org/wiki/Execuci%C3%B3_a_la_forca "Execució a la forca") (m. [1831](https://ca.wikipedia.org/wiki/1831 "1831")).
[![](https://upload.wikimedia.org/wikipedia/commons/a/ad/Rock_Hudson_-_portrait.jpg)](https://ca.wikipedia.org/wiki/Fitxer:Rock_Hudson_-_portrait.jpg)
[Rock Hudson](https://ca.wikipedia.org/wiki/Rock_Hudson "Rock Hudson")
[«](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Efem%C3%A8rides_seleccionades/Octubre "Viquipèdia:Efemèrides seleccionades/Octubre") [1 d'octubre](https://ca.wikipedia.org/wiki/1_d%27octubre "1 d'octubre") · [2 d'octubre](https://ca.wikipedia.org/wiki/2_d%27octubre "2 d'octubre") · [3 d'octubre](https://ca.wikipedia.org/wiki/3_d%27octubre "3 d'octubre") [»](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Efem%C3%A8rides_seleccionades/Octubre "Viquipèdia:Efemèrides seleccionades/Octubre")
  

![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/40px-Wikimedia-logo.svg.png)
La Viquipèdia és part de la família de projectes [sense ànim de lucre](https://ca.wikipedia.org/wiki/Organitzaci%C3%B3_sense_%C3%A0nim_de_lucre "Organització sense ànim de lucre"), multilingües i de [contingut obert](https://ca.wikipedia.org/wiki/Contingut_obert "Contingut obert") de la **[Fundació Wikimedia](https://meta.wikimedia.org/wiki/Wikimedia_movement "m:Wikimedia movement")**.
[![Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://ca.wikipedia.org/wiki/Fitxer:Commons-logo.svg "Commons") **[Commons](https://commons.wikimedia.org/wiki/ "c:")**  
Repositori multimèdia* [![Viquinotícies](https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/Wikinews-logo-51px.png/40px-Wikinews-logo-51px.png)](https://ca.wikipedia.org/wiki/Fitxer:Wikinews-logo-51px.png "Viquinotícies") **[Viquinotícies](https://ca.wikinews.org/wiki/ "n:")**  
Periodisme lliure [![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://ca.wikipedia.org/wiki/Fitxer:Wikimedia_Community_Logo.svg "Meta-Wiki") **[Meta-Wiki](https://meta.wikimedia.org/wiki/ "m:")**  
Coordinació de projectes* [![Viccionari](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Viccionari.png/40px-Viccionari.png)](https://ca.wikipedia.org/wiki/Fitxer:Viccionari.png "Viccionari") **[Viccionari](https://ca.wiktionary.org/wiki/ "wikt:")**  
Diccionari i tesaurus [![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://ca.wikipedia.org/wiki/Fitxer:Wikidata-logo.svg "Wikidata") **[Wikidata](https://www.wikidata.org/wiki/ "d:")**  
Base de dades* [![Viquillibres](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://ca.wikipedia.org/wiki/Fitxer:Wikibooks-logo.svg "Viquillibres") **[Viquillibres](https://ca.wikibooks.org/wiki/ "b:")**  
Llibres de text i manuals [![Viquidites](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://ca.wikipedia.org/wiki/Fitxer:Wikiquote-logo.svg "Viquidites") **[Viquidites](https://ca.wikiquote.org/wiki/ "q:")**  
Citacions i frases fetes [![Viquitexts](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://ca.wikipedia.org/wiki/Fitxer:Wikisource-logo.svg "Viquitexts") **[Viquitexts](https://ca.wikisource.org/wiki/ "s:")**  
Publicacions d'origen [![Viquiespècies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://ca.wikipedia.org/wiki/Fitxer:Wikispecies-logo.svg "Viquiespècies") **[Viquiespècies](https://species.wikimedia.org/wiki/P%C3%A0gina_principal "species:Pàgina principal")**  
Directori d'espècies* [![Wikiversity](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)](https://ca.wikipedia.org/wiki/Fitxer:Wikiversity-logo.svg "Wikiversity") **[Wikiversity](https://en.wikipedia.org/wiki/v: "en:v:")**  
Eines d'aprenentatge* [![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://ca.wikipedia.org/wiki/Fitxer:Wikivoyage-Logo-v3-icon.svg "Wikivoyage") **[Wikivoyage](https://ca.wikivoyage.org/wiki/ "voy:")**  
Guia de viatges* [![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://ca.wikipedia.org/wiki/Fitxer:MediaWiki-2020-icon.svg "MediaWiki") **[MediaWiki](https://www.mediawiki.org/wiki/ "mw:")**  
Programació wiki*  
---  
*Projecte sense versió en català o parcialment traduït  
Obtingut de «[https://ca.wikipedia.org/w/index.php?title=Portada&oldid=34514349](https://ca.wikipedia.org/w/index.php?title=Portada&oldid=34514349)»
[Categoria](https://ca.wikipedia.org/wiki/Especial:Categorias "Especial:Categorias"): 
  * [Portades de la Viquipèdia](https://ca.wikipedia.org/wiki/Categoria:Portades_de_la_Viquip%C3%A8dia "Categoria:Portades de la Viquipèdia")


353 llengües
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page - àfar")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа - abkhaz")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue - atjeh")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ - adigué")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad - afrikaans")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte - alemany suís")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк - altaic meridional")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ - amhàric")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw - Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada - aragonès")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet - anglès antic")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu - obolo")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ - angika")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة - àrab")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ - arameu")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا - Moroccan Arabic")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه - àrab egipci")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত - assamès")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada - asturià")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin - atacama")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер - àvar")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola - Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना - awadhi")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi - aimara")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə - azerbaidjanès")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه - South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит - baixkir")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama - balinès")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn - bavarès")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis - Samogitian")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman - Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina - Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman - West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка - belarús")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка - Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé - betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница - búlgar")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना - Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej - bislama")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian - Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ - Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ - bambara")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা - bengalí")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། - tibetà")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা - Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer - bretó")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana - bosnià")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo - Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola - bugui")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан - Russia Buriat")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina - Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk - Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо - txetxè")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid - cebuà")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman - chamorro")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page - choctaw")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ - cherokee")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama - xeiene")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک - kurd central")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra - cors")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ - cree")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife - tàtar de Crimea")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana - txec")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna - caixubi")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница - eslau eclesiàstic")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница - txuvaix")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan - gal·lès")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside - danès")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu - Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite - alemany")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu - Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït - dinka")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri - Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok - baix sòrab")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo - Central Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना - Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ - divehi")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། - dzongka")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ - ewe")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια - grec")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP - Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page - anglès")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo - esperanto")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada - espanyol")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht - estonià")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala - basc")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua - extremeny")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی - persa")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir - fanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo - ful")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu - finès")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht - Võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu - fijià")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða - feroès")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn - fon")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal - francès")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla - Arpitan")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid - frisó septentrional")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl - friülà")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside - frisó occidental")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach - irlandès")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak - gagaús")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 - xinès gan")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal - Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag - gaèlic escocès")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada - gallec")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ - gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha - guaraní")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान - Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo - gorontalo")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 - gòtic")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page - Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ - gujarati")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü - wayú")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure - Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan - Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag - manx")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi - haussa")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p - xinès hakka")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi - hawaià")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי - hebreu")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ - hindi")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna - hindi de Fiji")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page - hiri motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica - croat")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona - alt sòrab")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal - crioll d’Haití")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap - hongarès")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ - armeni")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ - Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page - herero")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal - interlingua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah - iban")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama - indonesi")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine - interlingue")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ - igbo")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo - Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik - inupiak")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid - ilocano")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув - ingúix")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico - ido")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða - islandès")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale - italià")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ - inuktitut")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ - japonès")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej - crioll anglès de Jamaica")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju - lojban")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa - javanès")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი - georgià")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet - karakalpak")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan - cabilenc")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ - kabardí")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu - Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu - tyap")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi - kongo")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang - Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page - kikuiu")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page - kuanyama")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет - kazakh")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa - groenlandès")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម - khmer")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ - kannada")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura - Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 - coreà")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок - komi-permiac")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page - kanuri")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет - karatxai-balkar")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ - caixmiri")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk - kölsch")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk - kurd")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir - Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок - komi")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre - còrnic")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак - kirguís")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima - llatí")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja - judeocastellà")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit - luxemburguès")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин - Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин - lesguià")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef - Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka - ganda")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad - limburguès")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ - lígur")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala - ladí")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala - llombard")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó - lingala")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ - laosià")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ - luri septentrional")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis - lituà")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa - Latgalian")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa - letó")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan - madurès")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना - maithili")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama - Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа - mordovià moksa")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana - malgaix")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page - marshallès")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык - Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga - maori")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo - minangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница - macedoni")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ - malaiàlam")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас - mongol")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ - manipurí")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် - Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo - moore")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ - marathi")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш - mari occidental")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama - malai")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali - maltès")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page - creek")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal - mirandès")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ - birmà")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа - mordovià erza")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه - mazanderani")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl - Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale - napolità")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet - baix alemany")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad - baix saxó")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ - nepalès")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ - newari")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu - ndonga")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama - nias")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina - neerlandès")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside - noruec nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside - noruec bokmål")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine - novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ - n’Ko")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page - ndebele meridional")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde - Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele - sotho septentrional")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi - Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos - navaho")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu - nyanja")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh - occità")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu - Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura - oromo")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା - oriya")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс - osseta")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ - panjabi")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong - pangasinan")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung - pampanga")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal - papiament")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul - picard")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej - pidgin de Nigèria")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt - alemany pennsilvanià")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid - alemany palatí")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta - pali")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij - Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna - polonès")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada - piemontès")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ - Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα - pòntic")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ - paixtu")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal - portuguès")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj - Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa - quítxua")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ - Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala - retoromànic")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin - Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru - rundi")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală - romanès")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã - aromanès")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále - Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок - Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница - rus")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка - Rusyn")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro - ruandès")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् - sànscrit")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй - iacut")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ - santali")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale - sard")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali - sicilià")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page - escocès")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو - sindi")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu - sami septentrional")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî - sango")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica - serbocroat")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut - taixelhit")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ - xan")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව - singalès")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page - Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka - eslovac")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت - Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran - eslovè")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua - samoà")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo - sami d’Inari")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga - shona")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore - somali")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore - albanès")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна - serbi")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira - sranan")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu - swazi")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele - sotho meridional")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede - Saterland Frisian")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas - sondanès")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida - suec")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo - suahili")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ - Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta - silesià")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih - Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் - tàmil")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan - Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ - Tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ - Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ - telugu")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk - tètum")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ - tadjik")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก - tai")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ - tigrinya")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ - tigre")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa - turcman")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina - tagal")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə - talix")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono - setswana")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia - tongalès")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes - tok pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa - turc")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas - taroko")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu - tsonga")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит - tàtar")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu - tumbuka")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw - twi")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a - tahitià")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын - tuvinià")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам - udmurt")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت - uigur")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка - ucraïnès")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول - urdú")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa - uzbek")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani - venda")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio - vènet")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ - vepse")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính - vietnamita")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad - flamenc occidental")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad - volapük")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje - való")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli - waray")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk - wòlof")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 - xinès wu")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх - calmuc")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo - xosa")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა - mingrelià")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט - ídix")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ - ioruba")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz - zhuang")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad - zelandès")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ - amazic estàndard marroquí")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 - xinès")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 - xinès clàssic")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h - xinès min del sud")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 - cantonès")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu - zulu")


[Modifica els enllaços](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Modificau enllaços interlingües")
  * La pàgina va ser modificada per darrera vegada el 19 gen 2025 a les 08:33.
  * El text està disponible sota la [ Llicència de Creative Commons Reconeixement i Compartir-Igual](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Text_de_la_llic%C3%A8ncia_de_Creative_Commons_Reconeixement-Compartir_Igual_4.0_No_adaptada "Viquipèdia:Text de la llicència de Creative Commons Reconeixement-Compartir Igual 4.0 No adaptada"); es poden aplicar termes addicionals. Vegeu les [Condicions d'ús](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use/ca). Wikipedia® (Viquipèdia™) és una [marca registrada](https://ca.wikipedia.org/wiki/Marca_comercial "Marca comercial") de [Wikimedia Foundation, Inc](https://www.wikimediafoundation.org).  



  * [Política de privadesa](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Quant al projecte Viquipèdia](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Quant_a_la_Viquip%C3%A8dia)
  * [Descàrrec de responsabilitat](https://ca.wikipedia.org/wiki/Viquip%C3%A8dia:Av%C3%ADs_d%27exempci%C3%B3_de_responsabilitat)
  * [Codi de conducta](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Desenvolupadors](https://developer.wikimedia.org)
  * [Estadístiques](https://stats.wikimedia.org/#/ca.wikipedia.org)
  * [Declaració de cookies](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Versió per a mòbils](https://ca.wikipedia.org/w/index.php?title=Portada&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://ca.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://ca.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Cerca
Cerca
Portada
[](https://ca.wikipedia.org/wiki/Portada) [](https://ca.wikipedia.org/wiki/Portada) [](https://ca.wikipedia.org/wiki/Portada) [](https://ca.wikipedia.org/wiki/Portada) [](https://ca.wikipedia.org/wiki/Portada) [](https://ca.wikipedia.org/wiki/Portada) [](https://ca.wikipedia.org/wiki/Portada) [](https://ca.wikipedia.org/wiki/Portada)
353 llengües [Afegeix un tema ](https://ca.wikipedia.org/wiki/Portada)
