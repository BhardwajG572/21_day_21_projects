[Saltar para o conteúdo](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal#bodyContent)
Menu principal
Menu principal
mover para a barra lateral ocultar
Navegação 
  * [Página principal](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Visitar a página principal \[z\]")
  * [Conteúdo destacado](https://pt.wikipedia.org/wiki/Portal:Conte%C3%BAdo_destacado)
  * [Eventos atuais](https://pt.wikipedia.org/wiki/Portal:Eventos_atuais "Informação temática sobre eventos atuais")
  * [Esplanada](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Esplanada)
  * [Página aleatória](https://pt.wikipedia.org/wiki/Especial:Aleat%C3%B3ria "Carregar página aleatória \[x\]")
  * [Portais](https://pt.wikipedia.org/wiki/Portal:%C3%8Dndice)
  * [Páginas especiais](https://pt.wikipedia.org/wiki/Especial:P%C3%A1ginas_especiais)
  * [Informar um erro](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Informe_um_erro)


Colaboração 
  * [Boas-vindas](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Boas-vindas)
  * [Ajuda](https://pt.wikipedia.org/wiki/Ajuda:P%C3%A1gina_principal "Um local reservado para auxílio.")
  * [Páginas de testes públicas](https://pt.wikipedia.org/wiki/Ajuda:P%C3%A1gina_de_testes)
  * [Portal comunitário](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Portal_comunit%C3%A1rio "Sobre o projeto")
  * [Mudanças recentes](https://pt.wikipedia.org/wiki/Especial:Mudan%C3%A7as_recentes "Uma lista de mudanças recentes nesta wiki \[r\]")
  * [Manutenção](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Manuten%C3%A7%C3%A3o)
  * [Criar página](https://pt.wikipedia.org/wiki/Ajuda:Guia_de_edi%C3%A7%C3%A3o/Como_come%C3%A7ar_uma_p%C3%A1gina)
  * [Páginas novas](https://pt.wikipedia.org/wiki/Especial:P%C3%A1ginas_novas)
  * [Contato](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Contato)


[ ![](https://pt.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipédia](https://pt.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-fr.svg) ![](https://pt.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-pt.svg) ](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal)
[Busca ](https://pt.wikipedia.org/wiki/Especial:Pesquisar "Pesquisar na Wikipédia \[f\]")
Pesquisar
Aspeto
  * [Doar](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=pt.wikipedia.org&uselang=pt)
  * [Criar uma conta](https://pt.wikipedia.org/w/index.php?title=Especial:Criar_conta&returnto=Wikip%C3%A9dia%3AP%C3%A1gina+principal "É encorajado a criar uma conta e iniciar sessão; no entanto, não é obrigatório")
  * [Entrar](https://pt.wikipedia.org/w/index.php?title=Especial:Entrar&returnto=Wikip%C3%A9dia%3AP%C3%A1gina+principal "Aconselhamos-lhe a criar uma conta na Wikipédia, embora tal não seja obrigatório. \[o\]")


Ferramentas pessoais
  * [Doar](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=pt.wikipedia.org&uselang=pt)
  * [Criar uma conta](https://pt.wikipedia.org/w/index.php?title=Especial:Criar_conta&returnto=Wikip%C3%A9dia%3AP%C3%A1gina+principal "É encorajado a criar uma conta e iniciar sessão; no entanto, não é obrigatório")
  * [Entrar](https://pt.wikipedia.org/w/index.php?title=Especial:Entrar&returnto=Wikip%C3%A9dia%3AP%C3%A1gina+principal "Aconselhamos-lhe a criar uma conta na Wikipédia, embora tal não seja obrigatório. \[o\]")


[ocultar]
#  Wikipédia:Página principal
  * [Página principal](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Ver a página de projeto \[c\]")
  * [Discussão](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia_Discuss%C3%A3o:P%C3%A1gina_principal "Discussão sobre o conteúdo da página \[t\]")


português
  * [Ler](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal)
  * [Ver fonte](https://pt.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:P%C3%A1gina_principal&action=edit "Esta página está protegida.
Só pode ver o conteúdo. \[e\]")
  * [Ver histórico](https://pt.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:P%C3%A1gina_principal&action=history "Edições anteriores desta página. \[h\]")


Ferramentas
Ferramentas
mover para a barra lateral ocultar
Operações 
  * [Ler](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal)
  * [Ver fonte](https://pt.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:P%C3%A1gina_principal&action=edit)
  * [Ver histórico](https://pt.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:P%C3%A1gina_principal&action=history)


Geral 
  * [Páginas afluentes](https://pt.wikipedia.org/wiki/Especial:P%C3%A1ginas_afluentes/Wikip%C3%A9dia:P%C3%A1gina_principal "Lista de todas as páginas que contêm hiperligações para esta \[j\]")
  * [Alterações relacionadas](https://pt.wikipedia.org/wiki/Especial:Altera%C3%A7%C3%B5es_relacionadas/Wikip%C3%A9dia:P%C3%A1gina_principal "Mudanças recentes nas páginas para as quais esta contém hiperligações \[k\]")
  * [Carregar ficheiro](https://pt.wikipedia.org/wiki/Wikipedia:Carregar_ficheiro "Carregar ficheiros \[u\]")
  * [Hiperligação permanente](https://pt.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:P%C3%A1gina_principal&oldid=70150066 "Hiperligação permanente para esta revisão desta página")
  * [Informações da página](https://pt.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:P%C3%A1gina_principal&action=info "Mais informações sobre esta página")
  * [Obter URL encurtado](https://pt.wikipedia.org/w/index.php?title=Especial:UrlShortener&url=https%3A%2F%2Fpt.wikipedia.org%2Fwiki%2FWikip%25C3%25A9dia%3AP%25C3%25A1gina_principal)
  * [Transferir o código QR](https://pt.wikipedia.org/w/index.php?title=Especial:QrCode&url=https%3A%2F%2Fpt.wikipedia.org%2Fwiki%2FWikip%25C3%25A9dia%3AP%25C3%25A1gina_principal)


Imprimir/exportar 
  * [Criar um livro](https://pt.wikipedia.org/w/index.php?title=Especial:Livro&bookcmd=book_creator&referer=Wikip%C3%A9dia%3AP%C3%A1gina+principal)
  * [Transferir como PDF](https://pt.wikipedia.org/w/index.php?title=Especial:DownloadAsPdf&page=Wikip%C3%A9dia%3AP%C3%A1gina_principal&action=show-download-screen)
  * [Versão para impressão](https://pt.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:P%C3%A1gina_principal&printable=yes "Versão para impressão desta página \[p\]")


Noutros projetos 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Fundação Wikimedia](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Divulgação da Wikimedia](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Wikisource multilingue](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikilivros](https://pt.wikibooks.org/wiki/Wikilivros:P%C3%A1gina_principal)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunções](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikinotícias](https://pt.wikinews.org/wiki/P%C3%A1gina_principal)
  * [Wikiquote](https://pt.wikiquote.org/wiki/P%C3%A1gina_principal)
  * [Wikisource](https://pt.wikisource.org/wiki/Wikisource:P%C3%A1gina_principal)
  * [Wikiversidade](https://pt.wikiversity.org/wiki/P%C3%A1gina_principal)
  * [Wikivoyage](https://pt.wikivoyage.org/wiki/P%C3%A1gina_principal)
  * [Wikcionário](https://pt.wiktionary.org/wiki/Wikcion%C3%A1rio:P%C3%A1gina_principal)
  * [Elemento Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Hiperligação para o elemento do repositório de dados \[g\]")


Aspeto
mover para a barra lateral ocultar
Origem: Wikipédia, a enciclopédia livre.
[Boas-vindas](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Boas-vindas "Wikipédia:Boas-vindas") à [Wikipédia](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia "Wikipédia"),  
a [enciclopédia](https://pt.wikipedia.org/wiki/Enciclop%C3%A9dia "Enciclopédia") [livre](https://pt.wikipedia.org/wiki/Conte%C3%BAdo_livre "Conteúdo livre") que todos podem [editar](https://pt.wikipedia.org/wiki/Ajuda:Tutorial/Edi%C3%A7%C3%A3o "Ajuda:Tutorial/Edição"). |  **1 156 761** [artigos](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Artigo "Wikipédia:Artigo") em [português](https://pt.wikipedia.org/wiki/L%C3%ADngua_portuguesa "Língua portuguesa")  
**8 177** [editores ativos](https://pt.wikipedia.org/wiki/Especial:Estat%C3%ADsticas "Especial:Estatísticas")
  * [Ajuda](https://pt.wikipedia.org/wiki/Ajuda:P%C3%A1gina_principal "Ajuda:Página principal")
  * [Índice](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Navegue "Wikipédia:Navegue")
  * [Perguntas](https://pt.wikipedia.org/wiki/Ajuda:Perguntas_frequentes "Ajuda:Perguntas frequentes")
  * [Políticas](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Pol%C3%ADticas_e_recomenda%C3%A7%C3%B5es "Wikipédia:Políticas e recomendações")
  * [Portais](https://pt.wikipedia.org/wiki/Portal:%C3%8Dndice "Portal:Índice")

  
---|---  
[Arte](https://pt.wikipedia.org/wiki/Portal:Arte "Portal:Arte") |  [Biografias](https://pt.wikipedia.org/wiki/Portal:Biografias "Portal:Biografias") |  [Ciência](https://pt.wikipedia.org/wiki/Portal:Ci%C3%AAncia "Portal:Ciência") |  [Filosofia](https://pt.wikipedia.org/wiki/Portal:Filosofia "Portal:Filosofia") |  [Geografia](https://pt.wikipedia.org/wiki/Portal:Geografia "Portal:Geografia") |  [História](https://pt.wikipedia.org/wiki/Portal:Hist%C3%B3ria "Portal:História") |  [Matemática](https://pt.wikipedia.org/wiki/Portal:Matem%C3%A1tica "Portal:Matemática") |  [Sociedade](https://pt.wikipedia.org/wiki/Portal:Sociedade "Portal:Sociedade") |  [Tecnologia](https://pt.wikipedia.org/wiki/Portal:Tecnologia "Portal:Tecnologia")  
---|---|---|---|---|---|---|---|---  
Artigo em destaque
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Battlecruiser_SMS_Goeben_transfered_to_the_Ottoman_Empire_and_renamed_the_Yavuz_1914_%2849911053158%29_%28cropped%29.jpg/250px-Battlecruiser_SMS_Goeben_transfered_to_the_Ottoman_Empire_and_renamed_the_Yavuz_1914_%2849911053158%29_%28cropped%29.jpg)](https://pt.wikipedia.org/wiki/Persegui%C3%A7%C3%A3o_ao_Goeben_e_Breslau "Perseguição ao Goeben e Breslau")
A **[perseguição ao _Goeben_ e _Breslau_](https://pt.wikipedia.org/wiki/Persegui%C3%A7%C3%A3o_ao_Goeben_e_Breslau "Perseguição ao Goeben e Breslau")** foi uma ação naval ocorrida no início da [Primeira Guerra Mundial](https://pt.wikipedia.org/wiki/Primeira_Guerra_Mundial "Primeira Guerra Mundial") entre forças do [Reino Unido](https://pt.wikipedia.org/wiki/Reino_Unido_da_Gr%C3%A3-Bretanha_e_Irlanda "Reino Unido da Grã-Bretanha e Irlanda") sob o comando do [almirante](https://pt.wikipedia.org/wiki/Almirante "Almirante") [sir Berkeley Milne](https://pt.wikipedia.org/wiki/Berkeley_Milne "Berkeley Milne") contra aquelas da [Alemanha](https://pt.wikipedia.org/wiki/Imp%C3%A9rio_Alem%C3%A3o "Império Alemão") sob o comando do [vice-almirante](https://pt.wikipedia.org/wiki/Vice-almirante "Vice-almirante") [Wilhelm Souchon](https://pt.wikipedia.org/wiki/Wilhelm_Souchon "Wilhelm Souchon"). Ela ocorreu entre os dias 4 e 10 de agosto de 1914 no [Mar Mediterrâneo](https://pt.wikipedia.org/wiki/Mar_Mediterr%C3%A2neo "Mar Mediterrâneo") e [Mar Egeu](https://pt.wikipedia.org/wiki/Mar_Egeu "Mar Egeu") quando elementos da Frota do Mediterrâneo britânica tentaram interceptar as duas embarcações da Divisão do Mediterrâneo alemã. 
O [cruzador de batalha](https://pt.wikipedia.org/wiki/Cruzador_de_batalha "Cruzador de batalha") [SMS _Goeben_](https://pt.wikipedia.org/wiki/Yavuz_Sultan_Selim "Yavuz Sultan Selim") e o [cruzador rápido](https://pt.wikipedia.org/wiki/Cruzador_r%C3%A1pido "Cruzador rápido") [SMS _Breslau_](https://pt.wikipedia.org/wiki/Midilli_\(cruzador\) "Midilli \(cruzador\)") da [Marinha Imperial Alemã](https://pt.wikipedia.org/wiki/Marinha_Imperial_Alem%C3%A3 "Marinha Imperial Alemã") ficaram presos no Mediterrâneo com o início da guerra e assim foram instruídos a navegar para [Constantinopla](https://pt.wikipedia.org/wiki/Constantinopla "Constantinopla"), no [Império Otomano](https://pt.wikipedia.org/wiki/Imp%C3%A9rio_Otomano "Império Otomano"). Forças britânicas foram enviadas atrás deles, mas inicialmente não atacaram porque na época o Reino Unido e a Alemanha ainda não estavam em guerra. Os alemães reabasteceram na [Itália](https://pt.wikipedia.org/wiki/Reino_de_It%C3%A1lia_\(1861%E2%80%931946\) "Reino de Itália \(1861–1946\)") e escaparam por uma mistura de ordens contraditórias, cautela e recusa por parte de Milne de acreditar que eles estavam realmente seguindo para Constantinopla. (**[Artigo completo...](https://pt.wikipedia.org/wiki/Persegui%C3%A7%C3%A3o_ao_Goeben_e_Breslau "Perseguição ao Goeben e Breslau")**) 
Destacados recentemente: 
  * [_25_ (álbum)](https://pt.wikipedia.org/wiki/25_\(%C3%A1lbum\) "25 \(álbum\)")
  * [Espelhos nas culturas mesoamericanas](https://pt.wikipedia.org/wiki/Espelhos_nas_culturas_mesoamericanas "Espelhos nas culturas mesoamericanas")
  * _[O Segredo de Brokeback Mountain](https://pt.wikipedia.org/wiki/O_Segredo_de_Brokeback_Mountain "O Segredo de Brokeback Mountain")_


Compartilhe: [![Compartilhe via Facebook](https://upload.wikimedia.org/wikipedia/commons/thumb/2/22/Icon_Facebook.svg/20px-Icon_Facebook.svg.png)](https://www.facebook.com/sharer.php?u=http://pt.wikipedia.org/wiki/Persegui%C3%A7%C3%A3o_ao_Goeben_e_Breslau) [![Compartilhe via X](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/X_icon.svg/20px-X_icon.svg.png)](https://x.com/share?url=http://pt.wikipedia.org/wiki/Persegui%C3%A7%C3%A3o_ao_Goeben_e_Breslau&via=Wikipt&text=Veja+o+%23ArtigoEmDestaque+da+Wikip%C3%A9dia+em+portugu%C3%AAs+em&related=Wikipedia)
[Artigos destacados](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Artigos_destacados "Wikipédia:Artigos destacados"): [1512](https://pt.wikipedia.org/wiki/Categoria:!Artigos_destacados "Categoria:!Artigos destacados") • [Artigos bons](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Artigos_bons "Wikipédia:Artigos bons"): [1923](https://pt.wikipedia.org/wiki/Categoria:!Artigos_bons "Categoria:!Artigos bons")
Eventos atuais
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Jane-goodall.jpg/250px-Jane-goodall.jpg)](https://pt.wikipedia.org/wiki/Jane_Goodall "Jane Goodall")
  * **[Jane Goodall](https://pt.wikipedia.org/wiki/Jane_Goodall "Jane Goodall")** _(imagem)_ , [primatologista](https://pt.wikipedia.org/wiki/Primatologista "Primatologista") britânica conhecida pelo estudo das interações sociais de [chimpanzés](https://pt.wikipedia.org/wiki/Chimpanz%C3%A9s "Chimpanzés"), morre aos 91 anos.
  * **[Sismo](https://pt.wikipedia.org/wiki/Sismo_de_Cebu_de_2025 "Sismo de Cebu de 2025")** de magnitude 6,9 atinge [Cebu](https://pt.wikipedia.org/wiki/Cebu "Cebu"), [Filipinas](https://pt.wikipedia.org/wiki/Filipinas "Filipinas"), deixando mais de 72 mortos.
  * **[Ponte do Cânion Huajiang](https://pt.wikipedia.org/wiki/Ponte_do_C%C3%A2nion_Huajiang "Ponte do Cânion Huajiang")** , a mais alta do mundo, com 625 metros de altura, é inaugurada na [província](https://pt.wikipedia.org/wiki/Prov%C3%ADncias_da_China "Províncias da China") de [Guizhou](https://pt.wikipedia.org/wiki/Guizhou "Guizhou"), [China](https://pt.wikipedia.org/wiki/China "China").
  * **[Ataque numa capela](https://pt.wikipedia.org/wiki/Ataque_na_igreja_de_Grand_Blanc "Ataque na igreja de Grand Blanc")** de [A Igreja de Jesus Cristo dos Santos dos Últimos Dias](https://pt.wikipedia.org/wiki/A_Igreja_de_Jesus_Cristo_dos_Santos_dos_%C3%9Altimos_Dias "A Igreja de Jesus Cristo dos Santos dos Últimos Dias") de [Grand Blanc](https://pt.wikipedia.org/wiki/Grand_Blanc "Grand Blanc"), [Michigan](https://pt.wikipedia.org/wiki/Michigan "Michigan"), [Estados Unidos](https://pt.wikipedia.org/wiki/Estados_Unidos "Estados Unidos"), deixa cinco mortos e oito feridos durante culto e homenagem póstuma ao [presidente da Igreja](https://pt.wikipedia.org/wiki/Presidente_da_Igreja_\(Santos_dos_%C3%9Altimos_Dias\) "Presidente da Igreja \(Santos dos Últimos Dias\)"), [Russell M. Nelson](https://pt.wikipedia.org/wiki/Russell_M._Nelson "Russell M. Nelson").


**[Eventos a decorrer](https://pt.wikipedia.org/wiki/Portal:Eventos_atuais "Portal:Eventos atuais")** : [Guerra de Gaza](https://pt.wikipedia.org/wiki/Guerra_de_Gaza_\(2023%E2%80%93presente\) "Guerra de Gaza \(2023–presente\)") • [Guerra Rússia-Ucrânia](https://pt.wikipedia.org/wiki/Invas%C3%A3o_da_Ucr%C3%A2nia_pela_R%C3%BAssia_\(2022%E2%80%93presente\) "Invasão da Ucrânia pela Rússia \(2022–presente\)") • [Guerra Civil no Sudão](https://pt.wikipedia.org/wiki/Guerra_Civil_no_Sud%C3%A3o_\(2023%E2%80%93presente\) "Guerra Civil no Sudão \(2023–presente\)")   
**[Mortes recentes](https://pt.wikipedia.org/wiki/Mortes_em_2025 "Mortes em 2025")** : [José Antonio Álvarez Sánchez](https://pt.wikipedia.org/wiki/Jos%C3%A9_Antonio_%C3%81lvarez_S%C3%A1nchez "José Antonio Álvarez Sánchez") • [Gilsinho](https://pt.wikipedia.org/wiki/Gilsinho "Gilsinho") • [Manuel de Portugal](https://pt.wikipedia.org/wiki/Manuel_de_Portugal_\(cronista\) "Manuel de Portugal \(cronista\)") • [Berta Loran](https://pt.wikipedia.org/wiki/Berta_Loran "Berta Loran") • [Paulo Soares](https://pt.wikipedia.org/wiki/Paulo_Soares "Paulo Soares") • [Henrique Lins de Barros](https://pt.wikipedia.org/wiki/Henrique_Lins_de_Barros "Henrique Lins de Barros")
[Mais eventos atuais](https://pt.wikipedia.org/wiki/Portal:Eventos_atuais "Portal:Eventos atuais") • [Sugestões](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Eventos_atuais/Propostas "Wikipédia:Eventos atuais/Propostas")  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikinews-logo.svg) [Wikinotícias](https://pt.wikinews.org/wiki/P%C3%A1gina_principal "n:Página principal")
2 de outubro na história
[![Mahatma Gandhi](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Portrait_Gandhi.jpg/250px-Portrait_Gandhi.jpg)](https://pt.wikipedia.org/wiki/Ficheiro:Portrait_Gandhi.jpg "Mahatma Gandhi")Mahatma Gandhi
**[Dia Internacional da Não-Violência](https://pt.wikipedia.org/wiki/Dia_Internacional_da_N%C3%A3o-Viol%C3%AAncia "Dia Internacional da Não-Violência")** (2007); [Dia da Independência](https://pt.wikipedia.org/wiki/Dia_da_Independ%C3%AAncia "Dia da Independência") da **[Guiné](https://pt.wikipedia.org/wiki/Guin%C3%A9 "Guiné")** (1958) 
  * [1187](https://pt.wikipedia.org/wiki/1187 "1187") – A cidade de [Jerusalém](https://pt.wikipedia.org/wiki/Jerusal%C3%A9m "Jerusalém") é **[conquistada](https://pt.wikipedia.org/wiki/Cerco_de_Jerusal%C3%A9m_\(1187\) "Cerco de Jerusalém \(1187\)")** pelo [Império Aiúbida](https://pt.wikipedia.org/wiki/Imp%C3%A9rio_Ai%C3%BAbida "Império Aiúbida"), comandado por [Saladino](https://pt.wikipedia.org/wiki/Saladino "Saladino"), pondo fim a 88 anos de [ocupação cristã](https://pt.wikipedia.org/wiki/Reino_de_Jerusal%C3%A9m "Reino de Jerusalém").
  * [1789](https://pt.wikipedia.org/wiki/1789 "1789") – [Revolução Francesa](https://pt.wikipedia.org/wiki/Revolu%C3%A7%C3%A3o_Francesa "Revolução Francesa"): a **[Declaração dos Direitos do Homem e do Cidadão](https://pt.wikipedia.org/wiki/Declara%C3%A7%C3%A3o_dos_Direitos_do_Homem_e_do_Cidad%C3%A3o "Declaração dos Direitos do Homem e do Cidadão")** é aprovada pela [Assembleia Nacional Constituinte](https://pt.wikipedia.org/wiki/Assembleia_Nacional_Constituinte_\(Fran%C3%A7a\) "Assembleia Nacional Constituinte \(França\)").


  * [1992](https://pt.wikipedia.org/wiki/1992 "1992") – [Policiais militares](https://pt.wikipedia.org/wiki/Pol%C3%ADcia_Militar_do_Estado_de_S%C3%A3o_Paulo "Polícia Militar do Estado de São Paulo") invadem a [Penitenciária do Carandiru](https://pt.wikipedia.org/wiki/Casa_de_Deten%C3%A7%C3%A3o_de_S%C3%A3o_Paulo "Casa de Detenção de São Paulo"), em [São Paulo](https://pt.wikipedia.org/wiki/S%C3%A3o_Paulo "São Paulo"), durante uma revolta, matando 111 prisioneiros, no que ficou conhecido como o **[Massacre do Carandiru](https://pt.wikipedia.org/wiki/Massacre_do_Carandiru "Massacre do Carandiru")**.


**Nasceram neste dia…**
**[Ricardo III de Inglaterra](https://pt.wikipedia.org/wiki/Ricardo_III_de_Inglaterra "Ricardo III de Inglaterra")** ([1452](https://pt.wikipedia.org/wiki/1452 "1452")–[1485](https://pt.wikipedia.org/wiki/1485 "1485")) • **[Violet Jessop](https://pt.wikipedia.org/wiki/Violet_Jessop "Violet Jessop")** ([1867](https://pt.wikipedia.org/wiki/1867 "1867")–[1971](https://pt.wikipedia.org/wiki/1971 "1971")) • **[Mahatma Gandhi](https://pt.wikipedia.org/wiki/Mahatma_Gandhi "Mahatma Gandhi")** _(imagem)_ ([1869](https://pt.wikipedia.org/wiki/1869 "1869")–[1948](https://pt.wikipedia.org/wiki/1948 "1948")) • **[Sting](https://pt.wikipedia.org/wiki/Sting_\(m%C3%BAsico\) "Sting \(músico\)")** (n. [1951](https://pt.wikipedia.org/wiki/1951 "1951")) 
**Morreram neste dia…**
**[Marcel Duchamp](https://pt.wikipedia.org/wiki/Marcel_Duchamp "Marcel Duchamp")** ([1887](https://pt.wikipedia.org/wiki/1887 "1887")–[1968](https://pt.wikipedia.org/wiki/1968 "1968")) • **[Rock Hudson](https://pt.wikipedia.org/wiki/Rock_Hudson "Rock Hudson")** ([1925](https://pt.wikipedia.org/wiki/1925 "1925")–[1985](https://pt.wikipedia.org/wiki/1985 "1985")) • **[Peter Brian Medawar](https://pt.wikipedia.org/wiki/Peter_Brian_Medawar "Peter Brian Medawar")** ([1915](https://pt.wikipedia.org/wiki/1915 "1915")–[1987](https://pt.wikipedia.org/wiki/1987 "1987")) • **[Jamal Khashoggi](https://pt.wikipedia.org/wiki/Jamal_Khashoggi "Jamal Khashoggi")** ([1958](https://pt.wikipedia.org/wiki/1958 "1958")–[2018](https://pt.wikipedia.org/wiki/2018 "2018")) 
[Ver mais](https://pt.wikipedia.org/wiki/2_de_Outubro "2 de Outubro") • Outros dias: [30](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Efem%C3%A9rides/30_de_setembro "Wikipédia:Efemérides/30 de setembro") • [1](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Efem%C3%A9rides/1_de_outubro "Wikipédia:Efemérides/1 de outubro") • [2](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Efem%C3%A9rides/2_de_outubro "Wikipédia:Efemérides/2 de outubro") • [3](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Efem%C3%A9rides/3_de_outubro "Wikipédia:Efemérides/3 de outubro") • [4](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Efem%C3%A9rides/4_de_outubro "Wikipédia:Efemérides/4 de outubro") • [Ver todos](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Efem%C3%A9rides "Wikipédia:Efemérides")
Sabia que...
… em um jogo de futebol entre as seleções de [Malta](https://pt.wikipedia.org/wiki/Sele%C3%A7%C3%A3o_Maltesa_de_Futebol "Seleção Maltesa de Futebol") e [Eslováquia](https://pt.wikipedia.org/wiki/Sele%C3%A7%C3%A3o_Eslovaca_de_Futebol "Seleção Eslovaca de Futebol"), a canção "**[Numb](https://pt.wikipedia.org/wiki/Numb_\(can%C3%A7%C3%A3o_de_Linkin_Park\) "Numb \(canção de Linkin Park\)")** ", da banda [Linkin Park](https://pt.wikipedia.org/wiki/Linkin_Park "Linkin Park"), foi tocada acidentalmente no lugar do [hino maltês](https://pt.wikipedia.org/wiki/L-Innu_Malti "L-Innu Malti") _(áudio)_? 
… a exibição da telenovela brasileira _**[Vale Tudo](https://pt.wikipedia.org/wiki/Vale_Tudo "Vale Tudo")**_ (1988) em [Cuba](https://pt.wikipedia.org/wiki/Cuba "Cuba") fez com que os restaurantes abertos na ilha fossem chamados de "paladares", em referência a um restaurante da trama? 
… antes restrito ao uso militar, o [sistema de navegação por satélite](https://pt.wikipedia.org/wiki/Sistema_de_navega%C3%A7%C3%A3o_por_sat%C3%A9lite "Sistema de navegação por satélite") **[GPS](https://pt.wikipedia.org/wiki/Sistema_de_posicionamento_global "Sistema de posicionamento global")** foi liberado para uso civil gratuito pelo [governo dos Estados Unidos](https://pt.wikipedia.org/wiki/Governo_dos_Estados_Unidos "Governo dos Estados Unidos") após a derrubada do [voo KAL 007](https://pt.wikipedia.org/wiki/Voo_KAL_007 "Voo KAL 007") em 1983, quando este invadiu por engano o espaço aéreo da [União Soviética](https://pt.wikipedia.org/wiki/Uni%C3%A3o_Sovi%C3%A9tica "União Soviética")? 
… em sequência do maior acidente do mundo envolvendo [barragens de rejeitos](https://pt.wikipedia.org/wiki/Barragem_de_rejeitos "Barragem de rejeitos"), o **[rompimento de barragem em Mariana](https://pt.wikipedia.org/wiki/Rompimento_de_barragem_em_Mariana "Rompimento de barragem em Mariana")** , sedimentos contaminantes foram arrastados do [interior](https://pt.wikipedia.org/wiki/Interior_de_Minas_Gerais "Interior de Minas Gerais") de [Minas Gerais](https://pt.wikipedia.org/wiki/Minas_Gerais "Minas Gerais") por todo o leito do [rio Doce](https://pt.wikipedia.org/wiki/Rio_Doce "Rio Doce"), até os recifes de corais no arquipélago [atlântico](https://pt.wikipedia.org/wiki/Oceano_Atl%C3%A2ntico "Oceano Atlântico") de [Abrolhos](https://pt.wikipedia.org/wiki/Regi%C3%A3o_dos_Abrolhos "Região dos Abrolhos")? 
… o médico brasileiro **[Barata Ribeiro](https://pt.wikipedia.org/wiki/Barata_Ribeiro "Barata Ribeiro")** foi nomeado ministro do [Supremo Tribunal Federal](https://pt.wikipedia.org/wiki/Supremo_Tribunal_Federal "Supremo Tribunal Federal") em 1893, mesmo sem ser formado em [direito](https://pt.wikipedia.org/wiki/Direito "Direito")? 
[Índice geral](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Sabia_que "Wikipédia:Sabia que") • [Sugestões](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Sabia_que/Propostas "Wikipédia:Sabia que/Propostas")
Imagem do dia
[![Pintura Pahari de cerca de 1660–1670, proveniente de Bashohli, Jamu, Índia, representando a deusa hindu Bhadrakali adorada pelas três divindades supremas do hinduísmo: Brama, o criador, Vixnu, o preservador, e Xiva, o destruidor, para apaziguá-la após ter matado o demônio Mahishasura, que não podia ser morto nem por eles, nem pelos homens, nem por outros deuses. Sua vitória sobre o demônio é celebrada pelos hindus como a vitória do bem sobre o mal no dia de Vijayadashami. \(definição 2 850 × 2 850\)](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg/500px-Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)](https://pt.wikipedia.org/wiki/Ficheiro:Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg "Pintura Pahari de cerca de 1660–1670, proveniente de Bashohli, Jamu, Índia, representando a deusa hindu Bhadrakali adorada pelas três divindades supremas do hinduísmo: Brama, o criador, Vixnu, o preservador, e Xiva, o destruidor, para apaziguá-la após ter matado o demônio Mahishasura, que não podia ser morto nem por eles, nem pelos homens, nem por outros deuses. Sua vitória sobre o demônio é celebrada pelos hindus como a vitória do bem sobre o mal no dia de Vijayadashami. \(definição 2 850 × 2 850\)")  
---  
**Pintura Pahari** de cerca de 1660–1670, proveniente de [Bashohli](https://pt.wikipedia.org/wiki/Bashohli "Bashohli"), [Jamu](https://pt.wikipedia.org/wiki/Jamu_e_Caxemira_\(territ%C3%B3rio_da_Uni%C3%A3o\) "Jamu e Caxemira \(território da União\)"), [Índia](https://pt.wikipedia.org/wiki/%C3%8Dndia "Índia"), representando a deusa hindu [Bhadrakali](https://pt.wikipedia.org/wiki/C%C3%A1li_\(deusa_hindu\) "Cáli \(deusa hindu\)") adorada pelas [três divindades supremas](https://pt.wikipedia.org/wiki/Trim%C3%BArti "Trimúrti") do [hinduísmo](https://pt.wikipedia.org/wiki/Hindu%C3%ADsmo "Hinduísmo"): [Brama](https://pt.wikipedia.org/wiki/Brama "Brama"), o criador, [Vixnu](https://pt.wikipedia.org/wiki/Vixnu "Vixnu"), o preservador, e [Xiva](https://pt.wikipedia.org/wiki/Xiva "Xiva"), o destruidor, para apaziguá-la após ter matado o demônio [Mahishasura](https://pt.wikipedia.org/wiki/Mahishasura "Mahishasura"), que não podia ser morto nem por eles, nem pelos homens, nem por outros deuses. Sua vitória sobre o demônio é celebrada pelos hindus como a vitória do bem sobre o mal no dia de Vijayadashami.   
_(resolução original: 2 850 × 2 850)_
Compartilhe: [![Compartilhe via Facebook](https://upload.wikimedia.org/wikipedia/commons/thumb/2/22/Icon_Facebook.svg/20px-Icon_Facebook.svg.png)](http://www.facebook.com/sharer.php?u=https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Imagem_em_destaque/2_de_outubro_de_2025) [![Compartilhe via X](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/X_icon.svg/20px-X_icon.svg.png)](https://x.com/share?url=https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Imagem_em_destaque/2_de_outubro_de_2025&via=Wikipt&text=Veja+a+%23ImagemDoDia+da+Wikip%C3%A9dia+em+portugu%C3%AAs+em&related=Wikipedia)
[Índice geral](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Imagem_em_destaque "Wikipédia:Imagem em destaque") • [Commons](https://commons.wikimedia.org/wiki/Commons:Imagens_de_qualidade "commons:Commons:Imagens de qualidade")
Sobre a Wikipédia  
---  
A [Wikipédia](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia "Wikipédia") é um projeto de enciclopédia colaborativa, universal e multilíngue estabelecido na _internet_ sob o princípio _[wiki](https://pt.wikipedia.org/wiki/Wiki "Wiki")_. Tem como propósito fornecer um conteúdo livre, objetivo e verificável​​, que todos possam editar e melhorar. O projeto é definido pelos [princípios fundadores](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Cinco_pilares "Wikipédia:Cinco pilares") e o conteúdo é disponibilizado sob a licença [Creative Commons BY-SA](http://creativecommons.org/licenses/by-sa/3.0/deed.pt) e pode ser [reutilizado sob a mesma licença](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Citando_a_Wikip%C3%A9dia "Wikipédia:Citando a Wikipédia"), desde que respeitando os [termos de uso](https://foundation.wikimedia.org/wiki/Terms_of_Use/pt-br "wmf:Terms of Use/pt-br"). Todos podem publicar conteúdo _on-line_ desde que criem uma conta e sigam as regras básicas, como [verificabilidade](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Verificabilidade "Wikipédia:Verificabilidade") ou [notoriedade](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Crit%C3%A9rios_de_notoriedade "Wikipédia:Critérios de notoriedade").  Todos os editores da Wikipédia são voluntários e integram uma comunidade colaborativa, sem um líder, onde coordenam esforços em [projetos temáticos](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Projetos "Wikipédia:Projetos") e [espaços de discussão](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Esplanada "Wikipédia:Esplanada"). Dentre as várias [páginas de ajuda](https://pt.wikipedia.org/wiki/Ajuda:P%C3%A1gina_principal "Ajuda:Página principal") à disposição, estão as que explicam como [criar um artigo](https://pt.wikipedia.org/wiki/Ajuda:Guia_de_edi%C3%A7%C3%A3o/Como_come%C3%A7ar_uma_p%C3%A1gina "Ajuda:Guia de edição/Como começar uma página") ou [editar um artigo](https://pt.wikipedia.org/wiki/Ajuda:Tutorial/Edi%C3%A7%C3%A3o "Ajuda:Tutorial/Edição"). Em caso de dúvidas, não hesite em [perguntar](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Tire_suas_d%C3%BAvidas "Wikipédia:Tire suas dúvidas"). Debates e comentários sobre os artigos são bem-vindos. As [páginas de discussão](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_de_discuss%C3%A3o "Wikipédia:Página de discussão") servem para centralizar reflexões e avaliações sobre como melhorar o conteúdo da Wikipédia. | 
  * **Importante!**
  * [Princípio da imparcialidade](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Princ%C3%ADpio_da_imparcialidade "Wikipédia:Princípio da imparcialidade")
  * [Versões do português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Vers%C3%B5es_da_l%C3%ADngua_portuguesa "Wikipédia:Versões da língua portuguesa")
  * [Direitos de autor](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Direitos_de_autor "Wikipédia:Direitos de autor")
  * [Normas de conduta](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Normas_de_conduta "Wikipédia:Normas de conduta")
  * [Coisas a não fazer](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Coisas_a_n%C3%A3o_fazer "Wikipédia:Coisas a não fazer")


* * *
  * **Escrevendo artigos**
  * [O que é uma wiki?](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:O_que_%C3%A9_uma_wiki "Wikipédia:O que é uma wiki")
  * [Livro de estilo](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Livro_de_estilo "Wikipédia:Livro de estilo")
  * [Como contribuir](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Como_contribuir_para_a_Wikip%C3%A9dia "Wikipédia:Como contribuir para a Wikipédia")
  * [Tutorial](https://pt.wikipedia.org/wiki/Ajuda:Tutorial "Ajuda:Tutorial")
  * [Recursos livres](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Recursos_livres "Wikipédia:Recursos livres")
  * [Conteúdo destacado](https://pt.wikipedia.org/wiki/Portal:Conte%C3%BAdo_destacado "Portal:Conteúdo destacado")


* * *
  * **Ajude a Wikipédia**
  * [Páginas a traduzir](https://pt.wikipedia.org/wiki/Ajuda:Guia_de_tradu%C3%A7%C3%A3o "Ajuda:Guia de tradução")
  * [Artigos à espera de autor](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Artigos_pedidos "Wikipédia:Artigos pedidos")
  * [Manutenção](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Manuten%C3%A7%C3%A3o "Wikipédia:Manutenção")
  * [Donativos](https://donate.wikimedia.org/wiki/Special:FundraiserRedirector "donate:Special:FundraiserRedirector")


* * *
  * **Sobre a Wikipédia**
  * [Esplanada](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Esplanada "Wikipédia:Esplanada")
  * _[FAQ](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:FAQ "Wikipédia:FAQ")_
  * [Contato](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Contato "Wikipédia:Contato")
  * [Wikimedia](https://pt.wikipedia.org/wiki/Funda%C3%A7%C3%A3o_Wikimedia "Fundação Wikimedia")
  * [Software](https://pt.wikipedia.org/wiki/MediaWiki "MediaWiki")
  * [Estatísticas](https://pt.wikipedia.org/wiki/Especial:Estat%C3%ADsticas "Especial:Estatísticas")
  * [Consulta e reprodução](https://pt.wikipedia.org/wiki/Ajuda:Guia_de_consulta_e_reprodu%C3%A7%C3%A3o "Ajuda:Guia de consulta e reprodução")
  * [Decisões da comunidade](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Decis%C3%B5es_da_comunidade "Wikipédia:Decisões da comunidade")
  * [Informe um erro](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Informe_um_erro "Wikipédia:Informe um erro")


* * *
  * **Domínios**
  * [Wikipédia](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Dom%C3%ADnio_Wikip%C3%A9dia "Wikipédia:Domínio Wikipédia")
  * [MediaWiki](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Dom%C3%ADnio_MediaWiki "Wikipédia:Domínio MediaWiki")
  * [Predefinição](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Lista_de_predefini%C3%A7%C3%B5es "Wikipédia:Lista de predefinições")
  * [Ajuda](https://pt.wikipedia.org/wiki/Ajuda:P%C3%A1gina_principal "Ajuda:Página principal")

[Portal comunitário](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Portal_comunit%C3%A1rio "Wikipédia:Portal comunitário") • [O essencial](https://pt.wikipedia.org/wiki/Ajuda:Todo_o_indispens%C3%A1vel... "Ajuda:Todo o indispensável...")  
Projetos-irmãos  
---  
A Wikipédia existe graças à [Fundação Wikimedia](https://pt.wikipedia.org/wiki/Funda%C3%A7%C3%A3o_Wikimedia "Fundação Wikimedia"), entidade sem fins lucrativos que gere [projetos](https://wikimediafoundation.org/our-work/wikimedia-projects/ "foundationsite:our-work/wikimedia-projects/") em diversos idiomas e de [conteúdo livre](https://pt.wikipedia.org/wiki/Licen%C3%A7a_livre "Licença livre"): [![Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Commons-logo.svg "Commons") **[Commons](https://commons.wikimedia.org/wiki/P%C3%A1gina_principal "c:Página principal")**  
 _Repositório de mídia livre_ [![Incubator](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Incubator-logo.svg/40px-Incubator-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Incubator-logo.svg "Incubator") **[Incubator](https://incubator.wikimedia.org/wiki/Incubator:Main_Page/pt "incubator:Incubator:Main Page/pt")**  
 _Incubadora de projetos_ [![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikimedia_Community_Logo.svg "Meta-Wiki") **[Meta-Wiki](https://meta.wikimedia.org/wiki/P%C3%A1gina_principal "m:Página principal")**  
 _Projeto de coordenação_ [![Wikcionário](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wiktionary-logo.svg "Wikcionário") **[Wikcionário](https://pt.wiktionary.org/wiki/P%C3%A1gina_principal "wikt:Página principal")**  
 _Dicionário universal livre_ [![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikidata-logo.svg "Wikidata") **[Wikidata](https://www.wikidata.org/wiki/Wikidata:P%C3%A1gina_principal "d:Wikidata:Página principal")**  
 _Base de conhecimentos livre_ [![Wikilivros](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikibooks-logo.svg "Wikilivros") **[Wikilivros](https://pt.wikibooks.org/wiki/Wikilivros:P%C3%A1gina_principal "b:Wikilivros:Página principal")**  
 _Livros e manuais livres_ [![Wikinotícias](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikinews-logo.svg "Wikinotícias") **[Wikinotícias](https://pt.wikinews.org/wiki/P%C3%A1gina_principal "n:Página principal")**  
 _Jornalismo colaborativo_ [![Wikiquote](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikiquote-logo.svg "Wikiquote") **[Wikiquote](https://pt.wikiquote.org/wiki/pt:P%C3%A1gina_principal "q:pt:Página principal")**  
 _Coletânea de citações livre_ [![Wikisource](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikisource-logo.svg "Wikisource") **[Wikisource](https://pt.wikisource.org/wiki/pt:Wikisource:P%C3%A1gina_principal "s:pt:Wikisource:Página principal")**  
 _Biblioteca livre_ [![Wikispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikispecies-logo.svg "Wikispecies") **[Wikispecies](https://species.wikimedia.org/wiki/P%C3%A1gina_principal "species:Página principal")**  
 _Diretório de espécies livre_ [![Wikiversidade](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/40px-Wikiversity_logo_2017.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikiversity_logo_2017.svg "Wikiversidade") **[Wikiversidade](https://pt.wikiversity.org/wiki/pt:P%C3%A1gina_principal "v:pt:Página principal")**  
 _Universidade livre_ [![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikivoyage-Logo-v3-icon.svg "Wikivoyage") **[Wikivoyage](https://pt.wikivoyage.org/wiki/pt:P%C3%A1gina_principal "voy:pt:Página principal")**  
 _Guia livre de viagem_ [![Wikifunctions](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Wikifunctions-logo.svg/40px-Wikifunctions-logo.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikifunctions-logo.svg "Wikifunctions") **[Wikifunctions](https://www.wikifunctions.org/wiki/ "wikifunctions:")**  
 _Funções colaborativas_ [![Phabricator](https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/Wikimedia_Phabricator_logo_unpadded.svg/40px-Wikimedia_Phabricator_logo_unpadded.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikimedia_Phabricator_logo_unpadded.svg "Phabricator") **[Phabricator](https://phabricator.wikimedia.org/ "phabricator:")**  
 _Desenvolvimento colaborativo_ [![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/MediaWiki-2020-icon-spinning.svg/40px-MediaWiki-2020-icon-spinning.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:MediaWiki-2020-icon-spinning.svg "MediaWiki") **[MediaWiki](https://www.mediawiki.org/wiki/MediaWiki/pt "mw:MediaWiki/pt")**  
 _Software Wiki_ [![WikiTech](https://upload.wikimedia.org/wikipedia/commons/thumb/5/52/Wikitech-2021-blue-large-icon.svg/40px-Wikitech-2021-blue-large-icon.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikitech-2021-blue-large-icon.svg "WikiTech") **[WikiTech](https://wikitech.wikimedia.org/wiki/ "wikitech:")**  
 _Projetos técnicos_ [![Wikispore](https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/Wikispore_logo_without_text.svg/40px-Wikispore_logo_without_text.svg.png)](https://pt.wikipedia.org/wiki/Ficheiro:Wikispore_logo_without_text.svg "Wikispore") **[Wikispore](https://wikispore.wmflabs.org/wiki/ "wikispore:")**  
 _Projetos experimentais_ [Imprensa](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Contato/Imprensa "Wikipédia:Contato/Imprensa") • [Estatísticas](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Estat%C3%ADsticas "Wikipédia:Estatísticas")  
Obtida de "[https://pt.wikipedia.org/w/index.php?title=Wikipédia:Página_principal&oldid=70150066](https://pt.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:P%C3%A1gina_principal&oldid=70150066)"
353 línguas
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page — afar")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа — abcázio")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue — achém")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ — adigue")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad — africanês")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte — alemão suíço")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк — altai do sul")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ — amárico")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw — Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada — aragonês")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet — inglês antigo")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu — obolo")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ — angika")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة — árabe")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ — aramaico")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا — Moroccan Arabic")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه — Egyptian Arabic")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত — assamês")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada — asturiano")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin — atikamekw")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер — avar")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola — Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना — awadhi")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi — aimará")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə — azerbaijano")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه — South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит — bashkir")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama — balinês")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn — Bavarian")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis — Samogitian")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman — Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina — Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman — West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка — bielorrusso")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка — Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé — Betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница — búlgaro")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना — Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej — bislamá")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian — Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ — Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ — bambara")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা — bengalês")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། — tibetano")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা — Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer — bretão")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana — bósnio")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo — Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola — buginês")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан — Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada — catalão")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina — Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk — Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо — checheno")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid — cebuano")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman — chamorro")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page — choctaw")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ — cherokee")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama — cheyenne")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک — curdo central")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra — córsico")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ — cree")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife — tártara da Crimeia")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana — checo")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna — kashubian")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница — eslavo eclesiástico")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница — chuvash")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan — galês")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside — dinamarquês")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu — Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite — alemão")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu — Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït — dinka")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri — Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok — baixo sorábio")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo — Central Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना — Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ — divehi")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། — dzonga")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ — ewe")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια — grego")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP — Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page — inglês")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo — esperanto")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada — espanhol")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht — estónio")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala — basco")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua — Extremaduran")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی — persa")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir — fanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo — fula")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu — finlandês")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht — Võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu — fijiano")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða — feroês")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn — fon")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal — francês")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla — Arpitan")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid — frísio setentrional")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl — friulano")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside — frísico ocidental")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach — irlandês")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak — gagauz")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 — gan")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal — Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag — gaélico escocês")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada — galego")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ — Gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha — guarani")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान — Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo — gorontalo")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 — gótico")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page — Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ — guzerate")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü — Wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure — Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan — Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag — manx")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi — haúça")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p — hacá")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi — havaiano")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי — hebraico")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ — hindi")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna — Fiji Hindi")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page — hiri motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica — croata")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona — alto sorábio")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal — haitiano")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap — húngaro")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ — arménio")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ — Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page — herero")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal — interlíngua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah — iban")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama — indonésio")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine — interlingue")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ — igbo")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo — Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik — inupiaque")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid — ilocano")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув — inguche")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico — ido")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða — islandês")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale — italiano")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ — inuktitut")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ — japonês")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej — Jamaican Creole English")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju — lojban")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa — javanês")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი — georgiano")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet — kara-kalpak")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan — kabyle")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ — cabardiano")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu — Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu — tyap")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi — congolês")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang — Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page — quicuio")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page — cuanhama")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет — cazaque")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa — gronelandês")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម — khmer")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ — canarim")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura — Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 — coreano")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок — komi-permyak")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page — canúri")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет — carachaio-bálcaro")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ — caxemira")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk — kölsch")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk — curdo")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir — Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок — komi")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre — córnico")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак — quirguiz")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima — latim")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja — ladino")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit — luxemburguês")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин — Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин — lezghiano")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef — Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka — ganda")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad — limburguês")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ — ligure")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala — Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala — lombardo")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó — lingala")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ — laosiano")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ — luri do norte")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis — lituano")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa — Latgalian")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa — letão")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan — madurês")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना — maithili")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama — Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа — mocsa")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana — malgaxe")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page — marshalês")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык — Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga — maori")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo — minangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница — macedónio")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ — malaiala")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас — mongol")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ — manipuri")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် — Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo — mossi")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ — marata")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш — Western Mari")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama — malaio")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali — maltês")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page — creek")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal — mirandês")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ — birmanês")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа — erzya")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه — mazandarani")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl — Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale — napolitano")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet — baixo-alemão")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad — baixo-saxão")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ — nepalês")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ — newari")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu — dongo")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama — nias")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina — neerlandês")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside — norueguês nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside — norueguês bokmål")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine — Novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ — n’ko")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page — ndebele do sul")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde — Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele — soto setentrional")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi — Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos — navajo")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu — nianja")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh — occitano")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu — Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura — oromo")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା — oriá")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс — ossético")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ — panjabi")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong — língua pangasinesa")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung — pampango")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal — papiamento")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul — Picard")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej — pidgin nigeriano")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt — Pennsylvania German")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid — Palatine German")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta — páli")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij — Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna — polaco")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada — Piedmontese")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ — Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα — Pontic")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ — pastó")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj — Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa — quíchua")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ — Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala — romanche")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin — Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru — rundi")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală — romeno")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã — aromeno")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále — Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок — Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница — russo")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка — Rusyn")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro — quiniaruanda")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् — sânscrito")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй — sakha")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ — santali")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale — sardo")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali — siciliano")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page — scots")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو — sindi")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu — sami do norte")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî — sango")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica — servo-croata")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut — tachelhit")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ — shan")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව — cingalês")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page — Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka — eslovaco")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت — Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran — esloveno")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua — samoano")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo — inari sami")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga — shona")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore — somali")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore — albanês")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна — sérvio")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira — surinamês")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu — suázi")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele — sesoto")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede — Saterland Frisian")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas — sundanês")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida — sueco")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo — suaíli")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ — Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta — silesiano")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih — Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் — tâmil")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan — Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ — Tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ — Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ — telugu")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk — tétum")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ — tajique")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก — tailandês")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ — tigrínia")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ — tigré")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa — turcomano")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina — tagalo")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə — Talysh")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono — tswana")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia — tonga")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes — tok pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa — turco")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas — taroko")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu — tsonga")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит — tatar")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu — tumbuka")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw — twi")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a — taitiano")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын — tuviniano")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам — udmurte")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت — uigur")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка — ucraniano")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول — urdu")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa — usbeque")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani — venda")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio — véneto")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ — Veps")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính — vietnamita")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad — West Flemish")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad — volapuque")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje — valão")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli — waray")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk — uólofe")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 — wu")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх — kalmyk")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo — xosa")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა — Mingrelian")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט — iídiche")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ — ioruba")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz — zhuang")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad — Zeelandic")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ — tamazight marroquino padrão")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 — chinês")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 — Literary Chinese")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h — min nan")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 — cantonês")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu — zulu")


[Editar hiperligações](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Editar hiperligações interlínguas")
  * Esta página foi editada pela última vez às 10h48min de 20 de maio de 2025.
  * Este texto é disponibilizado nos termos da licença [Atribuição-CompartilhaIgual 4.0 Internacional (CC BY-SA 4.0) da Creative Commons](https://creativecommons.org/licenses/by-sa/4.0/deed.pt); pode estar sujeito a condições adicionais. Para mais detalhes, consulte as [condições de utilização](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use).


  * [Política de privacidade](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy/pt-br)
  * [Sobre a Wikipédia](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Sobre)
  * [Avisos gerais](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:Aviso_geral)
  * [Código de conduta](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Programadores](https://developer.wikimedia.org)
  * [Estatísticas](https://stats.wikimedia.org/#/pt.wikipedia.org)
  * [Declaração sobre cookies](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Versão móvel](https://pt.m.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:P%C3%A1gina_principal&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://pt.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://pt.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Busca
Pesquisar
Wikipédia:Página principal
[](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal) [](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal) [](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal) [](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal) [](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal) [](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal) [](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal) [](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal)
353 línguas [Adicionar tópico ](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal)
