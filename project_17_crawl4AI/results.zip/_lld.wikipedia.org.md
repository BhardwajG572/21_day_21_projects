[Vai al contenuto](https://lld.wikipedia.org/wiki/Plata_prinzipala#bodyContent)
Menu principale
Menu principale
sposta nella barra laterale nascuend
Navigazion 
  * [Plata prinzipala](https://lld.wikipedia.org/wiki/Plata_prinzipala "Va sun la plata prinzipala \[z\]")
  * [Portal de comunità](https://lld.wikipedia.org/wiki/Wikipedia:Portal_de_comunit%C3%A0 "Descrizion dl proiet, cie che te posses fé y ulà che te posses abiné la robes")
  * [Avenimënc de atualità](https://lld.wikipedia.org/wiki/Wikipedia:Avenim%C3%ABnc_de_atualit%C3%A0 "Nfurmazions sun avenimënc de atualità")
  * [Ultimi mudamënc](https://lld.wikipedia.org/wiki/Speciale:UltimeModifiche "Na lista de mudamënc fac da puech te la wiki \[r\]")
  * [Plata a caje](https://lld.wikipedia.org/wiki/Speciale:PaginaCasuale "Cëria na plata a cajo \[x\]")
  * [Aiut](https://lld.wikipedia.org/wiki/Help-url "Plata de aiut")


[ ![](https://lld.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://lld.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![](https://lld.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-lld.svg) ](https://lld.wikipedia.org/wiki/Plata_prinzipala)
[Crì ](https://lld.wikipedia.org/wiki/Speciale:Ricerca "Chir te Wikipedia \[f\]")
Crì
Aspetto
  * [Fé na dunazion](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=lld.wikipedia.org&uselang=lld)
  * [Scrite ite](https://lld.wikipedia.org/w/index.php?title=Speciale:CreaUtenza&returnto=Plata+prinzipala "L fos bon sce te te scrijësses it per avëi n cont y te culeghësses, ma te ne l mues nia fé")
  * [Culeghete](https://lld.wikipedia.org/w/index.php?title=Speciale:Entra&returnto=Plata+prinzipala "L fos bon sce te culeghësses, ma te ne muesses nia \[o\]")


Strumënc persunei
  * [Fé na dunazion](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=lld.wikipedia.org&uselang=lld)
  * [Scrite ite](https://lld.wikipedia.org/w/index.php?title=Speciale:CreaUtenza&returnto=Plata+prinzipala "L fos bon sce te te scrijësses it per avëi n cont y te culeghësses, ma te ne l mues nia fé")
  * [Culeghete](https://lld.wikipedia.org/w/index.php?title=Speciale:Entra&returnto=Plata+prinzipala "L fos bon sce te culeghësses, ma te ne muesses nia \[o\]")


# Plata prinzipala
  * [Plata prinzipala](https://lld.wikipedia.org/wiki/Plata_prinzipala "Cëlti ala usc \[c\]")
  * [Descuscion](https://lld.wikipedia.org/wiki/Discussione:Plata_prinzipala "Descuscion de chësta plata \[t\]")


Ladin
  * [Liej](https://lld.wikipedia.org/wiki/Plata_prinzipala)
  * [Ciara ala funtana](https://lld.wikipedia.org/w/index.php?title=Plata_prinzipala&action=edit "Chësta plata é sconada, mo pos odëi le codesc fondamental. \[e\]")
  * [Storia dl documënt](https://lld.wikipedia.org/w/index.php?title=Plata_prinzipala&action=history "Ultima verscions de chësta plata \[h\]")


Strumënc
Strumënc
sposta nella barra laterale nascuend
Azioni 
  * [Liej](https://lld.wikipedia.org/wiki/Plata_prinzipala)
  * [Ciara ala funtana](https://lld.wikipedia.org/w/index.php?title=Plata_prinzipala&action=edit)
  * [Storia dl documënt](https://lld.wikipedia.org/w/index.php?title=Plata_prinzipala&action=history)


Generel 
  * [Links che porta tlo](https://lld.wikipedia.org/wiki/Speciale:PuntanoQui/Plata_prinzipala "Na lista de duta la plates wiki che porta tlo \[j\]")
  * [Mudamënc che à da n fé cun chësc](https://lld.wikipedia.org/wiki/Speciale:ModificheCorrelate/Plata_prinzipala "Ultima mudazions te plates culeghedes a chësta plata \[k\]")
  * [Cëria su n documënt](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=lld "Cëria su documënc \[u\]")
  * [Link per for](https://lld.wikipedia.org/w/index.php?title=Plata_prinzipala&oldid=220978 "Link per for a chësta reviscion de la plata")
  * [Nfurmazions sun la plata](https://lld.wikipedia.org/w/index.php?title=Plata_prinzipala&action=info "Ulteriori informazioni su questa pagina")
  * [Zitea chësta plata](https://lld.wikipedia.org/w/index.php?title=Speciale:Cita&page=Plata_prinzipala&id=220978&wpFormIdentifier=titleform "Nfurmazion sun co zité chësta plata")
  * [Ottieni URL breve](https://lld.wikipedia.org/w/index.php?title=Speciale:UrlShortener&url=https%3A%2F%2Flld.wikipedia.org%2Fwiki%2FPlata_prinzipala)
  * [Scarica codice QR](https://lld.wikipedia.org/w/index.php?title=Speciale:QrCode&url=https%3A%2F%2Flld.wikipedia.org%2Fwiki%2FPlata_prinzipala)


Stampé/esporté 
  * [Mët adum n liber](https://lld.wikipedia.org/w/index.php?title=Speciale:Libro&bookcmd=book_creator&referer=Plata+prinzipala)
  * [Cëria ju coche PDF](https://lld.wikipedia.org/w/index.php?title=Speciale:DownloadAsPdf&page=Plata_prinzipala&action=show-download-screen)
  * [Verscion da stampé](https://lld.wikipedia.org/w/index.php?title=Plata_prinzipala&printable=yes "Verscion da stampé de chëesta plata \[p\]")


Te d'atri proiec 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikidata element](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Culegamënt cul element culegà de l archive di dac \[g\]")


Aspetto
sposta nella barra laterale nascuend
Da Wikipedia
**[Bëgngnüs y bëgngnüdes](https://lld.wikipedia.org/wiki/Aiuto:Prim_vares "Aiuto:Prim vares") sön la [Wikipedia ladina](https://lld.wikipedia.org/wiki/Wikipedia_ladina "Wikipedia ladina")**   
L'enziclopedia [lëdia ](https://lld.wikipedia.org/wiki/Wikipedia:L%27enziclopedia_l%C3%ABdia "Wikipedia:L'enziclopedia lëdia") y [colaborativa](https://lld.wikipedia.org/w/index.php?title=Wikipedia:Aiuta_Wikipedia&action=edit&redlink=1 "Wikipedia:Aiuta Wikipedia \(chësta plata ne dal nia\)")
* * *
[![Druca tlo per crì tl indesc di articuli!](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Crystal_Clear_app_xmag.svg/20px-Crystal_Clear_app_xmag.svg.png)](https://lld.wikipedia.org/wiki/Speciale:TutteLePagine "Druca tlo per crì tl indesc di articuli!") [**Chir tl indesc**](https://lld.wikipedia.org/wiki/Speciale:TutteLePagine "Speciale:TutteLePagine") [![Druca tlo per cialé do la categories di articuli!](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/1rightarrow_blue.svg/20px-1rightarrow_blue.svg.png)](https://lld.wikipedia.org/wiki/Wikipedia:Categories "Druca tlo per cialé do la categories di articuli!")[**Cëla do la categories**](https://lld.wikipedia.org/wiki/Wikipedia:Categories "Wikipedia:Categories") [![Druca tlo per jì danter i portai de tematiches!](https://upload.wikimedia.org/wikipedia/commons/thumb/7/70/Nuvola_apps_bookcase_simplified.svg/20px-Nuvola_apps_bookcase_simplified.svg.png)](https://lld.wikipedia.org/wiki/Portale:Portai "Druca tlo per jì danter i portai de tematiches!") [**Cëlti ite ai portai de tematiches**](https://lld.wikipedia.org/w/index.php?title=Portale:Portali&action=edit&redlink=1 "Portale:Portali \(chësta plata ne dal nia\)")
cun **[180 800](https://lld.wikipedia.org/wiki/Speciale:Statistiche "Speciale:Statistiche")** articuli per **[ladin](https://lld.wikipedia.org/wiki/Lingaz_ladin "Lingaz ladin")**  
y 40 partizipanc atifs 
[Juda pea](https://lld.wikipedia.org/wiki/Aiuto:Prim_vares "Aiuto:Prim vares") |  [Plata a caje](https://lld.wikipedia.org/wiki/Speciale:PaginaCasuale "Speciale:PaginaCasuale")  
---|---  
* * *
* * *
  * [![](https://upload.wikimedia.org/wikipedia/commons/5/57/Pragser_Wildsee_und_Seekofel_2.jpg)](https://lld.wikipedia.org/wiki/File:Pragser_Wildsee_und_Seekofel_2.jpg)
Articul dl mëns
[Le Rëgn de Fanes](https://lld.wikipedia.org/wiki/Le_R%C3%ABgn_de_Fanes "Le Rëgn de Fanes")
L ziclus plu mpurtant dla [lijëndes ladines](https://lld.wikipedia.org/wiki/Lij%C3%ABndes_ladines "Lijëndes ladines") ie bën chël dl **rëni de Fanes**. L se trata dla majera epica dl [popul ladin](https://lld.wikipedia.org/wiki/Popul_ladin "Popul ladin"), che nes ie unida repurteda tres l lëur de documentazion de [Karl Felix Wolff](https://lld.wikipedia.org/wiki/Karl_Felix_Wolff "Karl Felix Wolff"), che à mudà truepa pertes y metù adum la stories de Fanes cun chëles di [Arimanns de Fascia](https://lld.wikipedia.org/w/index.php?title=Arimanns_de_Fascia&action=edit&redlink=1 "Arimanns de Fascia \(chësta plata ne dal nia\)"). Tla verscion recostruida per ladin da [Angel Morlang](https://lld.wikipedia.org/wiki/Angel_Morlang "Angel Morlang") y scrita nce te forma de teater ie la storia cunzentreda mé ntëur al rëni de Fanes, nasciù tres la alianza de [Moltina](https://lld.wikipedia.org/wiki/Moltina "Moltina") cun la muntanioles. L rëni devënta for plu sterch y se slergia ora a dann di ujins dla autra valedes, ajache l rë de Fanes, che ie n fulestier maridà ite y che vën tlamà Raies te vel verscion dla storia uel for plu richëzes y pudëi. [- Gëura l articul](https://lld.wikipedia.org/wiki/Le_R%C3%ABgn_de_Fanes "Le Rëgn de Fanes")
## [Le Rëgn de Fanes](https://lld.wikipedia.org/wiki/Le_R%C3%ABgn_de_Fanes "Le Rëgn de Fanes")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Pragser_Wildsee_und_Seekofel_2.jpg/120px-Pragser_Wildsee_und_Seekofel_2.jpg)](https://lld.wikipedia.org/wiki/File:Pragser_Wildsee_und_Seekofel_2.jpg)
L ziclus plu mpurtant dla [lijëndes ladines](https://lld.wikipedia.org/wiki/Lij%C3%ABndes_ladines "Lijëndes ladines") ie bën chël dl **rëni de Fanes**. L se trata dla majera epica dl [popul ladin](https://lld.wikipedia.org/wiki/Popul_ladin "Popul ladin"), che nes ie unida repurteda tres l lëur de documentazion de [Karl Felix Wolff](https://lld.wikipedia.org/wiki/Karl_Felix_Wolff "Karl Felix Wolff"), che à mudà truepa pertes y metù adum la stories de Fanes cun chëles di [Arimanns de Fascia](https://lld.wikipedia.org/w/index.php?title=Arimanns_de_Fascia&action=edit&redlink=1 "Arimanns de Fascia \(chësta plata ne dal nia\)"). 
Tla verscion recostruida per ladin da [Angel Morlang](https://lld.wikipedia.org/wiki/Angel_Morlang "Angel Morlang") y scrita nce te forma de teater ie la storia cunzentreda mé ntëur al rëni de Fanes, nasciù tres la alianza de [Moltina](https://lld.wikipedia.org/wiki/Moltina "Moltina") cun la muntanioles. L rëni devënta for plu sterch y se slergia ora a dann di ujins dla autra valedes, ajache l rë de Fanes, che ie n fulestier maridà ite y che vën tlamà Raies te vel verscion dla storia uel for plu richëzes y pudëi. 
  

  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg/1700px-Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg)](https://lld.wikipedia.org/wiki/File:Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg)
Foto dl mëns
[Hartl (mont)](https://lld.wikipedia.org/wiki/Hartl_\(mont\) "Hartl \(mont\)")
**Hartl** ie na mont tla pert plu a nord y a uriënt dla [Mont de Sëuc](https://lld.wikipedia.org/wiki/Mont_S%C3%ABuc "Mont Sëuc"). L inuem _Hartl_ , che uel dì Leonhard, vën dala ciajea che fova iló dl luech da paur Hartl de Tannürz pra [Laion](https://lld.wikipedia.org/wiki/Laion "Laion"). N iëde ova la mont inuem Mont de Sëuracrëpa, l vedl inuem dl luech Seniam sëura l Iender. L semea che n iëde univa la ciajea Hartl abiteda dut l ann. Sal Hartl ruvun da [Urtijëi](https://lld.wikipedia.org/wiki/Urtij%C3%ABi "Urtijëi") sun l troi n. 19 su per Pedroc, da seniam (Soplajes) su per l troi n. 11 che va nchina te Sautaria. [- Gëura l articul](https://lld.wikipedia.org/wiki/Hartl_\(mont\) "Hartl \(mont\)")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg/250px-Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg)](https://lld.wikipedia.org/wiki/File:Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg)
**Hartl** ie na mont tla pert plu a nord y a uriënt dla [Mont de Sëuc](https://lld.wikipedia.org/wiki/Mont_S%C3%ABuc "Mont Sëuc"). L inuem _Hartl_ , che uel dì Leonhard, vën dala ciajea che fova iló dl luech da paur Hartl de Tannürz pra [Laion](https://lld.wikipedia.org/wiki/Laion "Laion"). N iëde ova la mont inuem Mont de Sëuracrëpa, l vedl inuem dl luech Seniam sëura l Iender. L semea che n iëde univa la ciajea Hartl abiteda dut l ann. Sal Hartl ruvun da [Urtijëi](https://lld.wikipedia.org/wiki/Urtij%C3%ABi "Urtijëi") sun l troi n. 19 su per Pedroc, da seniam (Soplajes) su per l troi n. 11 che va nchina te Sautaria. 
  

  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Flag_of_the_Kingdom_of_Prussia_%281803-1892%29.svg/1700px-Flag_of_the_Kingdom_of_Prussia_%281803-1892%29.svg.png)](https://lld.wikipedia.org/wiki/File:Flag_of_the_Kingdom_of_Prussia_\(1803-1892\).svg)
Rest dl mond
[Pruscia](https://lld.wikipedia.org/wiki/Pruscia "Pruscia")
La **Pruscia** ([tudësch](https://lld.wikipedia.org/wiki/Lingaz_tud%C3%ABsch "Lingaz tudësch"): _Preußen_) fova n [stat](https://lld.wikipedia.org/wiki/Stat "Stat") [tudësch](https://lld.wikipedia.org/wiki/Germania "Germania") sun la costa a sud-est dl [Mer Baltich](https://lld.wikipedia.org/wiki/Mer_Baltich "Mer Baltich"). La ova furmà l [Mper Tudësch](https://lld.wikipedia.org/wiki/Mper_Tud%C3%ABsch "Mper Tudësch") sota na dominazion prusciana tl 1871 canche la ova purtà adum duc i stac tudësc. La Pruscia se ova desfà _[de facto](https://lld.wikipedia.org/wiki/De_facto "De facto")_ canche l [pudëi dl guviern de Pruscia fova stat dat](https://lld.wikipedia.org/w/index.php?title=Preu%C3%9Fenschlag&action=edit&redlink=1 "Preußenschlag \(chësta plata ne dal nia\)") al [Canzelier de la Germania](https://lld.wikipedia.org/w/index.php?title=Canzelier_de_la_Germania&action=edit&redlink=1 "Canzelier de la Germania \(chësta plata ne dal nia\)") [Franz von Papen](https://lld.wikipedia.org/w/index.php?title=Franz_von_Papen&action=edit&redlink=1 "Franz von Papen \(chësta plata ne dal nia\)") tl 1932 y _[de jure](https://lld.wikipedia.org/wiki/De_jure "De jure")_ dai [aleac de la segonda viera mundiela](https://lld.wikipedia.org/wiki/Aleac_de_la_segonda_viera_mundiela "Aleac de la segonda viera mundiela") tl 1947. [- Gëura l articul](https://lld.wikipedia.org/wiki/Pruscia "Pruscia")
## [Pruscia](https://lld.wikipedia.org/wiki/Pruscia "Pruscia")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Flag_of_the_Kingdom_of_Prussia_%281803-1892%29.svg/120px-Flag_of_the_Kingdom_of_Prussia_%281803-1892%29.svg.png)](https://lld.wikipedia.org/wiki/File:Flag_of_the_Kingdom_of_Prussia_\(1803-1892\).svg)
La **Pruscia** ([tudësch](https://lld.wikipedia.org/wiki/Lingaz_tud%C3%ABsch "Lingaz tudësch"): _Preußen_) fova n [stat](https://lld.wikipedia.org/wiki/Stat "Stat") [tudësch](https://lld.wikipedia.org/wiki/Germania "Germania") sun la costa a sud-est dl [Mer Baltich](https://lld.wikipedia.org/wiki/Mer_Baltich "Mer Baltich"). La ova furmà l [Mper Tudësch](https://lld.wikipedia.org/wiki/Mper_Tud%C3%ABsch "Mper Tudësch") sota na dominazion prusciana tl 1871 canche la ova purtà adum duc i stac tudësc. La Pruscia se ova desfà _[de facto](https://lld.wikipedia.org/wiki/De_facto "De facto")_ canche l [pudëi dl guviern de Pruscia fova stat dat](https://lld.wikipedia.org/w/index.php?title=Preu%C3%9Fenschlag&action=edit&redlink=1 "Preußenschlag \(chësta plata ne dal nia\)") al [Canzelier de la Germania](https://lld.wikipedia.org/w/index.php?title=Canzelier_de_la_Germania&action=edit&redlink=1 "Canzelier de la Germania \(chësta plata ne dal nia\)") [Franz von Papen](https://lld.wikipedia.org/w/index.php?title=Franz_von_Papen&action=edit&redlink=1 "Franz von Papen \(chësta plata ne dal nia\)") tl 1932 y _[de jure](https://lld.wikipedia.org/wiki/De_jure "De jure")_ dai [aleac de la segonda viera mundiela](https://lld.wikipedia.org/wiki/Aleac_de_la_segonda_viera_mundiela "Aleac de la segonda viera mundiela") tl 1947. 
  



[![](https://upload.wikimedia.org/wikipedia/commons/5/57/Pragser_Wildsee_und_Seekofel_2.jpg)](https://lld.wikipedia.org/wiki/File:Pragser_Wildsee_und_Seekofel_2.jpg)
Articul dl mëns
[Le Rëgn de Fanes](https://lld.wikipedia.org/wiki/Le_R%C3%ABgn_de_Fanes "Le Rëgn de Fanes")
L ziclus plu mpurtant dla [lijëndes ladines](https://lld.wikipedia.org/wiki/Lij%C3%ABndes_ladines "Lijëndes ladines") ie bën chël dl **rëni de Fanes**. L se trata dla majera epica dl [popul ladin](https://lld.wikipedia.org/wiki/Popul_ladin "Popul ladin"), che nes ie unida repurteda tres l lëur de documentazion de [Karl Felix Wolff](https://lld.wikipedia.org/wiki/Karl_Felix_Wolff "Karl Felix Wolff"), che à mudà truepa pertes y metù adum la stories de Fanes cun chëles di [Arimanns de Fascia](https://lld.wikipedia.org/w/index.php?title=Arimanns_de_Fascia&action=edit&redlink=1 "Arimanns de Fascia \(chësta plata ne dal nia\)"). Tla verscion recostruida per ladin da [Angel Morlang](https://lld.wikipedia.org/wiki/Angel_Morlang "Angel Morlang") y scrita nce te forma de teater ie la storia cunzentreda mé ntëur al rëni de Fanes, nasciù tres la alianza de [Moltina](https://lld.wikipedia.org/wiki/Moltina "Moltina") cun la muntanioles. L rëni devënta for plu sterch y se slergia ora a dann di ujins dla autra valedes, ajache l rë de Fanes, che ie n fulestier maridà ite y che vën tlamà Raies te vel verscion dla storia uel for plu richëzes y pudëi. [- Gëura l articul](https://lld.wikipedia.org/wiki/Le_R%C3%ABgn_de_Fanes "Le Rëgn de Fanes")
## [Le Rëgn de Fanes](https://lld.wikipedia.org/wiki/Le_R%C3%ABgn_de_Fanes "Le Rëgn de Fanes")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Pragser_Wildsee_und_Seekofel_2.jpg/120px-Pragser_Wildsee_und_Seekofel_2.jpg)](https://lld.wikipedia.org/wiki/File:Pragser_Wildsee_und_Seekofel_2.jpg)
L ziclus plu mpurtant dla [lijëndes ladines](https://lld.wikipedia.org/wiki/Lij%C3%ABndes_ladines "Lijëndes ladines") ie bën chël dl **rëni de Fanes**. L se trata dla majera epica dl [popul ladin](https://lld.wikipedia.org/wiki/Popul_ladin "Popul ladin"), che nes ie unida repurteda tres l lëur de documentazion de [Karl Felix Wolff](https://lld.wikipedia.org/wiki/Karl_Felix_Wolff "Karl Felix Wolff"), che à mudà truepa pertes y metù adum la stories de Fanes cun chëles di [Arimanns de Fascia](https://lld.wikipedia.org/w/index.php?title=Arimanns_de_Fascia&action=edit&redlink=1 "Arimanns de Fascia \(chësta plata ne dal nia\)"). 
Tla verscion recostruida per ladin da [Angel Morlang](https://lld.wikipedia.org/wiki/Angel_Morlang "Angel Morlang") y scrita nce te forma de teater ie la storia cunzentreda mé ntëur al rëni de Fanes, nasciù tres la alianza de [Moltina](https://lld.wikipedia.org/wiki/Moltina "Moltina") cun la muntanioles. L rëni devënta for plu sterch y se slergia ora a dann di ujins dla autra valedes, ajache l rë de Fanes, che ie n fulestier maridà ite y che vën tlamà Raies te vel verscion dla storia uel for plu richëzes y pudëi. 
  

[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg/1700px-Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg)](https://lld.wikipedia.org/wiki/File:Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg)
Foto dl mëns
[Hartl (mont)](https://lld.wikipedia.org/wiki/Hartl_\(mont\) "Hartl \(mont\)")
**Hartl** ie na mont tla pert plu a nord y a uriënt dla [Mont de Sëuc](https://lld.wikipedia.org/wiki/Mont_S%C3%ABuc "Mont Sëuc"). L inuem _Hartl_ , che uel dì Leonhard, vën dala ciajea che fova iló dl luech da paur Hartl de Tannürz pra [Laion](https://lld.wikipedia.org/wiki/Laion "Laion"). N iëde ova la mont inuem Mont de Sëuracrëpa, l vedl inuem dl luech Seniam sëura l Iender. L semea che n iëde univa la ciajea Hartl abiteda dut l ann. Sal Hartl ruvun da [Urtijëi](https://lld.wikipedia.org/wiki/Urtij%C3%ABi "Urtijëi") sun l troi n. 19 su per Pedroc, da seniam (Soplajes) su per l troi n. 11 che va nchina te Sautaria. [- Gëura l articul](https://lld.wikipedia.org/wiki/Hartl_\(mont\) "Hartl \(mont\)")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg/250px-Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg)](https://lld.wikipedia.org/wiki/File:Saslonch_da_Hartl_Mont_de_S%C3%ABuc.jpg)
**Hartl** ie na mont tla pert plu a nord y a uriënt dla [Mont de Sëuc](https://lld.wikipedia.org/wiki/Mont_S%C3%ABuc "Mont Sëuc"). L inuem _Hartl_ , che uel dì Leonhard, vën dala ciajea che fova iló dl luech da paur Hartl de Tannürz pra [Laion](https://lld.wikipedia.org/wiki/Laion "Laion"). N iëde ova la mont inuem Mont de Sëuracrëpa, l vedl inuem dl luech Seniam sëura l Iender. L semea che n iëde univa la ciajea Hartl abiteda dut l ann. Sal Hartl ruvun da [Urtijëi](https://lld.wikipedia.org/wiki/Urtij%C3%ABi "Urtijëi") sun l troi n. 19 su per Pedroc, da seniam (Soplajes) su per l troi n. 11 che va nchina te Sautaria. 
  

[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Flag_of_the_Kingdom_of_Prussia_%281803-1892%29.svg/1700px-Flag_of_the_Kingdom_of_Prussia_%281803-1892%29.svg.png)](https://lld.wikipedia.org/wiki/File:Flag_of_the_Kingdom_of_Prussia_\(1803-1892\).svg)
Rest dl mond
[Pruscia](https://lld.wikipedia.org/wiki/Pruscia "Pruscia")
La **Pruscia** ([tudësch](https://lld.wikipedia.org/wiki/Lingaz_tud%C3%ABsch "Lingaz tudësch"): _Preußen_) fova n [stat](https://lld.wikipedia.org/wiki/Stat "Stat") [tudësch](https://lld.wikipedia.org/wiki/Germania "Germania") sun la costa a sud-est dl [Mer Baltich](https://lld.wikipedia.org/wiki/Mer_Baltich "Mer Baltich"). La ova furmà l [Mper Tudësch](https://lld.wikipedia.org/wiki/Mper_Tud%C3%ABsch "Mper Tudësch") sota na dominazion prusciana tl 1871 canche la ova purtà adum duc i stac tudësc. La Pruscia se ova desfà _[de facto](https://lld.wikipedia.org/wiki/De_facto "De facto")_ canche l [pudëi dl guviern de Pruscia fova stat dat](https://lld.wikipedia.org/w/index.php?title=Preu%C3%9Fenschlag&action=edit&redlink=1 "Preußenschlag \(chësta plata ne dal nia\)") al [Canzelier de la Germania](https://lld.wikipedia.org/w/index.php?title=Canzelier_de_la_Germania&action=edit&redlink=1 "Canzelier de la Germania \(chësta plata ne dal nia\)") [Franz von Papen](https://lld.wikipedia.org/w/index.php?title=Franz_von_Papen&action=edit&redlink=1 "Franz von Papen \(chësta plata ne dal nia\)") tl 1932 y _[de jure](https://lld.wikipedia.org/wiki/De_jure "De jure")_ dai [aleac de la segonda viera mundiela](https://lld.wikipedia.org/wiki/Aleac_de_la_segonda_viera_mundiela "Aleac de la segonda viera mundiela") tl 1947. [- Gëura l articul](https://lld.wikipedia.org/wiki/Pruscia "Pruscia")
## [Pruscia](https://lld.wikipedia.org/wiki/Pruscia "Pruscia")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Flag_of_the_Kingdom_of_Prussia_%281803-1892%29.svg/120px-Flag_of_the_Kingdom_of_Prussia_%281803-1892%29.svg.png)](https://lld.wikipedia.org/wiki/File:Flag_of_the_Kingdom_of_Prussia_\(1803-1892\).svg)
La **Pruscia** ([tudësch](https://lld.wikipedia.org/wiki/Lingaz_tud%C3%ABsch "Lingaz tudësch"): _Preußen_) fova n [stat](https://lld.wikipedia.org/wiki/Stat "Stat") [tudësch](https://lld.wikipedia.org/wiki/Germania "Germania") sun la costa a sud-est dl [Mer Baltich](https://lld.wikipedia.org/wiki/Mer_Baltich "Mer Baltich"). La ova furmà l [Mper Tudësch](https://lld.wikipedia.org/wiki/Mper_Tud%C3%ABsch "Mper Tudësch") sota na dominazion prusciana tl 1871 canche la ova purtà adum duc i stac tudësc. La Pruscia se ova desfà _[de facto](https://lld.wikipedia.org/wiki/De_facto "De facto")_ canche l [pudëi dl guviern de Pruscia fova stat dat](https://lld.wikipedia.org/w/index.php?title=Preu%C3%9Fenschlag&action=edit&redlink=1 "Preußenschlag \(chësta plata ne dal nia\)") al [Canzelier de la Germania](https://lld.wikipedia.org/w/index.php?title=Canzelier_de_la_Germania&action=edit&redlink=1 "Canzelier de la Germania \(chësta plata ne dal nia\)") [Franz von Papen](https://lld.wikipedia.org/w/index.php?title=Franz_von_Papen&action=edit&redlink=1 "Franz von Papen \(chësta plata ne dal nia\)") tl 1932 y _[de jure](https://lld.wikipedia.org/wiki/De_jure "De jure")_ dai [aleac de la segonda viera mundiela](https://lld.wikipedia.org/wiki/Aleac_de_la_segonda_viera_mundiela "Aleac de la segonda viera mundiela") tl 1947. 
  

  

####  Articul en vidrina 
Les **Dolomites** , a chëres che al ti vëgn ince dit _Crëps slauris_ , é na [morona de crëps](https://lld.wikipedia.org/wiki/Morona_de_cr%C3%ABps "Morona de crëps") dles [Alpes](https://lld.wikipedia.org/wiki/Alpes "Alpes") orientales [talianes](https://lld.wikipedia.org/wiki/Talia "Talia"), a süd dla morona priniziala dles Alpes che tol ite n raiun danter les [regiuns](https://lld.wikipedia.org/wiki/Regions_de_la_Talia "Regions de la Talia") [Trentin-Südtirol](https://lld.wikipedia.org/wiki/Trentin-S%C3%BCdtirol "Trentin-Südtirol"), [Venet](https://lld.wikipedia.org/wiki/Venet "Venet") y [Friul-Unieja-Giulia](https://lld.wikipedia.org/wiki/Friul-Unieja-Giulia "Friul-Unieja-Giulia") o plu avisa les [provinzies](https://lld.wikipedia.org/wiki/Provinzies_de_la_Talia "Provinzies de la Talia") de [Balsan](https://lld.wikipedia.org/wiki/S%C3%BCdtirol "Südtirol"), [Trënt](https://lld.wikipedia.org/wiki/Trentin "Trentin"), [Belum](https://lld.wikipedia.org/wiki/Provinzia_de_Belum "Provinzia de Belum"), [Udin](https://lld.wikipedia.org/wiki/Provinzia_de_Udin "Provinzia de Udin"), [Pordenone](https://lld.wikipedia.org/wiki/Provinzia_de_Pordenone "Provinzia de Pordenone"), [Vicenza](https://lld.wikipedia.org/wiki/Provinzia_de_Vicenza "Provinzia de Vicenza") y [Verona](https://lld.wikipedia.org/wiki/Provinzia_de_Verona "Provinzia de Verona") cun na picera pert ince te l’[Austria](https://lld.wikipedia.org/wiki/Austria "Austria") (les Dolomites de Lienz). Le crëp plü alt dles Dolomites é la [Marmoleda](https://lld.wikipedia.org/wiki/Marmoleda "Marmoleda") (3342 m), le su [dlaciá](https://lld.wikipedia.org/wiki/Dlaci%C3%A1 "Dlaciá") de döt le raiun y gran scenar dla [Pröma Gran Vera](https://lld.wikipedia.org/wiki/Pr%C3%B6ma_Gran_Vera "Pröma Gran Vera")[[1]](https://lld.wikipedia.org/wiki/Plata_prinzipala#cite_note-1).**..."[Dolomites](https://lld.wikipedia.org/wiki/Dolomites "Dolomites")"**
####  Imaja en vidrina 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Frea_pass_Sella_group_Pisciadu_Dolomites_South_Tyrol.jpg/330px-Frea_pass_Sella_group_Pisciadu_Dolomites_South_Tyrol.jpg)](https://lld.wikipedia.org/wiki/File:Frea_pass_Sella_group_Pisciadu_Dolomites_South_Tyrol.jpg)
Categories
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Ladin.png/40px-Ladin.png)](https://lld.wikipedia.org/wiki/File:Ladin.png)
**[Valedes ladines](https://lld.wikipedia.org/wiki/Valedes_ladines "Valedes ladines")**  
[Storia dles valades ladines](https://lld.wikipedia.org/wiki/Storia_dles_valades_ladines_dles_Dolomites "Storia dles valades ladines dles Dolomites") - [Cultura ladina](https://lld.wikipedia.org/wiki/Cultura_ladina "Cultura ladina") - [Dolomites](https://lld.wikipedia.org/wiki/Dolomites "Dolomites")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/Flag_of_Ladinia.svg/40px-Flag_of_Ladinia.svg.png)](https://lld.wikipedia.org/wiki/File:Flag_of_Ladinia.svg)
**[Lingaz ladin](https://lld.wikipedia.org/wiki/Ladin "Ladin")**  
[Leteratura](https://lld.wikipedia.org/wiki/Leteratura_ladina "Leteratura ladina") - [Linguistica](https://lld.wikipedia.org/wiki/Linguistica_ladina "Linguistica ladina")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Nuvola_apps_kalzium.png/40px-Nuvola_apps_kalzium.png)](https://lld.wikipedia.org/wiki/File:Nuvola_apps_kalzium.png)
**[Sciënza](https://lld.wikipedia.org/wiki/Sci%C3%ABnza "Sciënza")**  
[Astronomia](https://lld.wikipedia.org/wiki/Astronomia "Astronomia") - [Matematica](https://lld.wikipedia.org/wiki/Matematica "Matematica") - [Fisica](https://lld.wikipedia.org/wiki/Fisica "Fisica") - [Chimica](https://lld.wikipedia.org/wiki/Chimica "Chimica") - [Biologia](https://lld.wikipedia.org/wiki/Biologia "Biologia")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Nuvola_apps_browser.png/40px-Nuvola_apps_browser.png)](https://lld.wikipedia.org/wiki/File:Nuvola_apps_browser.png)
**[Sciënzes sozieles](https://lld.wikipedia.org/wiki/Sci%C3%ABnza_soziela "Sciënza soziela")**  
[Storia](https://lld.wikipedia.org/wiki/Storia "Storia") - [Geografia](https://lld.wikipedia.org/wiki/Geografia "Geografia") - [Filosofia](https://lld.wikipedia.org/wiki/Filosofia "Filosofia") - [Ert](https://lld.wikipedia.org/wiki/Ert "Ert")
Variantes Locales dl Ladin
**Articul por[Ladin Val Badia](https://lld.wikipedia.org/wiki/Ladin_Val_Badia "Ladin Val Badia")** |  **[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Gadertal.jpg/40px-Gadertal.jpg)](https://lld.wikipedia.org/wiki/File:Gadertal.jpg)**  
---|---  
**  
`{{Badiot}}`**
**Articul per[Ladin Gherdëina](https://lld.wikipedia.org/wiki/Ladin_gherd%C3%ABina "Ladin gherdëina")** |  **[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Val_Gardena_dall%27alto.JPG/40px-Val_Gardena_dall%27alto.JPG)](https://lld.wikipedia.org/wiki/File:Val_Gardena_dall%27alto.JPG)**  
---|---  
**  
`{{Gherdëina}}`**
**Articul por[Ladin Fascian](https://lld.wikipedia.org/wiki/Ladin_fascian "Ladin fascian")** |  **[![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Campitello_%28Val_di_Fassa%29.JPG/40px-Campitello_%28Val_di_Fassa%29.JPG)](https://lld.wikipedia.org/wiki/File:Campitello_\(Val_di_Fassa\).JPG)**  
---|---  
**  
`{{Fascian}}`**
**Articul por[Ladin Fodom](https://lld.wikipedia.org/wiki/Ladin_fodom "Ladin fodom")** |  **[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Pieve_di_Livinallongo%2C_Decanato_Church.jpg/40px-Pieve_di_Livinallongo%2C_Decanato_Church.jpg)](https://lld.wikipedia.org/wiki/File:Pieve_di_Livinallongo,_Decanato_Church.jpg)**  
---|---  
**  
`{{Fodom}}`**
**Articul por[Ladin Anpezan](https://lld.wikipedia.org/wiki/Ladin_anpezan "Ladin anpezan")** |  **[![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/Faloria_Cortina_d%27Ampezzo_10.jpg/40px-Faloria_Cortina_d%27Ampezzo_10.jpg)](https://lld.wikipedia.org/wiki/File:Faloria_Cortina_d%27Ampezzo_10.jpg)**  
---|---  
**  
`{{Anpezan}}`**
**Articul por[Ladin Dolomitan](https://lld.wikipedia.org/wiki/Ladin_dolomitan "Ladin dolomitan")** |  **[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Sella_da_Ciandepin%C3%ABi.jpg/40px-Sella_da_Ciandepin%C3%ABi.jpg)](https://lld.wikipedia.org/wiki/File:Sella_da_Ciandepin%C3%ABi.jpg)**  
---|---  
**  
`{{Dolomitan}}`**
**N valguna regules per scrijer sun la Wikipedia Ladina:**
1.Chësta ie na lerch per duc, respeteiela! Nia l adurvé per fé retlam o polemiches. 
2.Wikipedia ie neutrala y ne muessa nia repurté minonghes subietives. 
3.Indicheia ti articuli che te scrijes la funtanes scrites che revardea i contenuc. 
4.Sce ne te ses nia da ulà scumencé, cëleti ala [ujes fundamenteles](https://lld.wikipedia.org/wiki/Usc_fondamentales "Usc fondamentales"). 
5.Sce l ie mesun, jonteti pro suinsom al articul che te scrijes l idiom ladin che te adroves cun l Template che ie da abiné tla tabela "Variantes locales dl ladin" 
**[Café ladin](https://lld.wikipedia.org/wiki/Wikipedia:Caf%C3%A9_ladin "Wikipedia:Café ladin")** · **[Suport tecnich](https://lld.wikipedia.org/wiki/Wikipedia:Suport_tecnich "Wikipedia:Suport tecnich")** · **[Vocabolar dl ladin leterar](https://lld.wikipedia.org/wiki/Vocabolar_dl_ladin_leterar "Vocabolar dl ladin leterar")** · **[Wictionary](https://en.wikipedia.org/wiki/wikt:Category:Ladin_language "en:wikt:Category:Ladin language")** · **[Wikisource por ladin](https://wikisource.org/wiki/Main_Page/Ladin "oldwikisource:Main Page/Ladin")** · **[Wikiversità](https://it.wikipedia.org/wiki/v:Categoria:Lezioni_di_Cultura_ladina "it:v:Categoria:Lezioni di Cultura ladina")**
####  N proverb ladin 
“Do San Berto n’á le tëmp plü degun famëi” 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Ladin2_K.jpg/250px-Ladin2_K.jpg)](https://lld.wikipedia.org/wiki/File:Ladin2_K.jpg)
  

**Wikipedia y sü proiec te deplü lingac:** ![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Wikimedia_logo_family_complete-2013.svg/330px-Wikimedia_logo_family_complete-2013.svg.png)
  1. [↑](https://lld.wikipedia.org/wiki/Plata_prinzipala#cite_ref-1) Cultura Ladina, Lois Ellecosta, Intendënza Ladina, Balsan, 2007, pl. 14


Tëut da "[https://lld.wikipedia.org/w/index.php?title=Plata_prinzipala&oldid=220978](https://lld.wikipedia.org/w/index.php?title=Plata_prinzipala&oldid=220978)"
[Categories](https://lld.wikipedia.org/wiki/Speciale:Categorie "Speciale:Categorie"): 
  * [Platas por Ladin Val Badia](https://lld.wikipedia.org/wiki/Categoria:Platas_por_Ladin_Val_Badia "Categoria:Platas por Ladin Val Badia")
  * [Articul per Ladin Gherdëina](https://lld.wikipedia.org/wiki/Categoria:Articul_per_Ladin_Gherd%C3%ABina "Categoria:Articul per Ladin Gherdëina")
  * [Platas por Ladin Fascian](https://lld.wikipedia.org/wiki/Categoria:Platas_por_Ladin_Fascian "Categoria:Platas por Ladin Fascian")
  * [Platas por Ladin Fodom](https://lld.wikipedia.org/wiki/Categoria:Platas_por_Ladin_Fodom "Categoria:Platas por Ladin Fodom")
  * [Platas por Ladin Anpezan](https://lld.wikipedia.org/wiki/Categoria:Platas_por_Ladin_Anpezan "Categoria:Platas por Ladin Anpezan")
  * [Platas por Ladin Dolomitan](https://lld.wikipedia.org/wiki/Categoria:Platas_por_Ladin_Dolomitan "Categoria:Platas por Ladin Dolomitan")


353 lingac
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page - afar")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа - abkhasich")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue - accinese")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ - adyghe")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad - afrikaans")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte - tedesco svizzero")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк - altai meridionale")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ - amarich")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw - Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada - aragonesc")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet - inglese antico")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu - obolo")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ - angika")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة - arabich")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ - aramaico")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا - arabo marocchino")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه - arabo egiziano")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত - assamesc")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada - asturiano")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin - atikamekw")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер - avaro")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola - kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना - awadhi")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi - aymara")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə - azerbaijan")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه - South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит - bashkir")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama - balinese")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn - bavarese")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis - samogitico")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman - batak toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina - Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman - West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка - belarus")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка - Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé - betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница - bulgar")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना - Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej - bislama")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian - banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ - Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ - bambara")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা - bengalesc")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། - tibetan")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা - bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer - breton")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana - bosniach")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo - Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola - bugi")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан - Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada - catalan")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina - Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk - Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо - cecen")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid - cebuano")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman - chamorro")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page - choctaw")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ - cherokee")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama - cheyenne")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک - curdo centrale")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra - corsich")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ - cree")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife - turco crimeo")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana - cech")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna - kashubian")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница - slav eclesiastich")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница - ciuvascich")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan - galesc")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside - danesc")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu - Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite - todësch")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu - Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït - dinca")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri - Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok - basso sorabo")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo - dusun centrale")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना - Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ - divehi")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། - dzongkha")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ - ewe")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια - grech")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP - Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page - inglesc")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo - esperanto")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada - spagnol")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht - eston")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala - basch")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua - estremegno")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی - persian")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir - fanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo - fula")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu - finlandesc")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht - võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu - figiano")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða - faroesc")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn - fon")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal - franzesc")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla - francoprovenzale")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid - frisone settentrionale")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl - furlan")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside - frison dl vest")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach - irlandesc")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak - gagauzo")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 - gan")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal - Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag - gaelich scozesc")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada - galizian")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ - gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha - guaraní")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान - Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo - gorontalo")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 - gotico")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page - Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ - gujarati")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü - wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure - Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan - Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag - manx")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi - haussa")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p - hakka")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi - hawaiano")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי - ebraich")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ - hindi")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna - hindi figiano")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page - hiri motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica - croat")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona - alto sorabo")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal - creolo haitiano")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap - ungaresc")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ - armenich")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ - Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page - herero")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal - interlingua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah - iban")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama - indonesian")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine - interlingue")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ - igbo")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo - Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik - inupiak")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid - ilocano")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув - ingush")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico - ido")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða - islandesc")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale - talian")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ - inuktitut")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ - iapanesc")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej - creolo giamaicano")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju - lojban")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa - giavanesc")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი - georgian")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet - kara-kalpak")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan - cabilo")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ - cabardino")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu - Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu - tyap")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi - kongo")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang - Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page - kikuyu")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page - kuanyama")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет - kazakh")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa - groenlandesc")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម - khmer")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ - kannada")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura - Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 - corean")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок - permiaco")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page - kanuri")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет - karachay-Balkar")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ - kashmiri")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk - coloniese")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk - curdich")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir - Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок - komi")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre - cornich")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак - kyrgyz")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima - latin")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja - giudeo-spagnolo")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit - lussemburghesc")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин - Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин - lesgo")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef - Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka - ganda")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad - limburghese")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ - ligure")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala - lombardo")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó - lingala")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ - lao")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ - luri settentrionale")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis - lituan")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa - letgallo")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa - leton")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan - madurese")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना - maithili")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama - Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа - moksha")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana - malgasich")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page - marshallese")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык - Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga - maori")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo - menangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница - macedonich")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ - malayalam")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас - mongolich")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ - manipuri")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် - Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo - mossi")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ - marathi")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш - mari occidentale")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama - malesc")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali - maltesc")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page - creek")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal - mirandese")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ - birmanich")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа - erzya")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه - mazandarani")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl - Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale - napoletano")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet - basso tedesco")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad - basso tedesco olandese")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ - nepalesc")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ - newari")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu - ndonga")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama - nias")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina - neerlandesc")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside - norvegesc nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside - norvegesc bokmål")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine - novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ - n’ko")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page - ndebele dl süd")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde - Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele - sotho del nord")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi - Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos - navajan")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu - nyanja")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh - ocitan")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu - Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura - oromo")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା - odia")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс - ossetich")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ - punjabi")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong - pangasinan")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung - pampanga")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal - papiamento")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul - piccardo")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej - pidgin nigeriano")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt - tedesco della Pennsylvania")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid - tedesco palatino")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta - pali")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij - Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna - polach")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada - piemontese")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ - Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα - pontico")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ - pashto")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal - portoghesc")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj - Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa - quechua")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ - Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala - rumanc")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin - Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru - rundi")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală - rumen")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã - arumeno")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále - Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок - Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница - rus")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка - ruteno")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro - kinyarwanda")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् - sanscrit")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй - sacha")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ - santali")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale - sard")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali - siciliano")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page - scozzese")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو - sindhi")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu - sami dl nord")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî - sango")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica - serbo-croato")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut - tashelhit")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ - shan")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව - singalesc")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page - Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka - slovach")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت - Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran - sloven")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua - samoano")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo - sami di Inari")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga - shona")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore - somalich")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore - albanesc")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна - serb")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira - sranan tongo")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu - swati")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele - sotho dl süd")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede - saterfriesisch")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas - sundanesc")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida - svedesc")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo - swahili")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ - Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta - slesiano")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih - Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் - tamilich")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan - Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ - tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ - Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ - telugu")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk - tetum")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ - tajich")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก - thailandesc")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ - tigrin")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ - tigre")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa - turcmenich")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina - tagalog")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə - taliscio")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono - tswana")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia - tongaich")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes - tok pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa - türch")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas - taroko")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu - tsonga")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит - tatarich")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu - tumbuka")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw - ci")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a - taitiano")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын - tuvinian")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам - udmurt")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت - uigurich")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка - ucrainich")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول - urdu")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa - uzbech")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani - venda")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio - veneto")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ - vepso")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính - vietnamesc")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad - fiammingo occidentale")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad - volapük")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje - valonesc")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli - waray")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk - wolof")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 - wu")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх - kalmyk")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo - xhosa")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა - mengrelio")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט - yiddish")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ - yoruba")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz - zhuang")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad - zelandese")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ - tamazight del Marocco standard")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 - cinesc")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 - cinese classico")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h - min nan")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 - cantonese")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu - zulu")


[Muda i links](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Muda i links te autra rujenedes")
  * Chësta plata ie stata mudeda l'ultimo iede ai 27 ago 2023 dala 08:00.
  * L test ie a disposizion sota [Creative Commons Attribution-ShareAlike License](https://creativecommons.org/licenses/by-sa/4.0/); L po se dé autra condizions. Cëla [Terms of Use](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use) per details.


  * [Prutezion di dac](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy/it)
  * [Nfurmazions sun Wikipedia](https://lld.wikipedia.org/wiki/Wikipedia:Nfurmazions)
  * [Avisc de lege](https://lld.wikipedia.org/wiki/Wikipedia:Avisc_generei)
  * [Codice di condotta](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Svilupadëures](https://developer.wikimedia.org)
  * [Statistiches](https://stats.wikimedia.org/#/lld.wikipedia.org)
  * [Declarazion sui cookie](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Verscion mobila](https://lld.m.wikipedia.org/w/index.php?title=Plata_prinzipala&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://lld.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://lld.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Crì
Crì
Plata prinzipala
[](https://lld.wikipedia.org/wiki/Plata_prinzipala) [](https://lld.wikipedia.org/wiki/Plata_prinzipala) [](https://lld.wikipedia.org/wiki/Plata_prinzipala) [](https://lld.wikipedia.org/wiki/Plata_prinzipala) [](https://lld.wikipedia.org/wiki/Plata_prinzipala) [](https://lld.wikipedia.org/wiki/Plata_prinzipala) [](https://lld.wikipedia.org/wiki/Plata_prinzipala) [](https://lld.wikipedia.org/wiki/Plata_prinzipala)
353 lingac [Mët leprò n tema de descuscion ](https://lld.wikipedia.org/wiki/Plata_prinzipala)
