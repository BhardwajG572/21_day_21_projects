[Pereiti prie turinio](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis#bodyContent)
Pagrindinis meniu
Pagrindinis meniu
move to sidebar paslėpti
Naršymas 
  * [Pagrindinis puslapis](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Eiti į pradinį puslapį \[z\]")
  * [Bendruomenės puslapis](https://lt.wikipedia.org/wiki/Vikipedija:Bendruomen%C4%97 "Apie projektą, ką galima daryti, kur ką rasti")
  * [Forumas](https://lt.wikipedia.org/wiki/Vikipedija:Forumas)
  * [Naujausi keitimai](https://lt.wikipedia.org/wiki/Specialus:Naujausi_keitimai "Paskutinių keitimų sąrašas viki projekte \[r\]")
  * [Atsitiktinis straipsnis](https://lt.wikipedia.org/wiki/Specialus:Atsitiktinis_puslapis "Įkelti atsitiktinį puslapį \[x\]")
  * [Specialieji puslapiai](https://lt.wikipedia.org/wiki/Specialus:Specialieji_puslapiai)
  * [Pagalba](https://lt.wikipedia.org/wiki/Pagalba:Turinys)


[ ![](https://lt.wikipedia.org/static/images/icons/wikipedia.png) ![Vikipedija](https://lt.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-lt.svg) ![Laisvoji enciklopedija](https://lt.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-lt.svg) ](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis)
[Paieška ](https://lt.wikipedia.org/wiki/Specialus:Paie%C5%A1ka "Ieškoti lietuviškame wiki \[f\]")
Paieška
Išvaizda
  * [Parama](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=lt.wikipedia.org&uselang=lt)
  * [Sukurti paskyrą](https://lt.wikipedia.org/w/index.php?title=Specialus:Sukurti_paskyr%C4%85&returnto=Pagrindinis+puslapis "Skatiname susikurti paskyrą ir prisijungti, tačiau, tai nėra privaloma")
  * [Prisijungti](https://lt.wikipedia.org/w/index.php?title=Specialus:Prisijungimas&returnto=Pagrindinis+puslapis "Rekomenduojame prisijungti, nors tai nėra privaloma \[o\]")


Asmeniniai įrankiai
  * [Parama](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=lt.wikipedia.org&uselang=lt)
  * [Sukurti paskyrą](https://lt.wikipedia.org/w/index.php?title=Specialus:Sukurti_paskyr%C4%85&returnto=Pagrindinis+puslapis "Skatiname susikurti paskyrą ir prisijungti, tačiau, tai nėra privaloma")
  * [Prisijungti](https://lt.wikipedia.org/w/index.php?title=Specialus:Prisijungimas&returnto=Pagrindinis+puslapis "Rekomenduojame prisijungti, nors tai nėra privaloma \[o\]")


[paslėpti]
Šios [savaitės iniciatyva](https://lt.wikipedia.org/wiki/Vikipedija:Savait%C4%97s_iniciatyva "Vikipedija:Savaitės iniciatyva"): **UNESCO pasaulio paveldas**. Kviečiame prisidėti! 
# Pagrindinis puslapis
  * [Pagrindinis puslapis](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Rodyti puslapio turinį \[c\]")
  * [Aptarimas](https://lt.wikipedia.org/wiki/Aptarimas:Pagrindinis_puslapis "Puslapio turinio aptarimas \[t\]")


lietuvių
  * [Skaityti](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis)
  * [Peržiūrėti šaltinį](https://lt.wikipedia.org/w/index.php?title=Pagrindinis_puslapis&action=edit "Puslapis yra užrakintas. Galite pažiūrėti turinį. \[e\]")
  * [Istorija](https://lt.wikipedia.org/w/index.php?title=Pagrindinis_puslapis&action=history "Ankstesnės puslapio versijos \[h\]")


Įrankiai
Įrankiai
move to sidebar paslėpti
Veiksmai 
  * [Skaityti](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis)
  * [Peržiūrėti šaltinį](https://lt.wikipedia.org/w/index.php?title=Pagrindinis_puslapis&action=edit)
  * [Istorija](https://lt.wikipedia.org/w/index.php?title=Pagrindinis_puslapis&action=history)


Bendra 
  * [Susiję straipsniai](https://lt.wikipedia.org/wiki/Specialus:Kas_%C4%AF_%C4%8Dia_rodo/Pagrindinis_puslapis "Viki puslapių sąrašas, kuris nurodo čia \[j\]")
  * [Susiję keitimai](https://lt.wikipedia.org/wiki/Specialus:Pakeitimai_susijusiuose_puslapiuose/Pagrindinis_puslapis "Paskutiniai keitimai puslapiuose, pasiekiamuose iš šio puslapio \[k\]")
  * [Nuolatinė nuoroda](https://lt.wikipedia.org/w/index.php?title=Pagrindinis_puslapis&oldid=7571679 "Nuolatinė nuoroda į šią puslapio versiją")
  * [Puslapio informacija](https://lt.wikipedia.org/w/index.php?title=Pagrindinis_puslapis&action=info "Daugiau žinių apie šį puslapį")
  * [Cituoti straipsnį](https://lt.wikipedia.org/w/index.php?title=Specialus:CiteThisPage&page=Pagrindinis_puslapis&id=7571679&wpFormIdentifier=titleform "Informacija kaip cituoti šį puslapį")
  * [Gauti sutrumpintą URL nuorodą](https://lt.wikipedia.org/w/index.php?title=Specialus:UrlShortener&url=https%3A%2F%2Flt.wikipedia.org%2Fwiki%2FPagrindinis_puslapis)
  * [Atsisiųsti QR kodą](https://lt.wikipedia.org/w/index.php?title=Specialus:QrCode&url=https%3A%2F%2Flt.wikipedia.org%2Fwiki%2FPagrindinis_puslapis)


Spausdinti/eksportuoti 
  * [Kurti knygą](https://lt.wikipedia.org/w/index.php?title=Specialus:Book&bookcmd=book_creator&referer=Pagrindinis+puslapis)
  * [Parsisiųsti kaip PDF](https://lt.wikipedia.org/w/index.php?title=Specialus:DownloadAsPdf&page=Pagrindinis_puslapis&action=show-download-screen)
  * [Versija spausdinimui](https://lt.wikipedia.org/w/index.php?title=Pagrindinis_puslapis&printable=yes "Šio puslapio versija spausdinimui \[p\]")


Kituose projektuose 
  * [Vikiteka](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Metaviki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Vikirūšys](https://species.wikimedia.org/wiki/Main_Page)
  * [Vikiknygos](https://lt.wikibooks.org/wiki/Pagrindinis_puslapis)
  * [Vikiduomenys](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Vikicitatos](https://lt.wikiquote.org/wiki/Pagrindinis_puslapis)
  * [Vikišaltiniai](https://lt.wikisource.org/wiki/Pagrindinis_puslapis)
  * [Vikižodynas](https://lt.wiktionary.org/wiki/Viki%C5%BEodynas:Pagrindinis_puslapis)
  * [Vikiduomenys įrašas](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Nuoroda į susietą duomenų saugyklos įrašą \[g\]")


Išvaizda
move to sidebar paslėpti
Straipsnis iš Vikipedijos, laisvosios enciklopedijos.
Sveiki atvykę į Vikipediją  
Laisvąją enciklopediją, kurią kurti gali kiekvienas. |  [Lietuviškojoje Vikipedijoje](https://lt.wikipedia.org/wiki/Lietuvi%C5%A1koji_Vikipedija "Lietuviškoji Vikipedija"):  
**[223 567](https://lt.wikipedia.org/wiki/Specialus:Statistika "Specialus:Statistika")** straipsniai 
  * [Vikipedijos vedlys](https://lt.wikipedia.org/wiki/Pagalba:Sveiki_atvyk%C4%99_%C4%AF_Laisv%C4%85j%C4%85_enciklopedij%C4%85! "Pagalba:Sveiki atvykę į Laisvąją enciklopediją!")
  * [Pagalba](https://lt.wikipedia.org/wiki/Pagalba:Turinys "Pagalba:Turinys")
  * [DUK](https://lt.wikipedia.org/wiki/Pagalba:DUK "Pagalba:DUK")
  * [Bendruomenės portalas](https://lt.wikipedia.org/wiki/Vikipedija:Bendruomen%C4%97 "Vikipedija:Bendruomenė")
  * [Klausk](https://lt.wikipedia.org/wiki/Vikipedija:Pagalbos_biuras "Vikipedija:Pagalbos biuras")
  * [Taisyklės ir susitarimai](https://lt.wikipedia.org/wiki/Vikipedija:Taisykl%C4%97s_ir_susitarimai "Vikipedija:Taisyklės ir susitarimai")
  * [Paveikslėlių naudojimas](https://lt.wikipedia.org/wiki/Pagalba:Paveiksl%C4%97liai "Pagalba:Paveikslėliai")

  
---|---  
Apie Vikipediją **[Vikipedija](https://lt.wikipedia.org/wiki/Vikipedija "Vikipedija")** yra universali, daugiakalbė interneto enciklopedija, kaip bendruomeninis projektas, pagal _[viki](https://lt.wikipedia.org/wiki/Wiki "Wiki")_ technologiją ir [pamatinius principus](https://lt.wikipedia.org/wiki/Vikipedija:Penki_stulpai "Vikipedija:Penki stulpai") kuriama daugybės [savanorių](https://lt.wikipedia.org/wiki/Vikipedijos_bendruomen%C4%97 "Vikipedijos bendruomenė") bei išlaikoma iš paaukotų lėšų. Vikipedijos tikslas – pateikti [laisvą](https://lt.wikipedia.org/wiki/Vikipedija:Autori%C5%B3_teis%C4%97s "Vikipedija:Autorių teisės"), [nešališką](https://lt.wikipedia.org/wiki/Vikipedija:Neutralus_po%C5%BEi%C5%ABris "Vikipedija:Neutralus požiūris") ir [patikrinamą](https://lt.wikipedia.org/wiki/Vikipedija:Patikrinamumas "Vikipedija:Patikrinamumas") turinį, kurį be jokių apribojimų gimtąja kalba galėtų skaityti visi žmonės. Rašyti, pildyti, tobulinti straipsnius taip pat gali visi, jei laikomasi bendrų, visiems dalyviams galiojančių [taisyklių ir susitarimų](https://lt.wikipedia.org/wiki/Vikipedija:Taisykl%C4%97s_ir_susitarimai "Vikipedija:Taisyklės ir susitarimai"). Vikipedija nuolat kuriama, taisoma, tobulinama bei redaguojama, tad nėra [jokių garantijų](https://lt.wikipedia.org/wiki/Vikipedija:Joki%C5%B3_garantij%C5%B3 "Vikipedija:Jokių garantijų"), kad enciklopedijoje pateikiama informacija yra teisinga. Nauji dalyviai yra kviečiami apsilankyti [pagalbos puslapiuose](https://lt.wikipedia.org/wiki/Pagalba:Turinys "Pagalba:Turinys") ir [bendruomenės portale](https://lt.wikipedia.org/wiki/Vikipedija:Bendruomen%C4%97 "Vikipedija:Bendruomenė").  Vikipedija vadinama „laisvąja enciklopedija“, nes visas jos turinys pateikiamas pagal [GFDL](https://lt.wikipedia.org/wiki/GFDL "GFDL") ir [CC-BY-SA](https://lt.wikipedia.org/wiki/Creative_Commons "Creative Commons") licencijas, kurios leidžia enciklopedijos turinį naudoti, keisti ir platinti tiek nemokamai, tiek ir mokamai, jei laikomasi naudojimo sąlygų. |  Rinktinė iliustracija |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Panjshir_River_Valley_in_May_2011.jpg/500px-Panjshir_River_Valley_in_May_2011.jpg)](https://lt.wikipedia.org/wiki/Vaizdas:Panjshir_River_Valley_in_May_2011.jpg)  
---  
[Pandžširo slėnis](https://lt.wikipedia.org/wiki/Pand%C5%BE%C5%A1iro_sl%C4%97nis "Pandžširo slėnis"), [![Afganistanas](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Flag_of_the_Taliban.svg/40px-Flag_of_the_Taliban.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Flag_of_the_Taliban.svg "Afganistanas") [Afganistanas](https://lt.wikipedia.org/wiki/Afganistanas "Afganistanas")  
**[Projekto puslapis](https://lt.wikipedia.org/wiki/Vikiprojektas:Straipsni%C5%B3_iliustravimas "Vikiprojektas:Straipsnių iliustravimas")** • [Keisti](https://lt.wikipedia.org/wiki/%C5%A0ablonas:Prad%C5%BEia-Rinktin%C4%97-illu "Šablonas:Pradžia-Rinktinė-illu")  
Savaitės straipsnis [![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Juozo_Daugirdo_namas%2C_Vytauto_30.jpeg/250px-Juozo_Daugirdo_namas%2C_Vytauto_30.jpeg)](https://lt.wikipedia.org/wiki/Vaizdas:Juozo_Daugirdo_namas,_Vytauto_30.jpeg)Pagrindinis fasadas **Juozo Daugirdo namas** – daugiabutis pastatas [Kauno](https://lt.wikipedia.org/wiki/Kaunas "Kaunas") mieste, [Naujamiestyje](https://lt.wikipedia.org/wiki/Naujamiestis_\(Kaunas\) "Naujamiestis \(Kaunas\)"), stovintis smailiakampėje [Vytauto pr.](https://lt.wikipedia.org/w/index.php?title=Vytauto_prospektas_\(Kaunas\)&action=edit&redlink=1 "Vytauto prospektas \(Kaunas\) \(puslapis neegzistuoja\)") ir Bažnyčios g. sandūroje, per vieną pastatą nutolęs nuo [Autobusų stoties](https://lt.wikipedia.org/wiki/Kauno_autobus%C5%B3_stotis "Kauno autobusų stotis"), priešingoje pusėje nuo [Ramybės parko](https://lt.wikipedia.org/wiki/Ramyb%C4%97s_parkas "Ramybės parkas") (Senųjų kapinių). 1931 m. pastatytas pagal architekto [Vladimiro Dubeneckio](https://lt.wikipedia.org/wiki/Vladimiras_Dubeneckis "Vladimiras Dubeneckis") biure parengtą projektą. Tai buvo vienas vėlyviausių šio architekto suprojektuotų pastatų, atspindinčių XX a. [modernizmo architektūros](https://lt.wikipedia.org/wiki/Kauno_modernizmo_architekt%C5%ABra "Kauno modernizmo architektūra") tendencijas [tarpukario](https://lt.wikipedia.org/wiki/Tarpukaris "Tarpukaris") Kaune, vyravusias miesto planavimo ir vystymo normas bei tendencijas. 1992 m. įrašytas į [Kultūros vertybių registrą](https://lt.wikipedia.org/wiki/Kult%C5%ABros_vertybi%C5%B3_registras "Kultūros vertybių registras"), jam suteiktas regioninės reikšmės architektūros ir memorialinio paminklo statusas.  Namas pastatytas bendrovės „[Drobė](https://lt.wikipedia.org/wiki/AB_Drob%C4%97 "AB Drobė")“ direktoriaus, [Amerikos lietuvio](https://lt.wikipedia.org/wiki/JAV_lietuviai "JAV lietuviai") Juozo Daugirdo (1879–1947) užsakymu. Jis buvo kilęs iš [Čekiškės valsčiaus](https://lt.wikipedia.org/wiki/%C4%8Ceki%C5%A1k%C4%97s_vals%C4%8Dius "Čekiškės valsčius"), [Šlapučių](https://lt.wikipedia.org/wiki/%C5%A0lapu%C4%8Diai "Šlapučiai") kaimo. Po tarnybos rusų kariuomenėje, 1906–1922 m. buvo išvykęs į Ameriką uždarbiauti.  Namo statybos techninę priežiūrą vykdė Vladimiras Dubeneckis su savo biuro architektais [Vsevolodu Kopylovu](https://lt.wikipedia.org/wiki/Vsevolodas_Kopylovas "Vsevolodas Kopylovas") ir Leonidu Jankovičiumi. Pats savininkas taip pat aktyviai dalyvavo statybos darbų priežiūroje, kaip liudija įrašai darbų vykdytojo Boriso Blagoveščenskio vestame statybos žurnale. Pastato statybos tuometiniu adresu Vytauto pr. 14 pradėtos 1930 m., nugriovus sklype stovėjusius senus pastatus. Name buvo suprojektuota 12 butų, 3 krautuvės apatiniame aukšte, sargo, skalbyklos ir kitos pagalbinės patalpos rūsyje ir palėpėje. Daugiabutis baigtas statyti 1931 m. pabaigoje.  **[Daugiau...](https://lt.wikipedia.org/wiki/Juozo_Daugirdo_namas "Juozo Daugirdo namas")** **[Pavyzdiniai straipsniai](https://lt.wikipedia.org/wiki/Vikipedija:Pavyzdiniai_straipsniai "Vikipedija:Pavyzdiniai straipsniai")** • **[Verta paskaityti](https://lt.wikipedia.org/wiki/Vikipedija:Verta_paskaityti "Vikipedija:Verta paskaityti")** • [Keisti](https://lt.wikipedia.org/wiki/Vikiprojektas:Savait%C4%97s_straipsnis/Straipsnis "Vikiprojektas:Savaitės straipsnis/Straipsnis") • [Rinkti straipsnį](https://lt.wikipedia.org/wiki/Vikiprojektas:Savait%C4%97s_straipsnis "Vikiprojektas:Savaitės straipsnis") |  [spalio 1](https://lt.wikipedia.org/wiki/Spalio_1 "Spalio 1") d. įvykiai **Lietuvoje**
  * [1817](https://lt.wikipedia.org/wiki/1817 "1817") − [Vilniaus universitete](https://lt.wikipedia.org/wiki/Vilniaus_universitetas "Vilniaus universitetas") įkurta nelegali anticarinė studentų [filomatų](https://lt.wikipedia.org/wiki/Filomatai "Filomatai") draugija.
  * [1922](https://lt.wikipedia.org/wiki/1922 "1922") − [Lietuvoje](https://lt.wikipedia.org/wiki/Lietuva "Lietuva") įvesta nacionalinė [valiuta](https://lt.wikipedia.org/wiki/Valiuta "Valiuta") – [litas](https://lt.wikipedia.org/wiki/Litas "Litas") – viena iš stabiliausių valiutų tarpukario [Europoje](https://lt.wikipedia.org/wiki/Europa "Europa").
  * [1992](https://lt.wikipedia.org/wiki/1992 "1992") − kaip vienintelė mokėjimo priemonė Lietuvoje pradėjo funkcionuoti laikinieji pinigai – [bendrieji talonai](https://lt.wikipedia.org/wiki/Bendrieji_talonai "Bendrieji talonai").

**Pasaulyje**
  * [331 m. pr. m. e.](https://lt.wikipedia.org/wiki/331_m._pr._m._e. "331 m. pr. m. e.") − [Gaugamelų mūšyje](https://lt.wikipedia.org/wiki/Gaugamel%C5%B3_m%C5%AB%C5%A1is "Gaugamelų mūšis") [Aleksandro Makedoniečio](https://lt.wikipedia.org/wiki/Aleksandras_Makedonietis "Aleksandras Makedonietis") vadovaujama Makedonijos kariuomenė nugalėjo [Darijaus III](https://lt.wikipedia.org/wiki/Darijus_III "Darijus III") vadovaujamą [Persijos](https://lt.wikipedia.org/wiki/Persija "Persija") kariuomenę.
  * [1880](https://lt.wikipedia.org/wiki/1880 "1880") − [Thomas Edison](https://lt.wikipedia.org/wiki/Thomas_Edison "Thomas Edison") atidarė pirmąjį elektros lempučių fabriką.
  * [1938](https://lt.wikipedia.org/wiki/1938 "1938") − [Vokietija](https://lt.wikipedia.org/wiki/Tre%C4%8Diasis_Reichas "Trečiasis Reichas") aneksavo [Čekoslovakijos](https://lt.wikipedia.org/wiki/%C4%8Cekoslovakija "Čekoslovakija") [Sudetų kraštą](https://lt.wikipedia.org/wiki/Sudet%C5%B3_kra%C5%A1tas "Sudetų kraštas").
  * [1949](https://lt.wikipedia.org/wiki/1949 "1949") − [Mao Zedong](https://lt.wikipedia.org/wiki/Mao_Zedong "Mao Zedong") paskelbė Kiniją [Liaudies Respublika](https://lt.wikipedia.org/wiki/Kinijos_Liaudies_Respublika "Kinijos Liaudies Respublika").
  * [1969](https://lt.wikipedia.org/wiki/1969 "1969") − viršgarsinis keleivinis lėktuvas _[Concorde](https://lt.wikipedia.org/wiki/Concorde "Concorde")_ pirmą kartą pasiekė viršgarsinį greitį. [Keisti](https://lt.wikipedia.org/wiki/%C5%A0ablonas:Spalio_1_dienos_%C4%AFvykiai "Šablonas:Spalio 1 dienos įvykiai")

  
---|---  
Savaitės iniciatyva [![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/Codoj6.JPG/250px-Codoj6.JPG)](https://lt.wikipedia.org/wiki/Vaizdas:Codoj6.JPG)Čangano kraštovaizdis **[Čangano kraštovaizdžio kompleksas](https://lt.wikipedia.org/wiki/%C4%8Cangano_kra%C5%A1tovaizdis "Čangano kraštovaizdis")** ([viet.](https://lt.wikipedia.org/wiki/Vietnamie%C4%8Di%C5%B3_kalba "Vietnamiečių kalba") _Quần thể danh thắng Tràng An_ , 群體名勝長安) − [UNESCO](https://lt.wikipedia.org/wiki/UNESCO "UNESCO") Pasaulio paveldo objektas [Vietname](https://lt.wikipedia.org/wiki/Vietnamas "Vietnamas"), [Ninbinio provincijoje](https://lt.wikipedia.org/w/index.php?title=Ninbinio_provincija&action=edit&redlink=1 "Ninbinio provincija \(puslapis neegzistuoja\)"). Į pasaulio paveldo sąrašą įtrauktas [2014](https://lt.wikipedia.org/wiki/2014 "2014") m. dėl savo istorinės, kultūrinės ir gamtinės vertės. Tai – pirmasis mišrus pasaulio paveldas Pietryčių Azijoje.  Kompleksas apima 6026 [ha](https://lt.wikipedia.org/wiki/Hektaras "Hektaras") natūralios gamtos teritoriją [Raudonosios upės](https://lt.wikipedia.org/wiki/Raudonoji_up%C4%97 "Raudonoji upė") deltos pietiniame pakraštyje, per kurį teka Ngodongo ([viet.](https://lt.wikipedia.org/wiki/Vietnamie%C4%8Di%C5%B3_kalba "Vietnamiečių kalba") _Sông Ngô Đồng_), Hoanglongo ir kitos upės. Lygumose stūkso vaizdingi smiltainio kalnai, apaugę miškais, tarp jų įsiterpę upeliai ir šlapynės, yra daug urvų. Čia yra ir senosios X–XI a. Vietnamo sostinės [Hoalu](https://lt.wikipedia.org/w/index.php?title=Senasis_Hoalu_miestas&action=edit&redlink=1 "Senasis Hoalu miestas \(puslapis neegzistuoja\)") ([viet.](https://lt.wikipedia.org/wiki/Vietnamie%C4%8Di%C5%B3_kalba "Vietnamiečių kalba") _Hoa Lư_ , 華閭) likučiai su šventyklomis ir pagodomis. Gyvena apie 14 tūkst. gyventojų, kurie verčiasi žemės ūkiu. Objektas gausiai lankomas turistų.  Išskirtinį reljefą per milijonus metų suformavo [karstiniai reiškiniai](https://lt.wikipedia.org/wiki/Karstas_\(rei%C5%A1kinys\) "Karstas \(reiškinys\)"). Smiltainio bokštų pavidalo kalnai skiriami šlapynių ir vandens kelių, kurių dalis yra naviguojami plokščiadugnėmis valtimis. Dėl savo kraštovaizdžio panašumo su [Halongo įlanka](https://lt.wikipedia.org/wiki/Halongo_%C4%AFlanka "Halongo įlanka"), vietovė dar vadinama „Sausumos Halongu“.  Visame regione išsimėtę gausūs urvai, tarp kurių žinomiausi yra Tamkokas ([viet.](https://lt.wikipedia.org/wiki/Vietnamie%C4%8Di%C5%B3_kalba "Vietnamiečių kalba") _Tam Cốc_ , 三谷) ir Bikdongas ([viet.](https://lt.wikipedia.org/wiki/Vietnamie%C4%8Di%C5%B3_kalba "Vietnamiečių kalba") _Bích Động_ , 碧峝).  Šios [savaitės iniciatyva](https://lt.wikipedia.org/wiki/Vikiprojektas:Savait%C4%97s_iniciatyva "Vikiprojektas:Savaitės iniciatyva") yra **UNESCO pasaulio paveldas**. **[Projekto puslapis](https://lt.wikipedia.org/wiki/Vikipedija:Savait%C4%97s_iniciatyva "Vikipedija:Savaitės iniciatyva")** • [Keisti](https://lt.wikipedia.org/wiki/%C5%A0ablonas:Savait%C4%97s_tema "Šablonas:Savaitės tema") |  Naujienos
  * Spalio 1 d. [Filipinuose](https://lt.wikipedia.org/wiki/Filipinai "Filipinai") per [žemės drebėjimą](https://lt.wikipedia.org/wiki/%C5%BDem%C4%97s_dreb%C4%97jimas "Žemės drebėjimas") žuvo mažiausiai 60 žmonių.[[1]](https://www.lrt.lt/naujienos/pasaulyje/6/2698029/per-zemes-drebejima-filipinuose-zuvo-iki-60-zmoniu)
  * Rugsėjo 30 d. [Talibanas](https://lt.wikipedia.org/wiki/Talibanas "Talibanas") visame [Afganistane](https://lt.wikipedia.org/wiki/Afganistanas "Afganistanas") nutraukė interneto ryšį.[[2]](https://www.bbc.com/news/articles/c98dmq03n92o)
  * Rugsėjo 28 d. [Peru](https://lt.wikipedia.org/wiki/Peru "Peru") per protestus, nukreiptus prieš vyriausybę, sužeista bent 19 žmonių.[[3]](https://www.lrt.lt/naujienos/pasaulyje/6/2696116/per-antivyriausybinius-protestus-peru-suzeista-maziausiai-19-zmoniu)
  * Rugsėjo 28 d. [Moldovos](https://lt.wikipedia.org/wiki/Moldova "Moldova") parlamento rinkimus laimėjo valdančioji proeuropietiška [Veiksmo ir solidarumo partija](https://lt.wikipedia.org/w/index.php?title=Veiksmo_ir_solidarumo_partija&action=edit&redlink=1 "Veiksmo ir solidarumo partija \(puslapis neegzistuoja\)").[[4]](https://www.lrt.lt/naujienos/pasaulyje/6/2696031/moldovoje-parlamento-rinkimus-laimejo-valdancioji-proeuropietiska-partija)
  * Rugsėjo 25 d. Prisiekė [naujoji vyriausybė](https://lt.wikipedia.org/wiki/I._Ruginien%C4%97s_ministr%C5%B3_kabinetas "I. Ruginienės ministrų kabinetas"), vadovaujama [Ingos Ruginienės](https://lt.wikipedia.org/wiki/Inga_Ruginien%C4%97 "Inga Ruginienė").[[5]](https://www.lrt.lt/naujienos/lietuvoje/2/2691227/seimas-pritare-vyriausybes-programai-ministrai-prisieke-valstybei-turi-prasideti-darbas)
  * Rugsėjo 21 d. [Jungtinė Karalystė](https://lt.wikipedia.org/wiki/Jungtin%C4%97_Karalyst%C4%97 "Jungtinė Karalystė"), [Kanada](https://lt.wikipedia.org/wiki/Kanada "Kanada") ir [Australija](https://lt.wikipedia.org/wiki/Australija "Australija") pripažino [Palestinos valstybę](https://lt.wikipedia.org/wiki/Palestinos_valstyb%C4%97 "Palestinos valstybė").[[6]](https://edition.cnn.com/2025/09/21/world/palestinian-state-uk-canada-australia-intl)
  * Rugsėjo 17 d. [Nigeryje](https://lt.wikipedia.org/wiki/Nigeris "Nigeris") ginkluoti užpuolikai nušovė 22 žmones.[[7]](https://www.bbc.com/news/articles/ce863x3g7jko)
  * Rugsėjo 14 d. [Europos krepšinio čempionatą](https://lt.wikipedia.org/wiki/2025_m._Europos_krep%C5%A1inio_%C4%8Dempionatas "2025 m. Europos krepšinio čempionatas") laimėjo [Vokietijos rinktinė](https://lt.wikipedia.org/wiki/Vokietijos_vyr%C5%B3_krep%C5%A1inio_rinktin%C4%97 "Vokietijos vyrų krepšinio rinktinė").[[8]](https://www.basketnews.lt/news-231409-vokietijos-dominavimas-antras-auksas-per-trejus-metus.html)
  * Rugsėjo 10 d. [JAV](https://lt.wikipedia.org/wiki/JAV "JAV"), [Jutoje](https://lt.wikipedia.org/wiki/Juta "Juta"), nušautas konservatyvus aktyvistas, šalies prezidento [Donald Trump](https://lt.wikipedia.org/wiki/Donald_Trump "Donald Trump") šalininkas [Charlie Kirk](https://lt.wikipedia.org/wiki/Charlie_Kirk "Charlie Kirk").[[9]](https://www.bbc.com/news/live/c206zm81z4gt)
  * Rugsėjo 9 d. [Izraelis](https://lt.wikipedia.org/wiki/Izraelis "Izraelis") smogė „[Hamas](https://lt.wikipedia.org/wiki/Hamas "Hamas")“ biurui [Kataro](https://lt.wikipedia.org/wiki/Kataras "Kataras") sostinėje [Dohoje](https://lt.wikipedia.org/wiki/Doha "Doha").[[10]](https://www.lrt.lt/naujienos/pasaulyje/6/2670814/izraelis-teigia-smoges-hamas-biurui-kataro-sostineje-dohoje)

**[Projekto puslapis](https://lt.wikipedia.org/wiki/Vikiprojektas:Naujienos "Vikiprojektas:Naujienos")** • [Metų įvykiai](https://lt.wikipedia.org/wiki/Vikisritis:Metai "Vikisritis:Metai") • [Sporto naujienos](https://lt.wikipedia.org/wiki/Vikisritis:Sportas "Vikisritis:Sportas") • [Keisti](https://lt.wikipedia.org/wiki/Vikiprojektas:Naujienos/S%C4%85ra%C5%A1as "Vikiprojektas:Naujienos/Sąrašas")  
---|---  
Kiti projektai  
---  
|   
---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/WiktionaryLt.png/40px-WiktionaryLt.png)](https://lt.wikipedia.org/wiki/Vaizdas:WiktionaryLt.png) |  [**Vikižodynas**](https://lt.wiktionary.org/wiki/ "wikt:")  
 _Laisvasis žodynas_ |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Wikiquote-logo.svg) |  [**Vikicitatos**](https://lt.wikiquote.org/wiki/ "q:")  
 _Aforizmai, sentencijos_ |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Wikinews-logo.svg) |  [**Vikinaujienos**](https://wikinews.org)  
 _Naujausios žinios, aktualijos_ |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Commons-logo.svg) |  [**Vikiteka (_Wikimedia Commons_)**](https://commons.wikimedia.org/wiki/Pagrindinis_puslapis "commons:Pagrindinis puslapis")  
_Mediateka_  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Wikisource-logo.svg) |  [**Vikišaltiniai**](https://lt.wikisource.org/wiki/ "s:")  
 _Įvairūs tekstai_ |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Wikibooks-logo.svg) |  [**Vikiknygos**](https://lt.wikibooks.org/wiki/ "b:")  
 _Vadovėliai, knygos_ |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Wikispecies-logo.svg) |  [**Vikirūšys (_wikispecies_)**](https://species.wikimedia.org/wiki/ "wikispecies:")  
_Rūšių katalogas_ |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/40px-Wikimedia-logo.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Wikimedia-logo.svg) |  [**Metaviki**](https://meta.wikimedia.org/wiki/Pagrindinis_puslapis "m:Pagrindinis puslapis")  
 _Vikimedijos projektų koordinavimas_  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Wikidata-logo.svg) |  [**Vikiduomenys**](https://www.wikidata.org/wiki/ "d:")  
 _Žinių bazė_ |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Wikiversity-logo.svg) |  [**Vikiversitetas**](https://en.wikipedia.org/wiki/v: "en:v:")  
 _Mokomoji medžiaga_ |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:Wikivoyage-Logo-v3-icon.svg) |  [**Vikikelionės**](https://en.wikivoyage.org/wiki/ "wikivoyage:")  
 _Kelionių vadovas_ |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/MediaWiki-2020-logo.svg/40px-MediaWiki-2020-logo.svg.png)](https://lt.wikipedia.org/wiki/Vaizdas:MediaWiki-2020-logo.svg) |  [**MediaWiki**](https://www.mediawiki.org/wiki/ "mw:")  
 _Viki programinė įranga_  
  

Rodomas puslapis "[https://lt.wikipedia.org/w/index.php?title=Pagrindinis_puslapis&oldid=7571679](https://lt.wikipedia.org/w/index.php?title=Pagrindinis_puslapis&oldid=7571679)"
32 kalbų
  * [العربية](https://ar.wikipedia.org/wiki/ "arabų")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/ "žemaičių")
  * [Беларуская](https://be.wikipedia.org/wiki/ "baltarusių")
  * [Български](https://bg.wikipedia.org/wiki/ "bulgarų")
  * [Čeština](https://cs.wikipedia.org/wiki/ "čekų")
  * [Dansk](https://da.wikipedia.org/wiki/ "danų")
  * [Deutsch](https://de.wikipedia.org/wiki/ "vokiečių")
  * [English](https://en.wikipedia.org/wiki/ "anglų")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "esperanto")
  * [Español](https://es.wikipedia.org/wiki/ "ispanų")
  * [Eesti](https://et.wikipedia.org/wiki/ "estų")
  * [فارسی](https://fa.wikipedia.org/wiki/ "persų")
  * [Français](https://fr.wikipedia.org/wiki/ "prancūzų")
  * [Magyar](https://hu.wikipedia.org/wiki/ "vengrų")
  * [Italiano](https://it.wikipedia.org/wiki/ "italų")
  * [日本語](https://ja.wikipedia.org/wiki/ "japonų")
  * [ქართული](https://ka.wikipedia.org/wiki/ "gruzinų")
  * [Latina](https://la.wikipedia.org/wiki/ "lotynų")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/ "latgalių")
  * [Latviešu](https://lv.wikipedia.org/wiki/ "latvių")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "olandų")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "norvegų bukmolas")
  * [Polski](https://pl.wikipedia.org/wiki/ "lenkų")
  * [Português](https://pt.wikipedia.org/wiki/ "portugalų")
  * [Русский](https://ru.wikipedia.org/wiki/ "rusų")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "serbų")
  * [Svenska](https://sv.wikipedia.org/wiki/ "švedų")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "turkų")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/ "totorių")
  * [Українська](https://uk.wikipedia.org/wiki/ "ukrainiečių")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vietnamiečių")
  * [中文](https://zh.wikipedia.org/wiki/ "kinų")


  * Šis puslapis paskutinį kartą keistas 30 gegužės 2025 21:28.
  * Tekstas pateikiamas pagal [Creative Commons Attribution/Share-Alike Licenciją](https://creativecommons.org/licenses/by-sa/4.0/); gali būti taikomos papildomos sąlygos. Detaliau – [Terms of Use](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use) .


  * [Privatumo politika](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Apie Vikipediją](https://lt.wikipedia.org/wiki/Vikipedija:Apie)
  * [Jokių garantijų](https://lt.wikipedia.org/wiki/Vikipedija:General_disclaimer)
  * [Elgesio kodeksas](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Kūrėjai](https://developer.wikimedia.org)
  * [Statistika](https://stats.wikimedia.org/#/lt.wikipedia.org)
  * [Slapukų politika](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Mobili peržiūra](https://lt.m.wikipedia.org/w/index.php?title=Pagrindinis_puslapis&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://lt.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://lt.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Paieška
Paieška
Pagrindinis puslapis
[](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis) [](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis) [](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis) [](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis) [](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis) [](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis) [](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis) [](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis)
32 kalbų [Pridėti temą ](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis)
