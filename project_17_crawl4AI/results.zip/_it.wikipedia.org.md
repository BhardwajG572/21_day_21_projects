[Vai al contenuto](https://it.wikipedia.org/wiki/Pagina_principale#bodyContent)
Menu principale
Menu principale
sposta nella barra laterale nascondi
Navigazione 
  * [Pagina principale](https://it.wikipedia.org/wiki/Pagina_principale "Visita la pagina principale \[z\]")
  * [Ultime modifiche](https://it.wikipedia.org/wiki/Speciale:UltimeModifiche "Elenco delle ultime modifiche del sito \[r\]")
  * [Una voce a caso](https://it.wikipedia.org/wiki/Speciale:PaginaCasuale "Mostra una pagina a caso \[x\]")
  * [Nelle vicinanze](https://it.wikipedia.org/wiki/Speciale:NelleVicinanze)
  * [Vetrina](https://it.wikipedia.org/wiki/Wikipedia:Vetrina)
  * [Aiuto](https://it.wikipedia.org/wiki/Aiuto:Aiuto "Pagine di aiuto")
  * [Sportello informazioni](https://it.wikipedia.org/wiki/Aiuto:Sportello_informazioni)
  * [Pagine speciali](https://it.wikipedia.org/wiki/Speciale:PagineSpeciali)


Comunità 
  * [Portale Comunità](https://it.wikipedia.org/wiki/Portale:Comunit%C3%A0 "Descrizione del progetto, cosa puoi fare, dove trovare le cose")
  * [Bar](https://it.wikipedia.org/wiki/Wikipedia:Bar)
  * [Il Wikipediano](https://it.wikipedia.org/wiki/Wikipedia:Wikipediano)
  * [Contatti](https://it.wikipedia.org/wiki/Wikipedia:Contatti)


[ ![](https://it.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://it.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![L'enciclopedia libera](https://it.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-it.svg) ](https://it.wikipedia.org/wiki/Pagina_principale)
[Ricerca ](https://it.wikipedia.org/wiki/Speciale:Ricerca "Cerca in Wikipedia \[f\]")
Ricerca
Aspetto
  * [Fai una donazione](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=it.wikipedia.org&uselang=it)
  * [registrati](https://it.wikipedia.org/w/index.php?title=Speciale:CreaUtenza&returnto=Pagina+principale "Si consiglia di registrarsi e di effettuare l'accesso, anche se non è obbligatorio")
  * [entra](https://it.wikipedia.org/w/index.php?title=Speciale:Entra&returnto=Pagina+principale "Si consiglia di effettuare l'accesso, anche se non è obbligatorio \[o\]")


Strumenti personali
  * [Fai una donazione](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=it.wikipedia.org&uselang=it)
  * [registrati](https://it.wikipedia.org/w/index.php?title=Speciale:CreaUtenza&returnto=Pagina+principale "Si consiglia di registrarsi e di effettuare l'accesso, anche se non è obbligatorio")
  * [entra](https://it.wikipedia.org/w/index.php?title=Speciale:Entra&returnto=Pagina+principale "Si consiglia di effettuare l'accesso, anche se non è obbligatorio \[o\]")


# Pagina principale
  * [Pagina principale](https://it.wikipedia.org/wiki/Pagina_principale "Vedi la voce \[c\]")
  * [Discussione](https://it.wikipedia.org/wiki/Discussione:Pagina_principale "Vedi le discussioni relative a questa pagina \[t\]")


italiano
  * [Leggi](https://it.wikipedia.org/wiki/Pagina_principale)
  * [Visualizza sorgente](https://it.wikipedia.org/w/index.php?title=Pagina_principale&action=edit "Questa pagina è protetta, ma puoi vedere il suo codice sorgente \[e\]")
  * [Cronologia](https://it.wikipedia.org/w/index.php?title=Pagina_principale&action=history "Versioni precedenti di questa pagina \[h\]")


Strumenti
Strumenti
sposta nella barra laterale nascondi
Azioni 
  * [Leggi](https://it.wikipedia.org/wiki/Pagina_principale)
  * [Visualizza sorgente](https://it.wikipedia.org/w/index.php?title=Pagina_principale&action=edit)
  * [Cronologia](https://it.wikipedia.org/w/index.php?title=Pagina_principale&action=history)


Generale 
  * [Puntano qui](https://it.wikipedia.org/wiki/Speciale:PuntanoQui/Pagina_principale "Elenco di tutte le pagine che sono collegate a questa \[j\]")
  * [Modifiche correlate](https://it.wikipedia.org/wiki/Speciale:ModificheCorrelate/Pagina_principale "Elenco delle ultime modifiche alle pagine collegate a questa \[k\]")
  * [Link permanente](https://it.wikipedia.org/w/index.php?title=Pagina_principale&oldid=137151196 "Collegamento permanente a questa versione di questa pagina")
  * [Informazioni pagina](https://it.wikipedia.org/w/index.php?title=Pagina_principale&action=info "Ulteriori informazioni su questa pagina")
  * [Cita questa voce](https://it.wikipedia.org/w/index.php?title=Speciale:Cita&page=Pagina_principale&id=137151196&wpFormIdentifier=titleform "Informazioni su come citare questa pagina")
  * [Ottieni URL breve](https://it.wikipedia.org/w/index.php?title=Speciale:UrlShortener&url=https%3A%2F%2Fit.wikipedia.org%2Fwiki%2FPagina_principale)
  * [Scarica codice QR](https://it.wikipedia.org/w/index.php?title=Speciale:QrCode&url=https%3A%2F%2Fit.wikipedia.org%2Fwiki%2FPagina_principale)


Stampa/esporta 
  * [Crea un libro](https://it.wikipedia.org/w/index.php?title=Speciale:Libro&bookcmd=book_creator&referer=Pagina+principale)
  * [Scarica come PDF](https://it.wikipedia.org/w/index.php?title=Speciale:DownloadAsPdf&page=Pagina_principale&action=show-download-screen)
  * [Versione stampabile](https://it.wikipedia.org/w/index.php?title=Pagina_principale&printable=yes "Versione stampabile di questa pagina \[p\]")


In altri progetti 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Wikisource multilingue](https://wikisource.org/wiki/Main_Page)
  * [Wikispecie](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikibooks](https://it.wikibooks.org/wiki/Pagina_principale)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunzioni](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikinotizie](https://it.wikinews.org/wiki/Pagina_principale)
  * [Wikiquote](https://it.wikiquote.org/wiki/Pagina_principale)
  * [Wikisource](https://it.wikisource.org/wiki/Pagina_principale)
  * [Wikiversità](https://it.wikiversity.org/wiki/Pagina_principale)
  * [Wikivoyage](https://it.wikivoyage.org/wiki/Pagina_principale)
  * [Wikizionario](https://it.wiktionary.org/wiki/Pagina_principale)
  * [Elemento Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Collegamento all'elemento connesso dell'archivio dati \[g\]")


Aspetto
sposta nella barra laterale nascondi
Da Wikipedia, l'enciclopedia libera.
[Benvenuti](https://it.wikipedia.org/wiki/Aiuto:Benvenuto "Aiuto:Benvenuto") su [Wikipedia](https://it.wikipedia.org/wiki/Wikipedia "Wikipedia")   
L'enciclopedia [libera](https://it.wikipedia.org/wiki/Wikipedia:Wikipedia_%C3%A8_libera "Wikipedia:Wikipedia è libera") e [collaborativa](https://it.wikipedia.org/wiki/Wikipedia:Aiuta_Wikipedia "Wikipedia:Aiuta Wikipedia")
* * *
[![Clicca qui per sfogliare l'indice delle voci!](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Crystal_Clear_app_xmag.svg/20px-Crystal_Clear_app_xmag.svg.png)](https://it.wikipedia.org/wiki/Speciale:TutteLePagine "Clicca qui per sfogliare l'indice delle voci!") [**Sfoglia l'indice**](https://it.wikipedia.org/wiki/Speciale:TutteLePagine "Speciale:TutteLePagine") [![Clicca qui per consultare il sommario dei vari argomenti!](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/1rightarrow_blue.svg/20px-1rightarrow_blue.svg.png)](https://it.wikipedia.org/wiki/Wikipedia:Sommario "Clicca qui per consultare il sommario dei vari argomenti!")[**Consulta il sommario**](https://it.wikipedia.org/wiki/Wikipedia:Sommario "Wikipedia:Sommario") [![Clicca qui per navigare tra i portali tematici!](https://upload.wikimedia.org/wikipedia/commons/thumb/7/70/Nuvola_apps_bookcase_simplified.svg/20px-Nuvola_apps_bookcase_simplified.svg.png)](https://it.wikipedia.org/wiki/Portale:Portali "Clicca qui per navigare tra i portali tematici!") [**Naviga tra i portali tematici**](https://it.wikipedia.org/wiki/Portale:Portali "Portale:Portali")
**[1 937 841](https://it.wikipedia.org/wiki/Speciale:Statistiche "Speciale:Statistiche")** [voci](https://it.wikipedia.org/wiki/Aiuto:Voce "Aiuto:Voce") in **[italiano](https://it.wikipedia.org/wiki/Lingua_italiana "Lingua italiana")**
[Versione per dispositivi mobili](https://it.m.wikipedia.org?mobileaction=toggle_view_mobile) [Versione desktop](https://it.wikipedia.org?mobileaction=toggle_view_desktop)
![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/W-circle.svg/40px-W-circle.svg.png)
## Wikipedia
**Wikipedia** è un'[enciclopedia](https://it.wikipedia.org/wiki/Enciclopedia "Enciclopedia") online, [libera](https://it.wikipedia.org/wiki/Wikipedia:Wikipedia_%C3%A8_libera "Wikipedia:Wikipedia è libera") e collaborativa. 
Grazie al contributo di volontari da tutto il mondo, Wikipedia è disponibile [in oltre 340 lingue](https://meta.wikimedia.org/wiki/List_of_Wikipedias/it "m:List of Wikipedias/it"). [Chiunque](https://it.wikipedia.org/wiki/Wikipedia:Wikipediani "Wikipedia:Wikipediani") può contribuire alle [voci](https://it.wikipedia.org/wiki/Aiuto:Voce "Aiuto:Voce") esistenti o [crearne di nuove](https://it.wikipedia.org/wiki/Aiuto:Come_scrivere_una_voce "Aiuto:Come scrivere una voce"), affrontando sia gli argomenti tipici delle enciclopedie tradizionali sia quelli presenti in [almanacchi](https://it.wikipedia.org/wiki/Almanacco "Almanacco"), dizionari geografici e pubblicazioni specialistiche. 
Tutti i contenuti di Wikipedia sono [protetti](https://it.wikipedia.org/wiki/Wikipedia:Copyright "Wikipedia:Copyright") da una [licenza libera](https://it.wikipedia.org/wiki/Licenza_libera "Licenza libera"), la [Creative Commons CC BY-SA](https://it.wikipedia.org/wiki/Licenze_Creative_Commons "Licenze Creative Commons"), che ne permette il riutilizzo per [qualsiasi scopo](https://it.wikipedia.org/wiki/Contenuto_libero "Contenuto libero") a condizione di [adottare la medesima licenza](https://it.wikipedia.org/wiki/Copyleft "Copyleft"). 
![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/HSTools.svg/40px-HSTools.svg.png)
  * **Vuoi partecipare?** Leggi le [regole fondamentali](https://it.wikipedia.org/wiki/Wikipedia:Cinque_pilastri "Wikipedia:Cinque pilastri") e le altre [linee guida](https://it.wikipedia.org/wiki/Wikipedia:Raccomandazioni_e_linee_guida "Wikipedia:Raccomandazioni e linee guida"), e rispetta la _[wikiquette](https://it.wikipedia.org/wiki/Wikipedia:Wikiquette "Wikipedia:Wikiquette")_ ; la [registrazione](https://it.wikipedia.org/wiki/Aiuto:Come_registrarsi "Aiuto:Come registrarsi") è consigliata ma _non obbligatoria_.
  * **Serve aiuto?** Consulta le [istruzioni](https://it.wikipedia.org/wiki/Aiuto:Aiuto "Aiuto:Aiuto") e le [domande frequenti (FAQ)](https://it.wikipedia.org/wiki/Aiuto:FAQ "Aiuto:FAQ") o leggi [dove fare una domanda](https://it.wikipedia.org/wiki/Aiuto:Dove_fare_una_domanda "Aiuto:Dove fare una domanda"); se ti sei appena registrato puoi richiedere l'assegnazione di un [tutor](https://it.wikipedia.org/wiki/Progetto:Coordinamento/Accoglienza/Nuovi_arrivati "Progetto:Coordinamento/Accoglienza/Nuovi arrivati").
  * **Vuoi provare?** Modifica [la pagina di prova](https://it.wikipedia.org/wiki/Wikipedia:Pagina_delle_prove "Wikipedia:Pagina delle prove") o segui il [Tour guidato](https://it.wikipedia.org/wiki/Aiuto:Tour_guidato "Aiuto:Tour guidato") per imparare [come scrivere una voce](https://it.wikipedia.org/wiki/Aiuto:Come_scrivere_una_voce "Aiuto:Come scrivere una voce").
  * **Vuoi fare una donazione?** Wikipedia è completamente gratuita e priva di pubblicità grazie alle donazioni degli utenti. [Aiutaci a migliorarla e a mantenerla libera con una donazione](https://donate.wikimedia.org/w/index.php?title=Special:FundraiserLandingPage&country=IT&uselang=it&utm_medium=sidebar&utm_source=donate&utm_campaign=C13_it.wikipedia.org).
  * **Cosa pensi di Wikipedia?** Scrivi [il tuo parere](https://it.wikipedia.org/wiki/Wikipedia:Pareri_su_Wikipedia "Wikipedia:Pareri su Wikipedia").


![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/Text-x-generic_with_pencil-2.svg/40px-Text-x-generic_with_pencil-2.svg.png)
La [comunità](https://it.wikipedia.org/wiki/Portale:Comunit%C3%A0 "Portale:Comunità") di [Wikipedia in lingua italiana](https://it.wikipedia.org/wiki/Wikipedia_in_italiano "Wikipedia in italiano") è composta da 2 693 510 utenti registrati, dei quali 13 803 hanno contribuito con almeno una modifica nell'ultimo mese e 110 hanno [funzioni di servizio](https://it.wikipedia.org/wiki/Wikipedia:Amministratori "Wikipedia:Amministratori"). Gli utenti costituiscono una comunità collaborativa, in cui tutti i membri, grazie anche ai [progetti tematici](https://it.wikipedia.org/wiki/Portale:Progetti "Portale:Progetti") e ai rispettivi [luoghi di discussione](https://it.wikipedia.org/wiki/Wikipedia:Bar_tematici "Wikipedia:Bar tematici"), [coordinano](https://it.wikipedia.org/wiki/Progetto:Coordinamento "Progetto:Coordinamento") i propri sforzi nella redazione delle voci. 
![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/HSUtvald.svg/40px-HSUtvald.svg.png)
## Vetrina
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Arte_romana%2C_iperide%2C_II_sec._ca..JPG/120px-Arte_romana%2C_iperide%2C_II_sec._ca..JPG)](https://it.wikipedia.org/wiki/File:Arte_romana,_iperide,_II_sec._ca..JPG)
**Iperide** , figlio di Glaucippo del [demo di Collito](https://it.wikipedia.org/wiki/Collito "Collito") (in [greco antico](https://it.wikipedia.org/wiki/Lingua_greca_antica "Lingua greca antica"): Ὑπερείδης[?](https://it.wikipedia.org/wiki/Aiuto:Greco_antico "Aiuto:Greco antico"), _Hyperéidēs_ ; [Atene](https://it.wikipedia.org/wiki/Atene_\(citt%C3%A0_antica\) "Atene \(città antica\)"), [390](https://it.wikipedia.org/wiki/390_a.C. "390 a.C.")/[389](https://it.wikipedia.org/wiki/389_a.C. "389 a.C.") o 389/[388 a.C.](https://it.wikipedia.org/wiki/388_a.C. "388 a.C.") – [_luogo controverso_](https://it.wikipedia.org/wiki/Iperide#Cattura_da_parte_di_Antipatro_e_morte "Iperide"), 9 [pianepsione](https://it.wikipedia.org/wiki/Pianepsione "Pianepsione") [322 a.C.](https://it.wikipedia.org/wiki/322_a.C. "322 a.C.")), è stato un [oratore](https://it.wikipedia.org/wiki/Oratore "Oratore") e [politico](https://it.wikipedia.org/wiki/Politico "Politico") [ateniese](https://it.wikipedia.org/wiki/Atene_\(citt%C3%A0_antica\) "Atene \(città antica\)"), uno dei dieci [oratori attici](https://it.wikipedia.org/wiki/Oratori_attici "Oratori attici") inclusi nel _[Canone alessandrino](https://it.wikipedia.org/wiki/Canone_alessandrino "Canone alessandrino")_ , che fu compilato nel [III secolo a.C.](https://it.wikipedia.org/wiki/III_secolo_a.C. "III secolo a.C.") da [Aristofane di Bisanzio](https://it.wikipedia.org/wiki/Aristofane_di_Bisanzio "Aristofane di Bisanzio") e da [Aristarco di Samotracia](https://it.wikipedia.org/wiki/Aristarco_di_Samotracia "Aristarco di Samotracia"). 
Di famiglia benestante, entrò in politica da giovane, nel [362 a.C.](https://it.wikipedia.org/wiki/362_a.C. "362 a.C."), distinguendosi per delle azioni giudiziarie contro uomini politici molto in vista nell'[Atene](https://it.wikipedia.org/wiki/Atene_\(citt%C3%A0_antica\) "Atene \(città antica\)") dell'epoca. Assunta una posizione di rilievo nel partito anti-[macedone](https://it.wikipedia.org/wiki/Regno_di_Macedonia "Regno di Macedonia") ateniese (guidato al tempo da [Demostene](https://it.wikipedia.org/wiki/Demostene "Demostene") e [Licurgo](https://it.wikipedia.org/wiki/Licurgo_di_Atene "Licurgo di Atene")), collaborò con loro nel formare una lega di stati greci contro [Filippo II](https://it.wikipedia.org/wiki/Filippo_II_di_Macedonia "Filippo II di Macedonia") e, dopo la sconfitta subita da questa lega nella [battaglia di Cheronea](https://it.wikipedia.org/wiki/Battaglia_di_Cheronea_\(338_a.C.\) "Battaglia di Cheronea \(338 a.C.\)") ([338 a.C.](https://it.wikipedia.org/wiki/338_a.C. "338 a.C.")), promosse un decreto con provvedimenti straordinari per salvare Atene da un eventuale assedio, tra cui la liberazione degli schiavi e dei [meteci](https://it.wikipedia.org/wiki/Meteco "Meteco") che si fossero arruolati nell'esercito. Negli anni seguenti, Iperide, pur continuando a militare tra gli antimacedoni, svolse prevalentemente l'attività di [logografo](https://it.wikipedia.org/wiki/Logografia_\(retorica\) "Logografia \(retorica\)"), che aveva già intrapreso in precedenza. Nel [324 a.C.](https://it.wikipedia.org/wiki/324_a.C. "324 a.C."), in occasione dello scandalo di [Arpalo](https://it.wikipedia.org/wiki/Arpalo "Arpalo"), Iperide si schierò contro Demostene, accusandolo di aver agito contro gli interessi di Atene perché corrotto e ottenendo che fosse dichiarato colpevole. Nel [323 a.C.](https://it.wikipedia.org/wiki/323_a.C. "323 a.C."), alla morte di [Alessandro Magno](https://it.wikipedia.org/wiki/Alessandro_Magno "Alessandro Magno"), Iperide e [Leostene](https://it.wikipedia.org/wiki/Leostene "Leostene") furono i principali promotori della [guerra lamiaca](https://it.wikipedia.org/wiki/Guerra_lamiaca "Guerra lamiaca"), combattuta contro i Macedoni. Questo conflitto, dopo un iniziale avvio favorevole alla lega greca, vide la morte di Leostene e la disfatta della lega stessa: Demostene riuscì a suicidarsi, mentre Iperide, catturato pochi giorni dopo, fu fatto uccidere dal reggente [Antipatro](https://it.wikipedia.org/wiki/Antipatro_\(generale\) "Antipatro \(generale\)"). 
Definito da [Piero Treves](https://it.wikipedia.org/wiki/Piero_Treves "Piero Treves") come "avvocato abile" e "parlatore elegante", ma "politico molto mediocre", e da Carl Schneider come "primo avvocato in senso stretto della storia", Iperide fu apprezzato più come oratore che come politico. Nell'[antichità](https://it.wikipedia.org/wiki/Storia_antica "Storia antica") i pareri sulla sua eloquenza erano divergenti: la [scuola di Rodi](https://it.wikipedia.org/wiki/Stile_rodiese "Stile rodiese") lo prese come modello; gli oratori romani, in particolare [Marco Tullio Cicerone](https://it.wikipedia.org/wiki/Marco_Tullio_Cicerone "Marco Tullio Cicerone"), ne ammirarono l’ _acumen_ ; gli [atticisti](https://it.wikipedia.org/wiki/Atticismo "Atticismo") del [II secolo d.C.](https://it.wikipedia.org/wiki/II_secolo "II secolo"), però, condannarono aspramente la lingua da lui usata, un [dialetto attico](https://it.wikipedia.org/wiki/Dialetto_attico "Dialetto attico") non puro, contenente alcuni elementi del _sermo cotidianus_ e altri che testimoniavano il passaggio alla [koinè](https://it.wikipedia.org/wiki/Koin%C3%A8 "Koinè") ellenistica. Il giudizio di questi ultimi, in particolare di [Ermogene di Tarso](https://it.wikipedia.org/wiki/Ermogene_di_Tarso "Ermogene di Tarso"), pregiudicò la tradizione delle orazioni di Iperide: attualmente delle sue orazioni, sul cui numero, probabilmente 71, le fonti sono comunque discordi, solo 8 sono in buona parte leggibili. Di queste, 6 provengono da papiri egiziani non posteriori al [III secolo](https://it.wikipedia.org/wiki/III_secolo "III secolo") d.C., mentre le altre due sono state rinvenute in un [codice](https://it.wikipedia.org/wiki/Codice_\(filologia\) "Codice \(filologia\)") [bizantino](https://it.wikipedia.org/wiki/Impero_bizantino "Impero bizantino") del [IX](https://it.wikipedia.org/wiki/IX_secolo "IX secolo")/[X](https://it.wikipedia.org/wiki/X_secolo "X secolo") secolo, facente parte del Palinsesto di Archimede.  

[Leggi la voce](https://it.wikipedia.org/wiki/Iperide "Iperide") · [Tutte le voci in vetrina](https://it.wikipedia.org/wiki/Wikipedia:Vetrina "Wikipedia:Vetrina") 

![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/1/13/HS_VdQ.svg/40px-HS_VdQ.svg.png)
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Charles_Villiers_Stanford.jpg/120px-Charles_Villiers_Stanford.jpg)](https://it.wikipedia.org/wiki/File:Charles_Villiers_Stanford.jpg)
**Sir Charles Villiers Stanford** ([Dublino](https://it.wikipedia.org/wiki/Dublino "Dublino"), [30 settembre](https://it.wikipedia.org/wiki/30_settembre "30 settembre") [1852](https://it.wikipedia.org/wiki/1852 "1852") – [Londra](https://it.wikipedia.org/wiki/Londra "Londra"), [29 marzo](https://it.wikipedia.org/wiki/29_marzo "29 marzo") [1924](https://it.wikipedia.org/wiki/1924 "1924")) è stato un [compositore](https://it.wikipedia.org/wiki/Compositore "Compositore") e [direttore d'orchestra](https://it.wikipedia.org/wiki/Direttore_d%27orchestra "Direttore d'orchestra") [irlandese](https://it.wikipedia.org/wiki/Irlanda "Irlanda"). 
Nato a Dublino da una famiglia benestante molto appassionata di musica, figlio di un cantante ([basso](https://it.wikipedia.org/wiki/Basso_\(voce\) "Basso \(voce\)")) e di una [pianista](https://it.wikipedia.org/wiki/Pianoforte "Pianoforte"), Stanford si formò presso l'[Università di Cambridge](https://it.wikipedia.org/wiki/Universit%C3%A0_di_Cambridge "Università di Cambridge"), studiando poi a [Lipsia](https://it.wikipedia.org/wiki/Lipsia "Lipsia") e [Berlino](https://it.wikipedia.org/wiki/Berlino "Berlino"). 
Mentre era ancora studente, Stanford fu nominato organista del [Trinity College](https://it.wikipedia.org/wiki/Trinity_College_\(Cambridge\) "Trinity College \(Cambridge\)") di [Cambridge](https://it.wikipedia.org/wiki/Cambridge "Cambridge"). Nel [1882](https://it.wikipedia.org/wiki/1882 "1882"), all'età di 29 anni, fu uno dei fondatori del [Royal College of Music](https://it.wikipedia.org/wiki/Royal_College_of_Music "Royal College of Music"), dove insegnò composizione per il resto della sua vita. Dal [1887](https://it.wikipedia.org/wiki/1887 "1887") fu anche professore di musica all'Università di Cambridge. Esercitò un contributo determinante nel risollevare il prestigio della Cambridge University Musical Society, attirandovi personalità di fama internazionale. 
Stanford basò il suo insegnamento principalmente su principi classici, esemplificati nella musica di [Brahms](https://it.wikipedia.org/wiki/Johannes_Brahms "Johannes Brahms"), rimanendo scettico nei confronti delle tendenze modernistiche di inizio Novecento. Come direttore d'orchestra, Stanford diresse il Bach Choir e il festival triennale di musica classica di [Leeds](https://it.wikipedia.org/wiki/Leeds "Leeds"). 
Stanford compose molta musica orchestrale, tra cui sette [sinfonie](https://it.wikipedia.org/wiki/Sinfonia "Sinfonia"), ma i suoi lavori più apprezzati furono quelli di musica sacra corale, principalmente le [messe](https://it.wikipedia.org/wiki/Messa_\(musica\) "Messa \(musica\)") (di liturgia [anglicana](https://it.wikipedia.org/wiki/Anglicanesimo "Anglicanesimo")). Compose anche nove [opere liriche](https://it.wikipedia.org/wiki/Opera "Opera"), nessuna delle quali si è affermata nel repertorio consueto. 
Alcuni critici considerarono Stanford, insieme a [Charles Parry](https://it.wikipedia.org/wiki/Charles_Parry "Charles Parry") e ad [Alexander Campbell Mackenzie](https://it.wikipedia.org/wiki/Alexander_Campbell_Mackenzie "Alexander Campbell Mackenzie"), come uno dei principali artefici della rinascita della musica dalle isole britanniche. Tuttavia, dopo il successo incontrato nell'ultimo ventennio dell'[Ottocento](https://it.wikipedia.org/wiki/XIX_secolo "XIX secolo"), la sua fama fu offuscata nel [Novecento](https://it.wikipedia.org/wiki/XX_secolo "XX secolo") da quella di [Edward Elgar](https://it.wikipedia.org/wiki/Edward_Elgar "Edward Elgar") e di alcuni dei suoi stessi allievi, come [Gustav Holst](https://it.wikipedia.org/wiki/Gustav_Holst "Gustav Holst") e [Ralph Vaughan Williams](https://it.wikipedia.org/wiki/Ralph_Vaughan_Williams "Ralph Vaughan Williams").  

[Leggi la voce](https://it.wikipedia.org/wiki/Charles_Villiers_Stanford "Charles Villiers Stanford") · [Tutte le voci di qualità](https://it.wikipedia.org/wiki/Wikipedia:Voci_di_qualit%C3%A0 "Wikipedia:Voci di qualità") 

![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/PL_Wiki_CzyWiesz_ikona.svg/38px-PL_Wiki_CzyWiesz_ikona.svg.png)
## Lo sapevi che...
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Tipu%27s_Tiger_with_keyboard_on_display_2006AH4168.jpg/250px-Tipu%27s_Tiger_with_keyboard_on_display_2006AH4168.jpg)](https://it.wikipedia.org/wiki/File:Tipu%27s_Tiger_with_keyboard_on_display_2006AH4168.jpg)
La **tigre di Tīpū** (in [inglese](https://it.wikipedia.org/wiki/Lingua_inglese "Lingua inglese") _Tipu's Tiger_ , in [hindī](https://it.wikipedia.org/wiki/Lingua_hind%C4%AB "Lingua hindī") टीपू का बाघ) è un [automa musicale](https://it.wikipedia.org/wiki/Automa_musicale "Automa musicale") realizzato alla fine del [diciottesimo secolo](https://it.wikipedia.org/wiki/XVIII_secolo "XVIII secolo"). Si tratta di un congegno in legno dipinto con l'aspetto di una [tigre](https://it.wikipedia.org/wiki/Panthera_tigris "Panthera tigris") intenta ad aggredire un europeo supino. Quando viene azionata, l'avambraccio sinistro dell'uomo si muove come a simulare il suo terrore e dalla sua bocca proviene un suono lamentoso; al contempo, la tigre emette dei suoni che richiamano dei ruggiti. In uno dei suoi lati, la tigre di Tipu cela uno scomparto all'interno del quale vi è un [organetto](https://it.wikipedia.org/wiki/Organo_\(strumento_musicale\) "Organo \(strumento musicale\)") con diciotto tasti.  

[Leggi la voce](https://it.wikipedia.org/wiki/Tigre_di_Tipu "Tigre di Tipu")**·** [Proponi un'altra voce](https://it.wikipedia.org/wiki/Wikipedia:Lo_sapevi_che/Valutazione "Wikipedia:Lo sapevi che/Valutazione") 

![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/HSDagensdatum.svg/40px-HSDagensdatum.svg.png)
## Ricorrenze del [2 ottobre](https://it.wikipedia.org/wiki/2_ottobre "2 ottobre")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Portrait_Gandhi.jpg/120px-Portrait_Gandhi.jpg)](https://it.wikipedia.org/wiki/File:Portrait_Gandhi.jpg)Mahatma Gandhi
###  [Nati](https://it.wikipedia.org/wiki/Categoria:Nati_il_2_ottobre "Categoria:Nati il 2 ottobre")...
  * [Carlo Borromeo](https://it.wikipedia.org/wiki/Carlo_Borromeo "Carlo Borromeo") ([1538](https://it.wikipedia.org/wiki/1538 "1538"))
  * [Mahatma Gandhi](https://it.wikipedia.org/wiki/Mahatma_Gandhi "Mahatma Gandhi") ([1869](https://it.wikipedia.org/wiki/1869 "1869"))
  * [Omar Sívori](https://it.wikipedia.org/wiki/Omar_S%C3%ADvori "Omar Sívori") ([1935](https://it.wikipedia.org/wiki/1935 "1935"))


### ...e [morti](https://it.wikipedia.org/wiki/Categoria:Morti_il_2_ottobre "Categoria:Morti il 2 ottobre")
  * [Svante Arrhenius](https://it.wikipedia.org/wiki/Svante_Arrhenius "Svante Arrhenius") ([1927](https://it.wikipedia.org/wiki/1927 "1927"))
  * [Marcel Duchamp](https://it.wikipedia.org/wiki/Marcel_Duchamp "Marcel Duchamp") ([1968](https://it.wikipedia.org/wiki/1968 "1968"))
  * [Paavo Nurmi](https://it.wikipedia.org/wiki/Paavo_Nurmi "Paavo Nurmi") ([1973](https://it.wikipedia.org/wiki/1973 "1973"))


### In questo giorno accadde...
  * [1187](https://it.wikipedia.org/wiki/1187 "1187") – [Saladino](https://it.wikipedia.org/wiki/Saladino "Saladino") cattura [Gerusalemme](https://it.wikipedia.org/wiki/Gerusalemme "Gerusalemme") dopo 88 anni di regno [crociato](https://it.wikipedia.org/wiki/Crociata "Crociata").
  * [1836](https://it.wikipedia.org/wiki/1836 "1836") – [Charles Darwin](https://it.wikipedia.org/wiki/Charles_Darwin "Charles Darwin") fa ritorno in [Inghilterra](https://it.wikipedia.org/wiki/Inghilterra "Inghilterra") dopo il suo famoso viaggio sulla [HMS _Beagle_](https://it.wikipedia.org/wiki/HMS_Beagle "HMS Beagle"), durante il quale raccolse i dati che userà per sviluppare la sua [Teoria dell'evoluzione](https://it.wikipedia.org/wiki/L%27origine_delle_specie "L'origine delle specie").
  * [1950](https://it.wikipedia.org/wiki/1950 "1950") – Esce la prima striscia dei _[Peanuts](https://it.wikipedia.org/wiki/Peanuts "Peanuts")_ di [Charles M. Schulz](https://it.wikipedia.org/wiki/Charles_M._Schulz "Charles M. Schulz").  

  * [1967](https://it.wikipedia.org/wiki/1967 "1967") – [Thurgood Marshall](https://it.wikipedia.org/wiki/Thurgood_Marshall "Thurgood Marshall") presta giuramento come primo giudice [afroamericano](https://it.wikipedia.org/wiki/Afroamericano "Afroamericano") della [Corte suprema degli Stati Uniti](https://it.wikipedia.org/wiki/Corte_suprema_degli_Stati_Uniti_d%27America "Corte suprema degli Stati Uniti d'America").


**Ricorre oggi** : la [Giornata internazionale della nonviolenza](https://it.wikipedia.org/wiki/Giornata_internazionale_della_nonviolenza "Giornata internazionale della nonviolenza"). La [Chiesa cattolica](https://it.wikipedia.org/wiki/Chiesa_cattolica "Chiesa cattolica") celebra la [memoria](https://it.wikipedia.org/wiki/Memoria_\(liturgia\) "Memoria \(liturgia\)") dei santi [angeli custodi](https://it.wikipedia.org/wiki/Angelo_custode "Angelo custode") e [Leodegario di Autun](https://it.wikipedia.org/wiki/Leodegario_di_Autun "Leodegario di Autun"). Gli [Evanelici](https://it.wikipedia.org/wiki/Metodismo "Metodismo") commemorano [Pietro Carnesecchi](https://it.wikipedia.org/wiki/Pietro_Carnesecchi "Pietro Carnesecchi"). 
![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/HS_geo.svg/40px-HS_geo.svg.png)
## Nelle altre lingue
Di seguito sono elencate le 10 versioni maggiori di Wikipedia (per numero di voci, non necessariamente per qualità o dimensioni totali) e una selezione casuale di altre edizioni con un numero minore di voci: 
**Le 10 maggiori** (al 2 ottobre 2025): [English (_inglese_)](https://en.wikipedia.org/wiki/ "en:") (7 067 319) · [Binisaya (_cebuano_)](https://ceb.wikipedia.org/wiki/ "ceb:") (6 115 960) · [Deutsch (_tedesco_)](https://de.wikipedia.org/wiki/ "de:") (3 055 751) · [Français (_francese_)](https://fr.wikipedia.org/wiki/ "fr:") (2 712 293) · [Svenska (_svedese_)](https://sv.wikipedia.org/wiki/ "sv:") (2 617 098) · [Nederlands (_olandese_)](https://nl.wikipedia.org/wiki/ "nl:") (2 198 376) · [Русский (_russo_)](https://ru.wikipedia.org/wiki/ "ru:") (2 065 477) · [Español (_spagnolo_)](https://es.wikipedia.org/wiki/ "es:") (2 064 876) · **Italiano** (1 937 841) · [Polski (_polacco_)](https://pl.wikipedia.org/wiki/ "pl:") (1 670 477)
**Dal mondo di Wikipedia** : [Esperanto (_esperanto_)](https://eo.wikipedia.org/wiki/ "eo:") · [Eesti (_estone_)](https://et.wikipedia.org/wiki/ "et:") · [Ελληνικά (_greco_)](https://el.wikipedia.org/wiki/ "el:") · [Cymraeg (_gallese_)](https://cy.wikipedia.org/wiki/ "cy:") · [Ido (_ido_)](https://io.wikipedia.org/wiki/ "io:") · [Walon (_vallone_)](https://wa.wikipedia.org/wiki/ "wa:") · [Tarandíne (_tarantino_)](https://roa-tara.wikipedia.org/wiki/ "roa-tara:") · [Bân-lâm-gú (_min nan_)](https://zh-min-nan.wikipedia.org/wiki/ "zh-min-nan:") · [تركمن / Туркмен (_turkmeno_)](https://tk.wikipedia.org/wiki/ "tk:") · [Pangasinan (_pangasinan_)](https://pag.wikipedia.org/wiki/ "pag:") · [Líguru (_ligure_)](https://lij.wikipedia.org/wiki/ "lij:") · [Dzhudezmo (_giudesmo_ o _giudeo-spagnolo_)](https://lad.wikipedia.org/wiki/ "lad:") · [پښتو (_pashto_)](https://ps.wikipedia.org/wiki/ "ps:") · [Reo Tahiti (_tahitiano_)](https://ty.wikipedia.org/wiki/ "ty:") · [Af-Soomaali (_somalo_)](https://so.wikipedia.org/wiki/ "so:") · [МагIарул мацI (_avaro_)](https://av.wikipedia.org/wiki/ "av:") · [Bamanankan (_bambara_)](https://bm.wikipedia.org/wiki/ "bm:") · [Xitsonga (_tsonga_)](https://ts.wikipedia.org/wiki/ "ts:") · [ᨅᨗᨌᨑ ᨕᨘᨁᨗ (_buginese_)](https://bug.wikipedia.org/wiki/ "bug:")
![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Wikimedia-logo-circle.svg/40px-Wikimedia-logo-circle.svg.png)
## Oltre Wikipedia
Wikipedia è gestita da [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Pagina_Principale "wmf:Pagina Principale"), [organizzazione senza fini di lucro](https://it.wikipedia.org/wiki/Organizzazione_non_a_scopo_di_lucro "Organizzazione non a scopo di lucro") che sostiene diversi altri progetti [wiki](https://it.wikipedia.org/wiki/Wiki "Wiki") dal [contenuto libero](https://it.wikipedia.org/wiki/Contenuto_libero "Contenuto libero") e [multilingue](https://meta.wikimedia.org/wiki/Pagina_principale "m:Pagina principale"): 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/Pagina_principale "Commons")
[**Commons**](https://commons.wikimedia.org/wiki/Pagina_principale "commons:Pagina principale")  
Risorse multimediali condivise
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://it.wikiquote.org/wiki/Pagina_principale "Wikiquote")
[**Wikiquote**](https://it.wikiquote.org/wiki/Pagina_principale "q:Pagina principale")  
Raccolta di citazioni
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://it.wiktionary.org/wiki/Pagina_principale "Wikizionario")
[**Wikizionario**](https://it.wiktionary.org/wiki/Pagina_principale "wikt:Pagina principale")  
Dizionario e lessico
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://it.wikinews.org/wiki/Pagina_principale "Wikinotizie")
[**Wikinotizie**](https://it.wikinews.org/wiki/Pagina_principale "n:Pagina principale")  
Notizie a contenuto aperto
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/Pagina_principale "Wikispecies")
[**Wikispecies**](https://species.wikimedia.org/wiki/Pagina_principale "wikispecies:Pagina principale")  
Catalogo delle specie
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/Main_Page "Meta-Wiki")
[**Meta-Wiki**](https://meta.wikimedia.org/wiki/Main_Page "m:Main Page")  
Progetto di coordinamento Wikimedia
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://it.wikibooks.org/wiki/Pagina_principale "Wikibooks")
[**Wikibooks**](https://it.wikibooks.org/wiki/Pagina_principale "b:Pagina principale")  
Manuali e libri di testo liberi scritti ex novo
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://it.wikisource.org/wiki/Pagina_principale "Wikisource")
[**Wikisource**](https://it.wikisource.org/wiki/Pagina_principale "s:Pagina principale")  
Biblioteca di opere già pubblicate
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)](https://it.wikiversity.org/wiki/Pagina_principale "Wikiversità")
[**Wikiversità**](https://it.wikiversity.org/wiki/Pagina_principale "v:Pagina principale")  
Risorse e attività didattiche
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/Wikidata:Main_Page "Wikidata")
[**Wikidata**](https://www.wikidata.org/wiki/Wikidata:Main_Page "d:Wikidata:Main Page")  
Database di conoscenza libera
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://it.wikivoyage.org/wiki/Pagina_principale "Wikivoyage")
[**Wikivoyage**](https://it.wikivoyage.org/wiki/Pagina_principale "voy:Pagina principale")  
Guida turistica mondiale
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Wikifunctions-logo.svg/40px-Wikifunctions-logo.svg.png)](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page "Wikifunctions")
[**Wikifunctions**](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page "f:Wikifunctions:Main Page")  
Raccolta di funzioni
![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/W-circle.svg/40px-W-circle.svg.png)
## Wikipedia
**Wikipedia** è un'[enciclopedia](https://it.wikipedia.org/wiki/Enciclopedia "Enciclopedia") online, [libera](https://it.wikipedia.org/wiki/Wikipedia:Wikipedia_%C3%A8_libera "Wikipedia:Wikipedia è libera") e collaborativa. 
Grazie al contributo di volontari da tutto il mondo, Wikipedia è disponibile [in oltre 340 lingue](https://meta.wikimedia.org/wiki/List_of_Wikipedias/it "m:List of Wikipedias/it"). [Chiunque](https://it.wikipedia.org/wiki/Wikipedia:Wikipediani "Wikipedia:Wikipediani") può contribuire alle [voci](https://it.wikipedia.org/wiki/Aiuto:Voce "Aiuto:Voce") esistenti o [crearne di nuove](https://it.wikipedia.org/wiki/Aiuto:Come_scrivere_una_voce "Aiuto:Come scrivere una voce"), affrontando sia gli argomenti tipici delle enciclopedie tradizionali sia quelli presenti in [almanacchi](https://it.wikipedia.org/wiki/Almanacco "Almanacco"), dizionari geografici e pubblicazioni specialistiche. 
Tutti i contenuti di Wikipedia sono [protetti](https://it.wikipedia.org/wiki/Wikipedia:Copyright "Wikipedia:Copyright") da una [licenza libera](https://it.wikipedia.org/wiki/Licenza_libera "Licenza libera"), la [Creative Commons CC BY-SA](https://it.wikipedia.org/wiki/Licenze_Creative_Commons "Licenze Creative Commons"), che ne permette il riutilizzo per [qualsiasi scopo](https://it.wikipedia.org/wiki/Contenuto_libero "Contenuto libero") a condizione di [adottare la medesima licenza](https://it.wikipedia.org/wiki/Copyleft "Copyleft"). 
![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/HSTools.svg/40px-HSTools.svg.png)
  * **Vuoi partecipare?** Leggi le [regole fondamentali](https://it.wikipedia.org/wiki/Wikipedia:Cinque_pilastri "Wikipedia:Cinque pilastri") e le altre [linee guida](https://it.wikipedia.org/wiki/Wikipedia:Raccomandazioni_e_linee_guida "Wikipedia:Raccomandazioni e linee guida"), e rispetta la _[wikiquette](https://it.wikipedia.org/wiki/Wikipedia:Wikiquette "Wikipedia:Wikiquette")_ ; la [registrazione](https://it.wikipedia.org/wiki/Aiuto:Come_registrarsi "Aiuto:Come registrarsi") è consigliata ma _non obbligatoria_.
  * **Serve aiuto?** Consulta le [istruzioni](https://it.wikipedia.org/wiki/Aiuto:Aiuto "Aiuto:Aiuto") e le [domande frequenti (FAQ)](https://it.wikipedia.org/wiki/Aiuto:FAQ "Aiuto:FAQ") o leggi [dove fare una domanda](https://it.wikipedia.org/wiki/Aiuto:Dove_fare_una_domanda "Aiuto:Dove fare una domanda"); se ti sei appena registrato puoi richiedere l'assegnazione di un [tutor](https://it.wikipedia.org/wiki/Progetto:Coordinamento/Accoglienza/Nuovi_arrivati "Progetto:Coordinamento/Accoglienza/Nuovi arrivati").
  * **Vuoi provare?** Modifica [la pagina di prova](https://it.wikipedia.org/wiki/Wikipedia:Pagina_delle_prove "Wikipedia:Pagina delle prove") o segui il [Tour guidato](https://it.wikipedia.org/wiki/Aiuto:Tour_guidato "Aiuto:Tour guidato") per imparare [come scrivere una voce](https://it.wikipedia.org/wiki/Aiuto:Come_scrivere_una_voce "Aiuto:Come scrivere una voce").
  * **Vuoi fare una donazione?** Wikipedia è completamente gratuita e priva di pubblicità grazie alle donazioni degli utenti. [Aiutaci a migliorarla e a mantenerla libera con una donazione](https://donate.wikimedia.org/w/index.php?title=Special:FundraiserLandingPage&country=IT&uselang=it&utm_medium=sidebar&utm_source=donate&utm_campaign=C13_it.wikipedia.org).
  * **Cosa pensi di Wikipedia?** Scrivi [il tuo parere](https://it.wikipedia.org/wiki/Wikipedia:Pareri_su_Wikipedia "Wikipedia:Pareri su Wikipedia").


![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/Text-x-generic_with_pencil-2.svg/40px-Text-x-generic_with_pencil-2.svg.png)
La [comunità](https://it.wikipedia.org/wiki/Portale:Comunit%C3%A0 "Portale:Comunità") di [Wikipedia in lingua italiana](https://it.wikipedia.org/wiki/Wikipedia_in_italiano "Wikipedia in italiano") è composta da 2 693 510 utenti registrati, dei quali 13 803 hanno contribuito con almeno una modifica nell'ultimo mese e 110 hanno [funzioni di servizio](https://it.wikipedia.org/wiki/Wikipedia:Amministratori "Wikipedia:Amministratori"). Gli utenti costituiscono una comunità collaborativa, in cui tutti i membri, grazie anche ai [progetti tematici](https://it.wikipedia.org/wiki/Portale:Progetti "Portale:Progetti") e ai rispettivi [luoghi di discussione](https://it.wikipedia.org/wiki/Wikipedia:Bar_tematici "Wikipedia:Bar tematici"), [coordinano](https://it.wikipedia.org/wiki/Progetto:Coordinamento "Progetto:Coordinamento") i propri sforzi nella redazione delle voci. 
![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/PL_Wiki_Aktualnosci_ikona.svg/38px-PL_Wiki_Aktualnosci_ikona.svg.png)
**Voci nuove[in evidenza](https://it.wikipedia.org/wiki/Wikipedia:Novit%C3%A0 "Wikipedia:Novità"):**      [Miliardo noioso](https://it.wikipedia.org/wiki/Miliardo_noioso "Miliardo noioso")**·** [Mastodontoidea](https://it.wikipedia.org/wiki/Mastodontoidea "Mastodontoidea")**·** [Serranía de La Lindosa](https://it.wikipedia.org/wiki/Serran%C3%ADa_de_La_Lindosa "Serranía de La Lindosa")**·** [Mary Griffith](https://it.wikipedia.org/wiki/Mary_Griffith "Mary Griffith")**·** [Marc Breitman](https://it.wikipedia.org/wiki/Marc_Breitman "Marc Breitman")**·** [Marina Tabassum](https://it.wikipedia.org/wiki/Marina_Tabassum "Marina Tabassum")
**Voci sostanzialmente modificate[in evidenza](https://it.wikipedia.org/wiki/Wikipedia:Novit%C3%A0 "Wikipedia:Novità"):**      [Feticismo del piede](https://it.wikipedia.org/wiki/Feticismo_del_piede "Feticismo del piede")**·** _[Mugil cephalus](https://it.wikipedia.org/wiki/Mugil_cephalus "Mugil cephalus")_**·** [DC Extended Universe](https://it.wikipedia.org/wiki/DC_Extended_Universe "DC Extended Universe")**·** [Bauta](https://it.wikipedia.org/wiki/Bauta_\(maschera\) "Bauta \(maschera\)")**·** [Futbol'nyj Klub Černihiv](https://it.wikipedia.org/wiki/Futbol%27nyj_Klub_%C4%8Cernihiv "Futbol'nyj Klub Černihiv")**·** [László Moholy-Nagy](https://it.wikipedia.org/wiki/L%C3%A1szl%C3%B3_Moholy-Nagy "László Moholy-Nagy")
_**[il Wikipediano](https://it.wikipedia.org/wiki/Wikipedia:Wikipediano "Wikipedia:Wikipediano")**_ , notizie dalla comunità 
![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/HSContribs.svg/40px-HSContribs.svg.png)
## Lavori in corso
È in corso il _[Festival del ControlCopy](https://it.wikipedia.org/wiki/Wikipedia:Festival_della_qualit%C3%A0/Ottobre_2025 "Wikipedia:Festival della qualità/Ottobre 2025")_
![](https://upload.wikimedia.org/wikipedia/commons/8/8c/Bluebg_rounded_croped.png)
![ ](https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/HSWikimedia.svg/40px-HSWikimedia.svg.png)
## Dagli altri progetti
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Wikimedia-logo-meta.svg/20px-Wikimedia-logo-meta.svg.png)](https://it.wikipedia.org/wiki/Wikipedia:Traduzione_della_settimana "Wikipedia:Traduzione della settimana") **[Traduzione della settimana](https://it.wikipedia.org/wiki/Wikipedia:Traduzione_della_settimana "Wikipedia:Traduzione della settimana")** da [Meta-Wiki](https://it.wikipedia.org/wiki/Wikimedia_Meta-Wiki "Wikimedia Meta-Wiki")
Questa settimana la voce da tradurre è: 
  * [Federation of Central America (1921–1922)](https://www.wikidata.org/wiki/Q133844233 "d:Q133844233")


(versione in italiano: [Federazione dell'America centrale (1921–1922)](https://it.wikipedia.org/w/index.php?title=Federazione_dell%27America_centrale_\(1921%E2%80%931922\)&action=edit&redlink=1 "Federazione dell'America centrale \(1921–1922\) \(la pagina non esiste\)")) 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/20px-Wikiquote-logo.svg.png)](https://it.wikiquote.org/wiki/ "q:") **[Citazione del giorno](https://it.wikiquote.org/wiki/Wikiquote:Archivio_delle_citazioni_del_giorno "q:Wikiquote:Archivio delle citazioni del giorno")** da [Wikiquote](https://it.wikipedia.org/wiki/Wikiquote "Wikiquote")
**“** Una volta per tutte dunque ti viene imposto un breve precetto: ama e fa' ciò che vuoi; sia che tu taccia, taci per amore; sia che tu parli, parla per amore; sia che tu corregga, correggi per amore; sia che perdoni, perdona per amore; sia in te la radice dell'amore, poiché da questa radice non può procedere se non il bene.**„**  
**[Agostino d'Ippona](https://it.wikiquote.org/wiki/Agostino_d%27Ippona "q:Agostino d'Ippona")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/20px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/ "commons:") **[Immagine del giorno](https://commons.wikimedia.org/wiki/Commons:Immagine_del_giorno "commons:Commons:Immagine del giorno")** da [Commons](https://it.wikipedia.org/wiki/Wikimedia_Commons "Wikimedia Commons")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg/330px-Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)](https://it.wikipedia.org/wiki/File:Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)
Un dipinto Pahari del 1660-70 circa, proveniente da [Bashohli](https://it.wikipedia.org/wiki/Bashohli "Bashohli"), India, raffigurante la dea indù Bhadrakali adorata dalle tre divinità supreme dell'[Induismo](https://it.wikipedia.org/wiki/Induismo "Induismo"): [Brahma](https://it.wikipedia.org/wiki/Brahma "Brahma") il creatore, [Visnù](https://it.wikipedia.org/wiki/Visn%C3%B9 "Visnù") il preservatore e [Shiva](https://it.wikipedia.org/wiki/Siva_\(divinit%C3%A0\) "Siva \(divinità\)") il distruttore, per pacificarla dopo aver ucciso il demone [Mahiṣāsura](https://it.wikipedia.org/wiki/Mahi%E1%B9%A3%C4%81sura "Mahiṣāsura"), che non poteva essere ucciso né da loro, né dagli uomini, né da altri dei. La sua vittoria sul demone è celebrata dagli indù come la vittoria del bene sul male nel giorno di [Vijayadashami](https://it.wikipedia.org/wiki/Vijayadashami "Vijayadashami"), che cade oggi. 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://it.wikinews.org/wiki/ "n:") **[Ultime notizie](https://it.wikinews.org/wiki/ "n:")** da [Wikinotizie](https://it.wikipedia.org/wiki/Wikinotizie "Wikinotizie") 

mercoledì 1 ottobre 2025

  * [Morto Renato Casaro, illustratore di successi del cinema](https://it.wikinews.org/wiki/Morto_Renato_Casaro,_illustratore_di_successi_del_cinema "n:Morto Renato Casaro, illustratore di successi del cinema")
  * [Jannik Sinner ha vinto il China Open 2025](https://it.wikinews.org/wiki/Jannik_Sinner_ha_vinto_il_China_Open_2025 "n:Jannik Sinner ha vinto il China Open 2025")
  * [Fausto Durante - Segretario della CGIL Sarda - e il libro pagato dai sardi](https://it.wikinews.org/wiki/Fausto_Durante_-_Segretario_della_CGIL_Sarda_-_e_il_libro_pagato_dai_sardi "n:Fausto Durante - Segretario della CGIL Sarda - e il libro pagato dai sardi")



martedì 30 settembre 2025

  * [Calcio, Serie B 2025-2026: 6ª giornata](https://it.wikinews.org/wiki/Calcio,_Serie_B_2025-2026:_6%C2%AA_giornata "n:Calcio, Serie B 2025-2026: 6ª giornata")



domenica 28 settembre 2025

  * [La nazionale maschile di pallavolo italiana è campione del mondo per la quinta volta](https://it.wikinews.org/wiki/La_nazionale_maschile_di_pallavolo_italiana_%C3%A8_campione_del_mondo_per_la_quinta_volta "n:La nazionale maschile di pallavolo italiana è campione del mondo per la quinta volta")



sabato 27 settembre 2025

  * [Calcio, Serie B 2025-2026: 5ª giornata](https://it.wikinews.org/wiki/Calcio,_Serie_B_2025-2026:_5%C2%AA_giornata "n:Calcio, Serie B 2025-2026: 5ª giornata")


  

[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/20px-Wikisource-logo.svg.png)](https://it.wikisource.org/wiki/ "s:") **[Rilettura del mese](https://it.wikisource.org/wiki/Wikisource:Rilettura_del_mese "s:Wikisource:Rilettura del mese")** su [Wikisource](https://it.wikipedia.org/wiki/Wikisource "Wikisource")
_**[Come un sogno](https://it.wikisource.org/wiki/Indice:Barrili_-_Come_un_sogno,_Milano,_Treves,_1889.djvu "s:Indice:Barrili - Come un sogno, Milano, Treves, 1889.djvu")**_  
[Anton Giulio Barrili](https://it.wikipedia.org/wiki/Anton_Giulio_Barrili "Anton Giulio Barrili"), Milano, 1889. 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Barrili_-_Come_un_sogno%2C_Milano%2C_Treves%2C_1889.djvu/page7-170px-Barrili_-_Come_un_sogno%2C_Milano%2C_Treves%2C_1889.djvu.jpg)](https://it.wikisource.org/wiki/Indice:Barrili_-_Come_un_sogno,_Milano,_Treves,_1889.djvu "s:Indice:Barrili - Come un sogno, Milano, Treves, 1889.djvu")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/20px-Wikivoyage-Logo-v3-icon.svg.png)](https://it.wikivoyage.org/wiki/ "voy:") **[Destinazione del mese](https://it.wikivoyage.org/wiki/Wikivoyage:Destinazione_del_mese "voy:Wikivoyage:Destinazione del mese")** su [Wikivoyage](https://it.wikipedia.org/wiki/Wikivoyage "Wikivoyage")
_**[Albuquerque](https://it.wikivoyage.org/wiki/Albuquerque "voy:Albuquerque")**_
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Wv_Albuquerque_banner2.jpg/330px-Wv_Albuquerque_banner2.jpg)](https://it.wikivoyage.org/wiki/Albuquerque "voy:Albuquerque")
Conosciuta anche localmente come Duke City e con l'abbreviazione ABQ, è la [città più popolosa](https://it.wikipedia.org/wiki/Citt%C3%A0_del_Nuovo_Messico "Città del Nuovo Messico") dello [Stato](https://it.wikipedia.org/wiki/Stati_federati_degli_Stati_Uniti_d%27America "Stati federati degli Stati Uniti d'America") del [Nuovo Messico](https://it.wikipedia.org/wiki/Nuovo_Messico "Nuovo Messico") e la [32ª città più popolosa](https://it.wikipedia.org/wiki/Citt%C3%A0_degli_Stati_Uniti_d%27America_per_popolazione "Città degli Stati Uniti d'America per popolazione") degli [Stati Uniti](https://it.wikipedia.org/wiki/Stati_Uniti_d%27America "Stati Uniti d'America"). È la principale città dell'area metropolitana di Albuquerque. L'area metropolitana di Albuquerque è la 60ª più grande degli Stati Uniti. La città fu chiamata così in onore di [Francisco Fernández de la Cueva](https://it.wikipedia.org/wiki/Francisco_Fern%C3%A1ndez_de_la_Cueva_\(1666-1733\) "Francisco Fernández de la Cueva \(1666-1733\)"), che fu [viceré della Nuova Spagna](https://it.wikipedia.org/wiki/Vicer%C3%A9_della_Nuova_Spagna "Viceré della Nuova Spagna") dal 1702 al 1711. A dare il nome a quello che all'epoca era un villaggio in espansione fu il governatore della provincia, Francisco Cuervo y Valdés. Fernández de la Cueva era duca della città spagnola di [Alburquerque](https://it.wikipedia.org/wiki/Alburquerque_\(Badajoz\) "Alburquerque \(Badajoz\)"), nella [provincia di Badajoz](https://it.wikipedia.org/wiki/Provincia_di_Badajoz "Provincia di Badajoz"), vicino al confine con il [Portogallo](https://it.wikipedia.org/wiki/Portogallo "Portogallo"). 
**[Wikipedia non dà garanzie sulla validità dei contenuti](https://it.wikipedia.org/wiki/Wikipedia:Avvertenze_generali "Wikipedia:Avvertenze generali")**   
Il progetto è ospitato dalla [Wikimedia Foundation](https://it.wikipedia.org/wiki/Wikimedia_Foundation "Wikimedia Foundation"), che non può essere ritenuta responsabile di eventuali errori contenuti in questo sito.  
Ogni contributore è responsabile dei propri inserimenti.
* * *
[Sala stampa](https://it.wikipedia.org/wiki/Wikipedia:Sala_stampa "Wikipedia:Sala stampa") · [Contatti](https://it.wikipedia.org/wiki/Wikipedia:Contatti "Wikipedia:Contatti") · [FAQ](https://it.wikipedia.org/wiki/Aiuto:FAQ "Aiuto:FAQ") · [Copyright](https://it.wikipedia.org/wiki/Wikipedia:Copyright "Wikipedia:Copyright") · [Wikipedia sul tuo sito](https://it.wikipedia.org/wiki/Wikipedia:Wikipedia_sul_tuo_sito "Wikipedia:Wikipedia sul tuo sito") · [Citare Wikipedia](https://it.wikipedia.org/wiki/Aiuto:Come_citare_Wikipedia "Aiuto:Come citare Wikipedia") · _[Not Italian? it-0? Click here!](https://it.wikipedia.org/wiki/Wikipedia:Ambasciata "Wikipedia:Ambasciata")_
Altri progetti
  * [Wikisource](https://it.wikisource.org/wiki/Pagina_principale "s:Pagina principale")
  * [Wikiquote](https://it.wikiquote.org/wiki/Pagina_principale "q:Pagina principale")
  * [Wikibooks](https://it.wikibooks.org/wiki/Pagina_principale "b:Pagina principale")
  * [Wikiversità](https://it.wikiversity.org/wiki/Pagina_principale "v:Pagina principale")
  * [Wikinotizie](https://it.wikinews.org/wiki/Pagina_principale "n:Pagina principale")
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page?uselang=it)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page?uselang=it)
  * [Wikivoyage](https://it.wikivoyage.org/wiki/Pagina_principale "voy:Pagina principale")
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page "wikidata:Wikidata:Main Page")


Estratto da "[https://it.wikipedia.org/w/index.php?title=Pagina_principale&oldid=137151196](https://it.wikipedia.org/w/index.php?title=Pagina_principale&oldid=137151196)"
[Categoria](https://it.wikipedia.org/wiki/Categoria:Categorie "Categoria:Categorie"): 
  * [Pagina principale](https://it.wikipedia.org/wiki/Categoria:Pagina_principale "Categoria:Pagina principale")


70 lingue
  * [Afrikaans](https://af.wikipedia.org/wiki/ "afrikaans")
  * [العربية](https://ar.wikipedia.org/wiki/ "arabo")
  * [مصرى](https://arz.wikipedia.org/wiki/ "arabo egiziano")
  * [Asturianu](https://ast.wikipedia.org/wiki/ "asturiano")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/ "azerbaigiano")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/ "South Azerbaijani")
  * [Беларуская](https://be.wikipedia.org/wiki/ "bielorusso")
  * [Български](https://bg.wikipedia.org/wiki/ "bulgaro")
  * [বাংলা](https://bn.wikipedia.org/wiki/ "bengalese")
  * [Català](https://ca.wikipedia.org/wiki/ "catalano")
  * [Нохчийн](https://ce.wikipedia.org/wiki/ "ceceno")
  * [Cebuano](https://ceb.wikipedia.org/wiki/ "cebuano")
  * [Čeština](https://cs.wikipedia.org/wiki/ "ceco")
  * [Cymraeg](https://cy.wikipedia.org/wiki/ "gallese")
  * [Dansk](https://da.wikipedia.org/wiki/ "danese")
  * [Deutsch](https://de.wikipedia.org/wiki/ "tedesco")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "greco")
  * [English](https://en.wikipedia.org/wiki/ "inglese")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "esperanto")
  * [Español](https://es.wikipedia.org/wiki/ "spagnolo")
  * [Eesti](https://et.wikipedia.org/wiki/ "estone")
  * [Euskara](https://eu.wikipedia.org/wiki/ "basco")
  * [فارسی](https://fa.wikipedia.org/wiki/ "persiano")
  * [Suomi](https://fi.wikipedia.org/wiki/ "finlandese")
  * [Français](https://fr.wikipedia.org/wiki/ "francese")
  * [Galego](https://gl.wikipedia.org/wiki/ "galiziano")
  * [עברית](https://he.wikipedia.org/wiki/ "ebraico")
  * [हिन्दी](https://hi.wikipedia.org/wiki/ "hindi")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "croato")
  * [Magyar](https://hu.wikipedia.org/wiki/ "ungherese")
  * [Հայերեն](https://hy.wikipedia.org/wiki/ "armeno")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "indonesiano")
  * [日本語](https://ja.wikipedia.org/wiki/ "giapponese")
  * [ქართული](https://ka.wikipedia.org/wiki/ "georgiano")
  * [Қазақша](https://kk.wikipedia.org/wiki/ "kazako")
  * [한국어](https://ko.wikipedia.org/wiki/ "coreano")
  * [Latina](https://la.wikipedia.org/wiki/ "latino")
  * [Ladin](https://lld.wikipedia.org/wiki/ "ladino")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "lituano")
  * [Latviešu](https://lv.wikipedia.org/wiki/ "lettone")
  * [Minangkabau](https://min.wikipedia.org/wiki/ "menangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/ "macedone")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "malese")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/ "birmano")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "olandese")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "norvegese nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "norvegese bokmål")
  * [Polski](https://pl.wikipedia.org/wiki/ "polacco")
  * [Português](https://pt.wikipedia.org/wiki/ "portoghese")
  * [Română](https://ro.wikipedia.org/wiki/ "rumeno")
  * [Русский](https://ru.wikipedia.org/wiki/ "russo")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "serbo-croato")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "slovacco")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "sloveno")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "serbo")
  * [Svenska](https://sv.wikipedia.org/wiki/ "svedese")
  * [தமிழ்](https://ta.wikipedia.org/wiki/ "tamil")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/ "tagico")
  * [ไทย](https://th.wikipedia.org/wiki/ "thailandese")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "turco")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/ "tataro")
  * [Українська](https://uk.wikipedia.org/wiki/ "ucraino")
  * [اردو](https://ur.wikipedia.org/wiki/ "urdu")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/ "uzbeco")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vietnamita")
  * [Winaray](https://war.wikipedia.org/wiki/ "waray")
  * [中文](https://zh.wikipedia.org/wiki/ "cinese")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/ "min nan")
  * [粵語](https://zh-yue.wikipedia.org/wiki/ "cantonese")


  * Questa pagina è stata modificata per l'ultima volta il 2 gen 2024 alle 15:11.
  * Il testo è disponibile secondo la [licenza Creative Commons Attribuzione-Condividi allo stesso modo](https://creativecommons.org/licenses/by-sa/4.0/deed.it); possono applicarsi condizioni ulteriori. Vedi le [condizioni d'uso](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use/it) per i dettagli.


  * [Informativa sulla privacy](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy/it)
  * [Informazioni su Wikipedia](https://it.wikipedia.org/wiki/Wikipedia:Sala_stampa/Wikipedia)
  * [Avvertenze](https://it.wikipedia.org/wiki/Wikipedia:Avvertenze_generali)
  * [Codice di condotta](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Sviluppatori](https://developer.wikimedia.org)
  * [Statistiche](https://stats.wikimedia.org/#/it.wikipedia.org)
  * [Dichiarazione sui cookie](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Versione mobile](https://it.wikipedia.org/w/index.php?title=Pagina_principale&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://it.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://it.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Ricerca
Ricerca
Pagina principale
[](https://it.wikipedia.org/wiki/Pagina_principale) [](https://it.wikipedia.org/wiki/Pagina_principale) [](https://it.wikipedia.org/wiki/Pagina_principale) [](https://it.wikipedia.org/wiki/Pagina_principale) [](https://it.wikipedia.org/wiki/Pagina_principale) [](https://it.wikipedia.org/wiki/Pagina_principale) [](https://it.wikipedia.org/wiki/Pagina_principale) [](https://it.wikipedia.org/wiki/Pagina_principale)
70 lingue [Aggiungi argomento ](https://it.wikipedia.org/wiki/Pagina_principale)
