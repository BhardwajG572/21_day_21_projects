[Jump to content](https://ceb.wikipedia.org/wiki/Unang_Panid#bodyContent)
Panguna nga menu
Panguna nga menu
move to sidebar tagoa
Tabok-tabok 
  * [Unang Panid](https://ceb.wikipedia.org/wiki/Unang_Panid "Bisitaha ang Unang Panid \[alt-z\]")
  * [Tubaan](https://ceb.wikipedia.org/wiki/Wikipedia:Tubaan "Kabahin sa proyekto, unsay imong mahimo, asa mangita sa mga impormasyon")
  * [Mga bag-ong giusab](https://ceb.wikipedia.org/wiki/Espesyal:Bag-ongGiusab "Ang talaan sa mga bag-ong giusab sa wiki \[alt-r\]")
  * [Bisan unsang panid](https://ceb.wikipedia.org/wiki/Espesyal:Bisan-unsa "Pag-abli og bisan unsang panid \[alt-x\]")
  * [Tabang](https://ceb.wikipedia.org/wiki/Wikipedya:Tabang "Ang dapit nga angay mong pangitaan.")


[ ![](https://ceb.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://ceb.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-ceb.svg) ![Ang Gawasnong Ensayklopedya](https://ceb.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-ceb.svg) ](https://ceb.wikipedia.org/wiki/Unang_Panid)
[Pangita ](https://ceb.wikipedia.org/wiki/Espesyal:Pangita "Pangitaa Wikipedia \[alt-f\]")
Pangitaa
Appearance
Appearance
move to sidebar tagoa
Text
  * Small
Standard
Large

This page always uses small font size
Width
  * Standard
Wide

The content is as wide as possible for your browser window.
  * [Mga donasyon](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ceb.wikipedia.org&uselang=ceb)
  * [Paghimo og akawnt](https://ceb.wikipedia.org/w/index.php?title=Espesyal:Paghimo%27gAkawnt&returnto=Unang+Panid "Gidasig ka sa paghimo og akawnt ug sa pagpaila; apan dili kini kinahanglanon")
  * [Sulod](https://ceb.wikipedia.org/w/index.php?title=Espesyal:UserLogin&returnto=Unang+Panid "Gihangyo ka namo sa pag-''log-in'', apan wala kini gikinahanglan aron makausab ka sa mga panid. \[alt-o\]")


Personal nga galamiton
  * [Mga donasyon](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ceb.wikipedia.org&uselang=ceb)
  * [Paghimo og akawnt](https://ceb.wikipedia.org/w/index.php?title=Espesyal:Paghimo%27gAkawnt&returnto=Unang+Panid "Gidasig ka sa paghimo og akawnt ug sa pagpaila; apan dili kini kinahanglanon")
  * Not logged in
  * [Talk](https://ceb.wikipedia.org/wiki/Special:MyTalk "Your talk page \[alt-n\]")
  * [Contributions](https://ceb.wikipedia.org/wiki/Special:MyContributions "A list of your contributions \[alt-y\]")
  * [Sulod](https://ceb.wikipedia.org/w/index.php?title=Espesyal:UserLogin&returnto=Unang+Panid "Gihangyo ka namo sa pag-''log-in'', apan wala kini gikinahanglan aron makausab ka sa mga panid. \[alt-o\]")


**Mga bahin [Paghimo og account](https://ceb.wikipedia.org/wiki/Espesyal:Paghimo%27gAkawnt "Espesyal:Paghimo'gAkawnt") · [Blakbord](https://ceb.wikipedia.org/wiki/Wikipedia:Blakbord "Wikipedia:Blakbord") · [Mga sulod](https://ceb.wikipedia.org/wiki/Tabang:Mga_sulod "Tabang:Mga sulod") · [Kontaka ang tigdumala](https://ceb.wikipedia.org/wiki/Wikipedia:Tigdumala_noticeboard "Wikipedia:Tigdumala noticeboard") · [Embahada](https://ceb.wikipedia.org/wiki/Wikipedia:Embahada "Wikipedia:Embahada")** | [![Close](https://upload.wikimedia.org/wikipedia/commons/3/36/CloseWindow.svg)](https://ceb.wikipedia.org/wiki/Unang_Panid "Close")  
---|---  
Toggle the table of contents
## Mga sulod
move to sidebar tagoa
  * [ Sinugdanan ](https://ceb.wikipedia.org/wiki/Unang_Panid)
  * [ 1 Piniling artikulo ](https://ceb.wikipedia.org/wiki/Unang_Panid#Piniling_artikulo)
  * [ 2 Mga Panghitabo ](https://ceb.wikipedia.org/wiki/Unang_Panid#Mga_Panghitabo)


# Unang Panid
  * [Unang Panid](https://ceb.wikipedia.org/wiki/Unang_Panid "Tan-awa ang sulod ning panid \[alt-c\]")
  * [Panaghisgot-hisgot](https://ceb.wikipedia.org/wiki/Hisgot:Unang_Panid "Panaghisgot kabahin sa panid \[alt-t\]")


Cebuano
  * [Basaha](https://ceb.wikipedia.org/wiki/Unang_Panid)
  * [Tan-awa ang tinubdan](https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&action=edit "Giprotektahan kining panid.
Pwede nimong tan-awon ang ginikanan. \[alt-e\]")
  * [Tan-awa ang kaagi](https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&action=history "Mga miaging rebisyon ning panid \[alt-h\]")


Mga galamiton
Mga galamiton
move to sidebar tagoa
Actions 
  * [Basaha](https://ceb.wikipedia.org/wiki/Unang_Panid)
  * [Tan-awa ang tinubdan](https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&action=edit)
  * [Tan-awa ang kaagi](https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&action=history)
  * [Purge](https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&action=purge "Purge the server cache of this page \[alt-*\]")


Heneral 
  * [Unsay mga misumpay dinhi](https://ceb.wikipedia.org/wiki/Espesyal:WhatLinksHere/Unang_Panid "Talaan sa mga wiki nga panid nga misumpay dinhi \[alt-j\]")
  * [Mga may kalabotang kausaban](https://ceb.wikipedia.org/wiki/Espesyal:RecentChangesLinked/Unang_Panid "Mga bag-ong pag-usab sa mga panid gikan ning panid \[alt-k\]")
  * [Pagsumiter og payl](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=ceb "Pagsumiter og mga payl \[alt-u\]")
  * [Permanenteng sumpay](https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&oldid=35083564 "Permanenteng sumpay niining rebisyon sa panid")
  * [Impormasyon kabahin sa panid](https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&action=info "More information about this page")
  * [Kutloa kining maong artikulo](https://ceb.wikipedia.org/w/index.php?title=Espesyal:CiteThisPage&page=Unang_Panid&id=35083564&wpFormIdentifier=titleform "Impormasyon unsaon pagsitar kining panid")
  * [Pagkuha og pinamubo nga URL](https://ceb.wikipedia.org/w/index.php?title=Espesyal:UrlShortener&url=https%3A%2F%2Fceb.wikipedia.org%2Fwiki%2FUnang_Panid)
  * [Download QR code](https://ceb.wikipedia.org/w/index.php?title=Espesyal:QrCode&url=https%3A%2F%2Fceb.wikipedia.org%2Fwiki%2FUnang_Panid)


I-print/export 
  * [Paghimo og libro](https://ceb.wikipedia.org/w/index.php?title=Espesyal:Book&bookcmd=book_creator&referer=Unang+Panid)
  * [I-download isip PDF](https://ceb.wikipedia.org/w/index.php?title=Espesyal:DownloadAsPdf&page=Unang_Panid&action=show-download-screen)
  * [Mapatik nga bersiyon](https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&printable=yes "Mapatik nga bersyon ning panid \[alt-p\]")


Sa ubang mga proyekto 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Aytem sa Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Sumpay ngadto sa aytem sa konektadong tipiganan sa datos \[alt-g\]")


Gikan sa Wikipedia, ang gawasnong ensiklopedya
[Dayon](https://ceb.wikipedia.org/wiki/Wikipedia:Maayong_pag-abot,_higala! "Wikipedia:Maayong pag-abot, higala!") [Wikipedya](https://ceb.wikipedia.org/wiki/Wikipedya "Wikipedya"), ang libre ug gawasnong ensiklopedya.  | Ang Sinugboanong Wikipedya 
  * nag-inusarang ensiklopedya sa Binisaya  

  * walay bayad (tan-awa ang atong [_copyright_](https://ceb.wikipedia.org/wiki/Wikipedia:Katungod_sa_pagpatik "Wikipedia:Katungod sa pagpatik"))

  
---|---  
Kini ang among damgo:  Maapod-apod sa matag Bisaya/Sugboanon ang usa ka libreng ensiklopedya. [6,115,960](https://ceb.wikipedia.org/wiki/Espesyal:Estadistika "Espesyal:Estadistika") ka mga artikulo ug 3 file gisugdan [Hunyo 22, 2005](https://ceb.wikipedia.org/wiki/Wikipedia:Anunsyo "Wikipedia:Anunsyo").  [Miyerkules](https://ceb.wikipedia.org/wiki/Miyerkules "Miyerkules"), [Oktubre 1](https://ceb.wikipedia.org/wiki/Oktubre_1 "Oktubre 1"), [2025](https://ceb.wikipedia.org/wiki/2025 "2025"); 22:23 ([GMT+8](https://ceb.wikipedia.org/wiki/GMT "GMT")) karon  
[Bag-oha](https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&action=purge) |  | 
## Piniling artikulo  
---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/DSC08427.JPG/250px-DSC08427.JPG)](https://ceb.wikipedia.org/wiki/Payl:DSC08427.JPG)Kolehiyong Rogasyonista Ang **Rogationist College** (**Kolehiyong Rogasyonista**), nailhan usab sa minubong **RC** , usa ka [kolehiyong](https://ceb.wikipedia.org/wiki/Kolehiyo "Kolehiyo") gidumala sa mga [paring Rogasyonista](https://ceb.wikipedia.org/w/index.php?title=Mga_Rogasyonista_sa_Kasingkasing_ni_Hesus&action=edit&redlink=1 "Mga Rogasyonista sa Kasingkasing ni Hesus \(wala pa masulat\)"), usa ka orden sa [Simbahang Katoliko](https://ceb.wikipedia.org/wiki/Simbahang_Katoliko "Simbahang Katoliko"). _RCian_ , Rogasyonista o _Rogationist_ ang tawag sa mga magtutuon dinhi. Natukod sa tuig [1987](https://ceb.wikipedia.org/wiki/1987 "1987") isip Rogationist Academy sa [Silang](https://ceb.wikipedia.org/wiki/Silang,_Cavite "Silang, Cavite"), [Cavite](https://ceb.wikipedia.org/wiki/Cavite "Cavite"), [Pilipinas](https://ceb.wikipedia.org/wiki/Pilipinas "Pilipinas"). Mayoriya sa gihatag nga mga kurso nahiubos sa [inhenyeriya](https://ceb.wikipedia.org/wiki/Inhenyeriya "Inhenyeriya") ug [teknolohiya](https://ceb.wikipedia.org/w/index.php?title=Teknolohiya&action=edit&redlink=1 "Teknolohiya \(wala pa masulat\)").  **[padayo'g pag-basa...](https://ceb.wikipedia.org/wiki/Rogationist_College "Rogationist College")** [Ang ubang maayong mga artikulo](https://ceb.wikipedia.org/wiki/Wikipedia:Piniling_artikulo "Wikipedia:Piniling artikulo") – [Mga sugyot](https://ceb.wikipedia.org/wiki/Wikipedia:Piniling_artikulo#Sugyot_nga_mahimong_piniling_artikulo "Wikipedia:Piniling artikulo") – [Mga kinahanglanon](https://ceb.wikipedia.org/wiki/Wikipedia:WikiProyekto_Piniling_artikulo "Wikipedia:WikiProyekto Piniling artikulo")  
| 
## Mga Panghitabo  
---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Coronavirus_patients_at_the_Imam_Khomeini_Hospital_in_Tehran%2C_Iran--1_March_2020.jpg/120px-Coronavirus_patients_at_the_Imam_Khomeini_Hospital_in_Tehran%2C_Iran--1_March_2020.jpg)](https://ceb.wikipedia.org/wiki/Payl:Coronavirus_patients_at_the_Imam_Khomeini_Hospital_in_Tehran,_Iran--1_March_2020.jpg)
* [Coronavirus pandemya](https://ceb.wikipedia.org/wiki/Coronavirus_pandemya "Coronavirus pandemya"). 
**[Uban pang panghitabo...](https://ceb.wikipedia.org/wiki/Wikipedia:Mga_panghitabo "Wikipedia:Mga panghitabo")**  
**Makatabang ka sa pagkab-ot sa maong tinguha!**  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/70/Crystal_Clear_app_kedit.png/40px-Crystal_Clear_app_kedit.png)](https://ceb.wikipedia.org/wiki/Payl:Crystal_Clear_app_kedit.png)
  * **Pagpuno og artikulo** : 
    * Mahimong orihinal nga sinulat o hinubad gikan sa ubang Wikipedya.
    * Niay among [sugyot nga sulatonong mga artikulo](https://ceb.wikipedia.org/wiki/Wikipedia:Sulatonong_mga_artikulo "Wikipedia:Sulatonong mga artikulo").

|  [![](https://upload.wikimedia.org/wikipedia/commons/9/93/Evolution-tasks.png)](https://ceb.wikipedia.org/wiki/Payl:Evolution-tasks.png)
  * **Panindota ang mga eksisting nga artikulo**. 
    * Unaha ang imong (mga) hilig: [kompyuter](https://ceb.wikipedia.org/wiki/Kompyuter "Kompyuter"), [internet](https://ceb.wikipedia.org/wiki/Internet "Internet"), [ang imong lungsod](https://ceb.wikipedia.org/wiki/Talaan_sa_mga_lungsod_nga_Bisaya "Talaan sa mga lungsod nga Bisaya"), [ang imong paboritong banda nga BisRock](https://ceb.wikipedia.org/wiki/Talaan_sa_mga_BisRock_nga_banda "Talaan sa mga BisRock nga banda").
    * Pipila sa imong mahimo: butangi'g hulagway ([unsaon](https://en.wikipedia.org/wiki/Wikipedia:Picture_tutorial "en:Wikipedia:Picture tutorial")?), hinloa ang espeling, ayoha ang pagkasulat.

  
|  [Mga Ganghaan](https://ceb.wikipedia.org/wiki/Wikipedia:Ganghaan "Wikipedia:Ganghaan"):  |  [![3D_heart](https://upload.wikimedia.org/wikipedia/commons/thumb/4/49/3D_heart.png/40px-3D_heart.png)](https://ceb.wikipedia.org/wiki/Payl:3D_heart.png "3D_heart")[Kabisay-an](https://ceb.wikipedia.org/wiki/Ganghaan:Kabisay-an "Ganghaan:Kabisay-an") [![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Crystal128-kcoloredit.svg/40px-Crystal128-kcoloredit.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Crystal128-kcoloredit.svg)[Mga arte](https://ceb.wikipedia.org/wiki/Ganghaan:Mga_arte "Ganghaan:Mga arte") [![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Nuvola_apps_edu_mathematics.png/40px-Nuvola_apps_edu_mathematics.png)](https://ceb.wikipedia.org/wiki/Payl:Nuvola_apps_edu_mathematics.png)[Matematika](https://ceb.wikipedia.org/wiki/Ganghaan:Matematika "Ganghaan:Matematika") |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Sciences_de_la_terre.svg/40px-Sciences_de_la_terre.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Sciences_de_la_terre.svg)[Heyograpiya](https://ceb.wikipedia.org/wiki/Ganghaan:Heyograpiya "Ganghaan:Heyograpiya") [![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Fairytale_history.png/40px-Fairytale_history.png)](https://ceb.wikipedia.org/wiki/Payl:Fairytale_history.png)[Kasaysayan](https://ceb.wikipedia.org/wiki/Ganghaan:Kasaysayan "Ganghaan:Kasaysayan") [![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Sciences_exactes.svg/40px-Sciences_exactes.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Sciences_exactes.svg)[Siyensiya](https://ceb.wikipedia.org/wiki/Ganghaan:Siyensiya "Ganghaan:Siyensiya") |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Crystal_Clear_app_Login_Manager.svg/40px-Crystal_Clear_app_Login_Manager.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Crystal_Clear_app_Login_Manager.svg)[Bayograpiya](https://ceb.wikipedia.org/wiki/Ganghaan:Bayograpiya "Ganghaan:Bayograpiya") [![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Books-aj.svg_aj_ashton_01b.svg/40px-Books-aj.svg_aj_ashton_01b.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Books-aj.svg_aj_ashton_01b.svg)[Katitikan](https://ceb.wikipedia.org/wiki/Ganghaan:Katitikan "Ganghaan:Katitikan") [![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/64/Exquisite-home-mdk.png/40px-Exquisite-home-mdk.png)](https://ceb.wikipedia.org/wiki/Payl:Exquisite-home-mdk.png)[Teknolohiya](https://ceb.wikipedia.org/wiki/Ganghaan:Teknolohiya "Ganghaan:Teknolohiya") |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Socrates_blue_version2.png/40px-Socrates_blue_version2.png)](https://ceb.wikipedia.org/wiki/Payl:Socrates_blue_version2.png)[Pilosopiya](https://ceb.wikipedia.org/wiki/Ganghaan:Pilosopiya "Ganghaan:Pilosopiya") [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Gnome-home.svg/40px-Gnome-home.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Gnome-home.svg)[Katilingban](https://ceb.wikipedia.org/wiki/Ganghaan:Katilingban "Ganghaan:Katilingban") |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Crystal_Clear_filesystem_folder_blue.png/40px-Crystal_Clear_filesystem_folder_blue.png)](https://ceb.wikipedia.org/wiki/Payl:Crystal_Clear_filesystem_folder_blue.png)**[Uban pa](https://ceb.wikipedia.org/wiki/Wikipedia:Talaan_sa_mga_ganghaan "Wikipedia:Talaan sa mga ganghaan")**  
---|---|---|---|---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Cravate-normal.png/120px-Cravate-normal.png)](https://ceb.wikipedia.org/wiki/Payl:Cravate-normal.png)**Kinsa kami?**  
Ang mga serber nga nagapadagan sa Sinugboanong Wikipedya gipanag-iya sa [Wikimedia Foundation](https://ceb.wikipedia.org/wiki/Wikimedia_Foundation "Wikimedia Foundation").   
Ang [Wikimedia Pilipinas](http://www.wikimedia.org.ph) mao ang lokal nga tsapter sa nasod.  [Tan-awa dinhi ang talaan sa mga nag-una ug kanunayng tigtampohan](https://ceb.wikipedia.org/wiki/Wikipedia:Mga_tigtampohan "Wikipedia:Mga tigtampohan").   
Mahimo kaming makontak pinaagi sa indibidwal nga _panid sa tiggamit_. Pwede usab sa **[Tubaan](https://ceb.wikipedia.org/wiki/Wikipedia:Tubaan "Wikipedia:Tubaan")**.   
_**Don't speak Cebuano? You can post messages at our[Embassy](https://ceb.wikipedia.org/wiki/Wikipedya:Embahada "Wikipedya:Embahada").**_  
_**Di nagse-Sebwano? Maaari kang mag-iwan ng mensahe sa aming[Pasuguan](https://ceb.wikipedia.org/wiki/Wikipedya:Embahada "Wikipedya:Embahada").**_ |  **Ang Wikipedya sa ubang pinulongan**  
_Mga Wikipedya sa Pilipinas_ : [Binikol](https://bcl.wikipedia.org/wiki/ "bcl:") - [Iniloko](https://ilo.wikipedia.org/wiki/ "ilo:") - [Kinapampangan](https://pam.wikipedia.org/wiki/ "pam:") - [Pinanggasinan](https://pag.wikipedia.org/wiki/ "pag:") - [Tinagalog](https://tl.wikipedia.org/wiki/ "tl:") - [Tsinabakano](https://cbk-zam.wikipedia.org/wiki/ "cbk-zam:") - [Winaray](https://war.wikipedia.org/wiki/ "war:")  
_Mga Wikipedya sa ubang pinulongan_ : May total nga 273 ka mga wikipedya. Pipila sa labing dako mao kining mosunod.  
Labaw sa 100,000 artikulo: · [Kinatsila (Español)](https://es.wikipedia.org/wiki/ "es:") · [Pinlandes (Suomi)](https://fi.wikipedia.org/wiki/ "fi:") · [Ukranyano (Українська)](https://uk.wikipedia.org/wiki/ "uk:") · [Inebreo (עברית)](https://he.wikipedia.org/wiki/ "he:") · [Binyetnamita (Tiếng Việt)](https://vi.wikipedia.org/wiki/ "vi:") · [Winaray](https://war.wikipedia.org/wiki/ "war:")  
Labaw sa 20,000 artikulo: · [Inestonyo (Eesti)](https://et.wikipedia.org/wiki/ "et:") · [Minalayo (Bahasa Melayu)](https://ms.wikipedia.org/wiki/ "ms:") · [Iningles (simple)](https://simple.wikipedia.org/wiki/ "simple:") · [Ginalyego (Galego)](https://gl.wikipedia.org/wiki/ "gl:") · [Bag-ong Ninorwego (Nynorsk)](https://nn.wikipedia.org/wiki/ "nn:") · [Linatin (Latina)](https://la.wikipedia.org/wiki/ "la:") · [Hinabanes (Basa Jawa)](https://jv.wikipedia.org/wiki/ "jv:") · [Lineton (Latviešu)](https://lv.wikipedia.org/wiki/ "lv:") · [Binosniyo (Bosanski)](https://bs.wikipedia.org/wiki/ "bs:") · [Inislandes (Íslenska)](https://is.wikipedia.org/wiki/ "is:") · [Ginales (Cymraeg)](https://cy.wikipedia.org/wiki/ "cy:") · [Binyeloruso (Беларуская)](https://be.wikipedia.org/wiki/ "be:") · [Inoksitano (Occitan)](https://oc.wikipedia.org/wiki/ "oc:") · [tanang pinulongan](https://meta.wikimedia.org/wiki/List_of_Wikipedias "meta:List of Wikipedias")  
  
**Mga kaubang proyekto sa Wikipedya** :  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/20px-Wiktionary-logo.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Wiktionary-logo.svg) [Wiktionary](https://ceb.wiktionary.org/wiki/en:Main_Page "wikt:en:Main Page") (diksiyonaryo) |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/20px-Wikibooks-logo.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Wikibooks-logo.svg) [Wikibooks](https://ceb.wikibooks.org/wiki/en:Main_Page "b:en:Main Page") (libro)  
---|---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/20px-Wikiquote-logo.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Wikiquote-logo.svg) [Wikiquote](https://ceb.wikiquote.org/wiki/en:Main_Page "q:en:Main Page") (_quotes_) |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/20px-Wikisource-logo.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Wikisource-logo.svg) [Wikisource](https://ceb.wikisource.org/wiki/Main_Page:English "s:Main Page:English") (dokumento)  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/WikiSpecies.svg/20px-WikiSpecies.svg.png)](https://ceb.wikipedia.org/wiki/Payl:WikiSpecies.svg) [Wikispecies](https://species.wikimedia.org/wiki/ "species:") (organismo) |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/20px-Wikinews-logo.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Wikinews-logo.svg) [Wikinews](https://ceb.wikinews.org/wiki/Main_Page "n:Main Page") (balita)  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/20px-Wikiversity_logo_2017.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Wikiversity_logo_2017.svg) [Wikiversity](https://ceb.wikiversity.org/wiki/Main_Page "v:Main Page") (tulunghaan) |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/20px-Commons-logo.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Commons-logo.svg) [Commons](https://commons.wikimedia.org/wiki/Main_Page "c:Main Page") (mga _file_)  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/20px-Wikimedia-logo.svg.png)](https://ceb.wikipedia.org/wiki/Payl:Wikimedia-logo.svg) [Meta](https://meta.wikimedia.org/wiki/Main_Page "m:Main Page") (koordinasyon)  
Gikuha gikan sa "[https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&oldid=35083564](https://ceb.wikipedia.org/w/index.php?title=Unang_Panid&oldid=35083564)"
19 ka pinulongan
  * [العربية](https://ar.wikipedia.org/wiki/ "Arabic")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/ "Central Bikol")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/ "Chavacano")
  * [English](https://en.wikipedia.org/wiki/ "English")
  * [Español](https://es.wikipedia.org/wiki/ "Espanyol")
  * [Français](https://fr.wikipedia.org/wiki/ "Pranses")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "Indonesian")
  * [Ilokano](https://ilo.wikipedia.org/wiki/ "Iloko")
  * [日本語](https://ja.wikipedia.org/wiki/ "Hinapon")
  * [한국어](https://ko.wikipedia.org/wiki/ "Korean")
  * [Malagasy](https://mg.wikipedia.org/wiki/ "Malagasy")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "Malay")
  * [Pangasinan](https://pag.wikipedia.org/wiki/ "Pangasinan")
  * [Kapampangan](https://pam.wikipedia.org/wiki/ "Pampanga")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Tagalog](https://tl.wikipedia.org/wiki/ "Tagalog")
  * [Winaray](https://war.wikipedia.org/wiki/ "Waray")
  * [中文](https://zh.wikipedia.org/wiki/ "Inintsik")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/ "Minnan")


  * Kining maong panid kataposang giusab niadtong 3 Mayo 2025 sa 02:58.
  * Ang teksto anaa ubos sa [Creative Commons Attribution-ShareAlike License](https://creativecommons.org/licenses/by-sa/4.0/deed.en) ; dugang mga termino mahimong magamit. Tan-awa [ang Termino sa Paggamit](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use) alang sa mga detalye.


  * [Palisiya sa personal nga impormasyon](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Mahitungod sa Wikipedia](https://ceb.wikipedia.org/wiki/Wikipedia:Mahitungod_sa_Wikipedya)
  * [Mga pagpasabot](https://ceb.wikipedia.org/wiki/Wikipedia:Mga_pagpasabot)
  * [Code of Conduct](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Mga tig-ugmad](https://developer.wikimedia.org)
  * [Estadistika](https://stats.wikimedia.org/#/ceb.wikipedia.org)
  * [Pahayag sa cookie](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Alang sa <em>mobile</em>](https://ceb.m.wikipedia.org/w/index.php?title=Unang_Panid&mobileaction=toggle_view_mobile)
  * [Edit preview settings](https://ceb.wikipedia.org/wiki/Unang_Panid)


  * [![Wikimedia Foundation](https://ceb.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://ceb.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Pangita
Pangitaa
Toggle the table of contents
Unang Panid
[](https://ceb.wikipedia.org/wiki/Unang_Panid) [](https://ceb.wikipedia.org/wiki/Unang_Panid) [](https://ceb.wikipedia.org/wiki/Unang_Panid) [](https://ceb.wikipedia.org/wiki/Unang_Panid) [](https://ceb.wikipedia.org/wiki/Unang_Panid) [](https://ceb.wikipedia.org/wiki/Unang_Panid) [](https://ceb.wikipedia.org/wiki/Unang_Panid) [](https://ceb.wikipedia.org/wiki/Unang_Panid)
19 ka pinulongan [Pagdugang og topiko ](https://ceb.wikipedia.org/wiki/Unang_Panid)
