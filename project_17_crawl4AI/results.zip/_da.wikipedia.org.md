[Spring til indhold](https://da.wikipedia.org/wiki/Forside#bodyContent)
Hovedmenu
Hovedmenu
flyt til sidebjælken skjul
Navigation 
  * [Forside](https://da.wikipedia.org/wiki/Forside "Besøg forsiden \[z\]")
  * [Kategorier](https://da.wikipedia.org/wiki/Wikipedia:Kategorier)
  * [Fremhævet indhold](https://da.wikipedia.org/wiki/Wikipedia:Fremh%C3%A6vet_indhold)
  * [Tilfældig side](https://da.wikipedia.org/wiki/Speciel:Tilf%C3%A6ldig_side "Gå til en tilfældig side \[x\]")
  * [Tilfældige artikler](https://da.wikipedia.org/wiki/Wikipedia:Tilf%C3%A6ldige_artikler)
  * [Aktuelt](https://da.wikipedia.org/wiki/Wikipedia:Aktuelle_begivenheder)


deltagelse 
  * [Velkommen](https://da.wikipedia.org/wiki/Hj%C3%A6lp:Velkommen_til_Wikipedia)
  * [Skribentforside](https://da.wikipedia.org/wiki/Wikipedia:Forside "Om projektet, hvad du kan gøre, hvor tingene findes")
  * [Landsbybrønden](https://da.wikipedia.org/wiki/Wikipedia:Landsbybr%C3%B8nden)
  * [Projekter](https://da.wikipedia.org/wiki/Wikipedia:Projekter)
  * [Portaler](https://da.wikipedia.org/wiki/Portal:Portaler)
  * [Ønskede artikler](https://da.wikipedia.org/wiki/Wikipedia:WikiProjekt_Efterspurgte_artikler)
  * [Oprydning](https://da.wikipedia.org/wiki/Wikipedia:Oprydning)
  * [Kalender](https://da.wikipedia.org/wiki/Wikipedia:Kalender)
  * [Seneste ændringer](https://da.wikipedia.org/wiki/Speciel:Seneste_%C3%A6ndringer "Listen over de seneste ændringer i wikien. \[r\]")
  * [Hjælp](https://da.wikipedia.org/wiki/Hj%C3%A6lp:Forside "Stedet hvor du finder hjælp")
  * [Specialsider](https://da.wikipedia.org/wiki/Speciel:Specialsider)


Organisation 
  * [Kontakt Wikipedia](https://da.wikipedia.org/wiki/Wikipedia:Kontakt_Wikipedia)
  * [Wikimedia Danmark](https://dk.wikimedia.org/wiki/)
  * [GLAM](https://da.wikipedia.org/wiki/Wikipedia:GLAM)


[ ![](https://da.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://da.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![Den frie encyklopædi](https://da.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-da.svg) ](https://da.wikipedia.org/wiki/Forside)
[Søg ](https://da.wikipedia.org/wiki/Speciel:S%C3%B8gning "Søg på Wikipedia \[f\]")
Søg
Udseende
  * [Donation](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=da.wikipedia.org&uselang=da)
  * [Opret konto](https://da.wikipedia.org/w/index.php?title=Speciel:Opret_konto&returnto=Forside "Du opfordres til at oprette en konto og logge på, men det er ikke obligatorisk")
  * [Log på](https://da.wikipedia.org/w/index.php?title=Speciel:Log_p%C3%A5&returnto=Forside "Du opfordres til at logge på, men det er ikke obligatorisk. \[o\]")


Personlige værktøjer
  * [Donation](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=da.wikipedia.org&uselang=da)
  * [Opret konto](https://da.wikipedia.org/w/index.php?title=Speciel:Opret_konto&returnto=Forside "Du opfordres til at oprette en konto og logge på, men det er ikke obligatorisk")
  * [Log på](https://da.wikipedia.org/w/index.php?title=Speciel:Log_p%C3%A5&returnto=Forside "Du opfordres til at logge på, men det er ikke obligatorisk. \[o\]")


[Luk]
Du kan være med til at gøre Wikipedia bedre – [læs her hvordan!](https://da.wikipedia.org/wiki/Hj%C3%A6lp:Du_kan_v%C3%A6re_med_til_at_g%C3%B8re_Wikipedia_bedre! "Hjælp:Du kan være med til at gøre Wikipedia bedre!")  

Dansk Wikipedia har en Discord-server, hvor du kan chatte. Se mere på [Wikipedia:Discord](https://da.wikipedia.org/wiki/Wikipedia:Discord "Wikipedia:Discord")
_([Læs her om sitenotice](https://da.wikipedia.org/wiki/Hj%C3%A6lp:Sitenotice "Hjælp:Sitenotice"))_
# Forside
  * [Forside](https://da.wikipedia.org/wiki/Forside "Se indholdssiden \[c\]")
  * [Diskussion](https://da.wikipedia.org/wiki/Diskussion:Forside "Diskussion om indholdet på siden \[t\]")


dansk
  * [Læs](https://da.wikipedia.org/wiki/Forside)
  * [Vis kilde](https://da.wikipedia.org/w/index.php?title=Forside&action=edit "Denne side er beskyttet.
Du kan se kildeteksten. \[e\]")
  * [Se historik](https://da.wikipedia.org/w/index.php?title=Forside&action=history "Tidligere versioner af denne side \[h\]")


Værktøjer
Værktøjer
flyt til sidebjælken skjul
Handlinger 
  * [Læs](https://da.wikipedia.org/wiki/Forside)
  * [Vis kilde](https://da.wikipedia.org/w/index.php?title=Forside&action=edit)
  * [Se historik](https://da.wikipedia.org/w/index.php?title=Forside&action=history)


Generelt 
  * [Hvad henviser hertil](https://da.wikipedia.org/wiki/Speciel:Hvad_linker_hertil/Forside "Liste med alle sider som henviser hertil \[j\]")
  * [Beslægtede ændringer](https://da.wikipedia.org/wiki/Speciel:Relaterede_%C3%A6ndringer/Forside "Seneste ændringer af sider som denne side henviser til \[k\]")
  * [Upload fil](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=da&campaign=dk "Upload filer \[u\]")
  * [Permanent link](https://da.wikipedia.org/w/index.php?title=Forside&oldid=10000691 "Permanent link til denne version af denne side")
  * [Sideinformation](https://da.wikipedia.org/w/index.php?title=Forside&action=info "Yderligere oplysninger om denne side")
  * [Referer til denne side](https://da.wikipedia.org/w/index.php?title=Speciel:Citer&page=Forside&id=10000691&wpFormIdentifier=titleform "Information om, hvordan man kan citere denne side")
  * [Hent forkortet URL](https://da.wikipedia.org/w/index.php?title=Speciel:UrlShortener&url=https%3A%2F%2Fda.wikipedia.org%2Fwiki%2FForside)
  * [Download QR-kode](https://da.wikipedia.org/w/index.php?title=Speciel:QrCode&url=https%3A%2F%2Fda.wikipedia.org%2Fwiki%2FForside)


Udskriv/eksportér 
  * [Lav en bog](https://da.wikipedia.org/w/index.php?title=Speciel:Bog&bookcmd=book_creator&referer=Forside)
  * [Download som PDF](https://da.wikipedia.org/w/index.php?title=Speciel:DownloadAsPdf&page=Forside&action=show-download-screen)
  * [Udskriftsvenlig udgave](https://da.wikipedia.org/w/index.php?title=Forside&printable=yes "Printervenlig udgave af denne side \[p\]")


I andre projekter 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikibooks](https://da.wikibooks.org/wiki/Forside)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikiquote](https://da.wikiquote.org/wiki/Forside)
  * [Wikisource](https://da.wikisource.org/wiki/Forside)
  * [Wiktionary](https://da.wiktionary.org/wiki/Forside)
  * [Wikidata-element](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Link til tilknyttet emne i Wikidata \[g\]")


Udseende
flyt til sidebjælken skjul
Fra Wikipedia, den frie encyklopædi
|  **[Velkommen til Wikipedia](https://da.wikipedia.org/wiki/Hj%C3%A6lp:Velkommen_til_Wikipedia "Hjælp:Velkommen til Wikipedia")** , den frie [encyklopædi](https://da.wikipedia.org/wiki/Encyklop%C3%A6di "Encyklopædi") som [alle kan redigere](https://da.wikipedia.org/wiki/Hj%C3%A6lp:Artikeludvidelse "Hjælp:Artikeludvidelse").  
---  
  * [Astronomi](https://da.wikipedia.org/wiki/Portal:Astronomi "Portal:Astronomi")
  * [Botanik](https://da.wikipedia.org/wiki/Portal:Botanik "Portal:Botanik")
  * [Cykling](https://da.wikipedia.org/wiki/Portal:Cykling "Portal:Cykling")

| 
  * [Film](https://da.wikipedia.org/wiki/Portal:Film "Portal:Film")
  * [Geografi](https://da.wikipedia.org/wiki/Portal:Geografi "Portal:Geografi")
  * [Historie](https://da.wikipedia.org/wiki/Portal:Historie "Portal:Historie")

| 
  * [Musik](https://da.wikipedia.org/wiki/Portal:Musik "Portal:Musik")
  * [Kristendom](https://da.wikipedia.org/wiki/Portal:Kristendom "Portal:Kristendom")
  * [Kvinder](https://da.wikipedia.org/wiki/Portal:Kvinder "Portal:Kvinder")

| 
  * [Zoologi](https://da.wikipedia.org/wiki/Portal:Zoologi "Portal:Zoologi")
  * _[Flere portaler...](https://da.wikipedia.org/wiki/Portal:Portaler "Portal:Portaler")_

  
Der findes nu over 60 millioner artikler på [Wikipedia](https://da.wikipedia.org/wiki/Wikipedia "Wikipedia"), hvoraf [310.856](https://da.wikipedia.org/wiki/Speciel:Statistik "Speciel:Statistik") er på [dansk](https://da.wikipedia.org/wiki/Dansk_\(sprog\) "Dansk \(sprog\)"). _[Skribentforside](https://da.wikipedia.org/wiki/Wikipedia:Forside "Wikipedia:Forside") • [Hjælp](https://da.wikipedia.org/wiki/Hj%C3%A6lp:Forside "Hjælp:Forside") • [A–Å](https://da.wikipedia.org/wiki/Wikipedia:Alfabetisk_liste "Wikipedia:Alfabetisk liste") • [Projekter](https://da.wikipedia.org/wiki/Wikipedia:Projekter "Wikipedia:Projekter") • [Bekendtgørelser](https://da.wikipedia.org/wiki/Wikipedia:Bekendtg%C3%B8relser "Wikipedia:Bekendtgørelser") • [Wikipedia Mobil](https://da.m.wikipedia.org/) • [Kontakt Wikipedia](https://da.wikipedia.org/wiki/Hj%C3%A6lp:Kontakt_Wikipedia "Hjælp:Kontakt Wikipedia")_  
---  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/Emblem-star.svg/40px-Emblem-star.svg.png) Ugens artikel [![Kong Christian 10.](https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Christian_X_-_Peter_Elfelt.jpg/120px-Christian_X_-_Peter_Elfelt.jpg)](https://da.wikipedia.org/wiki/Christian_10. "Kong Christian 10.") **[Christian 10.](https://da.wikipedia.org/wiki/Christian_10. "Christian 10.")** (1870-1947) var [konge](https://da.wikipedia.org/wiki/Konger%C3%A6kken "Kongerækken") af [Danmark](https://da.wikipedia.org/wiki/Kongeriget_Danmark "Kongeriget Danmark") fra 1912 til sin død i 1947 og konge af [Island](https://da.wikipedia.org/wiki/Kongeriget_Island "Kongeriget Island") fra 1918 til 1944.  Han var søn af [Frederik 8.](https://da.wikipedia.org/wiki/Frederik_8. "Frederik 8.") og den tredje danske konge af den [Glücksburgske (Lyksborgske) slægt](https://da.wikipedia.org/wiki/Gl%C3%BCcksburgske_sl%C3%A6gt "Glücksburgske slægt"). Christian 10.s valgsprog var _Min Gud, mit Land, min Ære_.  Christian blev gift med [Alexandrine af Mecklenburg-Schwerin](https://da.wikipedia.org/wiki/Dronning_Alexandrine "Dronning Alexandrine") i 1898, og parret fik to sønner: [Frederik](https://da.wikipedia.org/wiki/Frederik_9. "Frederik 9.") (senere kong Frederik 9.) og [Knud](https://da.wikipedia.org/wiki/Arveprins_Knud "Arveprins Knud"). Ved hans fars død overtog han den danske trone, og sammen med sin dronning gjorde han en dyd ud af at besøge alle dele af kongeriget, herunder [Grønland](https://da.wikipedia.org/wiki/Gr%C3%B8nland "Grønland"), [Færøerne](https://da.wikipedia.org/wiki/F%C3%A6r%C3%B8erne "Færøerne") og Island. Kongehusets tradition med at tage på sommertogt med [kongeskibet](https://da.wikipedia.org/wiki/Kongeskibet_Dannebrog_\(A540,_1932-\) "Kongeskibet Dannebrog \(A540, 1932-\)") blev indført af Christian 10. og Alexandrine.  Christian var sammen med regeringen aktiv i at holde Danmark uden for [1. verdenskrig](https://da.wikipedia.org/wiki/1._Verdenskrig "1. Verdenskrig"). Under [Påskekrisen i 1920](https://da.wikipedia.org/wiki/P%C3%A5skekrisen_\(1920\) "Påskekrisen \(1920\)") afskedigede han – i modstrid med [Folketingets](https://da.wikipedia.org/wiki/Folketinget "Folketinget") ønske – [Ministeriet Zahle](https://da.wikipedia.org/wiki/Regeringen_Zahle_II "Regeringen Zahle II") i håb om at få et nyvalg og derved få en større bid af Nordslesvig, herunder [Flensborg](https://da.wikipedia.org/wiki/Flensborg "Flensborg"). Kuppet blev dog afværget, og ved [Genforeningen](https://da.wikipedia.org/wiki/Genforeningen_i_1920 "Genforeningen i 1920") blev Christian igen nationalt samlingspunkt, da han red over grænsen ved [Taps](https://da.wikipedia.org/wiki/Taps "Taps") på en hvid hest og mødte sønderjyderne på [Dybbøl](https://da.wikipedia.org/wiki/Historiecenter_Dybb%C3%B8l_Banke "Historiecenter Dybbøl Banke").  Under [den tyske besættelse af Danmark](https://da.wikipedia.org/wiki/Bes%C3%A6ttelsen "Besættelsen") under [2. verdenskrig](https://da.wikipedia.org/wiki/2._Verdenskrig "2. Verdenskrig") blev Christian i udlandet et symbol på den danske eftergivende holdning til [nazismen](https://da.wikipedia.org/wiki/Nazisme "Nazisme"), men han blev efterhånden meget populær i befolkningen på grund af sine daglige ture til hest rundt i [København](https://da.wikipedia.org/wiki/K%C3%B8benhavn "København"), og han fik efter krigen tilnavnet "Rytterkongen". (_[Læs mere..](https://da.wikipedia.org/wiki/Christian_10. "Christian 10.")_)_Seneste tre uger:_ [Puddel](https://da.wikipedia.org/wiki/Puddel "Puddel") — [London Calling](https://da.wikipedia.org/wiki/London_Calling "London Calling") — [Skagen](https://da.wikipedia.org/wiki/Skagen "Skagen") [Mere om Ugens artikel](https://da.wikipedia.org/wiki/Wikipedia:Ugens_artikel "Wikipedia:Ugens artikel") • [Arkiv](https://da.wikipedia.org/wiki/Wikipedia:Ugens_artikel/2025 "Wikipedia:Ugens artikel/2025") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Norway-sweden2.svg/40px-Norway-sweden2.svg.png) Dagens skandinaviske artikel [![Parsifal var Wagners siste opera.](https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/1895_Lenbach_Richard_Wagner_anagoria.JPG/120px-1895_Lenbach_Richard_Wagner_anagoria.JPG)](https://no.wikipedia.org/wiki/Parsifal_\(opera\) "Parsifal var Wagners siste opera.") _**[Parsifal](https://no.wikipedia.org/wiki/Parsifal_\(opera\) "no:Parsifal \(opera\)")**_ er en tyskspråklig opera fra 1882 i tre akter med tekst og musikk av Richard Wagner. Den er løst basert på Wolfram von Eschenbach episke dikt «Parzival» fra 1200-tallet, som handler om Kong Arthurs ridder Parsival og hans søken etter den hellige gral.  Wagner fikk ideen til verket i april 1857, men fullførte det ikke før 25 år senere. Det var hans siste opera, og for komposisjonen utnyttet han den spesielle akustikken til festspillhuset i Bayreuth. Parsifal ble først fremført under den andre Bayreuth-festivalen i 1882. Bayreuth-festivalen hadde monopol på Parsifal-produksjoner frem til 1903, da operaen ble fremført ved Metropolitan Opera i New York. Parsifal var ingen opera, uttrykte Wagner, men et «et festspill for helliggjørelse av scenen» (_Ein Bühnenweihfestspiel_). _[► Les mer her.](https://no.wikipedia.org/wiki/Parsifal_\(opera\) "no:Parsifal \(opera\)")__Dagens skandinaviske artikel er fra[norsk (bokmål)](https://no.wikipedia.org/wiki/ "no:") Wikipedia_ [Mere om Dagens skandinaviske artikel](https://da.wikipedia.org/wiki/Wikipedia:Dagens_skandinaviske_artikel "Wikipedia:Dagens skandinaviske artikel") • [Skanwiki](https://meta.wikimedia.org/wiki/Skanwiki "m:Skanwiki") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/Searchtool_right.svg/40px-Searchtool_right.svg.png) Fremhævede artikler |  [![Fremragende artikler](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Symbol_star_gold.svg/40px-Symbol_star_gold.svg.png)](https://da.wikipedia.org/wiki/Wikipedia:Fremragende_artikler "Fremragende artikler")Fremragende artikler | 
#### De nyeste [fremragende artikler](https://da.wikipedia.org/wiki/Wikipedia:Fremragende_artikler "Wikipedia:Fremragende artikler")
  * _[Casper& Mandrilaftalen](https://da.wikipedia.org/wiki/Casper_%26_Mandrilaftalen "Casper & Mandrilaftalen")_
  * [IC4](https://da.wikipedia.org/wiki/IC4 "IC4")
  * [Eurovision Song Contest 2014](https://da.wikipedia.org/wiki/Eurovision_Song_Contest_2014 "Eurovision Song Contest 2014")
  * _[Middelaldercentret](https://da.wikipedia.org/wiki/Middelaldercentret "Middelaldercentret")_

  
---|---  
[![Gode artikler](https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Symbol_support_vote.svg/40px-Symbol_support_vote.svg.png)](https://da.wikipedia.org/wiki/Wikipedia:Gode_artikler "Gode artikler")Gode artikler | 
#### De nyeste [gode artikler](https://da.wikipedia.org/wiki/Wikipedia:Gode_artikler "Wikipedia:Gode artikler")
  * [Linje 250S](https://da.wikipedia.org/wiki/Linje_250S "Linje 250S")
  * [Ove Sprogøe](https://da.wikipedia.org/wiki/Ove_Sprog%C3%B8e "Ove Sprogøe")
  * [Geoteknik](https://da.wikipedia.org/wiki/Geoteknik "Geoteknik")
  * _[Shu-bi-dua](https://da.wikipedia.org/wiki/Shu-bi-dua "Shu-bi-dua")_

  
[![Lovende artikler](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c4/Art%C3%ADculo_bueno-blue.svg/40px-Art%C3%ADculo_bueno-blue.svg.png)](https://da.wikipedia.org/wiki/Wikipedia:Lovende_artikler "Lovende artikler")Lovende artikler | 
#### De nyeste [lovende artikler](https://da.wikipedia.org/wiki/Wikipedia:Lovende_artikler "Wikipedia:Lovende artikler")
  * [George H.W. Bush](https://da.wikipedia.org/wiki/George_H.W._Bush "George H.W. Bush")
  * [General Motors](https://da.wikipedia.org/wiki/General_Motors "General Motors")
  * [General Dynamics F-16 Fighting Falcon](https://da.wikipedia.org/wiki/General_Dynamics_F-16_Fighting_Falcon "General Dynamics F-16 Fighting Falcon")
  * [Geelong](https://da.wikipedia.org/wiki/Geelong "Geelong")

  
[Rediger](https://da.wikipedia.org/wiki/Skabelon:Forside_fremh%C3%A6vede "Skabelon:Forside fremhævede") • [Mere fremhævet indhold](https://da.wikipedia.org/wiki/Wikipedia:Fremh%C3%A6vet_indhold "Wikipedia:Fremhævet indhold")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Gnome-fs-blockdev.svg/40px-Gnome-fs-blockdev.svg.png)
Kategorier
[![Naturvidenskab](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Gnome-applications-science.svg/40px-Gnome-applications-science.svg.png)](https://da.wikipedia.org/wiki/Kategori:Naturvidenskab "Naturvidenskab")Naturvidenskab | 
#### [Naturvidenskab](https://da.wikipedia.org/wiki/Kategori:Naturvidenskab "Kategori:Naturvidenskab")
  * [Astronomi](https://da.wikipedia.org/wiki/Kategori:Astronomi "Kategori:Astronomi")
  * [Biologi](https://da.wikipedia.org/wiki/Kategori:Biologi "Kategori:Biologi")
  * [Datalogi](https://da.wikipedia.org/wiki/Kategori:Datalogi "Kategori:Datalogi")
  * [Fysik](https://da.wikipedia.org/wiki/Kategori:Fysik "Kategori:Fysik")
  * [Geografi](https://da.wikipedia.org/wiki/Kategori:Geografi "Kategori:Geografi")
  * [Geologi](https://da.wikipedia.org/wiki/Kategori:Geologi "Kategori:Geologi")
  * [Kemi](https://da.wikipedia.org/wiki/Kategori:Kemi "Kategori:Kemi")
  * [Logik](https://da.wikipedia.org/wiki/Kategori:Logik "Kategori:Logik")
  * [Lægevidenskab](https://da.wikipedia.org/wiki/Kategori:L%C3%A6gevidenskab "Kategori:Lægevidenskab")
  * [Matematik](https://da.wikipedia.org/wiki/Kategori:Matematik "Kategori:Matematik")

  
---|---  
[![Humaniora](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/System-users.svg/40px-System-users.svg.png)](https://da.wikipedia.org/wiki/Kategori:Humaniora "Humaniora")Humaniora | 
####  [Humaniora](https://da.wikipedia.org/wiki/Kategori:Humaniora "Kategori:Humaniora") og [samfundsvidenskab](https://da.wikipedia.org/wiki/Kategori:Samfundsvidenskab "Kategori:Samfundsvidenskab")
  * [Antropologi](https://da.wikipedia.org/wiki/Kategori:Antropologi "Kategori:Antropologi")
  * [Arkitektur](https://da.wikipedia.org/wiki/Kategori:Arkitektur "Kategori:Arkitektur")
  * [Filosofi](https://da.wikipedia.org/wiki/Kategori:Filosofi "Kategori:Filosofi")
  * [Historie](https://da.wikipedia.org/wiki/Kategori:Historie "Kategori:Historie")
  * [Jura](https://da.wikipedia.org/wiki/Kategori:Jura "Kategori:Jura")
  * [Kommunikation](https://da.wikipedia.org/wiki/Kategori:Kommunikation "Kategori:Kommunikation")
  * [Psykologi](https://da.wikipedia.org/wiki/Kategori:Psykologi "Kategori:Psykologi")
  * [Pædagogik](https://da.wikipedia.org/wiki/Kategori:P%C3%A6dagogik "Kategori:Pædagogik")
  * [Sociologi](https://da.wikipedia.org/wiki/Kategori:Sociologi "Kategori:Sociologi")
  * [Sprogforskning](https://da.wikipedia.org/wiki/Kategori:Sprogforskning "Kategori:Sprogforskning")
  * [Statskundskab](https://da.wikipedia.org/wiki/Kategori:Statskundskab "Kategori:Statskundskab")
  * [Teologi](https://da.wikipedia.org/wiki/Kategori:Teologi "Kategori:Teologi")
  * [Økonomi](https://da.wikipedia.org/wiki/Kategori:%C3%98konomi "Kategori:Økonomi")

  
[![Teknik](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Nuvola_apps_kcmsystem.svg/40px-Nuvola_apps_kcmsystem.svg.png)](https://da.wikipedia.org/wiki/Kategori:Teknik "Teknik")Teknik | 
#### [Teknik](https://da.wikipedia.org/wiki/Kategori:Teknik "Kategori:Teknik")
  * [Elektronik](https://da.wikipedia.org/wiki/Kategori:Elektronik "Kategori:Elektronik")
  * [Energi](https://da.wikipedia.org/wiki/Kategori:Energi "Kategori:Energi")
  * [Industri](https://da.wikipedia.org/wiki/Kategori:Industri "Kategori:Industri")
  * [Jordbrug](https://da.wikipedia.org/wiki/Kategori:Jordbrug "Kategori:Jordbrug")
  * [Mekanik](https://da.wikipedia.org/wiki/Kategori:Mekanik "Kategori:Mekanik")
  * [Militær](https://da.wikipedia.org/wiki/Kategori:Milit%C3%A6r "Kategori:Militær")
  * [Robotter](https://da.wikipedia.org/wiki/Kategori:Robotter "Kategori:Robotter")
  * [Sundhedsvæsen](https://da.wikipedia.org/wiki/Kategori:Sundhedsv%C3%A6sen "Kategori:Sundhedsvæsen")
  * [Transport](https://da.wikipedia.org/wiki/Kategori:Transport "Kategori:Transport")

  
[![Kultur](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Gnome-applications-graphics.svg/40px-Gnome-applications-graphics.svg.png)](https://da.wikipedia.org/wiki/Kategori:Kultur "Kultur")Kultur | 
#### [Kultur](https://da.wikipedia.org/wiki/Kategori:Kultur "Kategori:Kultur")
  * [Dans](https://da.wikipedia.org/wiki/Kategori:Dans "Kategori:Dans")
  * [Film](https://da.wikipedia.org/wiki/Kategori:Film "Kategori:Film")
  * [Hobby](https://da.wikipedia.org/wiki/Kategori:Hobby "Kategori:Hobby")
  * [Kunst](https://da.wikipedia.org/wiki/Kategori:Kunst "Kategori:Kunst")
  * [Litteratur](https://da.wikipedia.org/wiki/Kategori:Litteratur "Kategori:Litteratur")
  * [Mad og drikke](https://da.wikipedia.org/wiki/Kategori:Mad_og_drikke "Kategori:Mad og drikke")
  * [Mode](https://da.wikipedia.org/wiki/Kategori:Mode "Kategori:Mode")
  * [Musik](https://da.wikipedia.org/wiki/Kategori:Musik "Kategori:Musik")
  * [Mytologi](https://da.wikipedia.org/wiki/Kategori:Mytologi "Kategori:Mytologi")
  * [Personer](https://da.wikipedia.org/wiki/Kategori:Personer "Kategori:Personer")
  * [Politik](https://da.wikipedia.org/wiki/Kategori:Politik "Kategori:Politik")
  * [Religion](https://da.wikipedia.org/wiki/Kategori:Religion "Kategori:Religion")
  * [Sport](https://da.wikipedia.org/wiki/Kategori:Sport "Kategori:Sport")
  * [Teater](https://da.wikipedia.org/wiki/Kategori:Teater "Kategori:Teater")
  * [Traditioner](https://da.wikipedia.org/wiki/Kategori:Traditioner "Kategori:Traditioner")
  * [Turisme](https://da.wikipedia.org/wiki/Kategori:Turisme "Kategori:Turisme")
  * [Underholdning](https://da.wikipedia.org/wiki/Kategori:Underholdning "Kategori:Underholdning")

  
[Flere kategorier](https://da.wikipedia.org/wiki/Wikipedia:Kategorier "Wikipedia:Kategorier")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/Internet-web-browser.svg/40px-Internet-web-browser.svg.png)
Aktuelle begivenheder
[Danmarks EU-formandskab](https://da.wikipedia.org/wiki/Danmarks_EU-formandskab_2025 "Danmarks EU-formandskab 2025") • [Gazakrigen](https://da.wikipedia.org/wiki/Gazakrigen_2023-nu "Gazakrigen 2023-nu") • [Ruslands invasion af Ukraine](https://da.wikipedia.org/wiki/Ruslands_invasion_af_Ukraine_2022 "Ruslands invasion af Ukraine 2022")
* * *
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Jonas_Vingegaard_-_Vuelta_a_Espa%C3%B1a_2025.jpg/120px-Jonas_Vingegaard_-_Vuelta_a_Espa%C3%B1a_2025.jpg)](https://da.wikipedia.org/wiki/Jonas_Vingegaard "Jonas Vingegaard")
  * Adskillige [droner](https://da.wikipedia.org/wiki/Drone_\(UAV\) "Drone \(UAV\)") **[observeres ved flere danske lufthavne](https://da.wikipedia.org/wiki/Droneobservationer_over_Danmark_2025 "Droneobservationer over Danmark 2025")** og indstiller flytrafikken.
  * [Storbritannien](https://da.wikipedia.org/wiki/Storbritannien "Storbritannien"), [Canada](https://da.wikipedia.org/wiki/Canada "Canada") og [Australien](https://da.wikipedia.org/wiki/Australien "Australien") anerkender officielt **[staten Palæstina](https://da.wikipedia.org/wiki/Pal%C3%A6stina_\(stat\) "Palæstina \(stat\)")**.
  * [Jonas Vingegaard](https://da.wikipedia.org/wiki/Jonas_Vingegaard "Jonas Vingegaard") (_billedet_) vinder som den første dansker nogensinde cykelløbet **[Vuelta a España](https://da.wikipedia.org/wiki/Vuelta_a_Espa%C3%B1a_2025 "Vuelta a España 2025")**.
  * Unge danske [håndværkere](https://da.wikipedia.org/wiki/H%C3%A5ndv%C3%A6rker "Håndværker") vinder et rekordstort antal medaljer ved europamesterskabet **[EuroSkills](https://da.wikipedia.org/wiki/EuroSkills "EuroSkills")** i [Herning](https://da.wikipedia.org/wiki/Herning "Herning").
  * Den amerikanske debattør **[Charlie Kirk](https://da.wikipedia.org/wiki/Charlie_Kirk "Charlie Kirk")** dræbes af skud under et offentligt debatmøde på [Utah Valley University](https://da.wikipedia.org/wiki/Utah_Valley_University "Utah Valley University").


[Rediger](https://da.wikipedia.org/wiki/Skabelon:Forside_Aktuelt "Skabelon:Forside Aktuelt") • [Flere aktuelle begivenheder](https://da.wikipedia.org/wiki/Wikipedia:Aktuelle_begivenheder "Wikipedia:Aktuelle begivenheder")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Office-calendar.svg/40px-Office-calendar.svg.png)
I dag
[![Sultan Saladin](https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Folio_from_The_book_of_knowledge_of_ingenious_mechanical_devices_%281354_Mamluk_copy%29._Part_of_a_water_clock_%28detail%29.jpg/120px-Folio_from_The_book_of_knowledge_of_ingenious_mechanical_devices_%281354_Mamluk_copy%29._Part_of_a_water_clock_%28detail%29.jpg)](https://da.wikipedia.org/wiki/Fil:Folio_from_The_book_of_knowledge_of_ingenious_mechanical_devices_\(1354_Mamluk_copy\)._Part_of_a_water_clock_\(detail\).jpg "Sultan Saladin")
Den **[2. oktober](https://da.wikipedia.org/wiki/2._oktober "2. oktober")** : [Guineas](https://da.wikipedia.org/wiki/Guinea "Guinea") uafhængighedsdag ([1958](https://da.wikipedia.org/wiki/1958 "1958")) 
  * [1187](https://da.wikipedia.org/wiki/1187 "1187") - [Muslimske](https://da.wikipedia.org/wiki/Muslim "Muslim") styrker under [sultan](https://da.wikipedia.org/wiki/Sultan "Sultan") **[Saladin](https://da.wikipedia.org/wiki/Saladin "Saladin")** (_billedet_) indtager [Jerusalem](https://da.wikipedia.org/wiki/Jerusalem "Jerusalem"), efter at byen i 88 år har været under [kristent](https://da.wikipedia.org/wiki/Kristendom "Kristendom") herredømme.
  * [1943](https://da.wikipedia.org/wiki/1943 "1943") - **[Arrestationen og deportationen](https://da.wikipedia.org/wiki/Redningen_af_de_danske_j%C3%B8der#Deportationsordren_og_flugten "Redningen af de danske jøder")** af de danske [jøder](https://da.wikipedia.org/wiki/J%C3%B8de "Jøde") starter.
  * [1972](https://da.wikipedia.org/wiki/1972 "1972") - Ved en **[folkeafstemning](https://da.wikipedia.org/wiki/Folkeafstemningen_om_Danmarks_optagelse_i_EF "Folkeafstemningen om Danmarks optagelse i EF")** stemmer et flertal for dansk indmeldelse i [EF](https://da.wikipedia.org/wiki/Europ%C3%A6iske_F%C3%A6llesskab "Europæiske Fællesskab").

  

[Rediger](https://da.wikipedia.org/wiki/Wikipedia:%C3%85rets_dage_kort/2._oktober "Wikipedia:Årets dage kort/2. oktober") • [Alle månedens dage](https://da.wikipedia.org/wiki/Wikipedia:%C3%85rets_dage_kort/Oktober "Wikipedia:Årets dage kort/Oktober")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Help-browser.svg/40px-Help-browser.svg.png)
Vidste du at...
_[Fra Wikipedias nyeste artikler…](https://da.wikipedia.org/wiki/Speciel:Nye_sider "Speciel:Nye sider")_
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/Mi_ne_vidas%2C_mi_ne_amdas%2C_mi_ne_parolas._-es.svg/120px-Mi_ne_vidas%2C_mi_ne_amdas%2C_mi_ne_parolas._-es.svg.png)](https://da.wikipedia.org/wiki/Fil:Mi_ne_vidas,_mi_ne_amdas,_mi_ne_parolas._-es.svg)
  * ... en opgørelse fra [Rockwool Fonden](https://da.wikipedia.org/wiki/Rockwool_Fondens_Forskningsenhed "Rockwool Fondens Forskningsenhed") i 1998 viste, at der begås **[assurancesvig](https://da.wikipedia.org/wiki/Assurancesvig "Assurancesvig")** i ca 12% af danske skadesanmeldelser til [forsikringsselskaberne](https://da.wikipedia.org/wiki/Forsikringsselskab "Forsikringsselskab")?
  * ... **[de tre vise aber](https://da.wikipedia.org/wiki/De_tre_vise_aber "De tre vise aber")** (_billedet_), der ikke ser, hører eller taler, har sin oprindelse i Japan?
  * ... den danske oprørsleder [Niels Ebbesen](https://da.wikipedia.org/wiki/Niels_Ebbesen "Niels Ebbesen") blev dræbt under **[Slaget ved Nonnebjerg](https://da.wikipedia.org/wiki/Slaget_ved_Nonnebjerg "Slaget ved Nonnebjerg")** i [1340](https://da.wikipedia.org/wiki/1340 "1340")?
  * ... en **[trembleuse](https://da.wikipedia.org/wiki/Trembleuse "Trembleuse")** er en drikkekop og underkop, hvor underkoppen har et hævet eller opretstående holdepunkt?


[Rediger](https://da.wikipedia.org/wiki/Skabelon:Vidste_du_at... "Skabelon:Vidste du at...") • [Flere vidste du at...](https://da.wikipedia.org/wiki/Wikipedia:Vidste_du_at... "Wikipedia:Vidste du at...")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Gravestone_icon2.svg/25px-Gravestone_icon2.svg.png)
Nyligt afdøde
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Jane-goodall.jpg/120px-Jane-goodall.jpg)](https://da.wikipedia.org/wiki/Fil:Jane-goodall.jpg)
  * [1. oktober](https://da.wikipedia.org/wiki/1._oktober "1. oktober") – [Jane Goodall](https://da.wikipedia.org/wiki/Jane_Goodall "Jane Goodall") (_billedet_), engelsk primatolog og antropolog (født [1934](https://da.wikipedia.org/wiki/1934 "1934"))
  * [29. september](https://da.wikipedia.org/wiki/29._september "29. september") – [Jørgen Leth](https://da.wikipedia.org/wiki/J%C3%B8rgen_Leth "Jørgen Leth"), dansk forfatter og filminstruktør (født [1937](https://da.wikipedia.org/wiki/1937 "1937"))
  * [28. september](https://da.wikipedia.org/wiki/28._september "28. september") – [José Araquistáin](https://da.wikipedia.org/wiki/Jos%C3%A9_Araquist%C3%A1in "José Araquistáin"), spansk fodboldspiller (født [1937](https://da.wikipedia.org/wiki/1937 "1937"))
  * [27. september](https://da.wikipedia.org/wiki/27._september "27. september") – [Franz Grundheber](https://da.wikipedia.org/wiki/Franz_Grundheber "Franz Grundheber"), tysk operasanger (født [1937](https://da.wikipedia.org/wiki/1937 "1937"))
  * [23. september](https://da.wikipedia.org/wiki/23._september "23. september") – [Claudia Cardinale](https://da.wikipedia.org/wiki/Claudia_Cardinale "Claudia Cardinale"), italiensk skuespillerinde (født [1938](https://da.wikipedia.org/wiki/1938 "1938"))


[Rediger](https://da.wikipedia.org/wiki/Skabelon:Nyligt_afd%C3%B8de "Skabelon:Nyligt afdøde") • [Flere nyligt afdøde](https://da.wikipedia.org/wiki/D%C3%B8de_i_2025#Oktober "Døde i 2025")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Image-x-generic.svg/40px-Image-x-generic.svg.png)
Dagens billede
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg/330px-Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)](https://da.wikipedia.org/wiki/Fil:Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)  
---  
Et [Pahar-maleri](https://da.wikipedia.org/wiki/Malerkunst_i_Indien "Malerkunst i Indien") fra byen Basohli i det vestlige [Indien](https://da.wikipedia.org/wiki/Indien "Indien") fra cirka 1660-1670. Billedet forestiller den hinduistiske gudinde Bhadrakali, der æres af de [tre øverste guder](https://da.wikipedia.org/wiki/Trimurti "Trimurti"): [Brahma](https://da.wikipedia.org/wiki/Brahma "Brahma") (skaberen), [Vishnu](https://da.wikipedia.org/wiki/Vishnu "Vishnu") (bevareren) og [Vishnu](https://da.wikipedia.org/wiki/Vishnu "Vishnu") (ødelæggeren), som tak for, at hun dræbte dæmonen Mahishasura, der ikke kunne dræbes af de tre, af mennesker eller andre guder. Hendes sejr over dæmonen fejres af hinduer på Vijayadashami, som er denne dag.   
[Rediger](https://da.wikipedia.org/wiki/Skabelon:POTD "Skabelon:POTD") • [Arkiv](https://commons.wikimedia.org/wiki/Commons:Dagens_billede "commons:Commons:Dagens billede")  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Wikipedia-logo-v2.svg/60px-Wikipedia-logo-v2.svg.png) Søsterprojekter Wikipedia ejes af paraplyorganisationen [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home "wikimedia:Home"), som driver flere [flersproglige](https://en.wikipedia.org/wiki/Wikipedia:Multilingual_coordination "w:Wikipedia:Multilingual coordination") og [frie](https://da.wikipedia.org/wiki/Wikipedia:Ophavsret "Wikipedia:Ophavsret") projekter hvor alle kan bidrage.  
  
[![Meta Wikimedia](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/ "Meta Wikimedia")  
[Meta-Wiki](https://meta.wikimedia.org/wiki/ "m:")  
Om   
Wikiprojekterne [![Wiktionary](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://da.wiktionary.org/wiki/ "Wiktionary")  
[Wiktionary](https://da.wiktionary.org/wiki/ "wikt:")  
Flersproget   
ordbog [![Wikiquote](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://da.wikiquote.org/wiki/ "Wikiquote")  
[Wikiquote](https://da.wikiquote.org/wiki/ "q:")  
Citatsamling  
[![Wikisource](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://da.wikisource.org/wiki/ "Wikisource")  
[Wikisource](https://da.wikisource.org/wiki/ "s:")  
Kildemateriale  
[![Wikibooks](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://da.wikibooks.org/wiki/ "Wikibooks")  
[Wikibooks](https://da.wikibooks.org/wiki/ "b:")  
Gratis bøger og  
manualer [![Wikiversity](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)](https://da.wikiversity.org/wiki/ "Wikiversity")  
[Wikiversity](https://da.wikiversity.org/wiki/ "v:")  
Fri læring  
[![Wikispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/ "Wikispecies")  
[Wikispecies](https://species.wikimedia.org/wiki/ "wikispecies:")  
Videnskabelig   
artsoversigt [![Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/ "Wikimedia Commons")  
[Commons](https://commons.wikimedia.org/wiki/ "commons:")  
Fildeling af   
billeder og lyd [![Wikinews](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://da.wikinews.org/wiki/ "Wikinews")  
[Wikinews](https://da.wikinews.org/wiki/ "n:")  
Nyhedstjeneste  
[![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "Wikidata")  
[Wikidata](https://www.wikidata.org/wiki/ "d:")  
Vidensdatabase  
[![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/ "MediaWiki")  
[MediaWiki](https://www.mediawiki.org/wiki/ "mw:")  
Wiki-software  
[![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://en.wikivoyage.org/wiki/ "Wikivoyage")  
[Wikivoyage](https://en.wikivoyage.org/wiki/ "wikivoyage:")  
Rejseguide  
[Mere om Wikimedia](https://da.wikipedia.org/wiki/Wikimedia "Wikimedia") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Preferences-desktop-locale.svg/48px-Preferences-desktop-locale.svg.png) Wikipedia på andre sprog **[English](https://en.wikipedia.org/wiki/ "en:") | [Føroyskt](https://fo.wikipedia.org/wiki/ "fo:") | [Íslenska](https://is.wikipedia.org/wiki/ "is:") | [Kalaallisut](https://kl.wikipedia.org/wiki/ "kl:") | [Norsk (bokmål)](https://no.wikipedia.org/wiki/ "no:") | [Nynorsk](https://nn.wikipedia.org/wiki/ "nn:") | [Suomi](https://fi.wikipedia.org/wiki/ "fi:") | [Davvisámegiella](https://se.wikipedia.org/wiki/ "se:") | [Svenska](https://sv.wikipedia.org/wiki/ "sv:")**
  * Flere end 1.500.000 artikler:  
[English](https://en.wikipedia.org/wiki/ "en:") **·** [Sinugboanong Binisaya](https://ceb.wikipedia.org/wiki/ "ceb:") **·** [Deutsch](https://de.wikipedia.org/wiki/ "de:") **·** [Svenska](https://sv.wikipedia.org/wiki/ "sv:") **·** [Français](https://fr.wikipedia.org/wiki/ "fr:") **·** [Nederlands](https://nl.wikipedia.org/wiki/ "nl:") **·** [Русский](https://ru.wikipedia.org/wiki/ "ru:")**·** [Español](https://es.wikipedia.org/wiki/ "es:") **·** [Italiano](https://it.wikipedia.org/wiki/ "it:") **·** [مصرى (Maṣrī)](https://arz.wikipedia.org/wiki/ "arz:") **·** [Polski](https://pl.wikipedia.org/wiki/ "pl:")


  * Flere end 1.000.000 artikler:  
[日本語](https://ja.wikipedia.org/wiki/ "ja:") **·** [中文](https://zh.wikipedia.org/wiki/ "zh:") **·** [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vi:") **·** [Українська](https://uk.wikipedia.org/wiki/ "uk:") **·** [Winaray](https://war.wikipedia.org/wiki/ "war:") **·** [العربية](https://ar.wikipedia.org/wiki/ "ar:") **·** [Português](https://pt.wikipedia.org/wiki/ "pt:")


  * Flere end 500.000 artikler:  
[فارسی](https://fa.wikipedia.org/wiki/ "fa:") **·** [Català](https://ca.wikipedia.org/wiki/ "ca:") **·** [Српски / Srpski](https://sr.wikipedia.org/wiki/ "sr:") **·** [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "id:") **·** [한국어](https://ko.wikipedia.org/wiki/ "ko:") **·** [Norsk (bokmål)](https://no.wikipedia.org/wiki/ "no:") **·** [Нохчийн](https://ce.wikipedia.org/wiki/ "ce:") **·** [Suomi](https://fi.wikipedia.org/wiki/ "fi:") **·** [Čeština](https://cs.wikipedia.org/wiki/ "cs:") **·** [Türkçe](https://tr.wikipedia.org/wiki/ "tr:") **·** [Magyar](https://hu.wikipedia.org/wiki/ "hu:") **·** [Tatarça / Татарча](https://tt.wikipedia.org/wiki/ "tt:")


  * Flere end 250.000 artikler:  
[Srpskohrvatski / Српскохрватски](https://sh.wikipedia.org/wiki/ "sh:") **·** [Română](https://ro.wikipedia.org/wiki/ "ro:") · [Bân-lâm-gú](https://zh-min-nan.wikipedia.org/wiki/ "zh-min-nan:") **·** [Euskara](https://eu.wikipedia.org/wiki/ "eu:") **·** [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "ms:") **·** [Esperanto](https://eo.wikipedia.org/wiki/ "eo:") **·** [עברית](https://he.wikipedia.org/wiki/ "he:") **·** [Հայերեն](https://hy.wikipedia.org/wiki/ "hy:") **·** **Dansk** **·** [Български](https://bg.wikipedia.org/wiki/ "bg:") **·** [Cymraeg](https://cy.wikipedia.org/wiki/ "cy:")


  * Flere end 150.000 artikler:  
[Slovenčina](https://sk.wikipedia.org/wiki/ "sk:") **·** [تۆرکجه](https://azb.wikipedia.org/wiki/ "azb:") **·** [O‘zbek](https://uz.wikipedia.org/wiki/ "uz:") **·** [Eesti](https://et.wikipedia.org/wiki/ "et:") **·** [Simple English](https://simple.wikipedia.org/wiki/ "simple:") **·** [Беларуская](https://be.wikipedia.org/wiki/ "be:") **·** [Қазақша](https://kk.wikipedia.org/wiki/ "kk:") **·** [Minangkabau](https://min.wikipedia.org/wiki/ "min:") **·** [Ελληνικά](https://el.wikipedia.org/wiki/ "el:") **·** [Hrvatski](https://hr.wikipedia.org/wiki/ "hr:") **·** [Lietuvių](https://lt.wikipedia.org/wiki/ "lt:") **·** [Galego](https://gl.wikipedia.org/wiki/ "gl:") **·** [Azərbaycanca](https://az.wikipedia.org/wiki/ "az:") **·** [اردو](https://ur.wikipedia.org/wiki/ "ur:") **·** [Slovenščina](https://sl.wikipedia.org/wiki/ "sl:") **·** [Ladin](https://lld.wikipedia.org/wiki/ "lld:") **·** [ქართული](https://ka.wikipedia.org/wiki/ "ka:") **·** [Nynorsk](https://nn.wikipedia.org/wiki/ "nn:") **·** [हिन्दी](https://hi.wikipedia.org/wiki/ "hi:") **·** [ไทย](https://th.wikipedia.org/wiki/ "th:") **·** [தமிழ்](https://ta.wikipedia.org/wiki/ "ta:")

[Komplet liste](https://meta.wikimedia.org/wiki/List_of_Wikipedias "meta:List of Wikipedias") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/60px-Wikimedia-logo.svg.png) Donationer Moderselskabet Wikimedia Foundation er uafhængigt af alle interesser og behøver derfor økonomisk støtte fra læsere og brugere for at holde driften i gang. [Giv et bidrag](https://foundation.wikimedia.org/wiki/Donate "wikimedia:Donate") til Wikimedia og vær med til at sikre udbygningen af de [servere](https://meta.wikimedia.org/wiki/Wikimedia_servers "m:Wikimedia servers"), som Wikipedia og søsterprojekterne afvikles på.  [Støt Wikipedia](https://foundation.wikimedia.org/wiki/Donate "wikimedia:Donate") **[Til toppen af siden](https://da.wikipedia.org/wiki/Forside#top)**  
Hentet fra "[https://da.wikipedia.org/w/index.php?title=Forside&oldid=10000691](https://da.wikipedia.org/w/index.php?title=Forside&oldid=10000691)"
[Kategori](https://da.wikipedia.org/wiki/Speciel:Kategorier "Speciel:Kategorier"): 
  * [Wikipedia administration](https://da.wikipedia.org/wiki/Kategori:Wikipedia_administration "Kategori:Wikipedia administration")


353 sprog
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – afar")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – abkhasisk")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – achinesisk")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – adyghe")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – afrikaans")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – schweizertysk")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – sydaltaisk")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – amharisk")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – aragonsk")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – oldengelsk")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – obolo")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – angika")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – arabisk")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – aramæisk")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – Moroccan Arabic")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – Egyptian Arabic")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – assamesisk")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – asturisk")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – atikamekw")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – avarisk")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – awadhi")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – aymara")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – aserbajdsjansk")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – bashkir")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – balinesisk")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – Bavarian")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – Samogitian")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – belarusisk")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – Betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница – bulgarsk")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – bislama")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – bambara")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – bengali")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – tibetansk")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – bretonsk")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – bosnisk")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – buginesisk")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – catalansk")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – tjetjensk")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – cebuano")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – chamorro")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – choctaw")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – cherokee")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – cheyenne")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – sorani")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – korsikansk")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – cree")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – krimtatarisk")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana – tjekkisk")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – kasjubisk")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – kirkeslavisk")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – tjuvasjisk")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – walisisk")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – tysk")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – dinka")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – nedersorbisk")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – Central Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – divehi")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – dzongkha")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – ewe")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – græsk")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – engelsk")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – esperanto")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – spansk")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht – estisk")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala – baskisk")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – Extremaduran")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – persisk")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – fanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – fulah")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – finsk")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – Võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – fijiansk")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – færøsk")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – fon")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal – fransk")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – Arpitan")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – nordfrisisk")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – friulisk")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – vestfrisisk")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – irsk")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – gagauzisk")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – gan-kinesisk")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – skotsk gælisk")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – galicisk")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – Gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – guarani")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – gorontalo")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – gotisk")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – gujarati")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – Wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – manx")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – hausa")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – hakka-kinesisk")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – hawaiiansk")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – hebraisk")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – hindi")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – Fiji Hindi")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – hirimotu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – kroatisk")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – øvresorbisk")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – haitisk")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – ungarsk")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ – armensk")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – herero")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – interlingua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – iban")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama – indonesisk")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – interlingue")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – igbo")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – inupiaq")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – iloko")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – ingush")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – ido")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – islandsk")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – italiensk")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – inuktitut")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – japansk")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – Jamaican Creole English")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – lojban")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – javanesisk")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – georgisk")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – karakalpakisk")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – kabylsk")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – kabardian")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – tyap")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – kongo")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – kikuyu")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – kuanyama")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – kasakhisk")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – grønlandsk")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – khmer")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – kannada")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – koreansk")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – komi-permjakisk")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – kanuri")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – karatjai-balkar")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – kashmiri")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – kölsch")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – kurdisk")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – komi")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – cornisk")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – kirgisisk")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima – latin")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – ladino")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – luxembourgsk")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – lezghian")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – ganda")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – limburgsk")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – ligurisk")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – lombardisk")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – lingala")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – lao")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – nordluri")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – litauisk")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – Latgalian")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – lettisk")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – madurese")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – maithili")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – moksha")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – malagassisk")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – marshallese")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – maori")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – minangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – makedonsk")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – malayalam")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – mongolsk")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – manipuri")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – mossi")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – marathi")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – Western Mari")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – malajisk")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – maltesisk")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – creek")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – mirandesisk")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – burmesisk")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – erzya")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – mazenisk")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – napolitansk")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – nedertysk")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – plattysk \(Holland\)")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – nepalesisk")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – newari")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – ndonga")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – nias")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina – nederlandsk")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – bokmål")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – Novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – n’ko")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – sydndebele")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – nordsotho")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – navajo")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – nyanja")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – occitansk")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – oromo")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – oriya")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – ossetisk")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – punjabi")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – pangasinan")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – pampanga")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – papiamento")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – Picard")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – nigeriansk pidgin")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – Pennsylvania German")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – Palatine German")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – pali")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – polsk")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – Piedmontese")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – Pontic")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – pashto")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – portugisisk")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – quechua")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – rætoromansk")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – rundi")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – rumænsk")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – arumænsk")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – russisk")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – Rusyn")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – kinyarwanda")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – sanskrit")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – jakutisk")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – santali")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – sardinsk")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – siciliansk")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – skotsk")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – sindhi")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – nordsamisk")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – sango")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – serbokroatisk")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – tachelhit")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – shan")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – singalesisk")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – slovakisk")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – slovensk")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – samoansk")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – enaresamisk")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – shona")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – somali")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – albansk")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – serbisk")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – sranan tongo")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – swati")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – sydsotho")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – Saterland Frisian")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – sundanesisk")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – svensk")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – swahili")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – schlesisk")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – tamil")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – Tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – telugu")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – tetum")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – tadsjikisk")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – thai")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – tigrinya")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – tigre")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – turkmensk")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – tagalog")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – Talysh")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – tswana")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – tongansk")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – tok pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – tyrkisk")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – taroko")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – tsonga")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – tatarisk")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – tumbuka")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – twi")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – tahitiansk")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – tuvinian")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – udmurt")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – uygurisk")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – ukrainsk")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – urdu")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – usbekisk")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – venda")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – venetiansk")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – Veps")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – vietnamesisk")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – West Flemish")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – volapyk")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – vallonsk")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – waray")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – wolof")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – wu-kinesisk")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – kalmyk")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – xhosa")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – Mingrelian")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – jiddisch")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – yoruba")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – zhuang")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – Zeelandic")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – tamazight")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 – kinesisk")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – Literary Chinese")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – min-kinesisk")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – kantonesisk")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – zulu")


[Redigér links](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Redigér sproglinks")
  * Denne side blev senest ændret den 14. juli 2019 kl. 19:17.
  * Tekst er tilgængelig under [Creative Commons Navngivelse/Del på samme vilkår 4.0](https://creativecommons.org/licenses/by-sa/4.0/deed.da); yderligere betingelser kan være gældende. Se [brugsbetingelserne](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use/da) for flere oplysninger.


  * [Privatlivspolitik](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Om Wikipedia](https://da.wikipedia.org/wiki/Wikipedia:Om)
  * [Forbehold](https://da.wikipedia.org/wiki/Wikipedia:Generelle_forbehold)
  * [Adfærdskodeks](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Udviklere](https://developer.wikimedia.org)
  * [Statistik](https://stats.wikimedia.org/#/da.wikipedia.org)
  * [Cookie-erklæring](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Mobilvisning](https://da.m.wikipedia.org/w/index.php?title=Forside&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://da.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://da.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Søg
Søg
Forside
[](https://da.wikipedia.org/wiki/Forside) [](https://da.wikipedia.org/wiki/Forside) [](https://da.wikipedia.org/wiki/Forside) [](https://da.wikipedia.org/wiki/Forside) [](https://da.wikipedia.org/wiki/Forside) [](https://da.wikipedia.org/wiki/Forside) [](https://da.wikipedia.org/wiki/Forside) [](https://da.wikipedia.org/wiki/Forside)
353 sprog [Tilføj emne ](https://da.wikipedia.org/wiki/Forside)
