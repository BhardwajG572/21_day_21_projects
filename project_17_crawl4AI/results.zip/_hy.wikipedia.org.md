[Jump to content](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB#bodyContent)
Հիմնական ընտրացանկ
Հիմնական ընտրացանկ
տեղափոխել կողագոտի թաքցնել
Նավարկում 
  * [Գլխավոր էջ](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
  * [Կատեգորիաներ](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%88%D6%80%D5%B8%D5%B6%D5%B8%D6%82%D5%B4_%D5%A8%D5%BD%D5%BF_%D5%AF%D5%A1%D5%BF%D5%A5%D5%A3%D5%B8%D6%80%D5%AB%D5%A1%D5%B6%D5%A5%D6%80%D5%AB)
  * [Պատահական հոդված](https://hy.wikipedia.org/wiki/%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:%D5%8A%D5%A1%D5%BF%D5%A1%D5%B0%D5%A1%D5%AF%D5%A1%D5%B6%D5%A7%D5%BB "Այցելեք պատահական էջ \[x\]")
  * [Նոր էջեր](https://hy.wikipedia.org/wiki/%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:%D5%86%D5%B8%D6%80%D5%A7%D5%BB%D5%A5%D6%80%D5%A8)
  * [Ընթացիկ իրադարձություններ](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D4%B8%D5%B6%D5%A9%D5%A1%D6%81%D5%AB%D5%AF_%D5%AB%D6%80%D5%A1%D5%A4%D5%A1%D6%80%D5%B1%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6%D5%B6%D5%A5%D6%80 "Տեղեկություններ ընթացիկ իրադարձությունների մասին")


Մասնակցել 
  * [Էությունը](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D4%B7%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6%D5%A8)
  * [Խորհրդարան](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D4%BD%D5%B8%D6%80%D5%B0%D6%80%D5%A4%D5%A1%D6%80%D5%A1%D5%B6)
  * [Վերջին փոփոխություններ](https://hy.wikipedia.org/wiki/%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:%D5%8E%D5%A5%D6%80%D5%BB%D5%AB%D5%B6%D6%83%D5%B8%D6%83%D5%B8%D5%AD%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6%D5%B6%D5%A5%D6%80%D5%A8 "Վիքիում կատարված վերջին փոփոխությունների ցանկը \[r\]")
  * [Օգնություն](https://hy.wikipedia.org/wiki/%D5%95%D5%A3%D5%B6%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6:%D4%B3%D5%AC%D5%AD%D5%A1%D6%81%D5%A1%D5%B6%D5%AF "Վիքիպեդիա նախագծի ուղեցույց")
  * [Սպասարկող էջեր](https://hy.wikipedia.org/wiki/%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2%D5%A7%D5%BB%D5%A5%D6%80%D5%A8)


[ ![](https://hy.wikipedia.org/static/images/icons/wikipedia.png) ![Վիքիպեդիա](https://hy.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-hy.svg) ![](https://hy.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-hy.svg) ](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
[Որոնել ](https://hy.wikipedia.org/wiki/%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:%D5%88%D6%80%D5%B8%D5%B6%D5%A5%D5%AC "Որոնել Վիքիպեդիա կայքում \[f\]")
Որոնել
Արտաքին տեսք
  * [Նվիրաբերել](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=hy.wikipedia.org&uselang=hy)
  * [Ստեղծել հաշիվ](https://hy.wikipedia.org/w/index.php?title=%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:CreateAccount&returnto=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80+%D5%A7%D5%BB "Խորհուրդ է տրվում ստեղծել մասնակցային հաշիվ և մուտք գործել համակարգ, սակայն դա անելը պարտադիր չէ։")
  * [Մտնել](https://hy.wikipedia.org/w/index.php?title=%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:%D5%84%D5%A1%D5%BD%D5%B6%D5%A1%D5%AF%D6%81%D5%AB%D5%B4%D5%B8%D6%82%D5%BF%D6%84&returnto=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80+%D5%A7%D5%BB "Կոչ ենք անում մտնել համակարգ, սակայն դա պարտադիր չէ \[o\]")


Անձնական գործիքներ
  * [Նվիրաբերել](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=hy.wikipedia.org&uselang=hy)
  * [Ստեղծել հաշիվ](https://hy.wikipedia.org/w/index.php?title=%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:CreateAccount&returnto=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80+%D5%A7%D5%BB "Խորհուրդ է տրվում ստեղծել մասնակցային հաշիվ և մուտք գործել համակարգ, սակայն դա անելը պարտադիր չէ։")
  * [Մտնել](https://hy.wikipedia.org/w/index.php?title=%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:%D5%84%D5%A1%D5%BD%D5%B6%D5%A1%D5%AF%D6%81%D5%AB%D5%B4%D5%B8%D6%82%D5%BF%D6%84&returnto=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80+%D5%A7%D5%BB "Կոչ ենք անում մտնել համակարգ, սակայն դա պարտադիր չէ \[o\]")


# Գլխավոր էջ
  * [Գլխավոր էջ](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Դիտել հոդվածը \[c\]")
  * [Քննարկում](https://hy.wikipedia.org/wiki/%D5%94%D5%B6%D5%B6%D5%A1%D6%80%D5%AF%D5%B8%D6%82%D5%B4:%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Քննարկումներ այս էջի բովանդակության մասին \[t\]")


հայերեն
  * [Կարդալ](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
  * [Դիտել վիքիկոդը](https://hy.wikipedia.org/w/index.php?title=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&action=edit "Այս էջը պաշտպանված է։ Դուք կարող եք դիտել նրա ելատեքստը։ \[e\]")
  * [Դիտել պատմությունը](https://hy.wikipedia.org/w/index.php?title=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&action=history "Այս էջի խմբագրումների պատմությունը \[h\]")


Գործիքներ
Գործիքներ
տեղափոխել կողագոտի թաքցնել
Գործողություններ 
  * [Կարդալ](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
  * [Դիտել վիքիկոդը](https://hy.wikipedia.org/w/index.php?title=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&action=edit)
  * [Դիտել պատմությունը](https://hy.wikipedia.org/w/index.php?title=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&action=history)


Ընդհանուր 
  * [Այստեղ հղվող էջերը](https://hy.wikipedia.org/wiki/%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:%D4%B1%D5%B5%D5%BD%D5%BF%D5%A5%D5%B2%D5%B0%D5%B2%D5%BE%D5%B8%D5%B2%D5%A7%D5%BB%D5%A5%D6%80%D5%A8/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Այս էջին հղվող բոլոր վիքի էջերի ցանկը \[j\]")
  * [Կապված փոփոխություններ](https://hy.wikipedia.org/wiki/%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:%D4%BF%D5%A1%D5%BA%D5%BE%D5%A1%D5%AE%D5%A7%D5%BB%D5%A5%D6%80%D5%AB%D6%83%D5%B8%D6%83%D5%B8%D5%AD%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6%D5%B6%D5%A5%D6%80%D5%A8/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Այս էջից կապված էջերի վերջին փոփոխությունները \[k\]")
  * [Մշտական հղում](https://hy.wikipedia.org/w/index.php?title=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&oldid=5662114 "Էջի այս տարբերակի մշտական հղում")
  * [Էջի վիճակագրություն](https://hy.wikipedia.org/w/index.php?title=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&action=info "Վիճակագրական տվյալներ էջի մասին")
  * [Մեջբերել այս էջը](https://hy.wikipedia.org/w/index.php?title=%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:CiteThisPage&page=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&id=5662114&wpFormIdentifier=titleform "Տեղեկատվություն, թե ինչպես պետք է մեջբերել այս էջը")
  * [Ստանալ կարճ URL հասցե](https://hy.wikipedia.org/w/index.php?title=%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:UrlShortener&url=https%3A%2F%2Fhy.wikipedia.org%2Fwiki%2F%25D4%25B3%25D5%25AC%25D5%25AD%25D5%25A1%25D5%25BE%25D5%25B8%25D6%2580_%25D5%25A7%25D5%25BB)
  * [Download QR code](https://hy.wikipedia.org/w/index.php?title=%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:QrCode&url=https%3A%2F%2Fhy.wikipedia.org%2Fwiki%2F%25D4%25B3%25D5%25AC%25D5%25AD%25D5%25A1%25D5%25BE%25D5%25B8%25D6%2580_%25D5%25A7%25D5%25BB)


Տպել/արտահանել 
  * [Ստեղծել գիրք](https://hy.wikipedia.org/w/index.php?title=%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:Book&bookcmd=book_creator&referer=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80+%D5%A7%D5%BB)
  * [Ներբեռնել որպես PDF](https://hy.wikipedia.org/w/index.php?title=%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:DownloadAsPdf&page=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&action=show-download-screen)
  * [Տպելու տարբերակ](https://hy.wikipedia.org/w/index.php?title=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&printable=yes "Այս էջի տպելու տարբերակ \[p\]")


Այլ նախագծերում 
  * [Վիքիպահեստ](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [ՄեդիաՎիքի](https://www.mediawiki.org/wiki/MediaWiki)
  * [Մետա-վիքի](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Բազմալեզու Վիքիդարան](https://wikisource.org/wiki/Main_Page)
  * [Վիքիցեղեր](https://species.wikimedia.org/wiki/Main_Page)
  * [Վիքիգրքեր](https://hy.wikibooks.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
  * [Վիքիտվյալներ](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Վիքիքաղվածք](https://hy.wikiquote.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
  * [Վիքիդարան](https://hy.wikisource.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
  * [Վիքիբառարան](https://hy.wiktionary.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
  * [Վիքիտվյալների տարր](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Հղում Վիքիտվյալի համապատասխան էջին \[g\]")


Արտաքին տեսք
տեղափոխել կողագոտի թաքցնել
Վիքիպեդիայից՝ ազատ հանրագիտարանից
Ազատ հանրագիտարան, որը կարող է խմբագրել յուրաքանչյուր ոք։
[Բջջային տարբերակ](https://hy.m.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
  * [Գրանցվի՛ր](https://hy.wikipedia.org/wiki/%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:CreateAccount "Սպասարկող:CreateAccount")
  * [Հինգ սյուներ](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%80%D5%AB%D5%B6%D5%A3_%D5%BD%D5%B5%D5%B8%D6%82%D5%B6%D5%A5%D6%80 "Վիքիպեդիա:Հինգ սյուներ")
  * [Խմբագրման ուղեցույց](https://hy.wikipedia.org/wiki/%D5%95%D5%A3%D5%B6%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6:%D4%B4%D5%A1%D5%BD%D5%A8%D5%B6%D5%A9%D5%A1%D6%81 "Օգնություն:Դասընթաց")
  * [Օգնություն](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%95%D5%A3%D5%B6%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6 "Վիքիպեդիա:Օգնություն")
  * [Հա՛րց տվեք](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%80%D5%A1%D6%80%D6%81%D5%A5%D6%80 "Վիքիպեդիա:Հարցեր")
  * [Ստեղծի՛ր հոդված](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%80%D5%B8%D5%A4%D5%BE%D5%A1%D5%AE%D5%AB_%D5%BD%D5%BF%D5%A5%D5%B2%D5%AE%D5%B8%D6%82%D5%B4 "Վիքիպեդիա:Հոդվածի ստեղծում")


[< «Շաբաթվա հոդված» նախագիծ](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%87%D5%A1%D5%A2%D5%A1%D5%A9%D5%BE%D5%A1_%D5%B0%D5%B8%D5%A4%D5%BE%D5%A1%D5%AE "Վիքիպեդիա:Շաբաթվա հոդված")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Rowlandson%2C_Thomas_-_Selling_a_Wife_-_1812-14.jpg/250px-Rowlandson%2C_Thomas_-_Selling_a_Wife_-_1812-14.jpg)](https://hy.wikipedia.org/wiki/%D5%8A%D5%A1%D5%BF%D5%AF%D5%A5%D6%80:Rowlandson,_Thomas_-_Selling_a_Wife_-_1812-14.jpg)
**Կանանց աճուրդային վաճառք** ([անգլ.](https://hy.wikipedia.org/wiki/%D4%B1%D5%B6%D5%A3%D5%AC%D5%A5%D6%80%D5%A5%D5%B6 "Անգլերեն")՝ Wife selling), այն պրակտիկան է, երբ ամուսինը վաճառում է իր կնոջը, և այն կարող է ներառել նաև կնոջ վաճառքը ամուսնությունից դուրս գտնվող որևէ 3-րդ անձի կողմից։ Կնոջ վաճառքն ունեցել է բազմաթիվ նպատակներ այս պրակտիկայի պատմության ընթացքում, և «կանանց վաճառք» տերմինը բոլոր աղբյուրներում նույնիմաստ սահմանված չէ։ 
Երբեմն կինը վաճառվում էր ամուսնու կողմից նոր ամուսնու՝ որպես ամուսնալուծության միջոց, այս դեպքերում երբեմն կնոջը թույլատրվում էր ընտրել իր ապագա ամուսնուն, եթե ընտրությունն արվում էր որոշակի ժամանակահատվածի ընթացքում, հատկապես երբ կինը երիտասարդ էր և գրավիչ։ Որոշ հասարակություններում կինը կարող էր ազատվել ամուսնությունից՝ վճարելով դրա դիմաց, կամ ամուսիններից որևէ մեկը կարող էր նախաձեռնել նման ձևով ամուսնալուծություն։ Կնոջ վաճառքի մեկ այլ պատճառ կարող էր լինել ամուսնու ֆինանսական պարտավորությունների՝ ընտանիքի պահպանման կամ ամուսնությունից առաջ ունեցած պարտքերի նվազեցումը։ Երբեմն հարկերը մուծվում էին կնոջ և երեխաների վաճառքի միջոցով՝ վաճառքից ստացված գումարն օգտագործելով որպես հարկային վճար, հատկապես այն ժամանակ, երբ հարկերն այնքան բարձր էին, որ անհնար էր գոյատևել։ Սովը և սովամահության վտանգը նույնպես կարող էին պատճառ դառնալ վաճառքի։ Խաղատնային պարտքերը երբեմն մարվում էին ազատ կամ [ստրուկ](https://hy.wikipedia.org/wiki/%D5%8D%D5%BF%D6%80%D5%AF%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6 "Ստրկություն") կնոջ վաճառքով։ Որոշ հասարակություններում կնոջը չէր տրվում ամուսին վաճառելու հարցում այն իրավունքները, որոնք վերապահված էին տղամարդուն, և երբեմն կնոջը ամբողջությամբ մերժվում էին որևէ իրավունքներ եթե ամուսինը որոշում էր նրան վաճառել, նույնիսկ՝ մերժման իրավունքը։ Ամուսնալուծությունը, որը կատարվել էր փոխադարձ համաձայնությամբ, սակայն կինը եղել էր ոչ բարեխիղճ, երբեմն հանգեցնում էր ամուսնալուծության չեղյալ հայտարարմանը, ինչը թույլ էր տալիս այնուհետև վաճառել նրան։ Ամուսինը կարող էր վաճառել իր կնոջը և այնուհետև դիմել դատարան՝ պահանջելով փոխհատուցում նոր տղամարդու հետ կնոջ ունեցած դավաճանության համար։ Ըստ որոշ օրենքների՝ ամուսնական դավաճանություն դիտվում էր որպես կնոջը հարճության մեջ վաճառելու օրինական հիմք։ 
Ազատ կինն իր հերթին կարող էր վաճառվել [ստրկության](https://hy.wikipedia.org/wiki/%D5%8D%D5%BF%D6%80%D5%AF%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6 "Ստրկություն")՝ օրինակ, եթե նա ամուսնացել էր [ծառայի հետ](https://hy.wikipedia.org/wiki/%D5%83%D5%B8%D6%80%D5%BF%D5%A1%D5%BF%D5%AB%D6%80%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6 "Ճորտատիրություն") կամ եթե նրա ամուսինը սպանվել էր։ Երբեմն ստրկատերը կարող էր վաճառել ստրկության մեջ գտնվող կնոջը։ Ստրկացված ընտանիքները հաճախ բաժանվում էին. կանայք, ամուսինները և երեխաները վաճառվում էին տարբեր գնորդների՝ հաճախ առանց երբևէ միմյանց կրկին տեսնելու։ Կնոջ վաճառքի սպառնալիքը երբեմն օգտագործվում էր ստրկության մեջ գտնվող ամուսնուն տիրոջ ենթակայության մեջ պահելու համար։ Պատերազմի ժամանակ կողմերից մեկը կարող էր (հնարավոր է՝ կեղծ կերպով) մեղադրել մյուսին կնոջ վաճառքի մեջ՝ որպես լրտեսության միջոց։ Կինը կարող էր դիտվել նաև որպես եկամուտ, և նրան կարող էր բռնագրավել տեղական իշխանությունը, եթե ամուսինը մահացել էր առանց ժառանգ թողնելու։ Կնոջ վաճառքը երբեմն նկարագրվում էր որպես կնոջ ծառայությունների վաճառք. այն կարող էր լինել որոշակի տարիների կտրվածքով՝ որից հետո նախատեսված էր ազատում։ Եթե վաճառքը ժամանակավոր էր, որոշ դեպքերում կնոջ վաճառքը համարվում էր ժամանակավոր միայն այն իմաստով, որ վաճառված և կրկին ամուսնացած կինը մահվանից հետո վերամիավորվելու էր իր առաջին ամուսնու հետ։ 
Իրավական և գործնական սահմանափակումներ գոյություն ունեին, և կային քննադատություններ։ Որոշ հասարակություններ հատուկ արգելում էին կնոջ վաճառքը՝ անգամ մահապատիժ․․․ [**Ավելին****⇒**](https://hy.wikipedia.org/wiki/%D4%BF%D5%A1%D5%B6%D5%A1%D5%B6%D6%81_%D5%A1%D5%B3%D5%B8%D6%82%D6%80%D5%A4 "Կանանց աճուրդ")
**Շարունակվող իրադարձություններ** ՝ [Իսրայելա-պաղեստինյան պատերազմ (2023-ներկա)](https://hy.wikipedia.org/wiki/%D4%BB%D5%BD%D6%80%D5%A1%D5%B5%D5%A5%D5%AC%D5%A1-%D5%BA%D5%A1%D5%B2%D5%A5%D5%BD%D5%BF%D5%AB%D5%B6%D5%B5%D5%A1%D5%B6_%D5%BA%D5%A1%D5%BF%D5%A5%D6%80%D5%A1%D5%A6%D5%B4_\(2023-%D5%B6%D5%A5%D6%80%D5%AF%D5%A1\) "Իսրայելա-պաղեստինյան պատերազմ \(2023-ներկա\)") • [Ռուսաստանի ներխուժում Ուկրաինա](https://hy.wikipedia.org/wiki/%D5%8C%D5%B8%D6%82%D5%BD%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6%D5%AB_%D5%B6%D5%A5%D6%80%D5%AD%D5%B8%D6%82%D5%AA%D5%B8%D6%82%D5%B4_%D5%88%D6%82%D5%AF%D6%80%D5%A1%D5%AB%D5%B6%D5%A1 "Ռուսաստանի ներխուժում Ուկրաինա")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Rt._Hon._Prime_Minister_Sushila_Karki_Official_Portrait.jpg/250px-Rt._Hon._Prime_Minister_Sushila_Karki_Official_Portrait.jpg)](https://hy.wikipedia.org/wiki/%D5%8D%D5%B8%D6%82%D5%B7%D5%AB%D5%AC%D5%A1_%D4%BF%D5%A1%D6%80%D5%AF%D5%AB "Սուշիլա Կարկի") [![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/9-10_September_2025_Russian_drone_incursion_into_Poland.jpg/250px-9-10_September_2025_Russian_drone_incursion_into_Poland.jpg)](https://hy.wikipedia.org/wiki/%D5%8C%D5%B8%D6%82%D5%BD%D5%A1%D5%AF%D5%A1%D5%B6_%D5%A1%D5%B6%D6%85%D5%A4%D5%A1%D5%B9%D5%B8%D6%82_%D5%A9%D5%BC%D5%B9%D5%B8%D5%B2_%D5%BD%D5%A1%D6%80%D6%84%D5%A5%D6%80%D5%AB_%D5%B6%D5%A5%D6%80%D5%AD%D5%B8%D6%82%D5%AA%D5%B8%D6%82%D5%B4%D5%A8_%D4%BC%D5%A5%D5%B0%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6 "Ռուսական անօդաչու թռչող սարքերի ներխուժումը Լեհաստան")
  * [սեպտեմբերի 22](https://hy.wikipedia.org/wiki/%D5%8D%D5%A5%D5%BA%D5%BF%D5%A5%D5%B4%D5%A2%D5%A5%D6%80%D5%AB_22 "Սեպտեմբերի 22")-ին [Ուսման Դեմբելեն](https://hy.wikipedia.org/wiki/%D5%88%D6%82%D5%BD%D5%B4%D5%A1%D5%B6_%D4%B4%D5%A5%D5%B4%D5%A2%D5%A5%D5%AC%D5%A5 "Ուսման Դեմբելե") և [Այտանա Բոնմատին](https://hy.wikipedia.org/wiki/%D4%B1%D5%B5%D5%BF%D5%A1%D5%B6%D5%A1_%D4%B2%D5%B8%D5%B6%D5%B4%D5%A1%D5%BF%D5%AB "Այտանա Բոնմատի"), որպես տարվա լավագույն ֆուտբոլիստներ, ստացել են [France Football](https://hy.wikipedia.org/wiki/France_Football "France Football") ամսագրի _[«Ոսկե գնդակ» մրցանակը](https://hy.wikipedia.org/wiki/%D5%88%D5%BD%D5%AF%D5%A5_%D5%A3%D5%B6%D5%A4%D5%A1%D5%AF_2025 "Ոսկե գնդակ 2025")_ ։
  * [սեպտեմբերի 19](https://hy.wikipedia.org/wiki/%D5%8D%D5%A5%D5%BA%D5%BF%D5%A5%D5%B4%D5%A2%D5%A5%D6%80%D5%AB_19 "Սեպտեմբերի 19")-ին [Զագրեբում](https://hy.wikipedia.org/wiki/%D4%B6%D5%A1%D5%A3%D6%80%D5%A5%D5%A2 "Զագրեբ") կայացած [ըմբշամարտի աշխարհի առաջնությունում](https://hy.wikipedia.org/wiki/%D4%B8%D5%B4%D5%A2%D5%B7%D5%A1%D5%B4%D5%A1%D6%80%D5%BF%D5%AB_%D5%A1%D5%B7%D5%AD%D5%A1%D6%80%D5%B0%D5%AB_%D5%A1%D5%BC%D5%A1%D5%BB%D5%B6%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6_2025 "Ըմբշամարտի աշխարհի առաջնություն 2025") _[Մալխաս Ամոյանը](https://hy.wikipedia.org/wiki/%D5%84%D5%A1%D5%AC%D5%AD%D5%A1%D5%BD_%D4%B1%D5%B4%D5%B8%D5%B5%D5%A1%D5%B6 "Մալխաս Ամոյան")_ դարձել է աշխարհի կրկնակի չեմպիոն։
  * [սեպտեմբերի 14](https://hy.wikipedia.org/wiki/%D5%8D%D5%A5%D5%BA%D5%BF%D5%A5%D5%B4%D5%A2%D5%A5%D6%80%D5%AB_14 "Սեպտեմբերի 14")-ին [Փարիզում](https://hy.wikipedia.org/wiki/%D5%93%D5%A1%D6%80%D5%AB%D5%A6 "Փարիզ") կայացած World challenge cup մրցաշարում _[Համլետ Մանուկյանը](https://hy.wikipedia.org/wiki/%D5%80%D5%A1%D5%B4%D5%AC%D5%A5%D5%BF_%D5%84%D5%A1%D5%B6%D5%B8%D6%82%D5%AF%D5%B5%D5%A1%D5%B6 "Համլետ Մանուկյան")_ նժույգ թափեր մարզագործիքի վրա կատարել է նոր տարր, որը պաշտոնապես կանվանվի «Մանուկյան»։
  * [սեպտեմբերի 12](https://hy.wikipedia.org/wiki/%D5%8D%D5%A5%D5%BA%D5%BF%D5%A5%D5%B4%D5%A2%D5%A5%D6%80%D5%AB_12 "Սեպտեմբերի 12")-ին Նեպալի պատմության մեջ առաջին անգամ վարչապետ է դարձել կին՝ **[Սուշիլա Կարկին](https://hy.wikipedia.org/wiki/%D5%8D%D5%B8%D6%82%D5%B7%D5%AB%D5%AC%D5%A1_%D4%BF%D5%A1%D6%80%D5%AF%D5%AB "Սուշիլա Կարկի")** , որին [հակակառավարական բողոքի ցույցերի](https://hy.wikipedia.org/wiki/%D5%86%D5%A5%D5%BA%D5%A1%D5%AC%D5%AB_%D5%B0%D5%A1%D5%AF%D5%A1%D5%AF%D5%A1%D5%BC%D5%A1%D5%BE%D5%A1%D6%80%D5%A1%D5%AF%D5%A1%D5%B6_%D5%A2%D5%B8%D5%B2%D5%B8%D6%84%D5%AB_%D6%81%D5%B8%D6%82%D5%B5%D6%81%D5%A5%D6%80_\(2025\) "Նեպալի հակակառավարական բողոքի ցույցեր \(2025\)") մասնակիցներն ընտրել են [սոցիալական ցանցում](https://hy.wikipedia.org/wiki/Discord "Discord") քվեարկելու միջոցով։
  * [սեպտեմբերի 11](https://hy.wikipedia.org/wiki/%D5%8D%D5%A5%D5%BA%D5%BF%D5%A5%D5%B4%D5%A2%D5%A5%D6%80%D5%AB_11 "Սեպտեմբերի 11")-ին [Ալբանիայում](https://hy.wikipedia.org/wiki/%D4%B1%D5%AC%D5%A2%D5%A1%D5%B6%D5%AB%D5%A1 "Ալբանիա") աշխարհում առաջին անգամ [արհեստական բանականության](https://hy.wikipedia.org/wiki/%D4%B1%D6%80%D5%B0%D5%A5%D5%BD%D5%BF%D5%A1%D5%AF%D5%A1%D5%B6_%D5%A2%D5%A1%D5%B6%D5%A1%D5%AF%D5%A1%D5%B6%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6 "Արհեստական բանականություն") _[համակարգը](https://hy.wikipedia.org/wiki/%D4%B4%D5%AB%D5%A5%D5%AC%D5%A1 "Դիելա")_ պաշտոնապես նշանակվել է նախարար։
  * [սեպտեմբերի 10](https://hy.wikipedia.org/wiki/%D5%8D%D5%A5%D5%BA%D5%BF%D5%A5%D5%B4%D5%A2%D5%A5%D6%80%D5%AB_10 "Սեպտեմբերի 10")-ի գիշերը [ռուսական](https://hy.wikipedia.org/wiki/%D5%8C%D5%B8%D6%82%D5%BD%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6 "Ռուսաստան") [անօդաչու թռչող սարքերը](https://hy.wikipedia.org/wiki/%D4%B1%D5%B6%D6%85%D5%A4%D5%A1%D5%B9%D5%B8%D6%82_%D5%A9%D5%BC%D5%B9%D5%B8%D5%B2_%D5%BD%D5%A1%D6%80%D6%84 "Անօդաչու թռչող սարք") զանգվածաբար **[ներխուժել են](https://hy.wikipedia.org/wiki/%D5%8C%D5%B8%D6%82%D5%BD%D5%A1%D5%AF%D5%A1%D5%B6_%D5%A1%D5%B6%D6%85%D5%A4%D5%A1%D5%B9%D5%B8%D6%82_%D5%A9%D5%BC%D5%B9%D5%B8%D5%B2_%D5%BD%D5%A1%D6%80%D6%84%D5%A5%D6%80%D5%AB_%D5%B6%D5%A5%D6%80%D5%AD%D5%B8%D6%82%D5%AA%D5%B8%D6%82%D5%B4%D5%A8_%D4%BC%D5%A5%D5%B0%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6 "Ռուսական անօդաչու թռչող սարքերի ներխուժումը Լեհաստան")** _(լուսանկարում)_ [Լեհաստանի](https://hy.wikipedia.org/wiki/%D4%BC%D5%A5%D5%B0%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6 "Լեհաստան") օդային տարածք՝ անցնելով [Ուկրաինայի](https://hy.wikipedia.org/wiki/%D5%88%D6%82%D5%AF%D6%80%D5%A1%D5%AB%D5%B6%D5%A1 "Ուկրաինա") և [Բելառուսի](https://hy.wikipedia.org/wiki/%D4%B2%D5%A5%D5%AC%D5%A1%D5%BC%D5%B8%D6%82%D5%BD "Բելառուս") տարածքներով:
  * [սեպտեմբերի 10](https://hy.wikipedia.org/wiki/%D5%8D%D5%A5%D5%BA%D5%BF%D5%A5%D5%B4%D5%A2%D5%A5%D6%80%D5%AB_10 "Սեպտեմբերի 10")-ին [Յուտայի](https://hy.wikipedia.org/wiki/%D5%85%D5%B8%D6%82%D5%BF%D5%A1 "Յուտա") Վելիի համալսարանում «Ամերիկյան վերադարձ» շրջագայության ժամանակ, ելույթի պահին _[սպանել են](https://hy.wikipedia.org/wiki/%D5%89%D5%A1%D6%80%D5%AC%D5%AB_%D5%94%D5%A8%D6%80%D6%84%D5%AB_%D5%BD%D5%BA%D5%A1%D5%B6%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6 "Չարլի Քըրքի սպանություն")_ ամերիկացի քաղաքական ակտիվիստ [Չարլի Քըրքին](https://hy.wikipedia.org/wiki/%D5%89%D5%A1%D6%80%D5%AC%D5%AB_%D5%94%D5%A8%D6%80%D6%84 "Չարլի Քըրք")։
  * [սեպտեմբերի 10](https://hy.wikipedia.org/wiki/%D5%8D%D5%A5%D5%BA%D5%BF%D5%A5%D5%B4%D5%A2%D5%A5%D6%80%D5%AB_10 "Սեպտեմբերի 10")-ին վարչապետ Ֆրանսուա Բայրուի կառավարության առաջարկած խնայողության միջոցառումների դեմ [Ֆրանսիայում](https://hy.wikipedia.org/wiki/%D5%96%D6%80%D5%A1%D5%B6%D5%BD%D5%AB%D5%A1 "Ֆրանսիա") _[համընդհանուր գործադուլ է սկսել](https://hy.wikipedia.org/wiki/%D4%B1%D6%80%D5%A3%D5%A5%D5%AC%D5%A1%D6%83%D5%A1%D5%AF%D5%A5%D5%AC_%D5%A1%D5%B4%D5%A5%D5%B6_%D5%AB%D5%B6%D5%B9 "Արգելափակել ամեն ինչ")_ ։
  * [սեպտեմբերի 8](https://hy.wikipedia.org/wiki/%D5%8D%D5%A5%D5%BA%D5%BF%D5%A5%D5%B4%D5%A2%D5%A5%D6%80%D5%AB_8 "Սեպտեմբերի 8")-ին [Նեպալում](https://hy.wikipedia.org/wiki/%D5%86%D5%A5%D5%BA%D5%A1%D5%AC "Նեպալ") սկսված _[հակակառավարական բողոքի ցույցերը](https://hy.wikipedia.org/wiki/%D5%86%D5%A5%D5%BA%D5%A1%D5%AC%D5%AB_%D5%B0%D5%A1%D5%AF%D5%A1%D5%AF%D5%A1%D5%BC%D5%A1%D5%BE%D5%A1%D6%80%D5%A1%D5%AF%D5%A1%D5%B6_%D5%A2%D5%B8%D5%B2%D5%B8%D6%84%D5%AB_%D6%81%D5%B8%D6%82%D5%B5%D6%81%D5%A5%D6%80_\(2025\) "Նեպալի հակակառավարական բողոքի ցույցեր \(2025\)")_ , որոնց հետևանքով զոհվել է 20 մարդ, հանգեցրել են վարչապետ Խադգա Պրասադ Շարմա Օլիի և նախագահ Ռամ Չանդրա Պաուդելի հրաժարականներին։
  * [օգոստոսի 31](https://hy.wikipedia.org/wiki/%D5%95%D5%A3%D5%B8%D5%BD%D5%BF%D5%B8%D5%BD%D5%AB_31 "Օգոստոսի 31")-ին [Սուդանի](https://hy.wikipedia.org/wiki/%D5%8D%D5%B8%D6%82%D5%A4%D5%A1%D5%B6 "Սուդան") Կենտրոնական Դարֆուր նահանգի _[Տարասին գյուղում տեղի ունեցած սողանքի](https://hy.wikipedia.org/wiki/%D5%8F%D5%A1%D6%80%D5%A1%D5%BD%D5%AB%D5%B6%D5%AB_%D5%BD%D5%B8%D5%B2%D5%A1%D5%B6%D6%84_\(2025\) "Տարասինի սողանք \(2025\)")_ հետևանքով զոհվել է առնվազն 370 բնակիչ։


[Վերջերս մահացածներ](https://hy.wikipedia.org/wiki/%D4%BF%D5%A1%D5%BF%D5%A5%D5%A3%D5%B8%D6%80%D5%AB%D5%A1:2025_%D5%B4%D5%A1%D5%B0%D5%A5%D6%80 "Կատեգորիա:2025 մահեր")՝ [Տիգրան Քեոսայան](https://hy.wikipedia.org/wiki/%D5%8F%D5%AB%D5%A3%D6%80%D5%A1%D5%B6_%D5%94%D5%A5%D5%B8%D5%BD%D5%A1%D5%B5%D5%A1%D5%B6 "Տիգրան Քեոսայան") • [Կլաուդիա Կարդինալե](https://hy.wikipedia.org/wiki/%D4%BF%D5%AC%D5%A1%D5%B8%D6%82%D5%A4%D5%AB%D5%A1_%D4%BF%D5%A1%D6%80%D5%A4%D5%AB%D5%B6%D5%A1%D5%AC%D5%A5 "Կլաուդիա Կարդինալե") • [Ռոբերտ Ռեդֆորդ](https://hy.wikipedia.org/wiki/%D5%8C%D5%B8%D5%A2%D5%A5%D6%80%D5%BF_%D5%8C%D5%A5%D5%A4%D6%86%D5%B8%D6%80%D5%A4 "Ռոբերտ Ռեդֆորդ") • [Ռուբեն Մանուկյան](https://hy.wikipedia.org/wiki/%D5%8C%D5%B8%D6%82%D5%A2%D5%A5%D5%B6_%D5%84%D5%A1%D5%B6%D5%B8%D6%82%D5%AF%D5%B5%D5%A1%D5%B6_\(%D5%B6%D5%AF%D5%A1%D6%80%D5%AB%D5%B9\) "Ռուբեն Մանուկյան \(նկարիչ\)") • [Ռոպեր Հատտեճյան](https://hy.wikipedia.org/wiki/%D5%8C%D5%B8%D5%BA%D5%A5%D6%80_%D5%80%D5%A1%D5%BF%D5%BF%D5%A5%D5%B3%D5%B5%D5%A1%D5%B6 "Ռոպեր Հատտեճյան")
[Հաջորդ թողարկում](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%86%D5%B8%D6%80%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6%D5%B6%D5%A5%D6%80/%D5%80%D5%A1%D5%BB%D5%B8%D6%80%D5%A4_%D5%A9%D5%B8%D5%B2%D5%A1%D6%80%D5%AF%D5%B4%D5%A1%D5%B6_%D5%BA%D5%A1%D5%BF%D6%80%D5%A1%D5%BD%D5%BF%D5%B8%D6%82%D5%B4 "Վիքիպեդիա:Նորություններ/Հաջորդ թողարկման պատրաստում") | [Պահոց](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%86%D5%B8%D6%80%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6%D5%B6%D5%A5%D6%80/%D5%8A%D5%A1%D5%B0%D5%B8%D6%81 "Վիքիպեդիա:Նորություններ/Պահոց") | [Խմբագրել](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%86%D5%B8%D6%80%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6%D5%B6%D5%A5%D6%80 "Վիքիպեդիա:Նորություններ")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Rione_II_Trevi%2C_00187_Roma%2C_Italy_-_panoramio_%2888%29.jpg/250px-Rione_II_Trevi%2C_00187_Roma%2C_Italy_-_panoramio_%2888%29.jpg)](https://hy.wikipedia.org/wiki/%D5%8F%D6%80%D5%A1%D5%B5%D5%A1%D5%B6%D5%B8%D5%BD%D5%AB_%D5%BD%D5%B5%D5%B8%D6%82%D5%B6 "Տրայանոսի սյուն") [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/da/Vyommitra_%28Space_friend%29%2C_ISRO.jpg/250px-Vyommitra_%28Space_friend%29%2C_ISRO.jpg)](https://hy.wikipedia.org/wiki/%D5%8E%D5%B5%D5%B8%D5%B4%D5%B4%D5%AB%D5%BF%D6%80%D5%A1 "Վյոմմիտրա")
  * [․․․Տրայանոս](https://hy.wikipedia.org/wiki/%D5%8F%D6%80%D5%A1%D5%B5%D5%A1%D5%B6%D5%B8%D5%BD "Տրայանոս") կայսրն իր անվան **[սյան](https://hy.wikipedia.org/wiki/%D5%8F%D6%80%D5%A1%D5%B5%D5%A1%D5%B6%D5%B8%D5%BD%D5%AB_%D5%BD%D5%B5%D5%B8%D6%82%D5%B6 "Տրայանոսի սյուն")** _(լուսանկարում)_ վրա պատկերված է 58 անգամ։
  * ․․․74 տարեկանում էլ է հնարավոր [ֆուտբոլ](https://hy.wikipedia.org/wiki/%D5%96%D5%B8%D6%82%D5%BF%D5%A2%D5%B8%D5%AC "Ֆուտբոլ") _[խաղալ](https://hy.wikipedia.org/wiki/%D4%B7%D5%A6%D5%A5%D5%AC%D5%A4%D5%AB%D5%B6_%D4%B2%D5%A1%D5%B0%D5%A1%D5%A4%D5%A5%D6%80 "Էզելդին Բահադեր")_ պրոֆեսիոնալ թիմում և նույնիսկ գոլ խփել։
  * ․․․ _[այս բժիշկն](https://hy.wikipedia.org/wiki/%D4%BF%D5%A1%D6%80%D5%AC_%D5%8F%D5%A1%D5%B6%D6%81%D5%AC%D5%A5%D6%80 "Կարլ Տանցլեր")_ իր տանն է պահել սիրելի կնոջ դիակը՝ նրա հետ քնելով նույն անկողնում։
  * ․․․երկու [մարդահամարների](https://hy.wikipedia.org/wiki/%D5%84%D5%A1%D6%80%D5%A4%D5%A1%D5%B0%D5%A1%D5%B4%D5%A1%D6%80 "Մարդահամար") միջև ընկած ժամանակահատվածում [Կալինինգրադի մարզի](https://hy.wikipedia.org/wiki/%D4%BF%D5%A1%D5%AC%D5%AB%D5%B6%D5%AB%D5%B6%D5%A3%D6%80%D5%A1%D5%A4%D5%AB_%D5%B4%D5%A1%D6%80%D5%A6 "Կալինինգրադի մարզ") _[գյուղերից մեկի](https://hy.wikipedia.org/wiki/%D4%B1%D5%AC%D5%BF%D5%A1%D5%B5%D5%BD%D5%AF%D5%B8%D5%A5_\(%D5%A3%D5%B5%D5%B8%D6%82%D5%B2,_%D4%BF%D5%A1%D5%AC%D5%AB%D5%B6%D5%AB%D5%B6%D5%A3%D6%80%D5%A1%D5%A4%D5%AB_%D5%B4%D5%A1%D6%80%D5%A6\) "Ալտայսկոե \(գյուղ, Կալինինգրադի մարզ\)")_ բնակչությունը կրճատվել է ուղիղ երկու անգամ՝ երկուսից դառնալով մեկ։
  * ․․․հնարավոր է կատարել սովորական [աթոռից](https://hy.wikipedia.org/wiki/%D4%B1%D5%A9%D5%B8%D5%BC "Աթոռ") և [հելիումով](https://hy.wikipedia.org/wiki/%D5%80%D5%A5%D5%AC%D5%AB%D5%B8%D6%82%D5%B4 "Հելիում") լցված օդերևութաբանական 42 [փուչիկներից](https://hy.wikipedia.org/wiki/%D5%93%D5%B8%D6%82%D5%B9%D5%AB%D5%AF "Փուչիկ") պատրաստված ինքնաշեն [օդապարիկով](https://hy.wikipedia.org/wiki/%D5%95%D5%A4%D5%A1%D5%BA%D5%A1%D6%80%D5%AB%D5%AF "Օդապարիկ") 45-րոպեանոց _[թռիչք](https://hy.wikipedia.org/wiki/%D5%84%D5%A1%D6%80%D5%A3%D5%A1%D5%A3%D5%A5%D5%BF%D5%B6%D5%AB_%D5%A1%D5%A9%D5%B8%D5%BC%D5%B8%D5%BE_%D5%A9%D5%BC%D5%AB%D5%B9%D6%84 "Մարգագետնի աթոռով թռիչք")_ ։
  * [․․․հնդկական](https://hy.wikipedia.org/wiki/%D5%80%D5%B6%D5%A4%D5%AF%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6 "Հնդկաստան") [տիեզերանավի](https://hy.wikipedia.org/wiki/%D4%B3%D5%A1%D5%A3%D5%A1%D5%B6%D5%B5%D5%A1%D5%B6 "Գագանյան") առաջին օդաչուն և նրա հետագա անձնակազմերի անդամ պետք է լինի մարդանման **[այս ռոբոտը](https://hy.wikipedia.org/wiki/%D5%8E%D5%B5%D5%B8%D5%B4%D5%B4%D5%AB%D5%BF%D6%80%D5%A1 "Վյոմմիտրա")** _(լուսանկարում)_ ։

  

[Հաջորդ թողարկում](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D4%B3%D5%AB%D5%BF%D5%A5%D5%AB%D5%9E%D6%84_%D5%B8%D6%80/%D5%80%D5%A1%D5%BB%D5%B8%D6%80%D5%A4_%D5%A9%D5%B8%D5%B2%D5%A1%D6%80%D5%AF%D5%B4%D5%A1%D5%B6_%D5%BA%D5%A1%D5%BF%D6%80%D5%A1%D5%BD%D5%BF%D5%B8%D6%82%D5%B4 "Վիքիպեդիա:Գիտեի՞ք որ/Հաջորդ թողարկման պատրաստում") | [Արխիվ](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%86%D5%A1%D5%AD%D5%A1%D5%A3%D5%AB%D5%AE:%D4%B3%D5%AB%D5%BF%D5%A5%D5%AB%D5%9E%D6%84_%D5%B8%D6%80/%D4%B1%D6%80%D5%AD%D5%AB%D5%BE "Վիքիպեդիա:Նախագիծ:Գիտեի՞ք որ/Արխիվ") | [Խմբագրել](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D4%B3%D5%AB%D5%BF%D5%A5%D5%AB%D5%9E%D6%84_%D5%B8%D6%80 "Վիքիպեդիա:Գիտեի՞ք որ")
  

[Վիքիպեդիան](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1 "Վիքիպեդիա") առցանց, բազմալեզու, խմբակային հանրագիտարանային նախագիծ է, որն աշխատում է [վիքի](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB "Վիքի") ձևաչափով։ Նախագիծը նպատակ ունի տրամադրել ազատ, հավաստի և ստուգելի բովանդակություն, որը յուրաքանչյուրը կարող է փոփոխել և բարելավել։ 
Վիքիպեդիան առաջնորդվում է [հիմնարար սկզբունքներով](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%80%D5%AB%D5%B6%D5%A3_%D5%BD%D5%B5%D5%B8%D6%82%D5%B6%D5%A5%D6%80 "Վիքիպեդիա:Հինգ սյուներ"), իսկ բովանդակությունը հրապարակվում է [Creative Commons BY-SA](https://creativecommons.org/licenses/by-sa/3.0/deed.hy "creativecommons:by-sa/3.0/deed.hy") արտոնագրի ներքո։ Այն կարելի է պատճենել և օգտագործել՝ պահպանելով սույն արտոնագրի պայմանները։ Վիքիպեդիայում ողջ տեղեկատվությունը ներկայացված է ազատ, առանց գովազդի և իր օգտագործողների անձնական տվյալների օգտագործման։
Վիքիպեդիայի հոդվածների հեղինակները կամավորներն են։ Նրանք կոորդինացնում են իրենց ջանքերը համաձայն համայնքում ընդունված կանոնների և ուղեցույցների ու առանց առաջնորդների։ 
Այս պահին [Հայերեն Վիքիպեդիայում](https://hy.wikipedia.org/wiki/%D5%80%D5%A1%D5%B5%D5%A5%D6%80%D5%A5%D5%B6_%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1 "Հայերեն Վիքիպեդիա") կա՝   
---  
[322 602](https://hy.wikipedia.org/wiki/%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:%D5%8E%D5%AB%D5%B3%D5%A1%D5%AF%D5%A1%D5%A3%D6%80%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6 "Սպասարկող:Վիճակագրություն")  
հոդված  |  [715](https://hy.wikipedia.org/wiki/%D5%8D%D5%BA%D5%A1%D5%BD%D5%A1%D6%80%D5%AF%D5%B8%D5%B2:ActiveUsers "Սպասարկող:ActiveUsers")  
ակտիվ խմբագիր  
Վիքիպեդիան հանրագիտարան է, որն ստեղծվել և զարգանում է քեզ նման այցելուների կողմից։ Այստեղ գործում է «մեկը բոլորի համար, բոլորը՝ մեկի համար» սկզբունքը։ 
  

Առաջին անգա՞մ ես փորձում. օգտվի՛ր [օգնության դասընթացից](https://hy.wikipedia.org/wiki/%D5%95%D5%A3%D5%B6%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6:%D4%B4%D5%A1%D5%BD%D5%A8%D5%B6%D5%A9%D5%A1%D6%81 "Օգնություն:Դասընթաց")։ Չգիտես՝ ինչի՞ց սկսել. ահա մի քանի խորհուրդ։ 
* * *
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Writing_star.svg/40px-Writing_star.svg.png)](https://hy.wikipedia.org/wiki/%D5%8A%D5%A1%D5%BF%D5%AF%D5%A5%D6%80:Writing_star.svg)**Մասնակցի՛ր այս ամիս կազմակերպվող նախագծերին։**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Mapa_regioes_italianas.jpg/120px-Mapa_regioes_italianas.jpg)](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%B6%D5%A1%D5%AD%D5%A1%D5%A3%D5%AB%D5%AE:%D4%BB%D5%BF%D5%A1%D5%AC%D5%A1%D5%AF%D5%A1%D5%B6_%D5%BE%D5%AB%D6%84%D5%AB%D5%A1%D6%80%D5%B7%D5%A1%D5%BE "Վիքինախագիծ:Իտալական վիքիարշավ")
  * **[Իտալական վիքիարշավ](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%B6%D5%A1%D5%AD%D5%A1%D5%A3%D5%AB%D5%AE:%D4%BB%D5%BF%D5%A1%D5%AC%D5%A1%D5%AF%D5%A1%D5%B6_%D5%BE%D5%AB%D6%84%D5%AB%D5%A1%D6%80%D5%B7%D5%A1%D5%BE "Վիքինախագիծ:Իտալական վիքիարշավ")**
  * [Հոդվածներ «Գյուղատնտեսական հանրագիտարանից»](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%B6%D5%A1%D5%AD%D5%A1%D5%A3%D5%AB%D5%AE:%D4%BF%D6%80%D5%A9%D5%A1%D5%AF%D5%A1%D5%B6_%D5%AE%D6%80%D5%A1%D5%A3%D5%AB%D6%80/%D4%B3%D5%80 "Վիքինախագիծ:Կրթական ծրագիր/ԳՀ")
  * [«Վիքիպեդիա» կրթական ծրագիր](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D4%BF%D6%80%D5%A9%D5%A1%D5%AF%D5%A1%D5%B6_%D5%AE%D6%80%D5%A1%D5%A3%D5%AB%D6%80 "Վիքիպեդիա:Կրթական ծրագիր")
  * [Բժշկական կարևորագույն հոդվածներ](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D4%B2%D5%AA%D5%B7%D5%AF%D5%A1%D5%AF%D5%A1%D5%B6_%D5%AF%D5%A1%D6%80%D6%87%D5%B8%D6%80%D5%A1%D5%A3%D5%B8%D6%82%D5%B5%D5%B6_%D5%B0%D5%B8%D5%A4%D5%BE%D5%A1%D5%AE%D5%B6%D5%A5%D6%80 "Վիքիպեդիա:Բժշկական կարևորագույն հոդվածներ")

  

[Նախագծի էջ](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%80%D5%A1%D5%B4%D5%A1%D5%A3%D5%B8%D6%80%D5%AE%D5%A1%D5%AF%D6%81%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6 "Վիքիպեդիա:Համագործակցություն") | [Հաջորդ թողարկում](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D5%80%D5%A1%D5%B4%D5%A1%D5%A3%D5%B8%D6%80%D5%AE%D5%A1%D5%AF%D6%81%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6/%D5%80%D5%A1%D5%BB%D5%B8%D6%80%D5%A4_%D5%A9%D5%B8%D5%B2%D5%A1%D6%80%D5%AF%D5%B4%D5%A1%D5%B6_%D5%BA%D5%A1%D5%BF%D6%80%D5%A1%D5%BD%D5%BF%D5%B8%D6%82%D5%B4 "Վիքիպեդիա:Համագործակցություն/Հաջորդ թողարկման պատրաստում")
[![Ռուսական զորքերի կողմից Երևանի բերդի գրավումը: Նկարիչ` Ֆրանց Ռուբո, 1827 թ.](https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Capture_of_Erivan_Fortress_by_Russia%2C_1827_%28by_Franz_Roubaud%29.jpg/250px-Capture_of_Erivan_Fortress_by_Russia%2C_1827_%28by_Franz_Roubaud%29.jpg)](https://hy.wikipedia.org/wiki/%D5%8A%D5%A1%D5%BF%D5%AF%D5%A5%D6%80:Capture_of_Erivan_Fortress_by_Russia,_1827_\(by_Franz_Roubaud\).jpg "Ռուսական զորքերի կողմից Երևանի բերդի գրավումը: Նկարիչ` Ֆրանց Ռուբո, 1827 թ.")Ռուսական զորքերի կողմից Երևանի բերդի գրավումը: Նկարիչ` Ֆրանց Ռուբո, 1827 թ.
  * [մ.թ.ա. 331](https://hy.wikipedia.org/wiki/%D5%84.%D5%A9.%D5%A1._331 "Մ.թ.ա. 331") թ. – տեղի ունեցավ [Գավգամելայի ճակատամարտը](https://hy.wikipedia.org/wiki/%D4%B3%D5%A1%D5%BE%D5%A3%D5%A1%D5%B4%D5%A5%D5%AC%D5%A1%D5%B5%D5%AB_%D5%B3%D5%A1%D5%AF%D5%A1%D5%BF%D5%A1%D5%B4%D5%A1%D6%80%D5%BF "Գավգամելայի ճակատամարտ")։
  * [1827](https://hy.wikipedia.org/wiki/1827 "1827") թ. – [ռուս](https://hy.wikipedia.org/wiki/%D5%8C%D5%B8%D6%82%D5%BD%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6 "Ռուսաստան")-[պարսկական](https://hy.wikipedia.org/wiki/%D5%8A%D5%A1%D6%80%D5%BD%D5%AF%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6 "Պարսկաստան") պատերազմի ժամանակ ռուսական զորքերը [Իվան Պասկևիչի](https://hy.wikipedia.org/wiki/%D4%BB%D5%BE%D5%A1%D5%B6_%D5%8A%D5%A1%D5%BD%D5%AF%D6%87%D5%AB%D5%B9 "Իվան Պասկևիչ") գլխավորությամբ գրավեցին **[Երևանի բերդը](https://hy.wikipedia.org/wiki/%D4%B5%D6%80%D6%87%D5%A1%D5%B6%D5%AB_%D5%A2%D5%A5%D6%80%D5%A4 "Երևանի բերդ")** ։
  * [1866](https://hy.wikipedia.org/wiki/1866 "1866") թ. – ծնվել է [Արշակ Ֆեթվաճյանը](https://hy.wikipedia.org/wiki/%D4%B1%D6%80%D5%B7%D5%A1%D5%AF_%D5%96%D5%A5%D5%A9%D5%BE%D5%A1%D5%B3%D5%B5%D5%A1%D5%B6 "Արշակ Ֆեթվաճյան"), հայ նկարիչ (մահ. [1947](https://hy.wikipedia.org/wiki/1947 "1947") թ.)։
  * [1911](https://hy.wikipedia.org/wiki/1911 "1911") թ. – մահացել է [Վիլհելմ Դիլթայը](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D5%AC%D5%B0%D5%A5%D5%AC%D5%B4_%D4%B4%D5%AB%D5%AC%D5%A9%D5%A1%D5%B5 "Վիլհելմ Դիլթայ"), [գերմանացի](https://hy.wikipedia.org/wiki/%D4%B3%D5%A5%D6%80%D5%B4%D5%A1%D5%B6%D5%AB%D5%A1 "Գերմանիա") [փիլիսոփա](https://hy.wikipedia.org/wiki/%D5%93%D5%AB%D5%AC%D5%AB%D5%BD%D5%B8%D6%83%D5%A1%D5%B5%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6 "Փիլիսոփայություն") (ծն. [1833](https://hy.wikipedia.org/wiki/1833 "1833") թ.)։
  * [1912](https://hy.wikipedia.org/wiki/1912 "1912") թ. – ծնվել է [Լև Գումիլյովը](https://hy.wikipedia.org/wiki/%D4%BC%D6%87_%D4%B3%D5%B8%D6%82%D5%B4%D5%AB%D5%AC%D5%B5%D5%B8%D5%BE "Լև Գումիլյով"), [ռուս](https://hy.wikipedia.org/wiki/%D5%8C%D5%B8%D6%82%D5%BD%D5%B6%D5%A5%D6%80 "Ռուսներ") գիտնական, պատմաբան-ազգագրագետ, պատմական և աշխարհագրական գիտությունների դոկտոր (մահ. [1992](https://hy.wikipedia.org/wiki/1992 "1992") թ.)։
  * [1883](https://hy.wikipedia.org/wiki/1883 "1883") թ. – մահացել է [Ռոմանոս Մելիքյանը](https://hy.wikipedia.org/wiki/%D5%8C%D5%B8%D5%B4%D5%A1%D5%B6%D5%B8%D5%BD_%D5%84%D5%A5%D5%AC%D5%AB%D6%84%D5%B5%D5%A1%D5%B6 "Ռոմանոս Մելիքյան"), հայ նշանավոր երգահան, երաժշտագետ, խմբավար և մանկավարժ (ծն. [1935](https://hy.wikipedia.org/wiki/1935 "1935") թ.)։
  * [1949](https://hy.wikipedia.org/wiki/1949 "1949") թ. – հռչակվեց [Չինաստանի Ժողովրդական Հանրապետությունը](https://hy.wikipedia.org/wiki/%D5%89%D5%AB%D5%B6%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6%D5%AB_%D4%BA%D5%B8%D5%B2%D5%B8%D5%BE%D6%80%D5%A4%D5%A1%D5%AF%D5%A1%D5%B6_%D5%80%D5%A1%D5%B6%D6%80%D5%A1%D5%BA%D5%A5%D5%BF%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6 "Չինաստանի Ժողովրդական Հանրապետություն")։
  * [1969](https://hy.wikipedia.org/wiki/1969 "1969") թ. – բացվել է [Պեկինի մետրոպոլիտենը](https://hy.wikipedia.org/wiki/%D5%8A%D5%A5%D5%AF%D5%AB%D5%B6%D5%AB_%D5%B4%D5%A5%D5%BF%D6%80%D5%B8%D5%BA%D5%B8%D5%AC%D5%AB%D5%BF%D5%A5%D5%B6 "Պեկինի մետրոպոլիտեն"), այն մեկ օրում տեղափոխում է մոտ 7 միլիոն մարդ։
  * [2009](https://hy.wikipedia.org/wiki/2009 "2009") թ. – մահացել է [Օթար Ճիլաձեն](https://hy.wikipedia.org/wiki/%D5%95%D5%A9%D5%A1%D6%80_%D5%83%D5%AB%D5%AC%D5%A1%D5%B1%D5%A5 "Օթար Ճիլաձե"), [վրացի](https://hy.wikipedia.org/wiki/%D5%8E%D6%80%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6 "Վրաստան") բանաստեղծ (ծն. [1933](https://hy.wikipedia.org/wiki/1933 "1933") թ.)։


  

[![Կաղապար:Potd/2025-10-01 \(hy\)](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Pez_murci%C3%A9lago_orbicular_%28Platax_orbicularis%29%2C_mar_Rojo%2C_Egipto%2C_2023-04-19%2C_DD_01.jpg/250px-Pez_murci%C3%A9lago_orbicular_%28Platax_orbicularis%29%2C_mar_Rojo%2C_Egipto%2C_2023-04-19%2C_DD_01.jpg)](https://hy.wikipedia.org/wiki/%D5%8A%D5%A1%D5%BF%D5%AF%D5%A5%D6%80:Pez_murci%C3%A9lago_orbicular_\(Platax_orbicularis\),_mar_Rojo,_Egipto,_2023-04-19,_DD_01.jpg "Կաղապար:Potd/2025-10-01 \(hy\)")[Կաղապար:Potd/2025-10-01 (hy)](https://hy.wikipedia.org/w/index.php?title=%D4%BF%D5%A1%D5%B2%D5%A1%D5%BA%D5%A1%D6%80:Potd/2025-10-01_\(hy\)&action=edit&redlink=1 "Կաղապար:Potd/2025-10-01 \(hy\) \(դեռ գրված չէ\)")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/60px-Wikimedia-logo.svg.png)
Վիքիպեդիան սպասարկում է [Վիքիմեդիա հիմնադրամը](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%B4%D5%A5%D5%A4%D5%AB%D5%A1_%D5%B0%D5%AB%D5%B4%D5%B6%D5%A1%D5%A4%D6%80%D5%A1%D5%B4 "Վիքիմեդիա հիմնադրամ"), ինչպես նաև ստորև նշված քույր նախագծերը, որոնք համակարգվում են [Մետավիքիում](https://meta.wikimedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "m:Գլխավոր էջ")՝
[![Commons](https://upload.wikimedia.org/wikipedia/commons/9/9d/Commons-logo-31px.png)](https://commons.wikimedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB?uselang=hy "Commons")
[**Վիքիպահեստ**](https://commons.wikimedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB?uselang=hy)   
Տեսաձայնային նյութերի շտեմարան
[![Wikiquote](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://hy.wikiquote.org/wiki/Wikiquote:%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Wikiquote")
[**Վիքիքաղվածք**](https://hy.wikiquote.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "q:Գլխավոր էջ")   
Մեջբերումներ
[![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/Wikidata:Main_Page?uselang=hy "Wikidata")
[**Վիքիտվյալներ**](https://www.wikidata.org/wiki/Wikidata:Main_Page?uselang=hy)   
Տվյալների շտեմարան
[![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://hy.wikivoyage.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Wikivoyage")
[**Վիքիճամփորդ**](https://hy.wikivoyage.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "voy:Գլխավոր էջ")   
Ճամփորդի ուղեցույց
[![Wiktionnaire](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://hy.wiktionary.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Wiktionnaire")
[**Վիքիբառարան**](https://hy.wiktionary.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%A2%D5%A1%D5%BC%D5%A1%D6%80%D5%A1%D5%B6:%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "wikt:Վիքիբառարան:Գլխավոր էջ")   
Բառարան
[![Wikilivres](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://hy.wikibooks.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Wikilivres")
[**Վիքիգրքեր**](https://hy.wikibooks.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "b:Գլխավոր էջ")   
Ձեռնարկներ
[![Wikisource](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://hy.wikisource.org/wiki/Wikisource:%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Wikisource")
[**Վիքիդարան**](https://hy.wikisource.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "s:Գլխավոր էջ")   
Գրադարան
[![Wikiversité](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)](https://hy.wikiversity.org/wiki/Wikiversit%C3%A9:%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Wikiversité")
[**Վիքիլսարան**](https://hy.wikiversity.org/wiki/Wikiversit%C3%A9:%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "v:Wikiversité:Գլխավոր էջ")   
Դասընթացներ և վարժություններ
[![Wikinews](https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/Wikinews-logo-51px.png/40px-Wikinews-logo-51px.png)](https://hy.wikinews.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Wikinews")
[**Վիքինորություններ**](https://hy.wikinews.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "n:Գլխավոր էջ")   
Նորությունների կայք
[![Wikispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB?uselang=hy "Wikispecies")
[**Վիքիցեղեր**](https://species.wikimedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB?uselang=hy)   
Տաքսոնոմիական տեղեկատու
  

Ստացված է «[https://hy.wikipedia.org/w/index.php?title=Գլխավոր_էջ&oldid=5662114](https://hy.wikipedia.org/w/index.php?title=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&oldid=5662114)» էջից
353 լեզու
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – աֆարերեն")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – աբխազերեն")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – աչեհերեն")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – ադիղերեն")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – աֆրիկաանս")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – շվեյցարական գերմաներեն")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – հարավային ալթայերեն")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – ամհարերեն")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – արագոներեն")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – հին անգլերեն")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – օբոլո")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – անգիկա")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – արաբերեն")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – արամեերեն")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – Moroccan Arabic")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – եգիպտական արաբերեն")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – ասամերեն")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – աստուրերեն")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – աթիկամեկ")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – ավարերեն")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – ավադհի")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – այմարա")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – ադրբեջաներեն")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – բաշկիրերեն")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – բալիերեն")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – Bavarian")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – Samogitian")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – բելառուսերեն")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – Betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница – բուլղարերեն")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – բիսլամա")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – բամբարա")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – բենգալերեն")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – տիբեթերեն")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – բրետոներեն")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – բոսնիերեն")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – բուգիերեն")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – կատալաներեն")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – չեչեներեն")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – սեբուերեն")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – չամոռո")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – չոկտո")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – չերոկի")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – շայեն")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – սորանի քրդերեն")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – կորսիկերեն")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – Cree")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – ղրիմյան թուրքերեն")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana – չեխերեն")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – Kashubian")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – սլավոներեն, եկեղեցական")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – չուվաշերեն")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – ուելսերեն")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside – դանիերեն")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – գերմաներեն")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – Dinka")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – ստորին սորբերեն")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – Central Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – դիվեհի")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – ջոնգքհա")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – էվե")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – հունարեն")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – անգլերեն")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – էսպերանտո")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – իսպաներեն")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht – էստոներեն")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala – բասկերեն")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – Extremaduran")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – պարսկերեն")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – Fanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – ֆուլահ")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – ֆիններեն")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – վորո")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – ֆիջիերեն")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – ֆարյորերեն")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – ֆոն")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal – ֆրանսերեն")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – Arpitan")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – հյուսիսային ֆրիզերեն")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – ֆրիուլիերեն")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – արևմտաֆրիզերեն")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – իռլանդերեն")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – գագաուզերեն")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – Gan")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – շոտլանդական գաելերեն")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – գալիսերեն")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – Gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – գուարանի")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – գորոնտալո")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – գոթերեն")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – գուջարաթի")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – վայուու")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – մեներեն")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – հաուսա")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – Hakka Chinese")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – հավայիերեն")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – եբրայերեն")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – հինդի")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – Fiji Hindi")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – Hiri Motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – խորվաթերեն")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – վերին սորբերեն")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – խառնակերտ հայիթերեն")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – հունգարերեն")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – հերերո")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – ինտերլինգուա")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – իբաներեն")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama – ինդոնեզերեն")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – ինտերլինգուե")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – իգբո")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – Inupiaq")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – իլոկերեն")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – ինգուշերեն")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – իդո")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – իսլանդերեն")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – իտալերեն")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – ինուկտիտուտ")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – ճապոներեն")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – Jamaican Creole English")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – լոժբան")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – ճավայերեն")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – վրացերեն")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – Kara-Kalpak")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – կաբիլերեն")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – կաբարդերեն")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – տիապ")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – Kongo")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – կիկույու")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – կուանյամա")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – ղազախերեն")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – կալաալիսուտ")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – քմերերեն")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – կաննադա")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – կորեերեն")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – պերմյակ կոմիերեն")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – կանուրի")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – կարաչայ-բալկարերեն")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – քաշմիրերեն")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – քյոլներեն")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – քրդերեն")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – կոմիերեն")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – կոռներեն")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – ղրղզերեն")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima – լատիներեն")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – լադինո")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – լյուքսեմբուրգերեն")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – լեզգիերեն")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – գանդա")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – լիմբուրգերեն")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – լիգուրերեն")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – լոմբարդերեն")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – լինգալա")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – լաոսերեն")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – հյուսիսային լուրիերեն")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – լիտվերեն")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – Latgalian")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – լատվիերեն")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – մադուրերեն")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – մայթիլի")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – մոկշայերեն")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – մալգաշերեն")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – մարշալերեն")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – մաորի")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – մինանգկաբաու")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – մակեդոներեն")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – մալայալամ")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – մոնղոլերեն")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – մանիպուրի")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – մոսսի")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – մարաթի")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – արևմտամարիերեն")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – մալայերեն")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – մալթայերեն")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – մասքոջի")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – միրանդերեն")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – բիրմայերեն")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – էրզյա")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – մազանդարաներեն")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – նեապոլերեն")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – ստորին գերմաներեն")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – ստորին սաքսոներեն")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – նեպալերեն")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – նեվարերեն")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – նդոնգա")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – նիասերեն")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina – հոլանդերեն")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – նոր նորվեգերեն")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – գրքային նորվեգերեն")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – Novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – նկո")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – հարավային նդեբելե")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – հյուսիսային սոթո")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – նավախո")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – նյանջա")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – օքսիտաներեն")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – օրոմո")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – օրիյա")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – օսերեն")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – փենջաբերեն")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – պանգասինաներեն")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – պամպանգաերեն")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – պապյամենտո")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – պիկարդերեն")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – նիգերիական փիջին")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – փենսիլվանական գերմաներեն")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – պալատինյան գերմաներեն")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – պալի")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – լեհերեն")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – պիեմոնտերեն")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – պոնտերեն")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – փուշթու")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – պորտուգալերեն")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – կեչուա")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – ռոմանշերեն")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – ռունդի")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – ռումիներեն")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – արոմաներեն")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – ռուսերեն")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – ռուսիներեն")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – կինյառուանդա")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – սանսկրիտ")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – յակուտերեն")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – սանտալի")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – սարդիներեն")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – սիցիլիերեն")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – շոտլանդերեն")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – սինդհի")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – հյուսիսային սաամի")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – սանգո")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – սերբա-խորվաթերեն")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – տաշելհիթ")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – շաներեն")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – սինհալերեն")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – սլովակերեն")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – սլովեներեն")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – սամոաերեն")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – ինարի սաամի")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – շոնա")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – սոմալիերեն")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – ալբաներեն")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – սերբերեն")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – սրանան տոնգո")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – սվազերեն")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – հարավային սոթո")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – Saterland Frisian")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – սունդաներեն")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – շվեդերեն")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – սուահիլի")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – սիլեզերեն")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – թամիլերեն")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – տուլու")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – թելուգու")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – տետում")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – տաջիկերեն")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – թայերեն")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – տիգրինյա")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – տիգրե")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – թուրքմեներեն")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – տագալերեն")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – թալիշերեն")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – ցվանա")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – տոնգերեն")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – տոկ փիսին")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – թուրքերեն")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – տարոկո")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – ցոնգա")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – թաթարերեն")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – տումբուկա")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – տուի")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – թաիտերեն")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – տուվերեն")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – ուդմուրտերեն")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – ույղուրերեն")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – ուկրաիներեն")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – ուրդու")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – ուզբեկերեն")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – վենդա")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – վենետերեն")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – վեպսերեն")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – վիետնամերեն")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – արևմտաֆլամանդերեն")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – վոլապյուկ")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – վալոներեն")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – վարայերեն")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – վոլոֆ")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – վու չինարեն")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – կալմիկերեն")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – քոսա")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – Mingrelian")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – իդիշ")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – յորուբա")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – ժուանգ")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – զեյլանդերեն")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – ընդհանուր մարոկյան թամազիղտ")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 – չինարեն")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – Literary Chinese")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – Minnan")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – կանտոներեն")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – զուլուերեն")


[Փոխել հղումները](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Խմբագրել միջլեզվային հղումները")
  * Այս էջը վերջին անգամ փոփոխվել է 25 փետրվարի 2018-ի ժամը 19:58-ին:
  * Տեքստը հասանելի է [Քրիեյթիվ Քոմոնս Հղման-Համանման տարածման](https://creativecommons.org/licenses/by-sa/4.0/deed.hy) թույլատրագրի ներքո, առանձին դեպքերում հնարավոր են հավելյալ պայմաններ։ Մանրամասնությունների համար այցելեք՝ [Օգտագործման պայմաններ](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use)։


  * [Գաղտնիության քաղաքականություն](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Վիքիպեդիայի մասին](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D4%B7%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6%D5%A8)
  * [Հրաժարագրեր](https://hy.wikipedia.org/wiki/%D5%8E%D5%AB%D6%84%D5%AB%D5%BA%D5%A5%D5%A4%D5%AB%D5%A1:%D4%B1%D5%A6%D5%A1%D5%BF%D5%B8%D6%82%D5%B4_%D5%BA%D5%A1%D5%BF%D5%A1%D5%BD%D5%AD%D5%A1%D5%B6%D5%A1%D5%BF%D5%BE%D5%B8%D6%82%D5%A9%D5%B5%D5%B8%D6%82%D5%B6%D5%AB%D6%81)
  * [Վարքագծի կանոնագիրք](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Ծրագրավորողներ](https://developer.wikimedia.org)
  * [Վիճակագրություն](https://stats.wikimedia.org/#/hy.wikipedia.org)
  * [Cookie statement](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Տեսքը բջջայինով](https://hy.m.wikipedia.org/w/index.php?title=%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://hy.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://hy.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Որոնել
Որոնել
Գլխավոր էջ
[](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB) [](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB) [](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB) [](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB) [](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB) [](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB) [](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB) [](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
353 լեզու [Ավելացնել քննարկում ](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB)
