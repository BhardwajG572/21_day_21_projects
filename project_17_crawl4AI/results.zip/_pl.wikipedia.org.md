[Przejdź do zawartości](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna#bodyContent)
Menu główne
Menu główne
przypnij ukryj
Nawigacja 
  * [Strona główna](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Przejdź na stronę główną \[z\]")
  * [Losuj artykuł](https://pl.wikipedia.org/wiki/Specjalna:Losowa_strona "Załaduj losową stronę \[x\]")
  * [Kategorie artykułów](https://pl.wikipedia.org/wiki/Portal:Kategorie_G%C5%82%C3%B3wne)
  * [Najlepsze artykuły](https://pl.wikipedia.org/wiki/Wikipedia:Wyr%C3%B3%C5%BCniona_zawarto%C5%9B%C4%87_Wikipedii)
  * [Częste pytania (FAQ)](https://pl.wikipedia.org/wiki/Pomoc:FAQ)


Dla czytelników 
  * [O Wikipedii](https://pl.wikipedia.org/wiki/Wikipedia:O_Wikipedii)
  * [Kontakt](https://pl.wikipedia.org/wiki/Wikipedia:Kontakt_z_wikipedystami)


Dla wikipedystów 
  * [Pierwsze kroki](https://pl.wikipedia.org/wiki/Pomoc:Pierwsze_kroki)
  * [Portal wikipedystów](https://pl.wikipedia.org/wiki/Wikipedia:Portal_wikipedyst%C3%B3w "O projekcie – co możesz zrobić, gdzie możesz znaleźć informacje")
  * [Ogłoszenia](https://pl.wikipedia.org/wiki/Wikipedia:Tablica_og%C5%82osze%C5%84)
  * [Zasady](https://pl.wikipedia.org/wiki/Wikipedia:Zasady)
  * [Pomoc](https://pl.wikipedia.org/wiki/Pomoc:Spis_tre%C5%9Bci)
  * [Strony specjalne](https://pl.wikipedia.org/wiki/Specjalna:Strony_specjalne)
  * [Ostatnie zmiany](https://pl.wikipedia.org/wiki/Specjalna:Ostatnie_zmiany "Lista ostatnich zmian w Wikipedii. \[r\]")


[ ![](https://pl.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://pl.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![wolna encyklopedia](https://pl.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-pl.svg) ](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna)
[Szukaj ](https://pl.wikipedia.org/wiki/Specjalna:Szukaj "Przeszukaj Wikipedię \[f\]")
Szukaj
Wygląd
  * [Wspomóż Wikipedię](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=pl.wikipedia.org&uselang=pl)
  * [Utwórz konto](https://pl.wikipedia.org/w/index.php?title=Specjalna:Utw%C3%B3rz_konto&returnto=Wikipedia%3AStrona+g%C5%82%C3%B3wna "Zachęcamy do stworzenia konta i zalogowania, ale nie jest to obowiązkowe.")
  * [Zaloguj się](https://pl.wikipedia.org/w/index.php?title=Specjalna:Zaloguj&returnto=Wikipedia%3AStrona+g%C5%82%C3%B3wna "Zachęcamy do zalogowania się, choć nie jest to obowiązkowe. \[o\]")


Narzędzia osobiste
  * [Wspomóż Wikipedię](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=pl.wikipedia.org&uselang=pl)
  * [Utwórz konto](https://pl.wikipedia.org/w/index.php?title=Specjalna:Utw%C3%B3rz_konto&returnto=Wikipedia%3AStrona+g%C5%82%C3%B3wna "Zachęcamy do stworzenia konta i zalogowania, ale nie jest to obowiązkowe.")
  * [Zaloguj się](https://pl.wikipedia.org/w/index.php?title=Specjalna:Zaloguj&returnto=Wikipedia%3AStrona+g%C5%82%C3%B3wna "Zachęcamy do zalogowania się, choć nie jest to obowiązkowe. \[o\]")


#  Wikipedia:Strona główna
60 języków
  * [العربية](https://ar.wikipedia.org/wiki/ "arabski")
  * [বাংলা](https://bn.wikipedia.org/wiki/ "bengalski")
  * [Беларуская](https://be.wikipedia.org/wiki/ "białoruski")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/ "Belarusian \(Taraškievica orthography\)")
  * [Български](https://bg.wikipedia.org/wiki/ "bułgarski")
  * [Bosanski](https://bs.wikipedia.org/wiki/ "bośniacki")
  * [Brezhoneg](https://br.wikipedia.org/wiki/ "bretoński")
  * [Català](https://ca.wikipedia.org/wiki/ "kataloński")
  * [Čeština](https://cs.wikipedia.org/wiki/ "czeski")
  * [Dansk](https://da.wikipedia.org/wiki/ "duński")
  * [Deutsch](https://de.wikipedia.org/wiki/ "niemiecki")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/ "dolnołużycki")
  * [Eesti](https://et.wikipedia.org/wiki/ "estoński")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "grecki")
  * [English](https://en.wikipedia.org/wiki/ "angielski")
  * [Español](https://es.wikipedia.org/wiki/ "hiszpański")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "esperanto")
  * [Euskara](https://eu.wikipedia.org/wiki/ "baskijski")
  * [فارسی](https://fa.wikipedia.org/wiki/ "perski")
  * [Français](https://fr.wikipedia.org/wiki/ "francuski")
  * [Galego](https://gl.wikipedia.org/wiki/ "galicyjski")
  * [한국어](https://ko.wikipedia.org/wiki/ "koreański")
  * [Հայերեն](https://hy.wikipedia.org/wiki/ "ormiański")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/ "górnołużycki")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "chorwacki")
  * [Ido](https://io.wikipedia.org/wiki/ "ido")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "indonezyjski")
  * [Íslenska](https://is.wikipedia.org/wiki/ "islandzki")
  * [Italiano](https://it.wikipedia.org/wiki/ "włoski")
  * [עברית](https://he.wikipedia.org/wiki/ "hebrajski")
  * [ქართული](https://ka.wikipedia.org/wiki/ "gruziński")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/ "kaszubski")
  * [Қазақша](https://kk.wikipedia.org/wiki/ "kazachski")
  * [Latina](https://la.wikipedia.org/wiki/ "łaciński")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/ "luksemburski")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "litewski")
  * [Magyar](https://hu.wikipedia.org/wiki/ "węgierski")
  * [Македонски](https://mk.wikipedia.org/wiki/ "macedoński")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "malajski")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "niderlandzki")
  * [日本語](https://ja.wikipedia.org/wiki/ "japoński")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "norweski \(bokmål\)")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "norweski \(nynorsk\)")
  * [Português](https://pt.wikipedia.org/wiki/ "portugalski")
  * [Română](https://ro.wikipedia.org/wiki/ "rumuński")
  * [Русский](https://ru.wikipedia.org/wiki/ "rosyjski")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "słowacki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "słoweński")
  * [Ślůnski](https://szl.wikipedia.org/wiki/ "śląski")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "serbski")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "serbsko-chorwacki")
  * [Suomi](https://fi.wikipedia.org/wiki/ "fiński")
  * [Svenska](https://sv.wikipedia.org/wiki/ "szwedzki")
  * [తెలుగు](https://te.wikipedia.org/wiki/ "telugu")
  * [ไทย](https://th.wikipedia.org/wiki/ "tajski")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "turecki")
  * [Українська](https://uk.wikipedia.org/wiki/ "ukraiński")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "wietnamski")
  * [中文](https://zh.wikipedia.org/wiki/ "chiński")


  * [Strona główna](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Zobacz stronę projektu \[c\]")
  * [Dyskusja](https://pl.wikipedia.org/wiki/Dyskusja_Wikipedii:Strona_g%C5%82%C3%B3wna "Dyskusja o zawartości tej strony \[t\]")


polski
  * [Czytaj](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna)
  * [Kod źródłowy](https://pl.wikipedia.org/w/index.php?title=Wikipedia:Strona_g%C5%82%C3%B3wna&action=edit "Ta strona jest zabezpieczona. Możesz zobaczyć kod źródłowy. \[e\]")
  * [Wyświetl historię](https://pl.wikipedia.org/w/index.php?title=Wikipedia:Strona_g%C5%82%C3%B3wna&action=history "Starsze wersje tej strony \[h\]")


Narzędzia
Narzędzia
przypnij ukryj
Działania 
  * [Czytaj](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna)
  * [Kod źródłowy](https://pl.wikipedia.org/w/index.php?title=Wikipedia:Strona_g%C5%82%C3%B3wna&action=edit)
  * [Wyświetl historię](https://pl.wikipedia.org/w/index.php?title=Wikipedia:Strona_g%C5%82%C3%B3wna&action=history)


Ogólne 
  * [Linkujące](https://pl.wikipedia.org/wiki/Specjalna:Linkuj%C4%85ce/Wikipedia:Strona_g%C5%82%C3%B3wna "Pokaż listę wszystkich stron linkujących do tej strony \[j\]")
  * [Zmiany w linkowanych](https://pl.wikipedia.org/wiki/Specjalna:Zmiany_w_linkowanych/Wikipedia:Strona_g%C5%82%C3%B3wna "Ostatnie zmiany w stronach, do których ta strona linkuje \[k\]")
  * [Prześlij plik](https://pl.wikipedia.org/wiki/Wikipedia:Prze%C5%9Blij_plik "Prześlij pliki \[u\]")
  * [Link do tej wersji](https://pl.wikipedia.org/w/index.php?title=Wikipedia:Strona_g%C5%82%C3%B3wna&oldid=76905328 "Stały link do tej wersji tej strony")
  * [Informacje o tej stronie](https://pl.wikipedia.org/w/index.php?title=Wikipedia:Strona_g%C5%82%C3%B3wna&action=info "Więcej informacji na temat tej strony")
  * [Zobacz skrócony adres URL](https://pl.wikipedia.org/w/index.php?title=Specjalna:Skr%C3%B3%C4%87_adres_URL&url=https%3A%2F%2Fpl.wikipedia.org%2Fwiki%2FWikipedia%3AStrona_g%25C5%2582%25C3%25B3wna)
  * [Pobierz kod QR](https://pl.wikipedia.org/w/index.php?title=Specjalna:Kod_QR&url=https%3A%2F%2Fpl.wikipedia.org%2Fwiki%2FWikipedia%3AStrona_g%25C5%2582%25C3%25B3wna)


Drukuj lub eksportuj 
  * [Utwórz książkę](https://pl.wikipedia.org/w/index.php?title=Specjalna:Ksi%C4%85%C5%BCka&bookcmd=book_creator&referer=Wikipedia%3AStrona+g%C5%82%C3%B3wna)
  * [Pobierz jako PDF](https://pl.wikipedia.org/w/index.php?title=Specjalna:DownloadAsPdf&page=Wikipedia%3AStrona_g%C5%82%C3%B3wna&action=show-download-screen)
  * [Wersja do druku](https://pl.wikipedia.org/w/index.php?title=Wikipedia:Strona_g%C5%82%C3%B3wna&printable=yes "Wersja do wydruku \[p\]")


W innych projektach 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikibooks](https://pl.wikibooks.org/wiki/Wikibooks:Strona_g%C5%82%C3%B3wna)
  * [Wikidane](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunkcje](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikinews](https://pl.wikinews.org/wiki/Strona_g%C5%82%C3%B3wna)
  * [Wikicytaty](https://pl.wikiquote.org/wiki/Strona_g%C5%82%C3%B3wna)
  * [Wikiźródła](https://pl.wikisource.org/wiki/Wiki%C5%BAr%C3%B3d%C5%82a:Strona_g%C5%82%C3%B3wna)
  * [Wikipodróże](https://pl.wikivoyage.org/wiki/Strona_g%C5%82%C3%B3wna)
  * [Wikisłownik](https://pl.wiktionary.org/wiki/Wikis%C5%82ownik:Strona_g%C5%82%C3%B3wna)
  * [Element Wikidanych](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Link do powiązanego elementu w repozytorium danych \[g\]")


Wygląd
przypnij ukryj
Z Wikipedii, wolnej encyklopedii
**Witaj w[Wikipedii](https://pl.wikipedia.org/wiki/Wikipedia "Wikipedia"),**
[wolnej](https://pl.wikipedia.org/wiki/Wolna_tre%C5%9B%C4%87 "Wolna treść") [encyklopedii](https://pl.wikipedia.org/wiki/Encyklopedia "Encyklopedia"), którą [każdy może redagować](https://pl.wikipedia.org/wiki/Pomoc:Pierwsze_kroki "Pomoc:Pierwsze kroki").  
[1 670 515](https://pl.wikipedia.org/wiki/Wikipedia:Liczba_artyku%C5%82%C3%B3w_w_polskoj%C4%99zycznej_Wikipedii "Wikipedia:Liczba artykułów w polskojęzycznej Wikipedii") artykułów, w tym 5333 [wyróżnione](https://pl.wikipedia.org/wiki/Wikipedia:Wyr%C3%B3%C5%BCniona_zawarto%C5%9B%C4%87_Wikipedii "Wikipedia:Wyróżniona zawartość Wikipedii")
[Kategorie Wikipedii](https://pl.wikipedia.org/wiki/Wikipedia:Kategorie_G%C5%82%C3%B3wne "Wikipedia:Kategorie Główne"):
[Nauki ścisłe](https://pl.wikipedia.org/wiki/Kategoria:Nauki_%C5%9Bcis%C5%82e "Kategoria:Nauki ścisłe") • [Nauki przyrodnicze](https://pl.wikipedia.org/wiki/Kategoria:Nauki_przyrodnicze "Kategoria:Nauki przyrodnicze") • [Nauki społeczne](https://pl.wikipedia.org/wiki/Kategoria:Nauki_spo%C5%82eczne "Kategoria:Nauki społeczne") • [Nauki humanistyczne](https://pl.wikipedia.org/wiki/Kategoria:Nauki_humanistyczne "Kategoria:Nauki humanistyczne") • [Technika](https://pl.wikipedia.org/wiki/Kategoria:Technika "Kategoria:Technika") • [Filozofia](https://pl.wikipedia.org/wiki/Kategoria:Filozofia "Kategoria:Filozofia") • [Historia](https://pl.wikipedia.org/wiki/Kategoria:Historia "Kategoria:Historia") • [Kultura](https://pl.wikipedia.org/wiki/Kategoria:Kultura "Kategoria:Kultura") • [Sztuka](https://pl.wikipedia.org/wiki/Kategoria:Sztuka "Kategoria:Sztuka") • [Religioznawstwo](https://pl.wikipedia.org/wiki/Kategoria:Religioznawstwo "Kategoria:Religioznawstwo") • [Gospodarka](https://pl.wikipedia.org/wiki/Kategoria:Gospodarka "Kategoria:Gospodarka") • [Społeczeństwo](https://pl.wikipedia.org/wiki/Kategoria:Spo%C5%82ecze%C5%84stwo "Kategoria:Społeczeństwo") • [Sport](https://pl.wikipedia.org/wiki/Kategoria:Sport "Kategoria:Sport") • [Polska](https://pl.wikipedia.org/wiki/Kategoria:Polska "Kategoria:Polska") • [Biografie](https://pl.wikipedia.org/wiki/Kategoria:Biografie "Kategoria:Biografie")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/Tydzie%C5%84_tematyczny_logo_propozycja.png/20px-Tydzie%C5%84_tematyczny_logo_propozycja.png)**[Tydzień Artykułu Niemieckiego IV](https://pl.wikipedia.org/wiki/Wikiprojekt:Tygodnie_tematyczne/Tydzie%C5%84_Artyku%C5%82u_Niemieckiego_IV "Wikiprojekt:Tygodnie tematyczne/Tydzień Artykułu Niemieckiego IV")**. [Dołącz](https://pl.wikipedia.org/wiki/Wikiprojekt:Tygodnie_tematyczne/Tydzie%C5%84_Artyku%C5%82u_Niemieckiego_IV#Uczestnicy "Wikiprojekt:Tygodnie tematyczne/Tydzień Artykułu Niemieckiego IV") do akcji!
![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/PL_Wiki_CzyWiesz_ikona.svg/38px-PL_Wiki_CzyWiesz_ikona.svg.png) Czy wiesz…
Z [nowych](https://pl.wikipedia.org/wiki/Specjalna:Nowe_strony "Specjalna:Nowe strony") i ostatnio rozbudowanych artykułów w Wikipedii: 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/AmericanBlackBear1_CincinnatiZoo.jpg/120px-AmericanBlackBear1_CincinnatiZoo.jpg)](https://pl.wikipedia.org/wiki/Plik:AmericanBlackBear1_CincinnatiZoo.jpg)
…co się dzieje z **[niedźwiedziem czarnym](https://pl.wikipedia.org/wiki/Nied%C5%BAwied%C5%BA_czarny "Niedźwiedź czarny")** _(na zdjęciu)_ podczas snu zimowego? 
…które zwierzę to tylko **[mrzonka](https://pl.wikipedia.org/wiki/Mrzonka_pierzak "Mrzonka pierzak")**? 
…kim jest **[Mohan Bhagwat](https://pl.wikipedia.org/wiki/Mohan_Bhagwat "Mohan Bhagwat")** i dlaczego żyje w celibacie? 
…jak **[Madhukar Dattatraya Deoras](https://pl.wikipedia.org/wiki/Madhukar_Dattatraya_Deoras "Madhukar Dattatraya Deoras")** definiował hinduizm? 
…że **[ojciec](https://pl.wikipedia.org/wiki/Giovanni_Santi "Giovanni Santi")** Rafaela Santiego również zajmował się malarstwem?  

_[Propozycje do ekspozycji](https://pl.wikipedia.org/wiki/Wikiprojekt:Czy_wiesz/propozycje "Wikiprojekt:Czy wiesz/propozycje") • [Jak napisać nowy artykuł?](https://pl.wikipedia.org/wiki/Pomoc:Jak_napisa%C4%87_nowy_artyku%C5%82 "Pomoc:Jak napisać nowy artykuł")_
![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/PL_Wiki_Aktualnosci_ikona.svg/38px-PL_Wiki_Aktualnosci_ikona.svg.png) Wydarzenia
**[Inwazja Rosji na Ukrainę](https://pl.wikipedia.org/wiki/Inwazja_Rosji_na_Ukrain%C4%99 "Inwazja Rosji na Ukrainę")** • **[wojna Izraela z Hamasem](https://pl.wikipedia.org/wiki/Wojna_Izraela_z_Hamasem "Wojna Izraela z Hamasem")**
[![Jane Goodall](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Jane_Goodall_2015.jpg/120px-Jane_Goodall_2015.jpg)](https://pl.wikipedia.org/wiki/Plik:Jane_Goodall_2015.jpg "Jane Goodall")  
[Jane Goodall](https://pl.wikipedia.org/wiki/Jane_Goodall "Jane Goodall")
  * Męska **[reprezentacja Włoch](https://pl.wikipedia.org/wiki/Reprezentacja_W%C5%82och_w_pi%C5%82ce_siatkowej_m%C4%99%C5%BCczyzn "Reprezentacja Włoch w piłce siatkowej mężczyzn")** obroniła tytuł [mistrza świata w siatkówce](https://pl.wikipedia.org/wiki/Mistrzostwa_%C5%9Awiata_w_Pi%C5%82ce_Siatkowej_M%C4%99%C5%BCczyzn_2025 "Mistrzostwa Świata w Piłce Siatkowej Mężczyzn 2025"), a [najbardziej wartościowym graczem](https://pl.wikipedia.org/wiki/Most_valuable_player "Most valuable player") turnieju został [Alessandro Michieletto](https://pl.wikipedia.org/wiki/Alessandro_Michieletto "Alessandro Michieletto") ([28 września](https://pl.wikipedia.org/wiki/Wrzesie%C5%84_2025#28_wrze%C5%9Bnia "Wrzesień 2025"))
  * Zaprzysiężono nowy rząd Litwy, nową [premier](https://pl.wikipedia.org/wiki/Premierzy_Litwy "Premierzy Litwy") została **[Inga Ruginienė](https://pl.wikipedia.org/wiki/Inga_Ruginien%C4%97 "Inga Ruginienė")** ([25 września](https://pl.wikipedia.org/wiki/Wrzesie%C5%84_2025#25_wrze%C5%9Bnia "Wrzesień 2025"))
  * **[Ousmane Dembélé](https://pl.wikipedia.org/wiki/Ousmane_Demb%C3%A9l%C3%A9 "Ousmane Dembélé")** i **[Aitana Bonmatí](https://pl.wikipedia.org/wiki/Aitana_Bonmat%C3%AD "Aitana Bonmatí")** zostali ogłoszeni zwycięzcami [Złotej Piłki](https://pl.wikipedia.org/wiki/Z%C5%82ota_Pi%C5%82ka "Złota Piłka"), przyznawanej przez magazyn [France Football](https://pl.wikipedia.org/wiki/France_Football "France Football") ([22 września](https://pl.wikipedia.org/wiki/Wrzesie%C5%84_2025#22_wrze%C5%9Bnia "Wrzesień 2025"))


**[Zmarli](https://pl.wikipedia.org/wiki/Zmarli_we_wrze%C5%9Bniu_2025 "Zmarli we wrześniu 2025")** : [Jane Goodall](https://pl.wikipedia.org/wiki/Jane_Goodall "Jane Goodall") _(na zdjęciu)_ • [Chang Chun-hsiung](https://pl.wikipedia.org/wiki/Chang_Chun-hsiung "Chang Chun-hsiung") • [Lucian Mureșan](https://pl.wikipedia.org/wiki/Lucian_Mure%C8%99an "Lucian Mureșan") • [George F. Smoot](https://pl.wikipedia.org/wiki/George_F._Smoot "George F. Smoot") • [Claudia Cardinale](https://pl.wikipedia.org/wiki/Claudia_Cardinale "Claudia Cardinale") • [Robert Redford](https://pl.wikipedia.org/wiki/Robert_Redford "Robert Redford") • [Andriej Czemierkin](https://pl.wikipedia.org/wiki/Andriej_Czemierkin "Andriej Czemierkin") • [Edmund Lawrence](https://pl.wikipedia.org/wiki/Edmund_Lawrence "Edmund Lawrence")
_[Więcej…](https://pl.wikipedia.org/wiki/Portal:Aktualno%C5%9Bci "Portal:Aktualności")_
![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/PL_Wiki_Kalendarium_ikona.svg/38px-PL_Wiki_Kalendarium_ikona.svg.png) Rocznice
**[2 października](https://pl.wikipedia.org/wiki/2_pa%C5%BAdziernika "2 października")** : [imieniny](https://pl.wikipedia.org/wiki/Imieniny "Imieniny") obchodzą m.in.: [Berengaria](https://pl.wikipedia.org/wiki/Berengaria "Berengaria"), [Stanimir](https://pl.wikipedia.org/wiki/Stanimir "Stanimir") i [Teofil](https://pl.wikipedia.org/wiki/Teofil "Teofil"); [Międzynarodowy Dzień bez Przemocy](https://pl.wikipedia.org/wiki/Mi%C4%99dzynarodowy_Dzie%C5%84_bez_Przemocy "Międzynarodowy Dzień bez Przemocy")  
Okrągłe, pięcioletnie rocznice: 
[![Max Bruch](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Die_Gartenlaube_%281881%29_b_557.jpg/120px-Die_Gartenlaube_%281881%29_b_557.jpg)](https://pl.wikipedia.org/wiki/Plik:Die_Gartenlaube_\(1881\)_b_557.jpg "Max Bruch")[Max Bruch](https://commons.wikimedia.org/wiki/File:Die_Gartenlaube_\(1881\)_b_557.jpg "c:File:Die Gartenlaube \(1881\) b 557.jpg")
[![Oskar Lange](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Oskar_R._Lange.jpg/120px-Oskar_R._Lange.jpg)](https://pl.wikipedia.org/wiki/Plik:Oskar_R._Lange.jpg "Oskar Lange")[Oskar Lange](https://commons.wikimedia.org/wiki/File:Oskar_R._Lange.jpg "c:File:Oskar R. Lange.jpg")
  * [1920](https://pl.wikipedia.org/wiki/1920 "1920") – zmarł niemiecki kompozytor i dyrygent **[Max Bruch](https://pl.wikipedia.org/wiki/Max_Bruch "Max Bruch")** (_na rysunku_)
  * [1940](https://pl.wikipedia.org/wiki/1940 "1940") – w [Warszawie](https://pl.wikipedia.org/wiki/Warszawa "Warszawa") Niemcy utworzyli **[getto żydowskie](https://pl.wikipedia.org/wiki/Getto_warszawskie "Getto warszawskie")**
  * [1950](https://pl.wikipedia.org/wiki/1950 "1950") – ukazał się pierwszy komiks z cyklu **„[Fistaszki](https://pl.wikipedia.org/wiki/Fistaszki "Fistaszki")”**
  * [1955](https://pl.wikipedia.org/wiki/1955 "1955") – zakończono eksploatację komputera **[ENIAC](https://pl.wikipedia.org/wiki/ENIAC "ENIAC")**
  * [1965](https://pl.wikipedia.org/wiki/1965 "1965") – zmarł polski ekonomista, działacz społeczny i państwowy **[Oskar Lange](https://pl.wikipedia.org/wiki/Oskar_Lange "Oskar Lange")** (_na fotografii_), profesor i rektor [Szkoły Głównej Planowania i Statystyki](https://pl.wikipedia.org/wiki/Szko%C5%82a_G%C5%82%C3%B3wna_Handlowa_w_Warszawie "Szkoła Główna Handlowa w Warszawie"), jeden z niewielu polskich ekonomistów cenionych na Zachodzie
  * [1985](https://pl.wikipedia.org/wiki/1985 "1985") – zmarł amerykański aktor filmowy **[Rock Hudson](https://pl.wikipedia.org/wiki/Rock_Hudson "Rock Hudson")** , grywał w dramatach, westernach, filmach wojennych, a także w komediach romantycznych, w których tworzył parę aktorską z [Doris Day](https://pl.wikipedia.org/wiki/Doris_Day "Doris Day")  

 _[1 października](https://pl.wikipedia.org/wiki/1_pa%C5%BAdziernika "1 października") • [Kalendarium dzień po dniu](https://pl.wikipedia.org/wiki/Kalendarium_dzie%C5%84_po_dniu "Kalendarium dzień po dniu") • [3 października](https://pl.wikipedia.org/wiki/3_pa%C5%BAdziernika "3 października")_


![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/HSUtvald.svg/40px-HSUtvald.svg.png) Artykuł na medal
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9d/Micha%C5%82_Weichert_1923.jpg/120px-Micha%C5%82_Weichert_1923.jpg)](https://pl.wikipedia.org/wiki/Plik:Micha%C5%82_Weichert_1923.jpg)
**[Michał Weichert](https://pl.wikipedia.org/wiki/Micha%C5%82_Weichert "Michał Weichert")** (ur. [5 maja](https://pl.wikipedia.org/wiki/5_maja "5 maja") [1890](https://pl.wikipedia.org/wiki/1890 "1890") w [Starymieście](https://pl.wikipedia.org/wiki/Staremiasto "Staremiasto"), zm. [11 marca](https://pl.wikipedia.org/wiki/11_marca "11 marca") [1967](https://pl.wikipedia.org/wiki/1967 "1967") w [Tel Awiwie](https://pl.wikipedia.org/wiki/Tel_Awiw-Jafa "Tel Awiw-Jafa")) – polski i żydowski reżyser teatralny, teatrolog, pedagog oraz prawnik. Uznawany za najwybitniejszego reżysera teatru [jidyszowego](https://pl.wikipedia.org/wiki/Jidysz "Jidysz") w Polsce. W 1919 roku był kierownikiem artystycznym [Trupy Wileńskiej](https://pl.wikipedia.org/wiki/Trupa_Wile%C5%84ska "Trupa Wileńska"), był twórcą i kierownikiem Żydowskiej Szkoły Dramatycznej, pierwszej na ziemiach polskich żydowskiej szkoły teatralnej. Od 1932 roku był kierownikiem [Żydowskiego Studia Eksperymentalnego „Jung Teater”](https://pl.wikipedia.org/wiki/Jung_Teater "Jung Teater"), przemianowanego w 1936 roku na Teatr Eksperymentalny Jung Bine i rok później na Naj Teater. Podczas [II wojny światowej](https://pl.wikipedia.org/wiki/II_wojna_%C5%9Bwiatowa "II wojna światowa") pełnił funkcję kierownika [Żydowskiej Samopomocy Społecznej](https://pl.wikipedia.org/wiki/%C5%BBydowska_Samopomoc_Spo%C5%82eczna "Żydowska Samopomoc Społeczna") oraz [Żydowskiego Urzędu Samopomocy](https://pl.wikipedia.org/wiki/%C5%BBydowski_Urz%C4%85d_Samopomocy "Żydowski Urząd Samopomocy"). Po wojnie oskarżony o [kolaborację](https://pl.wikipedia.org/wiki/Kolaboracja_pod_okupacj%C4%85_niemieck%C4%85_podczas_II_wojny_%C5%9Bwiatowej "Kolaboracja pod okupacją niemiecką podczas II wojny światowej"). Mimo uniewinniającego wyroku Sądu Specjalnego Karnego, Weichert stał się ofiarą [ostracyzmu](https://pl.wikipedia.org/wiki/Ostracyzm "Ostracyzm") ze strony społeczności żydowskiej, a żydowski sąd społeczny działający przez [CKŻP](https://pl.wikipedia.org/wiki/Centralny_Komitet_%C5%BByd%C3%B3w_w_Polsce "Centralny Komitet Żydów w Polsce") skazał go na napiętnowanie. Weichert był prawdopodobnie najbardziej znanym Żydem oskarżonym o kolaborację podczas II wojny światowej i sądzonym w Polsce. _[Czytaj więcej…](https://pl.wikipedia.org/wiki/Micha%C5%82_Weichert "Michał Weichert")_
_Inne[Artykuły na Medal](https://pl.wikipedia.org/wiki/Wikipedia:Artyku%C5%82y_na_Medal "Wikipedia:Artykuły na Medal") i [Listy na Medal](https://pl.wikipedia.org/wiki/Wikipedia:Listy_na_Medal "Wikipedia:Listy na Medal") • [Jak napisać doskonały artykuł?](https://pl.wikipedia.org/wiki/Pomoc:Jak_napisa%C4%87_doskona%C5%82y_artyku%C5%82 "Pomoc:Jak napisać doskonały artykuł")_
![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f0/HSBra.svg/40px-HSBra.svg.png) Dobry artykuł
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/1937_Edward_threepence_obverse.jpeg/120px-1937_Edward_threepence_obverse.jpeg)](https://pl.wikipedia.org/wiki/Plik:1937_Edward_threepence_obverse.jpeg)
**[Monety Edwarda VIII](https://pl.wikipedia.org/wiki/Monety_Edwarda_VIII "Monety Edwarda VIII")** – ogół monet [brytyjskiego](https://pl.wikipedia.org/wiki/Wielka_Brytania "Wielka Brytania") króla [Edwarda VIII](https://pl.wikipedia.org/wiki/Edward_VIII_Windsor "Edward VIII Windsor") wybitych w okresie od objęcia przez niego tronu w styczniu 1936 roku aż do jego abdykacji w grudniu tego samego roku. W związku z abdykacją produkcja monet Edwarda VIII przeznaczonych do obiegu w Wielkiej Brytanii nigdy się nie rozpoczęła, a w brytyjskiej Mennicy Królewskiej, która była już w zaawansowanym stadium przygotowań, zdążono jedynie wybić niewielką liczbę próbnych monet w celach testowych oraz prezentacyjnych. Większość z nich przechowywana jest obecnie w Muzeum Mennicy Królewskiej w [Llantrisant](https://pl.wikipedia.org/wiki/Llantrisant "Llantrisant"), w [Muzeum Brytyjskim](https://pl.wikipedia.org/wiki/Muzeum_Brytyjskie "Muzeum Brytyjskie") w [Londynie](https://pl.wikipedia.org/wiki/Londyn "Londyn"), w Kolekcji Królewskiej należącej do [brytyjskiej rodziny królewskiej](https://pl.wikipedia.org/wiki/Brytyjska_rodzina_kr%C3%B3lewska "Brytyjska rodzina królewska") oraz w tzw. Kolekcji Tyrana w [Stanach Zjednoczonych](https://pl.wikipedia.org/wiki/Stany_Zjednoczone "Stany Zjednoczone"). Pojedyncze próbne monety Edwarda VIII, znajdujące się w rękach prywatnych, osiągają często na aukcjach rekordowe ceny. Na rynku kolekcjonerskim dostępne są także liczne nieoficjalne naśladownictwa monet tego króla. _[Czytaj więcej…](https://pl.wikipedia.org/wiki/Monety_Edwarda_VIII "Monety Edwarda VIII")_
_[Inne Dobre Artykuły](https://pl.wikipedia.org/wiki/Wikipedia:Dobre_Artyku%C5%82y "Wikipedia:Dobre Artykuły") • [Jak pisać w stylu encyklopedycznym?](https://pl.wikipedia.org/wiki/Pomoc:Styl_%E2%80%93_poradnik_dla_autor%C3%B3w "Pomoc:Styl – poradnik dla autorów")_
![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/PL_Wiki_InM_ikona.svg/38px-PL_Wiki_InM_ikona.svg.png) Ilustracja na medal
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Belgian_F-16_Radom.JPG/500px-Belgian_F-16_Radom.JPG)](https://pl.wikipedia.org/wiki/Plik:Belgian_F-16_Radom.JPG)
Belgijski [F-16 Fighting Falcon](https://pl.wikipedia.org/wiki/General_Dynamics_F-16_Fighting_Falcon "General Dynamics F-16 Fighting Falcon") podczas lotu treningowego przed [radomskim](https://pl.wikipedia.org/wiki/Radom "Radom") [Air Show 2009](https://pl.wikipedia.org/wiki/Radom_Air_Show "Radom Air Show")  

_[Inne Ilustracje na Medal](https://pl.wikipedia.org/wiki/Wikipedia:Ilustracje_na_Medal "Wikipedia:Ilustracje na Medal") • [Jak zilustrować artykuł?](https://pl.wikipedia.org/wiki/Pomoc:Ilustrowanie "Pomoc:Ilustrowanie")_
![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Wikimedia-logo-circle.svg/40px-Wikimedia-logo-circle.svg.png) Siostrzane projekty Wikipedii
  * ![Wikiźródła](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)
[**Wikiźródła**](https://pl.wikisource.org/wiki/ "s:")  
Wolna biblioteka
  * ![Wikisłownik](https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/WiktionaryPl_nodesc.svg/40px-WiktionaryPl_nodesc.svg.png)
[**Wikisłownik**](https://pl.wiktionary.org/wiki/ "wikt:")  
Wielojęzyczny słownik
  * ![Commons](https://upload.wikimedia.org/wikipedia/commons/9/9d/Commons-logo-31px.png)
[**Commons**](https://commons.wikimedia.org/wiki/Strona_g%C5%82%C3%B3wna "c:Strona główna")  
Repozytorium mediów
  * ![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)
[**Wikidane**](https://www.wikidata.org/wiki/Wikidata:Strona_g%C5%82%C3%B3wna "d:Wikidata:Strona główna")  
Repozytorium danych
  * ![Wikinews](https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/Wikinews-logo-51px.png/40px-Wikinews-logo-51px.png)
[**Wikinews**](https://pl.wikinews.org/wiki/ "n:")  
Serwis informacyjny
  * ![Wikispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)
[**Wikispecies**](https://species.wikimedia.org/wiki/Strona_g%C5%82%C3%B3wna "wikispecies:Strona główna")  
Katalog gatunków
  * ![Wikibooks](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)
[**Wikibooks**](https://pl.wikibooks.org/wiki/ "b:")  
Wolne podręczniki
  * ![Wikicytaty](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)
[**Wikicytaty**](https://pl.wikiquote.org/wiki/ "q:")  
Kolekcja cytatów
  * ![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)
[**Wikipodróże**](https://pl.wikivoyage.org/wiki/ "voy:")  
Informacje turystyczne
  * ![Wikiwersytet](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)
[**Wikiwersytet**](https://beta.wikiversity.org/wiki/Strona_G%C5%82%C3%B3wna "betawikiversity:Strona Główna")  
Wolna edukacja
  * ![Wikifunkcje](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Wikifunctions-logo.svg/40px-Wikifunctions-logo.svg.png)
[**Wikifunkcje**](https://www.wikifunctions.org/wiki/ "f:")  
Wolna biblioteka funkcji


![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/HSSamarbetecolor.svg/40px-HSSamarbetecolor.svg.png) Organizacja i promocja Wikimediów
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/40px-Wikimedia-logo.svg.png)
[**Wikimedia Foundation**](https://wikimediafoundation.org/ "foundationsite:")  
Ponosi prawną i techniczną odpowiedzialność za Wikipedię.
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/Wikimediapolska-logo.png/40px-Wikimediapolska-logo.png)
[**Wikimedia Polska**](https://wikimedia.pl)  
Promocja polskich projektów Wikimedia
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)
[**Meta-Wiki**](https://meta.wikimedia.org/wiki/Strona_g%C5%82%C3%B3wna "m:Strona główna")  
Koordynacja projektów Wikimedia


Jeżeli jesteś nowym użytkownikiem Wikipedii, możesz znaleźć pomoc u innych członków [społeczności](https://pl.wikipedia.org/wiki/Wikipedia:Spo%C5%82eczno%C5%9B%C4%87_wikipedyst%C3%B3w "Wikipedia:Społeczność wikipedystów"), m.in. u [przewodników](https://pl.wikipedia.org/wiki/Pomoc:Przewodnicy "Pomoc:Przewodnicy") czy [administratorów](https://pl.wikipedia.org/wiki/Wikipedia:Administratorzy "Wikipedia:Administratorzy"). Poznaj też inne formy [kontaktu z wikipedystami](https://pl.wikipedia.org/wiki/Wikipedia:Kontakt_z_wikipedystami "Wikipedia:Kontakt z wikipedystami"). 
Zobacz też: [Strona główna z wczoraj](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna/Wczoraj "Wikipedia:Strona główna/Wczoraj") • [Strona główna na jutro](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna/Jutro "Wikipedia:Strona główna/Jutro") • [Dokumentacja](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna/Dokumentacja "Wikipedia:Strona główna/Dokumentacja")
Źródło: „[https://pl.wikipedia.org/w/index.php?title=Wikipedia:Strona_główna&oldid=76905328](https://pl.wikipedia.org/w/index.php?title=Wikipedia:Strona_g%C5%82%C3%B3wna&oldid=76905328)”
Ukryta kategoria: 
  * [Strona główna](https://pl.wikipedia.org/wiki/Kategoria:Strona_g%C5%82%C3%B3wna "Kategoria:Strona główna")


  * Tę stronę ostatnio edytowano 31 maj 2025, 15:06.
  * Tekst udostępniany na licencji [Creative Commons: uznanie autorstwa, na tych samych warunkach](https://creativecommons.org/licenses/by-sa/4.0/deed.pl), z możliwością obowiązywania dodatkowych ograniczeń. Zobacz szczegółowe informacje o [warunkach korzystania](https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/pl).


  * [Polityka prywatności](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [O Wikipedii](https://pl.wikipedia.org/wiki/Wikipedia:O_Wikipedii)
  * [Korzystasz z Wikipedii tylko na własną odpowiedzialność](https://pl.wikipedia.org/wiki/Wikipedia:Korzystasz_z_Wikipedii_tylko_na_w%C5%82asn%C4%85_odpowiedzialno%C5%9B%C4%87)
  * [Powszechne Zasady Postępowania](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Dla deweloperów](https://developer.wikimedia.org)
  * [Statystyki](https://stats.wikimedia.org/#/pl.wikipedia.org)
  * [Oświadczenie o ciasteczkach](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Wersja mobilna](https://pl.m.wikipedia.org/w/index.php?title=Wikipedia:Strona_g%C5%82%C3%B3wna&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://pl.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://pl.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Szukaj
Szukaj
Wikipedia:Strona główna
[](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna) [](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna) [](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna) [](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna) [](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna) [](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna) [](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna) [](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna)
60 języków [Dodaj temat ](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna)
