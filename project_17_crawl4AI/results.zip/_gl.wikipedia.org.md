[Saltar ao contido](https://gl.wikipedia.org/wiki/Portada#bodyContent)
Menú principal
Menú principal
mover á barra lateral agochar
Navegación 
  * [Portada](https://gl.wikipedia.org/wiki/Portada "Visitar a páxina principal \[z\]")
  * [Portal da comunidade](https://gl.wikipedia.org/wiki/Wikipedia:Portal_da_comunidade "Información acerca do proxecto, do que pode facer e dos lugares onde atopar as cousas")
  * [A Taberna](https://gl.wikipedia.org/wiki/Wikipedia:A_Taberna)
  * [Actualidade](https://gl.wikipedia.org/wiki/Wikipedia:Actualidade "Información acerca de acontecementos de actualidade")
  * [Cambios recentes](https://gl.wikipedia.org/wiki/Especial:Cambios_recentes "A lista de modificacións recentes no wiki \[r\]")
  * [Artigos de calidade](https://gl.wikipedia.org/wiki/Wikipedia:Artigos_de_calidade)
  * [Páxina ao chou](https://gl.wikipedia.org/wiki/Especial:Ao_chou "Cargar unha páxina ao chou \[x\]")
  * [Axuda](https://gl.wikipedia.org/wiki/Wikipedia:Axuda "O lugar para informarse")


[ ![](https://gl.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://gl.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![a Wikipedia en galego](https://gl.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-gl.svg) ](https://gl.wikipedia.org/wiki/Portada)
[Procura ](https://gl.wikipedia.org/wiki/Especial:Procurar "Procurar neste wiki \[f\]")
Procurar
Aparencia
  * [Doazóns](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=gl.wikipedia.org&uselang=gl)
  * [Crear unha conta](https://gl.wikipedia.org/w/index.php?title=Especial:Crear_unha_conta&returnto=Portada "É recomendable que cree unha conta e acceda ao sistema, se ben non é obrigatorio")
  * [Acceder ao sistema](https://gl.wikipedia.org/w/index.php?title=Especial:Iniciar_sesi%C3%B3n&returnto=Portada "É recomendable que se rexistre, se ben non é obrigatorio \[o\]")


Ferramentas persoais
  * [Doazóns](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=gl.wikipedia.org&uselang=gl)
  * [Crear unha conta](https://gl.wikipedia.org/w/index.php?title=Especial:Crear_unha_conta&returnto=Portada "É recomendable que cree unha conta e acceda ao sistema, se ben non é obrigatorio")
  * [Acceder ao sistema](https://gl.wikipedia.org/w/index.php?title=Especial:Iniciar_sesi%C3%B3n&returnto=Portada "É recomendable que se rexistre, se ben non é obrigatorio \[o\]")


# Portada
  * [Portada](https://gl.wikipedia.org/wiki/Portada "Ver o contido da páxina \[c\]")
  * [Conversa](https://gl.wikipedia.org/wiki/Conversa:Portada "Conversa acerca do contido desta páxina \[t\]")


galego
  * [Ler](https://gl.wikipedia.org/wiki/Portada)
  * [Ver o código fonte](https://gl.wikipedia.org/w/index.php?title=Portada&action=edit "Esta páxina está protexida.
Pode ver o código fonte. \[e\]")
  * [Ver o historial](https://gl.wikipedia.org/w/index.php?title=Portada&action=history "Versións anteriores desta páxina \[h\]")


Ferramentas
Ferramentas
mover á barra lateral agochar
Accións 
  * [Ler](https://gl.wikipedia.org/wiki/Portada)
  * [Ver o código fonte](https://gl.wikipedia.org/w/index.php?title=Portada&action=edit)
  * [Ver o historial](https://gl.wikipedia.org/w/index.php?title=Portada&action=history)


Xeral 
  * [Páxinas que ligan con esta](https://gl.wikipedia.org/wiki/Especial:P%C3%A1xinas_que_ligan_con_esta/Portada "Lista de todas as páxinas do wiki que ligan cara a aquí \[j\]")
  * [Cambios relacionados](https://gl.wikipedia.org/wiki/Especial:Cambios_relacionados/Portada "Cambios recentes nas páxinas ligadas desde esta \[k\]")
  * [Ligazón permanente](https://gl.wikipedia.org/w/index.php?title=Portada&oldid=7053480 "Ligazón permanente a esta versión desta páxina")
  * [Información da páxina](https://gl.wikipedia.org/w/index.php?title=Portada&action=info "Máis información sobre esta páxina")
  * [Citar esta páxina](https://gl.wikipedia.org/w/index.php?title=Especial:Cita&page=Portada&id=7053480&wpFormIdentifier=titleform "Información sobre como citar esta páxina")
  * [Xerar o enderezo URL acurtado](https://gl.wikipedia.org/w/index.php?title=Especial:UrlShortener&url=https%3A%2F%2Fgl.wikipedia.org%2Fwiki%2FPortada)
  * [Descargar o código QR](https://gl.wikipedia.org/w/index.php?title=Especial:QrCode&url=https%3A%2F%2Fgl.wikipedia.org%2Fwiki%2FPortada)


Imprimir/exportar 
  * [Crear un libro](https://gl.wikipedia.org/w/index.php?title=Especial:Libro&bookcmd=book_creator&referer=Portada)
  * [Descargar como PDF](https://gl.wikipedia.org/w/index.php?title=Especial:DownloadAsPdf&page=Portada&action=show-download-screen)
  * [Versión para imprimir](https://gl.wikipedia.org/w/index.php?title=Portada&printable=yes "Versión para imprimir da páxina \[p\]")


Noutros proxectos 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Fundación Wikimedia](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Divulgación da Wikimedia](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Wikisource multilingüe](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikilibros](https://gl.wikibooks.org/wiki/Portada)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifuncións](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikicitas](https://gl.wikiquote.org/wiki/Portada)
  * [Wikifontes](https://gl.wikisource.org/wiki/Portada)
  * [Wikcionario](https://gl.wiktionary.org/wiki/Wiktionary:P%C3%A1xina_principal)
  * [Elemento de Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Ligazón ao elemento conectado no repositorio de datos \[g\]")


Aparencia
mover á barra lateral agochar
Na Galipedia, a Wikipedia en galego.
|  [Dámosche a benvida](https://gl.wikipedia.org/wiki/Wikipedia:Benvida "Wikipedia:Benvida") á [Galipedia](https://gl.wikipedia.org/wiki/Galipedia "Galipedia") A [enciclopedia libre](https://gl.wikipedia.org/wiki/Wikipedia:Introduci%C3%B3n "Wikipedia:Introdución") que [calquera pode editar](https://gl.wikipedia.org/wiki/Axuda:Como_editar_unha_p%C3%A1xina "Axuda:Como editar unha páxina") |  [mércores](https://gl.wikipedia.org/wiki/M%C3%A9rcores "Mércores"), [1 de outubro](https://gl.wikipedia.org/wiki/1_de_outubro "1 de outubro") de [2025](https://gl.wikipedia.org/wiki/2025 "2025")   
[Versión para móbiles](https://gl.m.wikipedia.org)  
---|---  
Nesta versión en [galego](https://gl.wikipedia.org/wiki/Lingua_galega "Lingua galega"), que comezou o [8 de marzo](https://gl.wikipedia.org/wiki/8_de_marzo "8 de marzo") de [2003](https://gl.wikipedia.org/wiki/2003 "2003"), xa temos **[226 853](https://gl.wikipedia.org/wiki/Especial:Estat%C3%ADsticas "Especial:Estatísticas") artigos**.
[Benvida](https://gl.wikipedia.org/wiki/Wikipedia:Benvida "Wikipedia:Benvida") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Bullet_black.png/7px-Bullet_black.png) [COMOs](https://gl.wikipedia.org/wiki/Categor%C3%ADa:Wikipedia:COMOs "Categoría:Wikipedia:COMOs") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Bullet_black.png/7px-Bullet_black.png) [Preguntas frecuentes](https://gl.wikipedia.org/wiki/Wikipedia:Preguntas_m%C3%A1is_frecuentes "Wikipedia:Preguntas máis frecuentes") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Bullet_black.png/7px-Bullet_black.png) [Comunidade](https://gl.wikipedia.org/wiki/Wikipedia:Portal_da_comunidade "Wikipedia:Portal da comunidade") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Bullet_black.png/7px-Bullet_black.png) [Políticas](https://gl.wikipedia.org/wiki/Wikipedia:Pol%C3%ADticas_e_normas "Wikipedia:Políticas e normas") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Bullet_black.png/7px-Bullet_black.png) [Artigos de calidade](https://gl.wikipedia.org/wiki/Wikipedia:Artigos_de_calidade "Wikipedia:Artigos de calidade") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Bullet_black.png/7px-Bullet_black.png) [Axuda](https://gl.wikipedia.org/wiki/Wikipedia:Axuda "Wikipedia:Axuda")  
|  ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Blue-bg_rounded.svg/350px-Blue-bg_rounded.svg.png) ![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/HSUtvald.svg/40px-HSUtvald.svg.png)
## Artigo destacado  
---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/Psoriasis_on_back.jpg/250px-Psoriasis_on_back.jpg)](https://gl.wikipedia.org/wiki/Ficheiro:Psoriasis_on_back.jpg) A [psoríase](https://gl.wikipedia.org/wiki/Psor%C3%ADase "Psoríase") é unha [doenza autoinmune](https://gl.wikipedia.org/wiki/Doenza_autoinmune "Doenza autoinmune") que se caracteriza por manchas anormais na [pel](https://gl.wikipedia.org/wiki/Pel "Pel"). Estas manchas na pel son polo xeral [vermellas](https://gl.wikipedia.org/w/index.php?title=Eritema&action=edit&redlink=1 "Eritema \(a páxina aínda non existe\)"), resecas, con [proído](https://gl.wikipedia.org/wiki/Pro%C3%ADdo "Proído") e descamación. Nas persoas coa pel escura as manchas poden adquirir a cor púrpura. A psoríase varía en función do seu tamaño e poden ser manchas localizadas ou estendidas por todo o corpo. As lesións na pel poden desencadear cambios psoriáticos na rexión afectada, o cal é coñecido como [fenómeno de Koebner](https://gl.wikipedia.org/w/index.php?title=Fen%C3%B3meno_de_Koebner&action=edit&redlink=1 "Fenómeno de Koebner \(a páxina aínda non existe\)").  Existen cinco tipos principais de psoríase: vulgar, [guttata](https://gl.wikipedia.org/w/index.php?title=Psor%C3%ADase_guttata&action=edit&redlink=1 "Psoríase guttata \(a páxina aínda non existe\)"), [inversa](https://gl.wikipedia.org/w/index.php?title=Psor%C3%ADase_inversa&action=edit&redlink=1 "Psoríase inversa \(a páxina aínda non existe\)"), [pustulosa](https://gl.wikipedia.org/w/index.php?title=Psor%C3%ADase_pustulosa&action=edit&redlink=1 "Psoríase pustulosa \(a páxina aínda non existe\)") e [eritrodérmica](https://gl.wikipedia.org/w/index.php?title=Eritrodermia_psori%C3%A1sica&action=edit&redlink=1 "Eritrodermia psoriásica \(a páxina aínda non existe\)"). A psoríase de placas, tamén coñecida como _psoriasis vulgaris_ , supón arredor do 90% dos casos. Preséntase polo xeral como manchas vermellas con escamas brancas na parte superior. As áreas do corpo que adoitan ser as máis afectadas son a parte posterior dos antebrazos, canelas, área do [embigo](https://gl.wikipedia.org/wiki/Embigo "Embigo") e o coiro cabeludo. A psoríase guttata presenta lesións en forma de pinga. A psoríase pustulosa presenta pequenas [bóchegas](https://gl.wikipedia.org/wiki/B%C3%B3chega "Bóchega") non infecciosas cheas de [brume](https://gl.wikipedia.org/wiki/Brume "Brume"). A psoríase inversa forma parches vermellos nos pregos da pel. A psoríase eritrodérmica ocorre cando a erupción se estende moito e pode desenvolverse a partir de calquera dos outros tipos. As [unllas](https://gl.wikipedia.org/wiki/Unlla "Unlla") das mans e dos pés vense afectadas na maioría das persoas con psoríase nalgún momento da súa vida. Isto pode provocar manchas ou cambio de cor nas unllas. _[Outros artigos destacados](https://gl.wikipedia.org/wiki/Wikipedia:Artigo_destacado "Wikipedia:Artigo destacado") • [Artigos de calidade](https://gl.wikipedia.org/wiki/Wikipedia:Artigos_de_calidade "Wikipedia:Artigos de calidade")_  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Blue-bg_rounded.svg/350px-Blue-bg_rounded.svg.png) ![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/HSGalicia.png/40px-HSGalicia.png)  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/%C3%81nxel_Fole._Obra_literaria_completa_III._Obra_en_castel%C3%A1n.JPG/250px-%C3%81nxel_Fole._Obra_literaria_completa_III._Obra_en_castel%C3%A1n.JPG)](https://gl.wikipedia.org/wiki/Ficheiro:%C3%81nxel_Fole._Obra_literaria_completa_III._Obra_en_castel%C3%A1n.JPG) **[Ánxel Fole Sánchez](https://gl.wikipedia.org/wiki/%C3%81nxel_Fole "Ánxel Fole")** , nado en [Lugo](https://gl.wikipedia.org/wiki/Lugo "Lugo") o [11 de agosto](https://gl.wikipedia.org/wiki/11_de_agosto "11 de agosto") de [1903](https://gl.wikipedia.org/wiki/1903 "1903") e finado na mesma cidade o [9 de maio](https://gl.wikipedia.org/wiki/9_de_maio "9 de maio") de [1986](https://gl.wikipedia.org/wiki/1986 "1986"), foi un escritor en [galego](https://gl.wikipedia.org/wiki/Lingua_galega "Lingua galega") e [castelán](https://gl.wikipedia.org/wiki/Lingua_castel%C3%A1 "Lingua castelá") que practicou o [xornalismo](https://gl.wikipedia.org/wiki/Xornalismo "Xornalismo") e cultivou tódolos [xéneros literarios](https://gl.wikipedia.org/wiki/X%C3%A9nero_literario "Xénero literario") ([narrativa](https://gl.wikipedia.org/wiki/Narrativa "Narrativa"), [poesía](https://gl.wikipedia.org/wiki/Poes%C3%ADa "Poesía"), [teatro](https://gl.wikipedia.org/wiki/Teatro "Teatro") e [ensaio](https://gl.wikipedia.org/wiki/Ensaio_\(literatura\) "Ensaio \(literatura\)")), aínda que a súa sona lle vén fundamentalmente dos seus libros de [contos](https://gl.wikipedia.org/wiki/Conto "Conto"), recollidos en catro volumes: _[Á lus do candil](https://gl.wikipedia.org/wiki/%C3%81_lus_do_candil "Á lus do candil")_ ([Galaxia](https://gl.wikipedia.org/wiki/Editorial_Galaxia "Editorial Galaxia") 1953), _[Terra brava](https://gl.wikipedia.org/wiki/Terra_brava "Terra brava")_ (Galaxia 1955), _[Contos da néboa](https://gl.wikipedia.org/wiki/Contos_da_n%C3%A9boa "Contos da néboa")_ ([Edicións Castrelos](https://gl.wikipedia.org/wiki/Edici%C3%B3ns_Castrelos "Edicións Castrelos") 1972) e _[Historias que ninguén cre](https://gl.wikipedia.org/wiki/Historias_que_ningu%C3%A9n_cre "Historias que ninguén cre")_ ([Xerais](https://gl.wikipedia.org/wiki/Edici%C3%B3ns_Xerais_de_Galicia "Edicións Xerais de Galicia") 1981). Ingresou na [Real Academia Galega](https://gl.wikipedia.org/wiki/Real_Academia_Galega "Real Academia Galega") en 1963. No ano 1981 foi nomeado membro de honra da [Asociación de Escritores en Lingua Galega](https://gl.wikipedia.org/wiki/Asociaci%C3%B3n_de_Escritoras_e_Escritores_en_Lingua_Galega "Asociación de Escritoras e Escritores en Lingua Galega") e no ano 1983 foi proposto para o [Premio Nobel de Literatura](https://gl.wikipedia.org/wiki/Premio_Nobel_de_Literatura "Premio Nobel de Literatura"). En [1997](https://gl.wikipedia.org/wiki/1997 "1997") foille dedicado o [Día das Letras Galegas](https://gl.wikipedia.org/wiki/D%C3%ADa_das_Letras_Galegas "Día das Letras Galegas").  _[Outros artigos destacados sobre Galicia](https://gl.wikipedia.org/wiki/Wikipedia:Sobre_Galicia "Wikipedia:Sobre Galicia") • [O mes de outubro na cultura popular galega](https://gl.wikipedia.org/wiki/Outubro_na_cultura_popular_galega "Outubro na cultura popular galega")_  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Blue-bg_rounded.svg/350px-Blue-bg_rounded.svg.png) ![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Datum01.svg/40px-Datum01.svg.png)  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Jimmy_Carter.jpg/120px-Jimmy_Carter.jpg)](https://gl.wikipedia.org/wiki/Jimmy_Carter "Jimmy Carter")
  * [1876](https://gl.wikipedia.org/wiki/1876 "1876"), publícase o primeiro número do xornal _[El Diario de Lugo](https://gl.wikipedia.org/wiki/El_Diario_de_Lugo "El Diario de Lugo")_ , editado na capital [lucense](https://gl.wikipedia.org/wiki/Lugo "Lugo").
  * [1924](https://gl.wikipedia.org/wiki/1924 "1924"), nace [Jimmy Carter](https://gl.wikipedia.org/wiki/Jimmy_Carter "Jimmy Carter") (na imaxe), [presidente dos Estados Unidos](https://gl.wikipedia.org/wiki/Presidente_dos_Estados_Unidos "Presidente dos Estados Unidos") entre [1977](https://gl.wikipedia.org/wiki/1977 "1977") e [1981](https://gl.wikipedia.org/wiki/1981 "1981").
  * [1931](https://gl.wikipedia.org/wiki/1931 "1931"), a [República Española](https://gl.wikipedia.org/wiki/II_Rep%C3%BAblica_Espa%C3%B1ola "II República Española") recoñece o dereito ao voto das mulleres ([sufraxio feminino](https://gl.wikipedia.org/wiki/Sufraxio_feminino "Sufraxio feminino")).
  * [1958](https://gl.wikipedia.org/wiki/1958 "1958"), o congreso dos [Estados Unidos](https://gl.wikipedia.org/wiki/Estados_Unidos "Estados Unidos") crea a [NASA](https://gl.wikipedia.org/wiki/NASA "NASA").
  * [1960](https://gl.wikipedia.org/wiki/1960 "1960"), [Nixeria](https://gl.wikipedia.org/wiki/Nixeria "Nixeria") vólvese estado [independente](https://gl.wikipedia.org/wiki/Independencia "Independencia") do [Reino Unido](https://gl.wikipedia.org/wiki/Reino_Unido "Reino Unido").
  * [1978](https://gl.wikipedia.org/wiki/1978 "1978"), [Tuvalu](https://gl.wikipedia.org/wiki/Tuvalu "Tuvalu") consegue a súa independencia.

**Hoxe é o Día Internacional das Persoas da[terceira idade](https://gl.wikipedia.org/wiki/Terceira_idade "Terceira idade").** _[Máis efemérides do día de hoxe](https://gl.wikipedia.org/wiki/1_de_outubro "1 de outubro") • [Outras Efemérides destacadas](https://gl.wikipedia.org/wiki/Wikipedia:Efem%C3%A9rides_destacadas "Wikipedia:Efemérides destacadas")_  
|  |  ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Blue-bg_rounded.svg/350px-Blue-bg_rounded.svg.png) ![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/HSBild.svg/40px-HSBild.svg.png)  
---  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Torre_de_H%C3%A9rcules_-_DivesGallaecia2012-62.jpg/500px-Torre_de_H%C3%A9rcules_-_DivesGallaecia2012-62.jpg)](https://gl.wikipedia.org/wiki/Ficheiro:Torre_de_H%C3%A9rcules_-_DivesGallaecia2012-62.jpg)  
---  
[Breogán](https://gl.wikipedia.org/wiki/Breog%C3%A1n "Breogán") e a [torre de Hércules](https://gl.wikipedia.org/wiki/Torre_de_H%C3%A9rcules "Torre de Hércules").   
**Vexa o artigo[A Coruña](https://gl.wikipedia.org/wiki/A_Coru%C3%B1a "A Coruña")**  
_[Outras imaxes destacadas](https://gl.wikipedia.org/wiki/Wikipedia:Imaxe_do_d%C3%ADa "Wikipedia:Imaxe do día") • [Imaxes destacadas en Commons](https://commons.wikimedia.org/wiki/Featured_pictures "commons:Featured pictures")_  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Blue-bg_rounded.svg/350px-Blue-bg_rounded.svg.png) ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/W-circle.svg/40px-W-circle.svg.png)  
A [Wikipedia](https://gl.wikipedia.org/wiki/Wikipedia "Wikipedia") é unha enciclopedia universal en liña [multilingüe](https://meta.wikimedia.org/wiki/List_of_Wikipedias/gl "m:List of Wikipedias/gl"), colaborativa e gratuíta. O propósito da Wikipedia é fornecer un contido [libre](https://gl.wikipedia.org/wiki/Wikipedia:Dereitos_de_autor%C3%ADa "Wikipedia:Dereitos de autoría"), [obxectivo](https://gl.wikipedia.org/wiki/Wikipedia:Punto_de_vista_neutral "Wikipedia:Punto de vista neutral") e [verificable](https://gl.wikipedia.org/wiki/Wikipedia:Verificabilidade "Wikipedia:Verificabilidade") que todas as persoas poidan editar e mellorar.  O proxecto está baseado en [cinco principios](https://gl.wikipedia.org/wiki/Wikipedia:Cinco_piares "Wikipedia:Cinco piares") básicos, todo o contido está dispoñible baixo a licenza [Creative Commons BY-SA](http://creativecommons.org/licenses/by-sa/3.0/deed.pt) e pode ser copiado e reutilizado baixo esta mesma licenza._[Benvida](https://gl.wikipedia.org/wiki/Wikipedia:Benvida "Wikipedia:Benvida") • [Índice da Axuda](https://gl.wikipedia.org/wiki/Wikipedia:Axuda "Wikipedia:Axuda")_  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Blue-bg_rounded.svg/350px-Blue-bg_rounded.svg.png) ![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/Text-x-generic_with_pencil-2.svg/40px-Text-x-generic_with_pencil-2.svg.png)  
Podes consultar a [Axuda](https://gl.wikipedia.org/wiki/Wikipedia:Axuda "Wikipedia:Axuda") e a [Guía](https://gl.wikipedia.org/wiki/Wikipedia:Gu%C3%ADa "Wikipedia:Guía") para obter máis información de como participar, nas que atoparás información de como [comezar a colaborar](https://gl.wikipedia.org/wiki/Wikipedia:Como_comezar_a_colaborar "Wikipedia:Como comezar a colaborar"), [editar artigos](https://gl.wikipedia.org/wiki/Wikipedia:Gu%C3%ADa "Wikipedia:Guía") e [usar imaxes libres](https://gl.wikipedia.org/wiki/Wikipedia:Pol%C3%ADtica_de_uso_de_imaxes "Wikipedia:Política de uso de imaxes"). En caso de dúbidas síntete libre de [preguntar](https://gl.wikipedia.org/wiki/Wikipedia:A_Taberna_\(axuda\) "Wikipedia:A Taberna \(axuda\)")._[COMOs](https://gl.wikipedia.org/wiki/Categor%C3%ADa:Wikipedia:COMOs "Categoría:Wikipedia:COMOs") • [Preguntas máis frecuentes](https://gl.wikipedia.org/wiki/Wikipedia:Preguntas_m%C3%A1is_frecuentes "Wikipedia:Preguntas máis frecuentes")_  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Blue-bg_rounded.svg/350px-Blue-bg_rounded.svg.png) ![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/HSSamarbete.svg/40px-HSSamarbete.svg.png)
## Comunidade  
De acordo coas [nosas estatísticas](https://gl.wikipedia.org/wiki/Especial:Estat%C3%ADsticas "Especial:Estatísticas"), temos un total de 158 428 contas de usuario rexistradas na Galipedia, e entre elas 419 estiveron activas durante o último mes. Todas as persoas que editan a Galipedia son voluntarias, integrando unha comunidade colaborativa e coordinando os esforzos por medio de [proxectos temáticos](https://gl.wikipedia.org/wiki/Wikipedia:Wikiproxecto "Wikipedia:Wikiproxecto") e diversos [espazos de conversa](https://gl.wikipedia.org/wiki/Wikipedia:A_Taberna "Wikipedia:A Taberna")._[Portal da comunidade](https://gl.wikipedia.org/wiki/Wikipedia:Portal_da_comunidade "Wikipedia:Portal da comunidade") • [Políticas e normas](https://gl.wikipedia.org/wiki/Wikipedia:Pol%C3%ADticas_e_normas "Wikipedia:Políticas e normas")_  
|  [![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/Portada/gl "Meta-Wiki")Meta-Wiki [**Meta-Wiki**](https://meta.wikimedia.org/wiki/Portada/gl "m:Portada/gl")  
Coordinación  |  [![Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/Portada_galega "Wikimedia Commons")Wikimedia Commons [**Commons**](https://commons.wikimedia.org/wiki/Portada_galega "commons:Portada galega")  
Multimedia  |  [![Wiktionary](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Wiktionary-logo-gl.png/40px-Wiktionary-logo-gl.png)](https://gl.wiktionary.org/wiki/ "Wiktionary")Wiktionary [**Galizionario**](https://gl.wiktionary.org/wiki/ "wikt:")  
Dicionario  |  [![Wikibooks](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://gl.wikibooks.org/wiki/ "Wikibooks")Wikibooks [**Galilibros**](https://gl.wikibooks.org/wiki/ "b:")  
Libros  |  [![Wikisource](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://gl.wikisource.org/wiki/ "Wikisource")Wikisource [**Galifontes**](https://gl.wikisource.org/wiki/ "s:")  
Documentos  |  [![Wikiquote](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://gl.wikiquote.org/wiki/ "Wikiquote")Wikiquote [**Galicitas**](https://gl.wikiquote.org/wiki/ "q:")  
Citas  |  [![Wikispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/Portada_galega "Wikispecies")Wikispecies [**Wikispecies**](https://species.wikimedia.org/wiki/Portada_galega "wikispecies:Portada galega")  
Especies  |  [![Wikinews](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/120px-Wikinews-logo.svg.png)](https://wikinews.org/ "Wikinews")Wikinews [**Wikinews**](https://wikinews.org/)  
Novas  |  [![Wikiversity](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/60px-Wikiversity-logo.svg.png)](https://wikiversity.org/ "Wikiversity")Wikiversity [**Wikiversity**](https://wikiversity.org/)  
Aprendizaxe  |  [![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/60px-Wikivoyage-Logo-v3-icon.svg.png)](https://wikivoyage.org/ "Wikivoyage")Wikivoyage [**Wikivoyage**](https://wikivoyage.org/)  
Viaxes  |  [![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/120px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "Wikidata")Wikidata [**Wikidata**](https://www.wikidata.org/wiki/ "d:")  
Datos  |  [![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/60px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/MediaWiki/gl "MediaWiki")MediaWiki [**MediaWiki**](https://www.mediawiki.org/wiki/MediaWiki/gl "mw:MediaWiki/gl")  
Desenvolvemento   
---|---|---|---|---|---|---|---|---|---|---|---  
Obtido de «[https://gl.wikipedia.org/w/index.php?title=Portada&oldid=7053480](https://gl.wikipedia.org/w/index.php?title=Portada&oldid=7053480)»
[Categoría](https://gl.wikipedia.org/wiki/Especial:Categor%C3%ADas "Especial:Categorías"): 
  * [Índice](https://gl.wikipedia.org/wiki/Categor%C3%ADa:%C3%8Dndice "Categoría:Índice")


Categoría agochada: 
  * [Wikipedia:Artigos con extractos](https://gl.wikipedia.org/wiki/Categor%C3%ADa:Wikipedia:Artigos_con_extractos "Categoría:Wikipedia:Artigos con extractos")


40 linguas
  * [Aragonés](https://an.wikipedia.org/wiki/ "aragonés")
  * [العربية](https://ar.wikipedia.org/wiki/ "árabe")
  * [Asturianu](https://ast.wikipedia.org/wiki/ "asturiano")
  * [Català](https://ca.wikipedia.org/wiki/ "catalán")
  * [Cebuano](https://ceb.wikipedia.org/wiki/ "cebuano")
  * [Čeština](https://cs.wikipedia.org/wiki/ "checo")
  * [Dansk](https://da.wikipedia.org/wiki/ "dinamarqués")
  * [Deutsch](https://de.wikipedia.org/wiki/ "alemán")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "grego")
  * [English](https://en.wikipedia.org/wiki/ "inglés")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "esperanto")
  * [Español](https://es.wikipedia.org/wiki/ "español")
  * [Euskara](https://eu.wikipedia.org/wiki/ "éuscaro")
  * [Estremeñu](https://ext.wikipedia.org/wiki/ "Extremaduran")
  * [فارسی](https://fa.wikipedia.org/wiki/ "persa")
  * [Suomi](https://fi.wikipedia.org/wiki/ "finés")
  * [Français](https://fr.wikipedia.org/wiki/ "francés")
  * [עברית](https://he.wikipedia.org/wiki/ "hebreo")
  * [Magyar](https://hu.wikipedia.org/wiki/ "húngaro")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "indonesio")
  * [Italiano](https://it.wikipedia.org/wiki/ "italiano")
  * [日本語](https://ja.wikipedia.org/wiki/ "xaponés")
  * [한국어](https://ko.wikipedia.org/wiki/ "coreano")
  * [Latina](https://la.wikipedia.org/wiki/ "latín")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "neerlandés")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "noruegués nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "noruegués bokmål")
  * [Occitan](https://oc.wikipedia.org/wiki/ "occitano")
  * [Polski](https://pl.wikipedia.org/wiki/ "polaco")
  * [Português](https://pt.wikipedia.org/wiki/ "portugués")
  * [Română](https://ro.wikipedia.org/wiki/ "romanés")
  * [Русский](https://ru.wikipedia.org/wiki/ "ruso")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "serbocroata")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Svenska](https://sv.wikipedia.org/wiki/ "sueco")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "turco")
  * [Українська](https://uk.wikipedia.org/wiki/ "ucraíno")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vietnamita")
  * [Winaray](https://war.wikipedia.org/wiki/ "waray-waray")
  * [中文](https://zh.wikipedia.org/wiki/ "chinés")


  * A última edición desta páxina foi o 30 de abril de 2025 ás 17:05.
  * Todo o texto está dispoñible baixo a [licenza Creative Commons recoñecemento compartir igual 4.0](https://creativecommons.org/licenses/by-sa/4.0/); pódense aplicar termos adicionais. Consulte os [termos de uso](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use/gl) para obter máis información.  
Wikipedia® é unha marca rexistrada da [Wikimedia Foundation, Inc.](https://www.wikimediafoundation.org/), unha organización sen fins lucrativos.  



  * [Normas de protección de datos](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Acerca de Wikipedia](https://gl.wikipedia.org/wiki/Wikipedia:Acerca_de)
  * [Advertencias](https://gl.wikipedia.org/wiki/Wikipedia:Advertencia_xeral)
  * [Código de conduta](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Desenvolvedores](https://developer.wikimedia.org)
  * [Estatísticas](https://stats.wikimedia.org/#/gl.wikipedia.org)
  * [Declaración de cookies](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Vista móbil](https://gl.m.wikipedia.org/w/index.php?title=Portada&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://gl.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://gl.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Procura
Procurar
Portada
[](https://gl.wikipedia.org/wiki/Portada) [](https://gl.wikipedia.org/wiki/Portada) [](https://gl.wikipedia.org/wiki/Portada) [](https://gl.wikipedia.org/wiki/Portada) [](https://gl.wikipedia.org/wiki/Portada) [](https://gl.wikipedia.org/wiki/Portada) [](https://gl.wikipedia.org/wiki/Portada) [](https://gl.wikipedia.org/wiki/Portada)
40 linguas [Nova sección ](https://gl.wikipedia.org/wiki/Portada)
