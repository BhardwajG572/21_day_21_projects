[Aller au contenu](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal#bodyContent)
Menu principal
Menu principal
déplacer vers la barre latérale masquer
Navigation 
  * [Page d’accueil](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Accueil général \[z\]")
  * [Portails thématiques](https://fr.wikipedia.org/wiki/Portail:Accueil "Regroupements d'articles par thématiques")
  * [Article au hasard](https://fr.wikipedia.org/wiki/Sp%C3%A9cial:Page_au_hasard "Affiche un article au hasard \[x\]")
  * [Contact](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Contact "Qui contacter")


Contribuer 
  * [Débuter sur Wikipédia](https://fr.wikipedia.org/wiki/Aide:D%C3%A9buter "Guide pour apprendre à contribuer à Wikipédia")
  * [Aide](https://fr.wikipedia.org/wiki/Aide:Accueil "Accès à l’aide")
  * [Communauté](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_de_la_communaut%C3%A9 "À propos du projet, ce que vous pouvez faire, où trouver les informations")
  * [Pages spéciales](https://fr.wikipedia.org/wiki/Sp%C3%A9cial:Pages_sp%C3%A9ciales "Outils pour contribuer à Wikipédia")
  * [Modifications récentes](https://fr.wikipedia.org/wiki/Sp%C3%A9cial:Modifications_r%C3%A9centes "Liste des modifications récentes sur le wiki \[r\]")


[ ![](https://fr.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipédia](https://fr.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-fr.svg) ![l'encyclopédie libre](https://fr.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-fr.svg) ](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal)
[Rechercher ](https://fr.wikipedia.org/wiki/Sp%C3%A9cial:Recherche "Rechercher sur Wikipédia \[f\]")
Rechercher
Apparence
  * [Faire un don](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=fr.wikipedia.org&uselang=fr)
  * [Créer un compte](https://fr.wikipedia.org/w/index.php?title=Sp%C3%A9cial:Cr%C3%A9er_un_compte&returnto=Wikip%C3%A9dia%3AAccueil+principal "Nous vous encourageons à créer un compte utilisateur et vous connecter ; ce n’est cependant pas obligatoire.")
  * [Se connecter](https://fr.wikipedia.org/w/index.php?title=Sp%C3%A9cial:Connexion&returnto=Wikip%C3%A9dia%3AAccueil+principal "Nous vous encourageons à vous connecter ; ce n’est cependant pas obligatoire. \[o\]")


Outils personnels
  * [Faire un don](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=fr.wikipedia.org&uselang=fr)
  * [Créer un compte](https://fr.wikipedia.org/w/index.php?title=Sp%C3%A9cial:Cr%C3%A9er_un_compte&returnto=Wikip%C3%A9dia%3AAccueil+principal "Nous vous encourageons à créer un compte utilisateur et vous connecter ; ce n’est cependant pas obligatoire.")
  * [Se connecter](https://fr.wikipedia.org/w/index.php?title=Sp%C3%A9cial:Connexion&returnto=Wikip%C3%A9dia%3AAccueil+principal "Nous vous encourageons à vous connecter ; ce n’est cependant pas obligatoire. \[o\]")


# Bienvenue sur Wikipédia
353 langues
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – afar")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – abkhaze")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – aceh")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – adyguéen")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – afrikaans")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – alémanique")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – altaï du Sud")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – amharique")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – aragonais")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – ancien anglais")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – obolo")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – angika")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – arabe")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – araméen")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – arabe marocain")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – arabe égyptien")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – assamais")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – asturien")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – atikamekw")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – avar")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – awadhi")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – aymara")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – azerbaïdjanais")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – bachkir")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – balinais")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – bavarois")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – samogitien")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – batak toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – biélorusse")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница – bulgare")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – bichelamar")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – bambara")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – bengali")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – tibétain")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – breton")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – bosniaque")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – bugi")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – catalan")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – tchétchène")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – cebuano")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – chamorro")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – choctaw")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – cherokee")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – cheyenne")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – sorani")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – corse")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – cree")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – tatar de Crimée")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana – tchèque")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – kachoube")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – slavon d’église")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – tchouvache")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – gallois")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside – danois")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – allemand")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – dinka")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – bas-sorabe")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – dusun central")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – maldivien")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – dzongkha")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – éwé")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – grec")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – anglais")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – espéranto")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – espagnol")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht – estonien")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala – basque")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – estrémègne")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – persan")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – fanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – peul")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – finnois")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – fidjien")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – féroïen")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – fon")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – francoprovençal")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – frison septentrional")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – frioulan")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – frison occidental")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – irlandais")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – gagaouze")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – gan")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – créole guyanais")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – gaélique écossais")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – galicien")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – guarani")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – gorontalo")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – gotique")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – goudjarati")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – gurenne")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – mannois")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – haoussa")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – hakka")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – hawaïen")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – hébreu")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – hindi")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – hindi fidjien")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – hiri motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – croate")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – haut-sorabe")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – créole haïtien")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – hongrois")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ – arménien")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – arménien occidental")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – héréro")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – interlingua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – iban")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama – indonésien")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – interlingue")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – igbo")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – inupiaq")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – ilocano")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – ingouche")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – ido")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – islandais")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – italien")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – inuktitut")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – japonais")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – créole jamaïcain")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – lojban")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – javanais")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – géorgien")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – karakalpak")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – kabyle")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – kabarde")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – tyap")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – kikongo")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – kikuyu")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – kuanyama")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – kazakh")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – groenlandais")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – khmer")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – kannada")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – coréen")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – komi-permiak")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – kanouri")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – karatchaï balkar")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – cachemiri")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – kölsch")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – kurde")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – komi")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – cornique")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – kirghize")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima – latin")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – ladino")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – luxembourgeois")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – lezghien")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – lingua franca nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – ganda")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – limbourgeois")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – ligure")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – lombard")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – lingala")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – lao")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – lori du Nord")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – lituanien")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – latgalien")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – letton")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – madurais")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – maïthili")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – mokcha")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – malgache")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – marshallais")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – maori")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – minangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – macédonien")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – malayalam")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – mongol")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – manipuri")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – moré")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – marathi")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – mari occidental")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – malais")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – maltais")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – creek")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – mirandais")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – birman")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – erzya")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – mazandérani")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – napolitain")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – bas-allemand")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – bas-saxon néerlandais")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – népalais")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – newari")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – ndonga")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – niha")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina – néerlandais")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – norvégien nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – norvégien bokmål")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – n’ko")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – ndébélé du Sud")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – sotho du Nord")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – navajo")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – chewa")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – occitan")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – oromo")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – odia")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – ossète")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – pendjabi")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – pangasinan")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – pampangan")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – papiamento")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – picard")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – pidgin nigérian")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – pennsilfaanisch")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – allemand palatin")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – pali")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – polonais")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – piémontais")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – pontique")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – pachto")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – portugais")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – quechua")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – romanche")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – roundi")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – roumain")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – aroumain")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – russe")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – ruthène")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – kinyarwanda")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – sanskrit")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – iakoute")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – santali")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – sarde")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – sicilien")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – écossais")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – sindhi")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – same du Nord")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – sango")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – serbo-croate")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – chleuh")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – shan")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – cingalais")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – slovaque")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – slovène")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – samoan")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – same d’Inari")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – shona")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – somali")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – albanais")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – serbe")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – sranan tongo")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – swati")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – sotho du Sud")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – saterlandais")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – soundanais")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – suédois")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – swahili")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – silésien")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – tamoul")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – toulou")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – télougou")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – tétoum")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – tadjik")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – thaï")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – tigrigna")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – tigré")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – turkmène")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – tagalog")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – talysh")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – tswana")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – tongien")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – tok pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – turc")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – taroko")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – tsonga")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – tatar")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – tumbuka")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – twi")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – tahitien")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – touvain")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – oudmourte")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – ouïghour")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – ukrainien")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – ourdou")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – ouzbek")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – venda")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – vénitien")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – vepse")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – vietnamien")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – flamand occidental")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – volapük")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – wallon")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – waray")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – wolof")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – wu")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – kalmouk")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – xhosa")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – mingrélien")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – yiddish")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – yoruba")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – zhuang")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – zélandais")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – amazighe standard marocain")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 – chinois")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – chinois littéraire")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – minnan")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – cantonais")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – zoulou")


[Modifier les liens](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Modifier les liens interlangues")
  * [Accueil](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Voir la page du projet \[c\]")
  * [Discussion](https://fr.wikipedia.org/wiki/Discussion_Wikip%C3%A9dia:Accueil_principal "Discussion au sujet de cette page de contenu \[t\]")


français
  * [Lire](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal)
  * [Voir le texte source](https://fr.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:Accueil_principal&action=edit "Cette page est protégée.
Vous pouvez toutefois en visualiser la source. \[e\]")
  * [Voir l’historique](https://fr.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:Accueil_principal&action=history "Historique des versions de cette page \[h\]")


Outils
Outils
déplacer vers la barre latérale masquer
Actions 
  * [Lire](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal)
  * [Voir le texte source](https://fr.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:Accueil_principal&action=edit)
  * [Voir l’historique](https://fr.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:Accueil_principal&action=history)


Général 
  * [Pages liées](https://fr.wikipedia.org/wiki/Sp%C3%A9cial:Pages_li%C3%A9es/Wikip%C3%A9dia:Accueil_principal "Liste des pages liées qui pointent sur celle-ci \[j\]")
  * [Suivi des pages liées](https://fr.wikipedia.org/wiki/Sp%C3%A9cial:Suivi_des_liens/Wikip%C3%A9dia:Accueil_principal "Liste des modifications récentes des pages appelées par celle-ci \[k\]")
  * [Téléverser un fichier](https://fr.wikipedia.org/wiki/Aide:Importer_un_fichier "Téléverser des fichiers \[u\]")
  * [Lien permanent](https://fr.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:Accueil_principal&oldid=221036809 "Adresse permanente de cette version de cette page")
  * [Informations sur la page](https://fr.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:Accueil_principal&action=info "Davantage d’informations sur cette page")
  * [Obtenir l'URL raccourcie](https://fr.wikipedia.org/w/index.php?title=Sp%C3%A9cial:UrlShortener&url=https%3A%2F%2Ffr.wikipedia.org%2Fwiki%2FWikip%25C3%25A9dia%3AAccueil_principal)
  * [Télécharger le code QR](https://fr.wikipedia.org/w/index.php?title=Sp%C3%A9cial:QrCode&url=https%3A%2F%2Ffr.wikipedia.org%2Fwiki%2FWikip%25C3%25A9dia%3AAccueil_principal)


Imprimer / exporter 
  * [Créer un livre](https://fr.wikipedia.org/w/index.php?title=Sp%C3%A9cial:Livre&bookcmd=book_creator&referer=Wikip%C3%A9dia%3AAccueil+principal)
  * [Télécharger comme PDF](https://fr.wikipedia.org/w/index.php?title=Sp%C3%A9cial:DownloadAsPdf&page=Wikip%C3%A9dia%3AAccueil_principal&action=show-download-screen)
  * [Version imprimable](https://fr.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:Accueil_principal&printable=yes "Version imprimable de cette page \[p\]")


Dans d’autres projets 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Fondation Wikimédia](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Méta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Sensibilisation Wikimédia](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Wikisource multilingue](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikilivres](https://fr.wikibooks.org/wiki/Accueil)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikinews](https://fr.wikinews.org/wiki/Accueil)
  * [Wikiquote](https://fr.wikiquote.org/wiki/Wikiquote:Accueil)
  * [Wikisource](https://fr.wikisource.org/wiki/Wikisource:Accueil)
  * [Wikiversité](https://fr.wikiversity.org/wiki/Wikiversit%C3%A9:Accueil)
  * [Wikivoyage](https://fr.wikivoyage.org/wiki/Accueil)
  * [Wiktionnaire](https://fr.wiktionary.org/wiki/Wiktionnaire:Page_d%E2%80%99accueil)
  * [Élément Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Lien vers l’élément dans le dépôt de données connecté \[g\]")


Apparence
déplacer vers la barre latérale masquer
Une page de Wikipédia, l'encyclopédie libre.
L'encyclopédie libre que vous pouvez améliorer
[Version pour appareil mobile](https://fr.m.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal)
  * [Accueil de la communauté](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_de_la_communaut%C3%A9 "Wikipédia:Accueil de la communauté")
  * [Comment contribuer ?](https://fr.wikipedia.org/wiki/Aide:D%C3%A9buter "Aide:Débuter")
  * [Portails thématiques](https://fr.wikipedia.org/wiki/Portail:Accueil "Portail:Accueil")
  * [Principes fondateurs](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Principes_fondateurs "Wikipédia:Principes fondateurs")
  * [Sommaire de l'aide](https://fr.wikipedia.org/wiki/Aide:Accueil "Aide:Accueil")
  * [Poser une question](https://fr.wikipedia.org/wiki/Aide:Poser_une_question "Aide:Poser une question")


[![Couverture du numéro de juin 1957, illustrée par Ed Emshwiller.](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Super_science_fiction_195706.jpg/120px-Super_science_fiction_195706.jpg)](https://fr.wikipedia.org/wiki/Fichier:Super_science_fiction_195706.jpg "Couverture du numéro de juin 1957, illustrée par Ed Emshwiller.")Couverture du numéro de juin 1957, illustrée par Ed Emshwiller.
_**[Super-Science Fiction](https://fr.wikipedia.org/wiki/Super-Science_Fiction "Super-Science Fiction")**_ est un [magazine de science-fiction](https://fr.wikipedia.org/wiki/Magazine_de_science-fiction "Magazine de science-fiction") [américain](https://fr.wikipedia.org/wiki/%C3%89tats-Unis "États-Unis"), publié de 1956 à 1959 sous la direction de [William W. Scott](https://fr.wikipedia.org/wiki/William_W._Scott "William W. Scott") chez [Feature Publications](https://fr.wikipedia.org/wiki/Prize_Publications "Prize Publications"). 
Deux jeunes auteurs, [Robert Silverberg](https://fr.wikipedia.org/wiki/Robert_Silverberg "Robert Silverberg") et [Harlan Ellison](https://fr.wikipedia.org/wiki/Harlan_Ellison "Harlan Ellison"), ont déjà vendu à Scott des récits policiers pour ses autres magazines, _Trapped_ et _Guilty_. Rapidement, ils élargissent leur collaboration en proposant également des [nouvelles](https://fr.wikipedia.org/wiki/Nouvelle "Nouvelle") de science-fiction. Tout au long de la courte existence de _Super-Science Fiction_ , Scott publie de nombreux récits signés par ce duo ; Silverberg, en particulier, figure dans chaque numéro, souvent avec deux ou trois histoires, parfois même jusqu'à quatre. Le reste du contenu provient essentiellement d'[agents littéraires](https://fr.wikipedia.org/wiki/Agent_litt%C3%A9raire "Agent littéraire") et comprend majoritairement des manuscrits refusés par d'autres revues. Toutefois, Scott parvient à obtenir deux nouvelles importantes d'[Isaac Asimov](https://fr.wikipedia.org/wiki/Isaac_Asimov "Isaac Asimov"), un pilier incontournable de la science-fiction. 
Après quelques années, Feature Publications modifie la ligne éditoriale du magazine en misant sur les récits de monstres, cherchant ainsi à profiter de la popularité grandissante de _[Famous Monsters of Filmland](https://fr.wikipedia.org/wiki/Famous_Monsters_of_Filmland "Famous Monsters of Filmland")_. Quatre numéros supplémentaires paraissent alors, chacun centré sur une créature monstrueuse. Cependant, en octobre 1959, Feature décide d'arrêter la publication de _Super-Science Fiction_ , après dix-huit numéros. Malgré une réception critique mitigée, le magazine joue un rôle clé dans la formation de plusieurs auteurs majeurs, notamment Robert Silverberg, qui reconnaît que ses contributions à _Super-Science Fiction_ et à d'autres revues d'aventure lui ont offert une véritable « école d'écriture », lui permettant de perfectionner son art littéraire. 
  * _[Lire la suite](https://fr.wikipedia.org/wiki/Super-Science_Fiction "Super-Science Fiction")_


  * **[Contenus de qualité](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Contenus_de_qualit%C3%A9 "Wikipédia:Contenus de qualité")**
  * **[Bons contenus](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Bons_contenus "Wikipédia:Bons contenus")**
  * **[Sélection](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:S%C3%A9lection "Wikipédia:Sélection")**
  * **[Programme](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Lumi%C3%A8re_sur "Wikipédia:Lumière sur")**


[![Joseph Kabila en 2016.](https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Joseph_Kabila_April_2016.jpg/120px-Joseph_Kabila_April_2016.jpg)](https://fr.wikipedia.org/wiki/Fichier:Joseph_Kabila_April_2016.jpg "Joseph Kabila en 2016.")Joseph Kabila en 2016.
  * [30](https://fr.wikipedia.org/wiki/30_septembre "30 septembre") [septembre](https://fr.wikipedia.org/wiki/Septembre_2025 "Septembre 2025") : en [république démocratique du Congo](https://fr.wikipedia.org/wiki/R%C3%A9publique_d%C3%A9mocratique_du_Congo "République démocratique du Congo"), l'ancien [président de la république](https://fr.wikipedia.org/wiki/Pr%C3%A9sident_de_la_r%C3%A9publique_d%C3%A9mocratique_du_Congo "Président de la république démocratique du Congo") **[Joseph Kabila](https://fr.wikipedia.org/wiki/Joseph_Kabila "Joseph Kabila")** _(photo)_ est condamné par [contumace](https://fr.wikipedia.org/wiki/Contumace "Contumace") à la [peine de mort](https://fr.wikipedia.org/wiki/Peine_de_mort "Peine de mort").
  * [28](https://fr.wikipedia.org/wiki/28_septembre "28 septembre") [septembre](https://fr.wikipedia.org/wiki/Septembre_2025 "Septembre 2025") : en [Moldavie](https://fr.wikipedia.org/wiki/Moldavie "Moldavie"), le [Parti action et solidarité](https://fr.wikipedia.org/wiki/Parti_action_et_solidarit%C3%A9 "Parti action et solidarité") remporte à nouveau les **[élections législatives](https://fr.wikipedia.org/wiki/%C3%89lections_l%C3%A9gislatives_moldaves_de_2025 "Élections législatives moldaves de 2025")** dans le contexte de la [guerre russo-ukrainienne](https://fr.wikipedia.org/wiki/Guerre_russo-ukrainienne "Guerre russo-ukrainienne").
  * [27](https://fr.wikipedia.org/wiki/27_septembre "27 septembre") [septembre](https://fr.wikipedia.org/wiki/Septembre_2025 "Septembre 2025") : l'[Unesco](https://fr.wikipedia.org/wiki/Organisation_des_Nations_unies_pour_l%27%C3%A9ducation,_la_science_et_la_culture "Organisation des Nations unies pour l'éducation, la science et la culture") classe **[Sao Tomé-et-Principe](https://fr.wikipedia.org/wiki/Sao_Tom%C3%A9-et-Principe "Sao Tomé-et-Principe")** en [réserve mondiale de biosphère](https://fr.wikipedia.org/wiki/R%C3%A9serve_mondiale_de_biosph%C3%A8re "Réserve mondiale de biosphère"), première fois qu'un pays est couvert en intégralité sous ce niveau de protection environnementale.
  * [25](https://fr.wikipedia.org/wiki/25_septembre "25 septembre") [septembre](https://fr.wikipedia.org/wiki/Septembre_2025 "Septembre 2025") : en [France](https://fr.wikipedia.org/wiki/France "France"), l'ancien [président de la République](https://fr.wikipedia.org/wiki/Pr%C3%A9sident_de_la_R%C3%A9publique_fran%C3%A7aise "Président de la République française") [Nicolas Sarkozy](https://fr.wikipedia.org/wiki/Nicolas_Sarkozy "Nicolas Sarkozy") **[est condamné](https://fr.wikipedia.org/wiki/Affaire_Sarkozy-Kadhafi#Proc%C3%A8s "Affaire Sarkozy-Kadhafi")** à cinq ans d'emprisonnement pour [association de malfaiteurs](https://fr.wikipedia.org/wiki/Association_de_malfaiteurs_en_droit_p%C3%A9nal_fran%C3%A7ais "Association de malfaiteurs en droit pénal français") dans l'[affaire Sarkozy-Kadhafi](https://fr.wikipedia.org/wiki/Affaire_Sarkozy-Kadhafi "Affaire Sarkozy-Kadhafi").
  * [24](https://fr.wikipedia.org/wiki/24_septembre "24 septembre") [septembre](https://fr.wikipedia.org/wiki/Septembre_2025 "Septembre 2025") : selon l'[Institut de recherche de Potsdam sur les effets du changement climatique](https://fr.wikipedia.org/wiki/Institut_de_recherche_de_Potsdam_sur_les_effets_du_changement_climatique "Institut de recherche de Potsdam sur les effets du changement climatique"), la septième des neuf **[limites planétaires](https://fr.wikipedia.org/wiki/Limites_plan%C3%A9taires "Limites planétaires")** est franchie avec l'**[acidification des océans](https://fr.wikipedia.org/wiki/Acidification_des_oc%C3%A9ans "Acidification des océans")**.


* * *
**[Événements en cours](https://fr.wikipedia.org/wiki/Cat%C3%A9gorie:%C3%89v%C3%A9nement_en_cours "Catégorie:Événement en cours")** : 
  * [Manifestations à Madagascar](https://fr.wikipedia.org/wiki/Manifestations_de_2025_%C3%A0_Madagascar "Manifestations de 2025 à Madagascar")
  * [Global Sumud Flotilla](https://fr.wikipedia.org/wiki/Global_Sumud_Flotilla "Global Sumud Flotilla")
  * [Manifestations en Indonésie](https://fr.wikipedia.org/wiki/Manifestations_de_2025_en_Indon%C3%A9sie "Manifestations de 2025 en Indonésie")
  * [Conflit frontalier entre le Cambodge et la Thaïlande](https://fr.wikipedia.org/wiki/Conflit_frontalier_de_2025_entre_le_Cambodge_et_la_Tha%C3%AFlande "Conflit frontalier de 2025 entre le Cambodge et la Thaïlande")
  * [Opération israélienne en Cisjordanie](https://fr.wikipedia.org/wiki/Op%C3%A9ration_isra%C3%A9lienne_en_Cisjordanie_en_2025 "Opération israélienne en Cisjordanie en 2025")
  * [Extension de l'occupation israélienne en Syrie](https://fr.wikipedia.org/wiki/Extension_de_l%27occupation_isra%C3%A9lienne_en_Syrie_depuis_2024 "Extension de l'occupation israélienne en Syrie depuis 2024")
  * [Manifestations en Serbie](https://fr.wikipedia.org/wiki/Manifestations_de_2024-2025_en_Serbie "Manifestations de 2024-2025 en Serbie")
  * [Guerre de Gaza](https://fr.wikipedia.org/wiki/Guerre_de_Gaza_depuis_2023 "Guerre de Gaza depuis 2023")
  * [Guerre civile soudanaise](https://fr.wikipedia.org/wiki/Guerre_civile_soudanaise_\(depuis_2023\) "Guerre civile soudanaise \(depuis 2023\)")
  * [Invasion de l'Ukraine par la Russie](https://fr.wikipedia.org/wiki/Invasion_de_l%27Ukraine_par_la_Russie "Invasion de l'Ukraine par la Russie")
  * [Conflit du M23](https://fr.wikipedia.org/wiki/Conflit_du_M23 "Conflit du M23")
  * [Guerre civile birmane](https://fr.wikipedia.org/wiki/Guerre_civile_birmane_\(depuis_2021\) "Guerre civile birmane \(depuis 2021\)")
  * [Guerre des gangs en Haïti](https://fr.wikipedia.org/wiki/Guerre_des_gangs_en_Ha%C3%AFti "Guerre des gangs en Haïti")
  * [Crise anglophone au Cameroun](https://fr.wikipedia.org/wiki/Crise_anglophone_au_Cameroun "Crise anglophone au Cameroun")


  * [The Rugby Championship](https://fr.wikipedia.org/wiki/The_Rugby_Championship_2025 "The Rugby Championship 2025")
  * [Championnats du monde de slalom (canoë-kayak)](https://fr.wikipedia.org/wiki/Championnats_du_monde_de_slalom_\(cano%C3%AB-kayak\)_2025 "Championnats du monde de slalom \(canoë-kayak\) 2025")
  * [Championnats d'Europe de cyclisme sur route](https://fr.wikipedia.org/wiki/Championnats_d%27Europe_de_cyclisme_sur_route_2025 "Championnats d'Europe de cyclisme sur route 2025")
  * [Championnats du monde d'haltérophilie](https://fr.wikipedia.org/wiki/Championnats_du_monde_d%27halt%C3%A9rophilie_2025 "Championnats du monde d'haltérophilie 2025")
  * [Copa Libertadores féminine](https://fr.wikipedia.org/wiki/Copa_Libertadores_f%C3%A9minine_2025 "Copa Libertadores féminine 2025")
  * [Coupe du monde de football des moins de 20 ans](https://fr.wikipedia.org/wiki/Coupe_du_monde_de_football_des_moins_de_20_ans_2025 "Coupe du monde de football des moins de 20 ans 2025")


* * *
[![Jane Goodall en 2010.](https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/JaneGoodallOct10.jpg/120px-JaneGoodallOct10.jpg)](https://fr.wikipedia.org/wiki/Fichier:JaneGoodallOct10.jpg "Jane Goodall en 2010.")Jane Goodall en 2010.
**[Nécrologie](https://fr.wikipedia.org/wiki/Cat%C3%A9gorie:Mort_r%C3%A9cente "Catégorie:Mort récente")** : 
  * [2](https://fr.wikipedia.org/wiki/2_octobre "2 octobre") [octobre](https://fr.wikipedia.org/wiki/Octobre_2025 "Octobre 2025")
    * [Roland Bertranne](https://fr.wikipedia.org/wiki/Roland_Bertranne "Roland Bertranne")
  * [1er](https://fr.wikipedia.org/wiki/1er_octobre "1er octobre") [octobre](https://fr.wikipedia.org/wiki/Octobre_2025 "Octobre 2025")
    * [Claude Bourdin](https://fr.wikipedia.org/wiki/Claude_Bourdin "Claude Bourdin")
    * [Stefano Casagranda](https://fr.wikipedia.org/wiki/Stefano_Casagranda "Stefano Casagranda")
    * [Judit Elek](https://fr.wikipedia.org/wiki/Judit_Elek "Judit Elek")
    * [Jane Goodall](https://fr.wikipedia.org/wiki/Jane_Goodall "Jane Goodall") _(photo)_
    * [Gabriel Loubier](https://fr.wikipedia.org/wiki/Gabriel_Loubier "Gabriel Loubier")
    * [Mohamed Hashim Mohd Ali](https://fr.wikipedia.org/wiki/Mohamed_Hashim_Mohd_Ali "Mohamed Hashim Mohd Ali")
  * [30](https://fr.wikipedia.org/wiki/30_septembre "30 septembre") [septembre](https://fr.wikipedia.org/wiki/Septembre_2025 "Septembre 2025")
    * [Renato Casaro](https://fr.wikipedia.org/wiki/Renato_Casaro "Renato Casaro")
    * [Vitali Korotitch](https://fr.wikipedia.org/wiki/Vitali_Korotitch "Vitali Korotitch")
    * [Lawrence Moten](https://fr.wikipedia.org/wiki/Lawrence_Moten "Lawrence Moten")
    * [Nathi Mthethwa](https://fr.wikipedia.org/wiki/Nathi_Mthethwa "Nathi Mthethwa")
    * [Takako Saitō](https://fr.wikipedia.org/wiki/Takako_Sait%C5%8D "Takako Saitō")
    * [Bob Van Reeth](https://fr.wikipedia.org/wiki/Bob_Van_Reeth "Bob Van Reeth")
  * [29](https://fr.wikipedia.org/wiki/29_septembre "29 septembre") [septembre](https://fr.wikipedia.org/wiki/Septembre_2025 "Septembre 2025")
    * [Michel Jourdan](https://fr.wikipedia.org/wiki/Michel_Jourdan_\(auteur-compositeur\) "Michel Jourdan \(auteur-compositeur\)")
    * [Jørgen Leth](https://fr.wikipedia.org/wiki/J%C3%B8rgen_Leth "Jørgen Leth")
    * [Denis Raisin Dadre](https://fr.wikipedia.org/wiki/Denis_Raisin_Dadre "Denis Raisin Dadre")
    * [Faouzi Saichi](https://fr.wikipedia.org/wiki/Faouzi_Saichi "Faouzi Saichi")


  * **[Octobre 2025](https://fr.wikipedia.org/wiki/Octobre_2025 "Octobre 2025")**
  * **[Wikinews](https://fr.wikinews.org/wiki/Accueil "n:Accueil")**
  * **[Modifier](https://fr.wikipedia.org/wiki/Mod%C3%A8le:Accueil_actualit%C3%A9 "Modèle:Accueil actualité")**


  * [![L’île Wrangel en 2016.](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wrangel_Island.jpg/250px-Wrangel_Island.jpg)](https://fr.wikipedia.org/wiki/Fichier:Wrangel_Island.jpg "L’île Wrangel en 2016.")L’île Wrangel en 2016.L’**[île Wrangel](https://fr.wikipedia.org/wiki/%C3%8Ele_Wrangel "Île Wrangel")** _(photo)_ a reçu le nom de [celui qui n’a pas réussi à la découvrir](https://fr.wikipedia.org/wiki/Ferdinand_von_Wrangel "Ferdinand von Wrangel").
  * [Charles M. Schulz](https://fr.wikipedia.org/wiki/Charles_Schulz "Charles Schulz") détestait le titre _**[Peanuts](https://fr.wikipedia.org/wiki/Peanuts "Peanuts")**_ que le distributeur de ses bandes dessinées lui avait imposé.
  * [Le premier mari](https://fr.wikipedia.org/wiki/Friedrich_Mandl "Friedrich Mandl") d’[Hedy Lamarr](https://fr.wikipedia.org/wiki/Hedy_Lamarr "Hedy Lamarr") aurait souhaité acheter toutes les copies du film _**[Extase](https://fr.wikipedia.org/wiki/Extase_\(film\) "Extase \(film\)")**_ dans lequel son épouse jouait nue afin de les détruire.
  * Une variante de l’**[IA qui a battu des champions du monde de bridge](https://fr.wikipedia.org/wiki/Bridge#Intelligence_artificielle_et_bridge "Bridge")** en 2022 est employée par [Thales](https://fr.wikipedia.org/wiki/Thales "Thales"), au profit de l’[état-major français](https://fr.wikipedia.org/wiki/%C3%89tat-major#En_France "État-major").
  * On ne sait pas pourquoi de la **[barbe](https://fr.wikipedia.org/wiki/Barbe_\(cristallographie\) "Barbe \(cristallographie\)")** pousse sur certains matériaux [métalliques](https://fr.wikipedia.org/wiki/M%C3%A9tal "Métal"), mais elle peut créer des [courts-circuits](https://fr.wikipedia.org/wiki/Court-circuit "Court-circuit").
  * On peut jouer aux [échecs](https://fr.wikipedia.org/wiki/%C3%89checs "Échecs") dans des **[conditions féériques](https://fr.wikipedia.org/wiki/Condition_f%C3%A9erique "Condition féerique")**.


  * **[Archives](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Le_saviez-vous_%3F/Archives "Wikipédia:Le saviez-vous ?/Archives")**
  * **[Propositions](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Le_saviez-vous_%3F/Anecdotes_propos%C3%A9es "Wikipédia:Le saviez-vous ?/Anecdotes proposées")**
  * **[Programme](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Le_saviez-vous_%3F/Anecdotes_%C3%A0_publier "Wikipédia:Le saviez-vous ?/Anecdotes à publier")**
  * **[Modifier](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Le_saviez-vous_%3F "Wikipédia:Le saviez-vous ?")**


[Wikipédia](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia "Wikipédia") est un projet d’encyclopédie collective en ligne, universelle, multilingue et fonctionnant sur le principe du [wiki](https://fr.wikipedia.org/wiki/Wiki "Wiki"). Ce projet vise à offrir un contenu librement réutilisable, objectif et vérifiable, que chacun peut modifier et améliorer. 
Wikipédia est définie par des [principes fondateurs](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Principes_fondateurs "Wikipédia:Principes fondateurs"). Son contenu est sous [licence Creative Commons BY-SA](https://creativecommons.org/licenses/by-sa/4.0/deed.fr). Il peut être [copié et réutilisé sous la même licence](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Citation_et_r%C3%A9utilisation_du_contenu_de_Wikip%C3%A9dia "Wikipédia:Citation et réutilisation du contenu de Wikipédia"), sous réserve d'en respecter les conditions. Wikipédia fournit tous ses contenus gratuitement, sans publicité, et sans recourir à l'exploitation des données personnelles de ses utilisateurs. 
Les rédacteurs des articles de Wikipédia sont bénévoles. Ils coordonnent leurs efforts au sein d'une communauté collaborative, sans dirigeant. 
Aujourd'hui, [Wikipédia en français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia_en_fran%C3%A7ais "Wikipédia en français") compte :   
---  
[2 712 315](https://fr.wikipedia.org/wiki/Sp%C3%A9cial:Statistiques "Spécial:Statistiques")  
articles  |  [40 765](https://fr.wikipedia.org/wiki/Sp%C3%A9cial:Utilisateurs_actifs "Spécial:Utilisateurs actifs")  
contributeurs enregistrés actifs  
Chacun peut publier immédiatement du contenu en ligne, à condition de respecter les règles essentielles établies par la [Fondation Wikimedia](https://foundation.wikimedia.org/wiki/Terms_of_Use/fr "wmf:Terms of Use/fr") et par la communauté ; par exemple, la [vérifiabilité du contenu](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:V%C3%A9rifiabilit%C3%A9 "Wikipédia:Vérifiabilité"), l'[admissibilité des articles](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Crit%C3%A8res_d%27admissibilit%C3%A9_des_articles "Wikipédia:Critères d'admissibilité des articles") et [garder une attitude cordiale](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:R%C3%A8gles_de_savoir-vivre "Wikipédia:Règles de savoir-vivre"). 
De nombreuses pages d’aide sont à votre disposition, notamment pour [créer un article](https://fr.wikipedia.org/wiki/Aide:Comment_cr%C3%A9er_un_article "Aide:Comment créer un article"), [modifier un article](https://fr.wikipedia.org/wiki/Aide:Comment_modifier_une_page "Aide:Comment modifier une page") ou [insérer une image](https://fr.wikipedia.org/wiki/Aide:Ins%C3%A9rer_une_image "Aide:Insérer une image"). N’hésitez pas à [poser une question](https://fr.wikipedia.org/wiki/Aide:Poser_une_question "Aide:Poser une question") pour être aidé dans vos premiers pas, notamment dans un des [projets thématiques](https://fr.wikipedia.org/wiki/Projet:Accueil "Projet:Accueil") ou dans divers [espaces de discussion](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Avenue_des_caf%C3%A9s_et_bistros "Wikipédia:Avenue des cafés et bistros"). 
Les [pages de discussion](https://fr.wikipedia.org/wiki/Aide:Discussion "Aide:Discussion") servent à centraliser les réflexions et les remarques permettant d’améliorer les articles. 
**[Ressources pour débuter](https://fr.wikipedia.org/wiki/Aide:D%C3%A9buter "Aide:Débuter")**
[![Vue d'artiste de Jacques Cartier par Théophile Hamel, 1844, d'après une œuvre \(aujourd'hui disparue\) réalisée par François Riss en 1839.](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Jacques_Cartier_1851-1852.jpg/120px-Jacques_Cartier_1851-1852.jpg)](https://fr.wikipedia.org/wiki/Fichier:Jacques_Cartier_1851-1852.jpg "Vue d'artiste de Jacques Cartier par Théophile Hamel, 1844, d'après une œuvre \(aujourd'hui disparue\) réalisée par François Riss en 1839.")Vue d'artiste de Jacques Cartier par Théophile Hamel, 1844, d'après une œuvre (aujourd'hui disparue) réalisée par François Riss en 1839.
  * **[1187](https://fr.wikipedia.org/wiki/1187 "1187")** : [Saladin](https://fr.wikipedia.org/wiki/Saladin "Saladin") [reprend Jérusalem](https://fr.wikipedia.org/wiki/Si%C3%A8ge_de_J%C3%A9rusalem_\(1187\) "Siège de Jérusalem \(1187\)") aux [croisés](https://fr.wikipedia.org/wiki/Crois%C3%A9 "Croisé").
  * **[1535](https://fr.wikipedia.org/wiki/1535 "1535")** : [Jacques Cartier](https://fr.wikipedia.org/wiki/Jacques_Cartier "Jacques Cartier") _(vue d’artiste)_ arrive au [Canada](https://fr.wikipedia.org/wiki/Canada "Canada").
  * **[1928](https://fr.wikipedia.org/wiki/1928 "1928")** : à [Madrid](https://fr.wikipedia.org/wiki/Madrid "Madrid") , fondation de l'_[Opus Dei](https://fr.wikipedia.org/wiki/Opus_Dei "Opus Dei")_ par [Josemaría Escrivá de Balaguer](https://fr.wikipedia.org/wiki/Josemar%C3%ADa_Escriv%C3%A1_de_Balaguer "Josemaría Escrivá de Balaguer").
  * **[1935](https://fr.wikipedia.org/wiki/1935 "1935")** : les [Italiens](https://fr.wikipedia.org/wiki/Royaume_d%27Italie_\(1861-1946\) "Royaume d'Italie \(1861-1946\)") [envahissent l'Éthiopie](https://fr.wikipedia.org/wiki/Seconde_guerre_italo-%C3%A9thiopienne "Seconde guerre italo-éthiopienne").
  * **[1968](https://fr.wikipedia.org/wiki/1968 "1968")** : à [Mexico](https://fr.wikipedia.org/wiki/Mexico "Mexico"), la police tue environ 300 personnes lors du [massacre de Tlatelolco](https://fr.wikipedia.org/wiki/Massacre_de_Tlatelolco "Massacre de Tlatelolco").
  * **[1997](https://fr.wikipedia.org/wiki/1997 "1997")** : l'[Union européenne](https://fr.wikipedia.org/wiki/Union_europ%C3%A9enne "Union européenne") signe le [traité d'Amsterdam](https://fr.wikipedia.org/wiki/Trait%C3%A9_d%27Amsterdam "Traité d'Amsterdam"), qui modifie les [traités de Maastricht](https://fr.wikipedia.org/wiki/Trait%C3%A9_de_Maastricht "Traité de Maastricht") et de [Rome](https://fr.wikipedia.org/wiki/Trait%C3%A9_sur_le_fonctionnement_de_l%27Union_europ%C3%A9enne "Traité sur le fonctionnement de l'Union européenne").


  * **[Éphéméride détaillée du 2 octobre](https://fr.wikipedia.org/wiki/2_octobre "2 octobre")**
  * **[Archives](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%89ph%C3%A9m%C3%A9ride "Wikipédia:Éphéméride")**
  * **[Modifier](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%89ph%C3%A9m%C3%A9ride/2_octobre "Wikipédia:Éphéméride/2 octobre")**


[![Le château de Litomyšl \(Tchéquie\). \(définition réelle 4 074 × 2 622\)](https://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Litomy%C5%A1l_%28Leitomischl%29_chateau_-_by_Pudelek.jpg/330px-Litomy%C5%A1l_%28Leitomischl%29_chateau_-_by_Pudelek.jpg)](https://fr.wikipedia.org/wiki/Fichier:Litomy%C5%A1l_\(Leitomischl\)_chateau_-_by_Pudelek.jpg "Le château de Litomyšl \(Tchéquie\). \(définition réelle 4 074 × 2 622\)")
Le [château de Litomyšl](https://fr.wikipedia.org/wiki/Ch%C3%A2teau_de_Litomy%C5%A1l "Château de Litomyšl") ([Tchéquie](https://fr.wikipedia.org/wiki/Tch%C3%A9quie "Tchéquie")).   
_(définition réelle 4 074 × 2 622)_
  * **[Archives](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Image_du_jour/octobre_2025 "Wikipédia:Image du jour/octobre 2025")**
  * **[Voir les images](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Image_du_jour "Wikipédia:Image du jour")**


**[Images de qualité sur Wikimédia Commons](https://commons.wikimedia.org/wiki/Commons:Images_de_qualit%C3%A9 "commons:Commons:Images de qualité")**
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/60px-Wikimedia-logo.svg.png)
Wikipédia est hébergée par la [Wikimedia Foundation](https://fr.wikipedia.org/wiki/Fondation_Wikim%C3%A9dia "Fondation Wikimédia"), de même que les projets suivants, coordonnés sur le site [Méta-Wiki](https://meta.wikimedia.org/wiki/Accueil "m:Accueil") :
[![Commons](https://upload.wikimedia.org/wikipedia/commons/9/9d/Commons-logo-31px.png)](https://commons.wikimedia.org/wiki/Accueil?uselang=fr "Commons")
[**Commons**](https://commons.wikimedia.org/wiki/Accueil?uselang=fr)   
Médiathèque
[![Wikiquote](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://fr.wikiquote.org/wiki/Wikiquote:Accueil "Wikiquote")
[**Wikiquote**](https://fr.wikiquote.org/wiki/Wikiquote:Accueil "q:Wikiquote:Accueil")   
Citations
[![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/Wikidata:Main_Page?uselang=fr "Wikidata")
[**Wikidata**](https://www.wikidata.org/wiki/Wikidata:Main_Page?uselang=fr)   
Base de données
[![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://fr.wikivoyage.org/wiki/Accueil "Wikivoyage")
[**Wikivoyage**](https://fr.wikivoyage.org/wiki/Accueil "voy:Accueil")   
Guide de voyage
[![Wiktionnaire](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://fr.wiktionary.org/wiki/Wiktionnaire:Page_d%E2%80%99accueil "Wiktionnaire")
[**Wiktionnaire**](https://fr.wiktionary.org/wiki/Wiktionnaire:Page_d%E2%80%99accueil "wikt:Wiktionnaire:Page d’accueil")   
Dictionnaire
[![Wikilivres](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://fr.wikibooks.org/wiki/Accueil "Wikilivres")
[**Wikilivres**](https://fr.wikibooks.org/wiki/Accueil "b:Accueil")   
Manuels
[![Wikisource](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://fr.wikisource.org/wiki/Wikisource:Accueil "Wikisource")
[**Wikisource**](https://fr.wikisource.org/wiki/Wikisource:Accueil "s:Wikisource:Accueil")   
Bibliothèque
[![Wikiversité](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/40px-Wikiversity_logo_2017.svg.png)](https://fr.wikiversity.org/wiki/Wikiversit%C3%A9:Accueil "Wikiversité")
[**Wikiversité**](https://fr.wikiversity.org/wiki/Wikiversit%C3%A9:Accueil "v:Wikiversité:Accueil")   
Cours et exercices
[![Wikinews](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://fr.wikinews.org/wiki/Accueil "Wikinews")
[**Wikinews**](https://fr.wikinews.org/wiki/Accueil "n:Accueil")   
Site d'actualités
[![Wikispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/Accueil?uselang=fr "Wikispecies")
[**Wikispecies**](https://species.wikimedia.org/wiki/Accueil?uselang=fr)   
Répertoire taxonomique
[![Wikifunctions](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Wikifunctions-logo.svg/40px-Wikifunctions-logo.svg.png)](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page "Wikifunctions")
[**Wikifunctions**](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page "f:Wikifunctions:Main Page")   
_nouveau projet - accès limité_  
Bibliothèque de fonctions
  

Ce document provient de « [https://fr.wikipedia.org/w/index.php?title=Wikipédia:Accueil_principal&oldid=221036809](https://fr.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:Accueil_principal&oldid=221036809) ».
  * La dernière modification de cette page a été faite le 10 décembre 2024 à 22:30.
  * [Droit d'auteur](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Citation_et_r%C3%A9utilisation_du_contenu_de_Wikip%C3%A9dia "Wikipédia:Citation et réutilisation du contenu de Wikipédia") : les textes sont disponibles sous [licence Creative Commons attribution, partage dans les mêmes conditions](https://creativecommons.org/licenses/by-sa/4.0/deed.fr) ; d’autres conditions peuvent s’appliquer. Voyez les [conditions d’utilisation](https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/fr) pour plus de détails, ainsi que les [crédits graphiques](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Cr%C3%A9dits_graphiques "Wikipédia:Crédits graphiques").   
Wikipedia® est une marque déposée de la [Wikimedia Foundation, Inc.](https://wikimediafoundation.org/), organisation de bienfaisance régie par le paragraphe [501(c)(3)](https://fr.wikipedia.org/wiki/501c "501c") du code fiscal des États-Unis.  



  * [Politique de confidentialité](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy/fr)
  * [À propos de Wikipédia](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%80_propos_de_Wikip%C3%A9dia)
  * [Avertissements](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Avertissements_g%C3%A9n%C3%A9raux)
  * [Contact](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Contact)
  * [Code de conduite](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Développeurs](https://developer.wikimedia.org)
  * [Statistiques](https://stats.wikimedia.org/#/fr.wikipedia.org)
  * [Déclaration sur les témoins (cookies)](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Version mobile](https://fr.wikipedia.org/w/index.php?title=Wikip%C3%A9dia:Accueil_principal&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://fr.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://fr.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Rechercher
Rechercher
Bienvenue sur Wikipédia
[](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal) [](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal) [](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal) [](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal) [](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal) [](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal) [](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal) [](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal)
353 langues [Ajouter un sujet ](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal)
