[Přeskočit na obsah](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana#bodyContent)
Hlavní menu
Hlavní menu
přesunout do postranního panelu skrýt
Navigace 
  * [Hlavní strana](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Navštívit Hlavní stranu \[alt-z\]")
  * [Nápověda](https://cs.wikipedia.org/wiki/N%C3%A1pov%C4%9Bda:Obsah "Místo, kde najdete pomoc")
  * [Potřebuji pomoc](https://cs.wikipedia.org/wiki/Wikipedie:Pot%C5%99ebuji_pomoc "Pokud si nevíte rady, zeptejte se ostatních")
  * [Nejlepší články](https://cs.wikipedia.org/wiki/Wikipedie:Nejlep%C5%A1%C3%AD_%C4%8Dl%C3%A1nky "Přehled článků, které jsou považovány za nejlepší na české Wikipedii")
  * [Náhodný článek](https://cs.wikipedia.org/wiki/Speci%C3%A1ln%C3%AD:N%C3%A1hodn%C3%A1_str%C3%A1nka "Přejít na náhodně vybranou stránku \[alt-x\]")
  * [Poslední změny](https://cs.wikipedia.org/wiki/Speci%C3%A1ln%C3%AD:Posledn%C3%AD_zm%C4%9Bny "Seznam posledních změn na této wiki \[alt-r\]")
  * [Komunitní portál](https://cs.wikipedia.org/wiki/Wikipedie:Port%C3%A1l_Wikipedie "O projektu, jak můžete pomoci, kde hledat")
  * [Pod lípou](https://cs.wikipedia.org/wiki/Wikipedie:Pod_l%C3%ADpou "Hlavní diskusní fórum")
  * [Speciální stránky](https://cs.wikipedia.org/wiki/Speci%C3%A1ln%C3%AD:Speci%C3%A1ln%C3%AD_str%C3%A1nky)


[ ![](https://cs.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedie](https://cs.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-cs.svg) ![Wikipedie: Otevřená encyklopedie](https://cs.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-cs.svg) ](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana)
[Hledání ](https://cs.wikipedia.org/wiki/Speci%C3%A1ln%C3%AD:Hled%C3%A1n%C3%AD "Prohledat tuto wiki \[alt-f\]")
Hledat
Vzhled
Vzhled
přesunout do postranního panelu skrýt
Písmo
  * Malé
Standardní
Velké

Tato stránka vždy používá malé písmo.
Šířka
  * Běžné
Široké

Obsah je nejširší možný pro vaše okno prohlížeče.
  * [Podpořte Wikipedii](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=cs.wikipedia.org&uselang=cs)
  * [Vytvoření účtu](https://cs.wikipedia.org/w/index.php?title=Speci%C3%A1ln%C3%AD:Vytvo%C5%99it_%C3%BA%C4%8Det&returnto=Hlavn%C3%AD+strana "Doporučujeme vytvořit si účet a přihlásit se, ovšem není to povinné")
  * [Přihlášení](https://cs.wikipedia.org/w/index.php?title=Speci%C3%A1ln%C3%AD:P%C5%99ihl%C3%A1sit&returnto=Hlavn%C3%AD+strana "Doporučujeme vám přihlásit se, ovšem není to povinné. \[alt-o\]")


Osobní nástroje
  * [Podpořte Wikipedii](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=cs.wikipedia.org&uselang=cs)
  * [Vytvoření účtu](https://cs.wikipedia.org/w/index.php?title=Speci%C3%A1ln%C3%AD:Vytvo%C5%99it_%C3%BA%C4%8Det&returnto=Hlavn%C3%AD+strana "Doporučujeme vytvořit si účet a přihlásit se, ovšem není to povinné")
  * [Přihlášení](https://cs.wikipedia.org/w/index.php?title=Speci%C3%A1ln%C3%AD:P%C5%99ihl%C3%A1sit&returnto=Hlavn%C3%AD+strana "Doporučujeme vám přihlásit se, ovšem není to povinné. \[alt-o\]")


[ Wiki Loves Earth Zapojte se do Czech Wiki Photo 2025 a vyhrajte skvělé ceny! ](https://commons.wikimedia.org/wiki/Commons:Czech_Wiki_Photo)
[ ![Skrýt](https://upload.wikimedia.org/wikipedia/foundation/2/20/CloseWindow19x19.png) ](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Skrýt")
# Hlavní strana
  * [Hlavní strana](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Zobrazit obsahovou stránku \[alt-c\]")
  * [Diskuse](https://cs.wikipedia.org/wiki/Diskuse:Hlavn%C3%AD_strana "Diskuse ke stránce \[alt-t\]")


čeština
  * [Číst](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana)
  * [Zobrazit zdroj](https://cs.wikipedia.org/w/index.php?title=Hlavn%C3%AD_strana&action=edit "Tato stránka je zamčena. Můžete si prohlédnout její zdrojový kód. \[alt-e\]")
  * [Zobrazit historii](https://cs.wikipedia.org/w/index.php?title=Hlavn%C3%AD_strana&action=history "Starší verze této stránky. \[alt-h\]")


Nástroje
Nástroje
přesunout do postranního panelu skrýt
Akce 
  * [Číst](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana)
  * [Zobrazit zdroj](https://cs.wikipedia.org/w/index.php?title=Hlavn%C3%AD_strana&action=edit)
  * [Zobrazit historii](https://cs.wikipedia.org/w/index.php?title=Hlavn%C3%AD_strana&action=history)


Obecné 
  * [Odkazuje sem](https://cs.wikipedia.org/wiki/Speci%C3%A1ln%C3%AD:Co_odkazuje_na/Hlavn%C3%AD_strana "Seznam všech wikistránek, které sem odkazují \[alt-j\]")
  * [Související změny](https://cs.wikipedia.org/wiki/Speci%C3%A1ln%C3%AD:Souvisej%C3%ADc%C3%AD_zm%C4%9Bny/Hlavn%C3%AD_strana "Nedávné změny stránek, na které je odkazováno \[alt-k\]")
  * [Načíst soubor](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=cs "Nahrát obrázky či jiná multimédia \[alt-u\]")
  * [Trvalý odkaz](https://cs.wikipedia.org/w/index.php?title=Hlavn%C3%AD_strana&oldid=21091310 "Trvalý odkaz na současnou verzi této stránky")
  * [Informace o stránce](https://cs.wikipedia.org/w/index.php?title=Hlavn%C3%AD_strana&action=info "Více informací o této stránce")
  * [Citovat stránku](https://cs.wikipedia.org/w/index.php?title=Speci%C3%A1ln%C3%AD:Citovat&page=Hlavn%C3%AD_strana&id=21091310&wpFormIdentifier=titleform "Informace o tom, jak citovat tuto stránku")
  * [Získat zkrácené URL](https://cs.wikipedia.org/w/index.php?title=Speci%C3%A1ln%C3%AD:UrlShortener&url=https%3A%2F%2Fcs.wikipedia.org%2Fwiki%2FHlavn%25C3%25AD_strana)
  * [Stáhnout QR kód](https://cs.wikipedia.org/w/index.php?title=Speci%C3%A1ln%C3%AD:QrCode&url=https%3A%2F%2Fcs.wikipedia.org%2Fwiki%2FHlavn%25C3%25AD_strana)
  * [Editovat mezijazykové odkazy](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Editovat mezijazykové odkazy")


Tisk/export 
  * [Vytvořit knihu](https://cs.wikipedia.org/w/index.php?title=Speci%C3%A1ln%C3%AD:Kniha&bookcmd=book_creator&referer=Hlavn%C3%AD+strana)
  * [Stáhnout jako PDF](https://cs.wikipedia.org/w/index.php?title=Speci%C3%A1ln%C3%AD:DownloadAsPdf&page=Hlavn%C3%AD_strana&action=show-download-screen)
  * [Verze k tisku](https://cs.wikipedia.org/w/index.php?title=Hlavn%C3%AD_strana&printable=yes "Tato stránka v podobě vhodné k tisku \[alt-p\]")


Na jiných projektech 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Vícejazyčné Wikizdroje](https://wikisource.org/wiki/Main_Page)
  * [Wikidruhy](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikiknihy](https://cs.wikibooks.org/wiki/Wikiknihy:Hlavn%C3%AD_strana)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunkce](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikizprávy](https://cs.wikinews.org/wiki/Wikizpr%C3%A1vy:Hlavn%C3%AD_strana)
  * [Wikicitáty](https://cs.wikiquote.org/wiki/Wikicit%C3%A1ty:Hlavn%C3%AD_strana)
  * [Wikizdroje](https://cs.wikisource.org/wiki/Wikizdroje:Hlavn%C3%AD_strana)
  * [Wikiverzita](https://cs.wikiversity.org/wiki/Wikiverzita:Hlavn%C3%AD_strana)
  * [Wikicesty](https://cs.wikivoyage.org/wiki/Hlavn%C3%AD_strana)
  * [Wikislovník](https://cs.wiktionary.org/wiki/Wikislovn%C3%ADk:Hlavn%C3%AD_strana)
  * [Položka Wikidat](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Odkaz na propojenou položku datového úložiště \[alt-g\]")


Z Wikipedie, otevřené encyklopedie
[Vítejte ve Wikipedii](https://cs.wikipedia.org/wiki/Wikipedie:Pr%C5%AFvodce "Wikipedie:Průvodce"),
internetové [encyklopedii](https://cs.wikipedia.org/wiki/Encyklopedie "Encyklopedie"), kterou může [upravovat každý](https://cs.wikipedia.org/wiki/N%C3%A1pov%C4%9Bda:%C3%9Avod "Nápověda:Úvod").  
[Česká Wikipedie](https://cs.wikipedia.org/wiki/%C4%8Cesk%C3%A1_Wikipedie "Česká Wikipedie") má nyní **[577 819](https://cs.wikipedia.org/wiki/Speci%C3%A1ln%C3%AD:Statistika "Speciální:Statistika")** [článků](https://cs.wikipedia.org/wiki/Speci%C3%A1ln%C3%AD:Nov%C3%A9_str%C3%A1nky "Speciální:Nové stránky").
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/Other_languages_icon.svg/120px-Other_languages_icon.svg.png)  
[Jiné jazyky](https://cs.wikipedia.org/wiki/Wikipedie:Seznam_jazyk%C5%AF_Wikipedie "Wikipedie:Seznam jazyků Wikipedie")  
[Embassy](https://cs.wikipedia.org/wiki/Wikipedie:Velvyslanectv%C3%AD "Wikipedie:Velvyslanectví")
[Článek týdne](https://cs.wikipedia.org/wiki/Wikipedie:%C4%8Cl%C3%A1nek_t%C3%BDdne "Wikipedie:Článek týdne")
[![Pohlednice Kunratic z roku 1911](https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/Kunratice_u_Fr%C3%BDdlantu_1911.jpg/120px-Kunratice_u_Fr%C3%BDdlantu_1911.jpg)](https://commons.wikimedia.org/wiki/File:Kunratice_u_Fr%C3%BDdlantu_1911.jpg "Pohlednice Kunratic z roku 1911")Pohlednice Kunratic z roku 1911
**[Kunratice](https://cs.wikipedia.org/wiki/Kunratice_\(okres_Liberec\) "Kunratice \(okres Liberec\)")** jsou vesnice na severu [České republiky](https://cs.wikipedia.org/wiki/%C4%8Cesko "Česko"), ve [Frýdlantském výběžku](https://cs.wikipedia.org/wiki/Fr%C3%BDdlantsk%C3%BD_v%C3%BDb%C4%9B%C5%BEek "Frýdlantský výběžek") [Libereckého kraje](https://cs.wikipedia.org/wiki/Libereck%C3%BD_kraj "Liberecký kraj"), v [okrese Liberec](https://cs.wikipedia.org/wiki/Okres_Liberec "Okres Liberec"). Od krajského města [Liberec](https://cs.wikipedia.org/wiki/Liberec "Liberec") jsou vzdáleny 17 kilometrů severozápadním směrem. Žije zde 344 obyvatel. Katastr obce je součástí [geomorfologické provincie](https://cs.wikipedia.org/wiki/Geomorfologick%C3%A1_provincie "Geomorfologická provincie") [Česká vysočina](https://cs.wikipedia.org/wiki/%C4%8Cesk%C3%A1_vyso%C4%8Dina "Česká vysočina") a po jeho severní straně zde protéká řeka [Smědá](https://cs.wikipedia.org/wiki/Sm%C4%9Bd%C3%A1 "Smědá"), jejímž zdejším přítokem je Kunratický potok. 
Obec vznikla při obchodní cestě z východu do [Žitavy](https://cs.wikipedia.org/wiki/%C5%BDitava "Žitava") a rozvíjela se až do [třicetileté války](https://cs.wikipedia.org/wiki/T%C5%99icetilet%C3%A1_v%C3%A1lka "Třicetiletá válka"), po níž v rámci [rekatolizace](https://cs.wikipedia.org/wiki/Rekatolizace "Rekatolizace") část obyvatel odešla do sousední [Lužice](https://cs.wikipedia.org/wiki/Lu%C5%BEice "Lužice"). V závěru 18. století se Kunratice několikrát připojily na stranu revoltujících proti [robotě](https://cs.wikipedia.org/wiki/Robota "Robota"), avšak povstání byla vždy potlačena. Na počátku 19. století došlo nedaleko v lokalitě zvané Tongrund k ozbrojenému konfliktu mezi [Napoleonovou](https://cs.wikipedia.org/wiki/Napoleon_Bonaparte "Napoleon Bonaparte") a [habsburskou armádou](https://cs.wikipedia.org/wiki/C%C3%ADsa%C5%99sk%C3%A1_arm%C3%A1da_\(habsbursk%C3%A1\) "Císařská armáda \(habsburská\)"), ve kterém se povedlo francouzské útočníky porazit. 
Na přelomu 19. a 20. století v obci fungovala výrobna ovocných džemů a šťáv, cihelna a šamotka. Mezi lety 1900 a 1976 byla dostupná [železničním spojením](https://cs.wikipedia.org/wiki/%C5%BDelezni%C4%8Dn%C3%AD_tra%C5%A5_Fr%C3%BDdlant_v_%C4%8Cech%C3%A1ch_%E2%80%93_He%C5%99manice "Železniční trať Frýdlant v Čechách – Heřmanice"). V polovině 20. století však poklesl vlivem [druhé světové války](https://cs.wikipedia.org/wiki/Druh%C3%A1_sv%C4%9Btov%C3%A1_v%C3%A1lka "Druhá světová válka") a následného [odsunu Němců](https://cs.wikipedia.org/wiki/Vys%C3%ADdlen%C3%AD_N%C4%9Bmc%C5%AF_z_%C4%8Ceskoslovenska "Vysídlení Němců z Československa") počet obyvatel, mezi roky 1980 a 1992 se obec stala součástí sousedního [Frýdlantu](https://cs.wikipedia.org/wiki/Fr%C3%BDdlant "Frýdlant"). Počínaje rokem 2013 se v Kunraticích v odkazu na někdejší průmyslový podnik pořádá mezinárodní [JamParáda](https://cs.wikipedia.org/wiki/JamPar%C3%A1da "JamParáda"), soutěž ve výrobě [zavařenin](https://cs.wikipedia.org/wiki/Zava%C5%99enina "Zavařenina").
[Nejlepší články](https://cs.wikipedia.org/wiki/Wikipedie:Nejlep%C5%A1%C3%AD_%C4%8Dl%C3%A1nky "Wikipedie:Nejlepší články") • [Dobré články](https://cs.wikipedia.org/wiki/Wikipedie:Dobr%C3%A9_%C4%8Dl%C3%A1nky "Wikipedie:Dobré články") • [Další články týdne…](https://cs.wikipedia.org/wiki/Wikipedie:%C4%8Cl%C3%A1nek_t%C3%BDdne/2025 "Wikipedie:Článek týdne/2025")
[Víte, že…](https://cs.wikipedia.org/wiki/Wikipedie:Zaj%C3%ADmavosti "Wikipedie:Zajímavosti")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/da/Ouroborus_cataphractus01.jpg/120px-Ouroborus_cataphractus01.jpg)](https://commons.wikimedia.org/wiki/File:Ouroborus_cataphractus01.jpg)
  * … **[kruhochvost štítnatý](https://cs.wikipedia.org/wiki/Kruhochvost_%C5%A1t%C3%ADtnat%C3%BD "Kruhochvost štítnatý")** se při obraně stočí do kruhu a chytne se za ocas _(na obrázku)_?
  * … malíř **[Max Ernst](https://cs.wikipedia.org/wiki/Max_Ernst "Max Ernst")** hrál náčelníka banditů v Buñuelově filmu _[Zlatý věk](https://cs.wikipedia.org/wiki/Zlat%C3%BD_v%C4%9Bk_\(film,_1930\) "Zlatý věk \(film, 1930\)")_?
  * … první česká filmová režisérka **[Olga Rautenkranzová](https://cs.wikipedia.org/wiki/Olga_Rautenkranzov%C3%A1 "Olga Rautenkranzová")** byla vnučkou advokáta a politika [Vavřince Svátka](https://cs.wikipedia.org/wiki/Vav%C5%99inec_Sv%C3%A1tek "Vavřinec Svátek")?
  * … **[tholiny](https://cs.wikipedia.org/wiki/Tholin "Tholin")** jsou zodpovědné za okrovou atmosféru [Titanu](https://cs.wikipedia.org/wiki/Titan_\(m%C4%9Bs%C3%ADc\) "Titan \(měsíc\)") nebo načervenalý povrch [Pluta](https://cs.wikipedia.org/wiki/Pluto_\(trpasli%C4%8D%C3%AD_planeta\) "Pluto \(trpasličí planeta\)") a jeho měsíce [Charona](https://cs.wikipedia.org/wiki/Charon_\(m%C4%9Bs%C3%ADc\) "Charon \(měsíc\)")?


[Další zajímavosti…](https://cs.wikipedia.org/wiki/Wikipedie:Zaj%C3%ADmavosti/2025 "Wikipedie:Zajímavosti/2025")
[Listování kategoriemi](https://cs.wikipedia.org/wiki/Kategorie:Hlavn%C3%AD_kategorie "Kategorie:Hlavní kategorie")
  * **[Články podle témat](https://cs.wikipedia.org/wiki/Kategorie:%C4%8Cl%C3%A1nky_podle_t%C3%A9mat "Kategorie:Články podle témat")**
  * [Čas](https://cs.wikipedia.org/wiki/Kategorie:%C4%8Cas "Kategorie:Čas")
  * [Dorozumívání](https://cs.wikipedia.org/wiki/Kategorie:Dorozum%C3%ADv%C3%A1n%C3%AD "Kategorie:Dorozumívání")
  * [Geografie](https://cs.wikipedia.org/wiki/Kategorie:Geografie "Kategorie:Geografie")
  * [Historie](https://cs.wikipedia.org/wiki/Kategorie:Historie "Kategorie:Historie")
  * [Informace](https://cs.wikipedia.org/wiki/Kategorie:Informace "Kategorie:Informace")
  * [Kultura](https://cs.wikipedia.org/wiki/Kategorie:Kultura "Kategorie:Kultura")
  * [Lidé](https://cs.wikipedia.org/wiki/Kategorie:Lid%C3%A9 "Kategorie:Lidé")
  * [Matematika](https://cs.wikipedia.org/wiki/Kategorie:Matematika "Kategorie:Matematika")
  * [Politika](https://cs.wikipedia.org/wiki/Kategorie:Politika "Kategorie:Politika")
  * [Právo](https://cs.wikipedia.org/wiki/Kategorie:Pr%C3%A1vo "Kategorie:Právo")
  * [Příroda](https://cs.wikipedia.org/wiki/Kategorie:P%C5%99%C3%ADroda "Kategorie:Příroda")
  * [Rekordy](https://cs.wikipedia.org/wiki/Kategorie:Rekordy "Kategorie:Rekordy")
  * [Společnost](https://cs.wikipedia.org/wiki/Kategorie:Spole%C4%8Dnost "Kategorie:Společnost")
  * [Sport](https://cs.wikipedia.org/wiki/Kategorie:Sport "Kategorie:Sport")
  * [Technika](https://cs.wikipedia.org/wiki/Kategorie:Technika "Kategorie:Technika")
  * [Umění](https://cs.wikipedia.org/wiki/Kategorie:Um%C4%9Bn%C3%AD "Kategorie:Umění")
  * [Věda](https://cs.wikipedia.org/wiki/Kategorie:V%C4%9Bda "Kategorie:Věda")
  * [Vojenství](https://cs.wikipedia.org/wiki/Kategorie:Vojenstv%C3%AD "Kategorie:Vojenství")
  * [Vzdělávání](https://cs.wikipedia.org/wiki/Kategorie:Vzd%C4%9Bl%C3%A1v%C3%A1n%C3%AD "Kategorie:Vzdělávání")
  * [Zdravotnictví](https://cs.wikipedia.org/wiki/Kategorie:Zdravotnictv%C3%AD "Kategorie:Zdravotnictví")
  * [Život](https://cs.wikipedia.org/wiki/Kategorie:%C5%BDivot "Kategorie:Život")
  * **[Seznamy](https://cs.wikipedia.org/wiki/Kategorie:Seznamy "Kategorie:Seznamy")**


[Všechny kategorie…](https://cs.wikipedia.org/wiki/Speci%C3%A1ln%C3%AD:Kategorie "Speciální:Kategorie")
[Tematické portály](https://cs.wikipedia.org/wiki/Port%C3%A1l:Obsah "Portál:Obsah")
  * **Hlavní témata**
  * [Historie](https://cs.wikipedia.org/wiki/Port%C3%A1l:Historie "Portál:Historie")
  * [Geografie](https://cs.wikipedia.org/wiki/Port%C3%A1l:Geografie "Portál:Geografie")
  * [Příroda](https://cs.wikipedia.org/wiki/Port%C3%A1l:P%C5%99%C3%ADroda "Portál:Příroda")
  * [Doprava](https://cs.wikipedia.org/wiki/Port%C3%A1l:Doprava "Portál:Doprava")
  * [Lidé](https://cs.wikipedia.org/wiki/Port%C3%A1l:Lid%C3%A9 "Portál:Lidé")
  * [Kultura](https://cs.wikipedia.org/wiki/Port%C3%A1l:Kultura "Portál:Kultura")
  * [Náboženství](https://cs.wikipedia.org/wiki/Port%C3%A1l:N%C3%A1bo%C5%BEenstv%C3%AD "Portál:Náboženství")
  * [Sport](https://cs.wikipedia.org/wiki/Port%C3%A1l:Sport "Portál:Sport")


[Dobré portály](https://cs.wikipedia.org/wiki/Wikipedie:Dobr%C3%A9_%C4%8Dl%C3%A1nky#Port%C3%A1ly "Wikipedie:Dobré články") • [Všechny portály…](https://cs.wikipedia.org/wiki/Port%C3%A1l:Obsah "Portál:Obsah")
[Wikipedie](https://cs.wikipedia.org/wiki/Wikipedie:Port%C3%A1l_Wikipedie "Wikipedie:Portál Wikipedie")
  * **O nás**
  * [Česká Wikipedie](https://cs.wikipedia.org/wiki/%C4%8Cesk%C3%A1_Wikipedie "Česká Wikipedie")
  * [Diskuse o Wikipedii](https://cs.wikipedia.org/wiki/Wikipedie:Pod_l%C3%ADpou "Wikipedie:Pod lípou")
  * [Spolek Wikimedia ČR](https://cs.wikipedia.org/wiki/Wikimedia_%C4%8Cesk%C3%A1_republika "Wikimedia Česká republika")
  * [Kontakt](https://cs.wikipedia.org/wiki/Wikipedie:Kontakt "Wikipedie:Kontakt")
  * [Jak citovat Wikipedii](https://cs.wikipedia.org/wiki/Wikipedie:Citov%C3%A1n%C3%AD_Wikipedie "Wikipedie:Citování Wikipedie")


  * **Pomozte vylepšit**
  * [Často čtené texty nižší kvality](https://cs.wikipedia.org/wiki/Wikipedie:WikiProjekt_Kvalita/%C4%8Cl%C3%A1nky_k_roz%C5%A1%C3%AD%C5%99en%C3%AD "Wikipedie:WikiProjekt Kvalita/Články k rozšíření")
  * [Další nedodělané články](https://cs.wikipedia.org/wiki/Wikipedie:%C3%9Adr%C5%BEba "Wikipedie:Údržba")
  * [Chybějící články](https://cs.wikipedia.org/wiki/Wikipedie:Po%C5%BEadovan%C3%A9_%C4%8Dl%C3%A1nky "Wikipedie:Požadované články")


  * **Podpora**
  * [Úvod pro nováčky](https://cs.wikipedia.org/wiki/N%C3%A1pov%C4%9Bda:%C3%9Avod_pro_nov%C3%A1%C4%8Dky "Nápověda:Úvod pro nováčky")
  * [Řekněte si o pomoc](https://cs.wikipedia.org/wiki/Wikipedie:Pot%C5%99ebuji_pomoc "Wikipedie:Potřebuji pomoc")
  * [Zdroje informací](https://cs.wikipedia.org/wiki/Wikipedie:Zdroje_informac%C3%AD "Wikipedie:Zdroje informací")
  * [Často kladené otázky](https://cs.wikipedia.org/wiki/Wikipedie:%C4%8Casto_kladen%C3%A9_ot%C3%A1zky "Wikipedie:Často kladené otázky")
  * [Časté chyby](https://cs.wikipedia.org/wiki/Wikipedie:%C4%8Cast%C3%A9_chyby "Wikipedie:Časté chyby")


[Další nápověda…](https://cs.wikipedia.org/wiki/N%C3%A1pov%C4%9Bda:Obsah "Nápověda:Obsah")
[Ostatní projekty](https://cs.wikipedia.org/wiki/Nadace_Wikimedia "Nadace Wikimedia")
Wikipedii provozuje nezisková [nadace Wikimedia](https://cs.wikipedia.org/wiki/Nadace_Wikimedia "Nadace Wikimedia"), která spravuje i řadu dalších otevřených mnohojazyčných [wiki](https://cs.wikipedia.org/wiki/Wiki "Wiki") projektů: 
[![logo Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/20px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/Hlavn%C3%AD_strana "logo Wikimedia Commons")
**[Commons](https://commons.wikimedia.org/wiki/Hlavn%C3%AD_strana "commons:Hlavní strana")** • úložiště médií 
[![logo Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/20px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/Wikidata:Hlavn%C3%AD_strana "logo Wikidata")
**[Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page "d:Wikidata:Main Page")** • databáze vědomostí 
[![logo Wikislovník](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Notification-icon-Wiktionary-logo.svg/20px-Notification-icon-Wiktionary-logo.svg.png)](https://cs.wiktionary.org/wiki/Wikislovn%C3%ADk:Hlavn%C3%AD_strana "logo Wikislovník")
**[Wikislovník](https://cs.wiktionary.org/wiki/Wikislovn%C3%ADk:Hlavn%C3%AD_strana "wikt:Wikislovník:Hlavní strana")** • výkladový slovník 
[![logo Wikizdroje](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/20px-Wikisource-logo.svg.png)](https://cs.wikisource.org/wiki/Wikizdroje:Hlavn%C3%AD_strana "logo Wikizdroje")
**[Wikizdroje](https://cs.wikisource.org/wiki/Wikizdroje:Hlavn%C3%AD_strana "s:Wikizdroje:Hlavní strana")** • původní dokumenty 
[![logo Wikicitáty](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/20px-Wikiquote-logo.svg.png)](https://cs.wikiquote.org/wiki/Wikicit%C3%A1ty:Hlavn%C3%AD_strana "logo Wikicitáty")
**[Wikicitáty](https://cs.wikiquote.org/wiki/Wikicit%C3%A1ty:Hlavn%C3%AD_strana "q:Wikicitáty:Hlavní strana")** • sbírka citátů 
[![logo Wikiknihy](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/20px-Wikibooks-logo.svg.png)](https://cs.wikibooks.org/wiki/Wikiknihy:Hlavn%C3%AD_strana "logo Wikiknihy")
**[Wikiknihy](https://cs.wikibooks.org/wiki/Wikiknihy:Hlavn%C3%AD_strana "b:Wikiknihy:Hlavní strana")** • knihy a manuály 
[![logo Wikizprávy](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/20px-Wikinews-logo.svg.png)](https://cs.wikinews.org/wiki/Wikizpr%C3%A1vy:Hlavn%C3%AD_strana "logo Wikizprávy")
**[Wikizprávy](https://cs.wikinews.org/wiki/Wikizpr%C3%A1vy:Hlavn%C3%AD_strana "n:Wikizprávy:Hlavní strana")** • zpravodajství 
[![logo Wikiverzita](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/20px-Wikiversity_logo_2017.svg.png)](https://cs.wikiversity.org/wiki/Wikiverzita:Hlavn%C3%AD_strana "logo Wikiverzita")
**[Wikiverzita](https://cs.wikiversity.org/wiki/Wikiverzita:Hlavn%C3%AD_strana "v:Wikiverzita:Hlavní strana")** • vzdělávací nástroje 
[![logo Wikidruhy](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/20px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/Hlavn%C3%AD_strana "logo Wikidruhy")
**[Wikidruhy](https://species.wikimedia.org/wiki/Hlavn%C3%AD_strana "wikispecies:Hlavní strana")** • biologický adresář 
[![logo Wikicesty](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/20px-Wikivoyage-Logo-v3-icon.svg.png)](https://cs.wikivoyage.org/wiki/Hlavn%C3%AD_strana "logo Wikicesty")
**[Wikicesty](https://cs.wikivoyage.org/wiki/Wikicesty:Hlavn%C3%AD_strana "voy:Wikicesty:Hlavní strana")** • cestovní průvodce 
[![logo Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/20px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/Hlavn%C3%AD_strana "logo Meta-Wiki")
**[Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page/cs "m:Main Page/cs")** • koordinace projektů 
[![logo MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/20px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/Hlavn%C3%AD_strana "logo MediaWiki")
**[MediaWiki](https://www.mediawiki.org/wiki/MediaWiki "mw:MediaWiki")** • wiki software 
[![logo Wikifunctions](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Wikifunctions-logo.svg/20px-Wikifunctions-logo.svg.png)](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page "logo Wikifunctions")
**[Wikifunkce](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page "wikifunctions:Wikifunctions:Main Page")** • repozitář kódu 
[Další informace…](https://cs.wikipedia.org/wiki/Nadace_Wikimedia "Nadace Wikimedia")
[Obrázek týdne](https://cs.wikipedia.org/wiki/Wikipedie:Obr%C3%A1zek_t%C3%BDdne "Wikipedie:Obrázek týdne")
[![Tygří hnízdo je buddhistický klášter u bhútánského města Paro](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Paro_Taktsang%2C_Bhutan_%28edited%29.jpg/500px-Paro_Taktsang%2C_Bhutan_%28edited%29.jpg)](https://commons.wikimedia.org/wiki/File:Paro_Taktsang,_Bhutan_\(edited\).jpg "Tygří hnízdo je buddhistický klášter u bhútánského města Paro")Tygří hnízdo je buddhistický klášter u bhútánského města Paro
[Tygří hnízdo](https://cs.wikipedia.org/wiki/Tyg%C5%99%C3%AD_hn%C3%ADzdo "Tygří hnízdo") je [buddhistický](https://cs.wikipedia.org/wiki/Buddhismus "Buddhismus") [klášter](https://cs.wikipedia.org/wiki/Kl%C3%A1%C5%A1ter#Buddhistick%C3%A9_kl%C3%A1%C5%A1tery "Klášter") u [bhútánského](https://cs.wikipedia.org/wiki/Bh%C3%BAt%C3%A1n "Bhútán") města [Paro](https://cs.wikipedia.org/wiki/Paro "Paro")
[Nejlepší obrázky](https://commons.wikimedia.org/wiki/Commons:Featured_pictures/cs "commons:Commons:Featured pictures/cs") • [Další obrázky týdne…](https://cs.wikipedia.org/wiki/Wikipedie:Obr%C3%A1zek_t%C3%BDdne/2025 "Wikipedie:Obrázek týdne/2025")
[Aktuality](https://cs.wikipedia.org/wiki/Port%C3%A1l:Aktuality "Portál:Aktuality")
  * **[Válka na Ukrajině](https://cs.wikipedia.org/wiki/Rusk%C3%A1_invaze_na_Ukrajinu "Ruská invaze na Ukrajinu")** ([časová osa](https://cs.wikipedia.org/wiki/%C4%8Casov%C3%A1_osa_rusk%C3%A9_invaze_na_Ukrajinu_\(2025\) "Časová osa ruské invaze na Ukrajinu \(2025\)"))
  * **[Válka v Pásmu Gazy](https://cs.wikipedia.org/wiki/V%C3%A1lka_v_P%C3%A1smu_Gazy "Válka v Pásmu Gazy")** ([časová osa](https://cs.wikipedia.org/wiki/%C4%8Casov%C3%A1_osa_v%C3%A1lky_v_P%C3%A1smu_Gazy "Časová osa války v Pásmu Gazy") • [hladomor](https://cs.wikipedia.org/wiki/Hladomor_v_P%C3%A1smu_Gazy "Hladomor v Pásmu Gazy"))
  * **[Súdánská válka](https://cs.wikipedia.org/wiki/S%C3%BAd%C3%A1nsk%C3%A1_v%C3%A1lka "Súdánská válka")**


* * * 

[29. září](https://cs.wikipedia.org/wiki/29._z%C3%A1%C5%99%C3%AD "29. září") – pondělí
     [![Moldavsko](https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Flag_of_Moldova.svg/40px-Flag_of_Moldova.svg.png)](https://cs.wikipedia.org/wiki/Moldavsko "Moldavsko") [Parlamentní volby](https://cs.wikipedia.org/wiki/Parlamentn%C3%AD_volby_v_Moldavsku_2025 "Parlamentní volby v Moldavsku 2025") v [Moldavsku](https://cs.wikipedia.org/wiki/Moldavsko "Moldavsko") vyhrála prozápadní [strana PAS](https://cs.wikipedia.org/wiki/Strana_akce_a_solidarity "Strana akce a solidarity") prezidentky [Maii Sanduové](https://cs.wikipedia.org/wiki/Maia_Sanduov%C3%A1 "Maia Sanduová"). 

[25. září](https://cs.wikipedia.org/wiki/25._z%C3%A1%C5%99%C3%AD "25. září") – čtvrtek
     [![Polsko](https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Flag_of_Poland.svg/40px-Flag_of_Poland.svg.png)](https://cs.wikipedia.org/wiki/Polsko "Polsko")[![Nepál](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Flag_of_Nepal.svg/20px-Flag_of_Nepal.svg.png)](https://cs.wikipedia.org/wiki/Nep%C3%A1l "Nepál") Polský [skialpinista](https://cs.wikipedia.org/wiki/Skialpinismus "Skialpinismus") [Andrzej Bargiel](https://cs.wikipedia.org/w/index.php?title=Andrzej_Bargiel&action=edit&redlink=1 "Andrzej Bargiel \(stránka neexistuje\)") se stal prvním člověkem na světě, který vystoupal bez kyslíku na vrchol [Mount Everestu](https://cs.wikipedia.org/wiki/Mount_Everest "Mount Everest") a poté z něj sjel na lyžích až do základního tábora pod [ledovcem Khumbu](https://cs.wikipedia.org/wiki/Khumbu_\(ledovec\) "Khumbu \(ledovec\)"). 

[23. září](https://cs.wikipedia.org/wiki/23._z%C3%A1%C5%99%C3%AD "23. září") – středa
     [![Čína](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Flag_of_the_People%27s_Republic_of_China.svg/40px-Flag_of_the_People%27s_Republic_of_China.svg.png)](https://cs.wikipedia.org/wiki/%C4%8C%C3%ADna "Čína")[![Tchaj-wan](https://upload.wikimedia.org/wikipedia/commons/thumb/7/72/Flag_of_the_Republic_of_China.svg/40px-Flag_of_the_Republic_of_China.svg.png)](https://cs.wikipedia.org/wiki/Tchaj-wan "Tchaj-wan")[![Filipíny](https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Flag_of_the_Philippines.svg/40px-Flag_of_the_Philippines.svg.png)](https://cs.wikipedia.org/wiki/Filip%C3%ADny "Filipíny") [Tajfun](https://cs.wikipedia.org/wiki/Tropick%C3%A1_cykl%C3%B3na "Tropická cyklóna") [Ragasa](https://cs.wikipedia.org/w/index.php?title=Tajfun_Ragasa&action=edit&redlink=1 "Tajfun Ragasa \(stránka neexistuje\)"), o rychlosti až 195 km/h, dorazil k břehům Číny a [Hongkongu](https://cs.wikipedia.org/wiki/Hongkong "Hongkong"), když předtím způsobil značné škody a úmrtí na [Filipínách](https://cs.wikipedia.org/wiki/Filip%C3%ADny "Filipíny") a [Tchaj-wanu](https://cs.wikipedia.org/wiki/Tchaj-wan "Tchaj-wan"). Na dva milióny lidí bylo evakuováno. 

[19. září](https://cs.wikipedia.org/wiki/19._z%C3%A1%C5%99%C3%AD "19. září") – pátek
     [![Česko](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Flag_of_the_Czech_Republic.svg/40px-Flag_of_the_Czech_Republic.svg.png)](https://cs.wikipedia.org/wiki/%C4%8Cesko "Česko") Na [lánském zámku](https://cs.wikipedia.org/wiki/L%C3%A1ny_\(z%C3%A1mek,_okres_Kladno\) "Lány \(zámek, okres Kladno\)") byla za účasti médií, archivářů a prezidenta [Petra Pavla](https://cs.wikipedia.org/wiki/Petr_Pavel "Petr Pavel") otevřena [obálka s „posledními slovy“](https://cs.wikipedia.org/wiki/Tom%C3%A1%C5%A1_Garrigue_Masaryk#Ob%C3%A1lka_v_N%C3%A1rodn%C3%ADm_archivu_%E2%80%93_%E2%80%9EPosledn%C3%AD_slova%E2%80%9C "Tomáš Garrigue Masaryk") prezidenta [T. G. Masaryka](https://cs.wikipedia.org/wiki/Tom%C3%A1%C5%A1_Garrigue_Masaryk "Tomáš Garrigue Masaryk"). 

[16. září](https://cs.wikipedia.org/wiki/16._z%C3%A1%C5%99%C3%AD "16. září") – úterý
     [![Izrael](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Flag_of_Israel.svg/40px-Flag_of_Israel.svg.png)](https://cs.wikipedia.org/wiki/Izrael "Izrael")[![Palestina](https://upload.wikimedia.org/wikipedia/commons/thumb/0/00/Flag_of_Palestine.svg/40px-Flag_of_Palestine.svg.png)](https://cs.wikipedia.org/wiki/St%C3%A1t_Palestina "Palestina") V rámci [války v Pásmu Gazy](https://cs.wikipedia.org/wiki/V%C3%A1lka_v_P%C3%A1smu_Gazy "Válka v Pásmu Gazy") zahájil Izrael [ofenzívu](https://cs.wikipedia.org/wiki/%C3%9Atok "Útok") s cílem [Gazu](https://cs.wikipedia.org/wiki/Gaza "Gaza") obsadit. 

[11. září](https://cs.wikipedia.org/wiki/11._z%C3%A1%C5%99%C3%AD "11. září") – čtvrtek
     [![Brazílie](https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Flag_of_Brazil.svg/40px-Flag_of_Brazil.svg.png)](https://cs.wikipedia.org/wiki/Braz%C3%ADlie "Brazílie") [Brazilský](https://cs.wikipedia.org/wiki/Braz%C3%ADlie "Brazílie") nejvyšší soud odsoudil bývalého [brazilského prezidenta](https://cs.wikipedia.org/wiki/Prezident_Braz%C3%ADlie "Prezident Brazílie") [Jaira Bolsonara](https://cs.wikipedia.org/wiki/Jair_Bolsonaro "Jair Bolsonaro") k 27 letům odnětí svobody za [pokus o státní převrat](https://cs.wikipedia.org/wiki/%C3%9Atok_na_Brazilsk%C3%BD_n%C3%A1rodn%C3%AD_kongres "Útok na Brazilský národní kongres").      [![Bělorusko](https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Flag_of_Belarus.svg/40px-Flag_of_Belarus.svg.png)](https://cs.wikipedia.org/wiki/B%C4%9Blorusko "Bělorusko")[![USA](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Flag_of_the_United_States.svg/40px-Flag_of_the_United_States.svg.png)](https://cs.wikipedia.org/wiki/Spojen%C3%A9_st%C3%A1ty_americk%C3%A9 "USA") [Bělorusko](https://cs.wikipedia.org/wiki/B%C4%9Blorusko "Bělorusko") propustilo 52 vězňů, [Spojené státy](https://cs.wikipedia.org/wiki/Spojen%C3%A9_st%C3%A1ty_americk%C3%A9 "Spojené státy americké") uvolní sankce uvalené na běloruskou leteckou společnost [Belavia](https://cs.wikipedia.org/wiki/Belavia "Belavia"). 

[10. září](https://cs.wikipedia.org/wiki/10._z%C3%A1%C5%99%C3%AD "10. září") – středa
     [![Polsko](https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Flag_of_Poland.svg/40px-Flag_of_Poland.svg.png)](https://cs.wikipedia.org/wiki/Polsko "Polsko")[![Rusko](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Flag_of_Russia.svg/40px-Flag_of_Russia.svg.png)](https://cs.wikipedia.org/wiki/Rusko "Rusko") Síly [NATO](https://cs.wikipedia.org/wiki/Severoatlantick%C3%A1_aliance "Severoatlantická aliance") [sestřelily](https://cs.wikipedia.org/wiki/Vniknut%C3%AD_rusk%C3%BDch_dron%C5%AF_do_Polska_10._z%C3%A1%C5%99%C3%AD_2025 "Vniknutí ruských dronů do Polska 10. září 2025") nejméně 8 ruských [bezpilotních letadel](https://cs.wikipedia.org/wiki/Bezpilotn%C3%AD_letadlo "Bezpilotní letadlo") narušujících [polský](https://cs.wikipedia.org/wiki/Polsko "Polsko") vzdušný prostor. Polsko následně aktivovalo článek 4 [Severoatlantické smlouvy](https://cs.wikipedia.org/wiki/Severoatlantick%C3%A1_smlouva "Severoatlantická smlouva").      [![USA](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Flag_of_the_United_States.svg/40px-Flag_of_the_United_States.svg.png)](https://cs.wikipedia.org/wiki/Spojen%C3%A9_st%C3%A1ty_americk%C3%A9 "USA")[![Utah](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Flag_of_Utah.svg/40px-Flag_of_Utah.svg.png)](https://cs.wikipedia.org/wiki/Utah "Utah") [Charlie Kirk](https://cs.wikipedia.org/wiki/Charlie_Kirk "Charlie Kirk"), mládežnický aktivista [Republikánské strany](https://cs.wikipedia.org/wiki/Republik%C3%A1nsk%C3%A1_strana_\(USA\) "Republikánská strana \(USA\)"), byl [zastřelen](https://cs.wikipedia.org/wiki/Atent%C3%A1t_na_Charlieho_Kirka "Atentát na Charlieho Kirka") ve městě [Orem](https://cs.wikipedia.org/wiki/Orem "Orem") v [Utahu](https://cs.wikipedia.org/wiki/Utah "Utah").
* * *
  * **Nedávná úmrtí**


  * [Jane Goodallová](https://cs.wikipedia.org/wiki/Jane_Goodallov%C3%A1 "Jane Goodallová") (91)
  * [Vitalij Korotyč](https://cs.wikipedia.org/wiki/Vitalij_Koroty%C4%8D "Vitalij Korotyč") (89)
  * [Jørgen Leth](https://cs.wikipedia.org/wiki/J%C3%B8rgen_Leth "Jørgen Leth") (88)
  * [Russell M. Nelson](https://cs.wikipedia.org/wiki/Russell_M._Nelson "Russell M. Nelson") (101)
  * [Tony Harrison](https://cs.wikipedia.org/wiki/Tony_Harrison "Tony Harrison") (88)
  * [Lucian Mureșan](https://cs.wikipedia.org/wiki/Lucian_Mure%C8%99an "Lucian Mureșan") (94)
  * [George F. Smoot](https://cs.wikipedia.org/wiki/George_F._Smoot "George F. Smoot") (80)
  * [Juraj Bartusz](https://cs.wikipedia.org/wiki/Juraj_Bartusz "Juraj Bartusz") (91)
  * [Danny Thompson](https://cs.wikipedia.org/wiki/Danny_Thompson "Danny Thompson") (86)


[Další aktuality…](https://cs.wikipedia.org/wiki/Port%C3%A1l:Aktuality "Portál:Aktuality")
[1. říjen v minulosti](https://cs.wikipedia.org/wiki/1._%C5%99%C3%ADjen "1. říjen")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/1975_MUHAMMAD_ALI_v_JOE_FRAZIER_III_THRILLA_IN_MANILA_AP_photo.jpg/120px-1975_MUHAMMAD_ALI_v_JOE_FRAZIER_III_THRILLA_IN_MANILA_AP_photo.jpg)](https://commons.wikimedia.org/wiki/File:1975_MUHAMMAD_ALI_v_JOE_FRAZIER_III_THRILLA_IN_MANILA_AP_photo.jpg)
  * 0[965](https://cs.wikipedia.org/wiki/965 "965") – Do úřadu byl uveden papež **[Jan XIII.](https://cs.wikipedia.org/wiki/Jan_XIII. "Jan XIII.")**
  * [1795](https://cs.wikipedia.org/wiki/1795 "1795") – [První Francouzská republika](https://cs.wikipedia.org/wiki/Prvn%C3%AD_Francouzsk%C3%A1_republika "První Francouzská republika") **anektovala[Rakouské Nizozemí](https://cs.wikipedia.org/wiki/Rakousk%C3%A9_Nizozem%C3%AD "Rakouské Nizozemí")** (dnešní [Belgii](https://cs.wikipedia.org/wiki/Belgie "Belgie")).
  * [1975](https://cs.wikipedia.org/wiki/1975 "1975") – **[Muhammad Ali](https://cs.wikipedia.org/wiki/Muhammad_Ali "Muhammad Ali")** _(na obrázku)_ v [Manile](https://cs.wikipedia.org/wiki/Manila "Manila") potřetí porazil [Joea Fraziera](https://cs.wikipedia.org/wiki/Joe_Frazier "Joe Frazier").
  * [1985](https://cs.wikipedia.org/wiki/1985 "1985") – **[Operace Dřevěná noha](https://cs.wikipedia.org/wiki/Operace_D%C5%99ev%C4%9Bn%C3%A1_noha "Operace Dřevěná noha")** : [Izraelské](https://cs.wikipedia.org/wiki/Izrael "Izrael") letouny bombardovaly [tuniskou](https://cs.wikipedia.org/wiki/Tunisko "Tunisko") centrálu [Organizace pro osvobození Palestiny](https://cs.wikipedia.org/wiki/Organizace_pro_osvobozen%C3%AD_Palestiny "Organizace pro osvobození Palestiny").
  * [2015](https://cs.wikipedia.org/wiki/2015 "2015") – Silné deště v [Guatemale](https://cs.wikipedia.org/wiki/Guatemala "Guatemala") vyvolaly **[mohutný sesuv půdy](https://cs.wikipedia.org/wiki/Sesuv_v_Guatemale_2015 "Sesuv v Guatemale 2015")** , zahynulo okolo 280 lidí.


* * *
  * [José Beyaert](https://cs.wikipedia.org/w/index.php?title=Jos%C3%A9_Beyaert&action=edit&redlink=1 "José Beyaert \(stránka neexistuje\)") (* [1925](https://cs.wikipedia.org/wiki/1925 "1925"))
  * [Benno Pludra](https://cs.wikipedia.org/wiki/Benno_Pludra "Benno Pludra") (* 1925)


[Další výročí…](https://cs.wikipedia.org/wiki/Wikipedie:Vybran%C3%A1_v%C3%BDro%C4%8D%C3%AD_dne/%C5%99%C3%ADjen "Wikipedie:Vybraná výročí dne/říjen")
Citováno z „[https://cs.wikipedia.org/w/index.php?title=Hlavní_strana&oldid=21091310](https://cs.wikipedia.org/w/index.php?title=Hlavn%C3%AD_strana&oldid=21091310)“
353 jazyků
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – afarština")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – abcházština")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – acehština")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – adygejština")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – afrikánština")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – němčina \(Švýcarsko\)")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – altajština \(jižní\)")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – amharština")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – aragonština")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – staroangličtina")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – obolo")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – angika")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – arabština")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – aramejština")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – arabština \(marocká\)")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – arabština \(egyptská\)")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – ásámština")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – asturština")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – atikamekština")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – avarština")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – awadhština")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – ajmarština")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – ázerbájdžánština")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – baškirština")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – balijština")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – bavorština")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – žemaitština")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – batak toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – běloruština")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – batavština")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница – bulharština")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – bislamština")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – bandžarština")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – bambarština")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – bengálština")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – tibetština")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – bišnuprijskomanipurština")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – bretonština")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – bosenština")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – bugiština")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – katalánština")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – čečenština")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – cebuánština")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – čamoro")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – čoktština")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – čerokézština")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – čejenština")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – kurdština \(sorání\)")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – korsičtina")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – kríjština")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – tatarština \(krymská\)")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – kašubština")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – staroslověnština")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – čuvaština")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – velština")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside – dánština")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – němčina")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – dinkština")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – dolnolužická srbština")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – kadazandusunština")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – maledivština")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – dzongkä")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – eweština")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – řečtina")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – angličtina")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – esperanto")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – španělština")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht – estonština")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala – baskičtina")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – extremadurština")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – perština")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – fantština")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – fulbština")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – finština")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – võruština")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – fidžijština")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – faerština")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – fonština")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal – francouzština")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – franko-provensálština")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – fríština \(severní\)")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – furlanština")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – fríština \(západní\)")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – irština")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – gagauzština")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – čínština \(dialekty Gan\)")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – skotská gaelština")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – galicijština")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – gilačtina")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – guaranština")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – gorontalo")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – gótština")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – gudžarátština")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – wayúuština")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – manština")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – hauština")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – čínština \(dialekty Hakka\)")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – havajština")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – hebrejština")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – hindština")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – hindština \(Fidži\)")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – hiri motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – chorvatština")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – hornolužická srbština")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – haitština")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – maďarština")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ – arménština")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – hererština")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – interlingua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – ibanština")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama – indonéština")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – interlingue")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – igboština")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – inupiakština")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – ilokánština")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – inguština")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – ido")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – islandština")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – italština")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – inuktitutština")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – japonština")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – jamajská kreolština")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – lojban")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – javánština")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – gruzínština")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – karakalpačtina")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – kabylština")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – kabardinština")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – tyap")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – konžština")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – kikujština")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – kuaňamština")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – kazaština")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – grónština")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – khmérština")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – kannadština")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – korejština")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – komi-permjačtina")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – kanuri")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – karačajevo-balkarština")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – kašmírština")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – kolínština")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – kurdština")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – komijština")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – kornština")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – kyrgyzština")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima – latina")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – ladinština")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – lucemburština")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – lezginština")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – lingua franca nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – gandština")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – limburština")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – ligurština")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – lombardština")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – lingalština")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – laoština")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – lúrština \(severní\)")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – litevština")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – latgalština")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – lotyština")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – madurština")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – maithiliština")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – mokšanština")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – malgaština")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – maršálština")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – maorština")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – minangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – makedonština")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – malajálamština")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – mongolština")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – manipurština")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – mosi")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – maráthština")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – marijština \(západní\)")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – malajština")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – maltština")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – kríkština")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – mirandština")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – barmština")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – erzjanština")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – mázandaránština")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – neapolština")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – dolnoněmčina")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – dolnosaština")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – nepálština")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – névárština")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – ndondština")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – nias")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina – nizozemština")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – norština \(nynorsk\)")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – norština \(bokmål\)")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – n’ko")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – ndebele \(Jižní Afrika\)")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – sotština \(severní\)")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – navažština")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – ňandžština")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – okcitánština")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – oromština")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – urijština")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – osetština")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – paňdžábština")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – pangasinanština")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – papangau")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – papiamento")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – picardština")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – nigerijský pidžin")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – němčina \(pensylvánská\)")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – falčtina")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – pálí")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – polština")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – piemonština")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – pontština")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – paštština")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – portugalština")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – kečuánština")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – rétorománština")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – kirundština")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – rumunština")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – arumunština")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – ruština")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – rusínština")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – kiňarwandština")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – sanskrt")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – jakutština")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – santálština")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – sardština")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – sicilština")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – skotština")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – sindhština")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – sámština \(severní\)")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – sangština")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – srbochorvatština")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – tašelhit")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – šanština")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – sinhálština")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – slovenština")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – slovinština")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – samojština")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – sámština \(inarijská\)")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – šonština")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – somálština")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – albánština")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – srbština")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – sranan tongo")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – siswatština")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – sotština \(jižní\)")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – fríština \(saterlandská\)")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – sundština")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – švédština")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – svahilština")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – slezština")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – tamilština")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – tuluština")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – telugština")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – tetumština")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – tádžičtina")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – thajština")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – tigrinijština")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – tigrejština")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – turkmenština")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – tagalog")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – talyština")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – setswanština")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – tongánština")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – tok pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – turečtina")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – taroko")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – tsonga")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – tatarština")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – tumbukština")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – twi")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – tahitština")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – tuvinština")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – udmurtština")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – ujgurština")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – ukrajinština")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – urdština")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – uzbečtina")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – venda")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – benátština")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – vepština")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – vietnamština")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – vlámština \(západní\)")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – volapük")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – valonština")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – warajština")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – wolofština")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – čínština \(dialekty Wu\)")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – kalmyčtina")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – xhoština")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – mingrelština")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – jidiš")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – jorubština")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – čuangština")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – zélandština")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – tamazight \(standardní marocký\)")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 – čínština")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – čínština \(klasická\)")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – čínština \(dialekty Minnan\)")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – kantonština")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – zuluština")


[Upravit odkazy](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Editovat mezijazykové odkazy")
  * Stránka byla naposledy editována 30. 3. 2022 v 11:26.
  * Text je dostupný pod [licencí Creative Commons Uveďte původ – Zachovejte licenci](https://creativecommons.org/licenses/by-sa/4.0/deed.cs), případně za dalších podmínek. Podrobnosti naleznete na stránce [Podmínky užití](https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/cs).


  * [Ochrana osobních údajů](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [O Wikipedii](https://cs.wikipedia.org/wiki/Wikipedie)
  * [Vyloučení odpovědnosti](https://cs.wikipedia.org/wiki/Wikipedie:Vylou%C4%8Den%C3%AD_odpov%C4%9Bdnosti)
  * [Kontaktujte Wikipedii](https://cs.wikipedia.org/wiki/Wikipedie:Kontakt)
  * [Kodex chování](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Vývojáři](https://developer.wikimedia.org)
  * [Statistiky](https://stats.wikimedia.org/#/cs.wikipedia.org)
  * [Prohlášení o cookies](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Mobilní verze](https://cs.m.wikipedia.org/w/index.php?title=Hlavn%C3%AD_strana&mobileaction=toggle_view_mobile)
  * [Upravit nastavení náhledů](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana)


  * [![Wikimedia Foundation](https://cs.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://cs.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Hledání
Hledat
Hlavní strana
[](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana) [](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana) [](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana) [](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana) [](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana) [](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana) [](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana) [](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana)
353 jazyků [Přidat téma ](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana)
