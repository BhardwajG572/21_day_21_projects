[跳至內容](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh#bodyContent)
Tsú-suán-tuann
Tsú-suán-tuann
移至側邊欄 Bih
Se̍h chām 
  * [Thâu-ia̍h](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Khì thâu-ia̍h​\[z\] \[alt-z\]")
  * [Bûn-chiuⁿ bo̍k-chhù](https://zh-min-nan.wikipedia.org/wiki/Tek-pia%CC%8Dt:%E5%85%A8%E9%83%A8%E9%A0%81%E9%9D%A2)
  * [Sûi-chāi kéng ia̍h](https://zh-min-nan.wikipedia.org/wiki/Tek-pia%CC%8Dt:%E9%9A%A8%E4%BE%BF%E5%85%B6%E9%A0%81%E9%9D%A2 "Chhìn-chhái hian chi̍t ia̍h​\[x\] \[alt-x\]")
  * [Sin-bûn sū-kiāⁿ](https://zh-min-nan.wikipedia.org/wiki/Sin-b%C3%BBn_s%C5%AB-ki%C4%81%E2%81%BF "Thê-kiong hiān-sî sin-bûn ê poē-kéng chu-liāu")


Pian-chi̍p 
  * [Soat-bêng](https://zh-min-nan.wikipedia.org/wiki/Pang-ch%C4%81n:Bo%CC%8Dk-lio%CC%8Dk "Sú-iōng ê pang-chān")
  * [Siā-lí mn̂g-chhùi-kháu](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:Si%C4%81-l%C3%AD_mn%CC%82g-chh%C3%B9i-kh%C3%A1u "Koan-hē chit ê sū-kang, lí ē-tāng chò siáⁿ, khì tó-ūi chhoé")
  * [Thó-lūn](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:Chhi%C5%AB-%C3%A1-kha)
  * [Chòe-kīn ê kái-piàn](https://zh-min-nan.wikipedia.org/wiki/Tek-pia%CC%8Dt:%E6%9C%80%E8%BF%91%E5%85%B6%E6%94%B9%E8%AE%8A "Choè-kīn tī wiki ū kái--koè ê lia̍t-toaⁿ​\[r\] \[alt-r\]")


[ ![](https://zh-min-nan.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://zh-min-nan.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![Chū-iû ê Pek-kho-choân-su](https://zh-min-nan.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-zh_min_nan.svg) ](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh)
[Chhiau-chhoē ](https://zh-min-nan.wikipedia.org/wiki/Tek-pia%CC%8Dt:%E5%B0%8B%E8%A8%8E "Chhoē Wikipedia​\[f\] \[alt-f\]")
Chhoē
Guā-māu
Guā-māu
移至側邊欄 Bih
Bûn-jī
  * Suè
Piau-tsún
Tuā

Tsit ia̍h thong-siông sú-iōng sió jī-hîng tuā-suè
Khuan-tōo
  * Piau-tsún
Khuah

內容已盡可能延展寬度以適應您的瀏覽器視窗。
  * [Kià-hù](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=zh-min-nan.wikipedia.org&uselang=nan)
  * [Khui sin kháu-chō](https://zh-min-nan.wikipedia.org/w/index.php?title=Tek-pia%CC%8Dt:%E9%96%8B%E8%B3%AC%E6%88%B6&returnto=Th%C3%A2u-ia%CC%8Dh "Kiàn-gī lí seng khui chi̍t-ê kháu-chō \(bô-it-tēng ài\); chiah koh teng-ji̍p.")
  * [Teng-ji̍p](https://zh-min-nan.wikipedia.org/w/index.php?title=Tek-pia%CC%8Dt:%E7%94%A8%E6%88%B6%E8%BA%92%E5%BA%95&returnto=Th%C3%A2u-ia%CC%8Dh "Hi-bāng lí teng-ji̍p; m̄-ko bô kiông-chè​\[o\] \[alt-o\]")


Kò-jîn kang-khū
  * [Kià-hù](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=zh-min-nan.wikipedia.org&uselang=nan)
  * [Khui sin kháu-chō](https://zh-min-nan.wikipedia.org/w/index.php?title=Tek-pia%CC%8Dt:%E9%96%8B%E8%B3%AC%E6%88%B6&returnto=Th%C3%A2u-ia%CC%8Dh "Kiàn-gī lí seng khui chi̍t-ê kháu-chō \(bô-it-tēng ài\); chiah koh teng-ji̍p.")
  * [Teng-ji̍p](https://zh-min-nan.wikipedia.org/w/index.php?title=Tek-pia%CC%8Dt:%E7%94%A8%E6%88%B6%E8%BA%92%E5%BA%95&returnto=Th%C3%A2u-ia%CC%8Dh "Hi-bāng lí teng-ji̍p; m̄-ko bô kiông-chè​\[o\] \[alt-o\]")


# Thâu-ia̍h
  * [Thâu-ia̍h](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "khoàⁿ ia̍h ê loē-iông​\[c\] \[alt-c\]")
  * [Thó-lūn](https://zh-min-nan.wikipedia.org/wiki/Th%C3%B3-l%C5%ABn:Th%C3%A2u-ia%CC%8Dh "Loē-iông ê thó-lūn​\[t\] \[alt-t\]")


閩南語 / Bân-lâm-gí
  * [Tha̍k](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh)
  * [khoàⁿ goân-sú lōe-iông](https://zh-min-nan.wikipedia.org/w/index.php?title=Th%C3%A2u-ia%CC%8Dh&action=edit "Chit ia̍h pó-hō͘ tiâu leh.
Lí ē-sái khoàⁿ i ê goân-sí-bé.​\[e\] \[alt-e\]")
  * [khoàⁿ le̍k-sú](https://zh-min-nan.wikipedia.org/w/index.php?title=Th%C3%A2u-ia%CC%8Dh&action=history "Chit ia̍h ê chá-chêng pán-pún​\[h\] \[alt-h\]")


Ke-si kheh-á
Ke-si
移至側邊欄 Bih
操作 
  * [Tha̍k](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh)
  * [khoàⁿ goân-sú lōe-iông](https://zh-min-nan.wikipedia.org/w/index.php?title=Th%C3%A2u-ia%CC%8Dh&action=edit)
  * [khoàⁿ le̍k-sú](https://zh-min-nan.wikipedia.org/w/index.php?title=Th%C3%A2u-ia%CC%8Dh&action=history)


It-puann 
  * [Tó-ūi liân kàu chia](https://zh-min-nan.wikipedia.org/wiki/Tek-pia%CC%8Dt:T%C3%B3-%C5%ABi_li%C3%A2n_k%C3%A0u_chia/Th%C3%A2u-ia%CC%8Dh "Só͘-ū liân kàu chia ê liat-toaⁿ​\[j\] \[alt-j\]")
  * [Siong-koan ê kái-piàn](https://zh-min-nan.wikipedia.org/wiki/Tek-pia%CC%8Dt:Siong-koan_%C3%AA_k%C3%A1i-pi%C3%A0n/Th%C3%A2u-ia%CC%8Dh "Liân kàu chit ia̍h koh choè-kīn ū kái koè--ê​\[k\] \[alt-k\]")
  * [Kā tóng-àn chiūⁿ-bāng](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=nan "Chún-pī beh upload tóng-àn​\[u\] \[alt-u\]")
  * [Éng-kiú liân-kiat](https://zh-min-nan.wikipedia.org/w/index.php?title=Th%C3%A2u-ia%CC%8Dh&oldid=3110471 "Chi̍t ia̍h kái--koè pán-pún ê éng-kiú liân-kiat")
  * [Ia̍h ê chu-sìn](https://zh-min-nan.wikipedia.org/w/index.php?title=Th%C3%A2u-ia%CC%8Dh&action=info "更多關於此頁面的資訊")
  * [Ín-iōng chit phiⁿ bûn-chiuⁿ](https://zh-min-nan.wikipedia.org/w/index.php?title=Tek-pia%CC%8Dt:%E5%BC%95%E7%94%A8%E6%AD%A4%E9%A0%81%E9%9D%A2&page=Th%C3%A2u-ia%CC%8Dh&id=3110471&wpFormIdentifier=titleform "Koan-hē án-chóaⁿ īng chit ia̍h--ê soat-bêng.")
  * [Hōo-lâng té bāng-tsí](https://zh-min-nan.wikipedia.org/w/index.php?title=Tek-pia%CC%8Dt:%E7%B8%AE%E7%B6%B2%E5%9D%80%E5%99%A8&url=https%3A%2F%2Fzh-min-nan.wikipedia.org%2Fwiki%2FTh%25C3%25A2u-ia%25CC%258Dh)
  * [Hōo-lâng hā-tsài QR bé](https://zh-min-nan.wikipedia.org/w/index.php?title=Tek-pia%CC%8Dt:QR%E7%A2%BC&url=https%3A%2F%2Fzh-min-nan.wikipedia.org%2Fwiki%2FTh%25C3%25A2u-ia%25CC%258Dh)


Ìn-soat/su-chhut 
  * [Chò PDF hā-chài](https://zh-min-nan.wikipedia.org/w/index.php?title=Tek-pia%CC%8Dt:%E4%B8%8B%E8%BC%89%E7%82%BAPDF&page=Th%C3%A2u-ia%CC%8Dh&action=show-download-screen)
  * [Ìn-soat pán-pún](javascript:print\(\); "Chit ia̍h ê ìn-soat pán-pún​\[p\] \[alt-p\]")


Chí-mōe kè-ōe 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [維基媒體基金會](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [維基媒體拓展](https://outreach.wikimedia.org/wiki/Main_Page)
  * [To-gí-giân Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikiquote](https://zh-min-nan.wikiquote.org/wiki/Th%C3%A2u-ia%CC%8Dh)
  * [Wikisource](https://zh-min-nan.wikisource.org/wiki/Th%C3%A2u-ia%CC%8Dh)
  * [Wiktionary](https://zh-min-nan.wiktionary.org/wiki/Th%C3%A2u-ia%CC%8Dh)
  * [Wikidata hāng-bo̍k](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "liân khì chu-liāu chhng-khò͘ --ê hāng-bo̍k​\[g\] \[alt-g\]")


Wikipedia (chū-iû ê pek-kho-choân-su) beh kā lí kóng...
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Incubator-logo.svg/40px-Incubator-logo.svg.png)](https://zh-min-nan.wikipedia.org/wiki/t%C3%B3ng-%C3%A0n:Incubator-logo.svg) [Kóaⁿ-kín lâi-khì Wikimedia Incubator pang-bâng siá Bân-lâm-gú pán-pún ê Wikinews.](https://incubator.wikimedia.org/wiki/Wn/nan/Th%C3%A2u-ia%CC%8Dh) [![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://zh-min-nan.wikipedia.org/wiki/t%C3%B3ng-%C3%A0n:Wikinews-logo.svg)
[Hoan-gêng](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:Hoan-g%C3%AAng "Wikipedia:Hoan-gêng") kong-lîm [Wikipedia](https://zh-min-nan.wikipedia.org/wiki/Wikipedia "Wikipedia")  
[Chū-iû](https://zh-min-nan.wikipedia.org/wiki/Ch%C5%AB-i%C3%BB_l%C5%8De-i%C3%B4ng "Chū-iû lōe-iông") ê [pek-kho-choân-su](https://zh-min-nan.wikipedia.org/wiki/Pek-kho-cho%C3%A2n-su "Pek-kho-choân-su") |  Chit-má ū **[433,807](https://zh-min-nan.wikipedia.org/wiki/Tek-pia%CC%8Dt:%E7%B5%B1%E8%A8%88 "Tek-pia̍t:統計")** phiⁿ [Bân-lâm-gú](https://zh-min-nan.wikipedia.org/wiki/B%C3%A2n-l%C3%A2m-g%C3%BA "Bân-lâm-gú") ê bûn-chiuⁿ
  * [Bo̍k-lio̍k](https://zh-min-nan.wikipedia.org/wiki/Pang-ch%C4%81n:Bo%CC%8Dk-lio%CC%8Dk "Pang-chān:Bo̍k-lio̍k")
  * [Chú-tê](https://zh-min-nan.wikipedia.org/wiki/Portal:Th%C3%A2u-ia%CC%8Dh "Portal:Thâu-ia̍h")
  * [Chhiū-á-kha](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:Chhi%C5%AB-%C3%A1-kha "Wikipedia:Chhiū-á-kha")
  * [FAQ](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:FAQ "Wikipedia:FAQ")
  * [Guestbook](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:Help_for_non-Min_Nan_speakers "Wikipedia:Help for non-Min Nan speakers")  

  * [Hoan-gêng](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:Hoan-g%C3%AAng_sin_i%C5%8Dng-chi%C3%A1 "Wikipedia:Hoan-gêng sin iōng-chiá")
  * [Liân-lo̍k](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:Li%C3%A2n-lo%CC%8Dk "Wikipedia:Liân-lo̍k")
  * [Pian-chi̍p](https://zh-min-nan.wikipedia.org/wiki/Pang-ch%C4%81n:Pian-chi%CC%8Dp "Pang-chān:Pian-chi̍p")
  * [Sin bûn-chiuⁿ](https://zh-min-nan.wikipedia.org/wiki/Tek-pia%CC%8Dt:%E6%96%B0%E5%85%B6%E9%A0%81%E9%9D%A2 "Tek-pia̍t:新其頁面")  

  * [Hàn-jī choán-siá chiò-iáⁿ](http://taigi.lohankhapedia.org/wiki/Th%C3%A2u-ia%CC%8Dh)

  
---|---  
[Gē-su̍t](https://zh-min-nan.wikipedia.org/wiki/Portal:G%C4%93-su%CC%8Dt "Portal:Gē-su̍t") |  [Ki-su̍t](https://zh-min-nan.wikipedia.org/wiki/Portal:Ki-su%CC%8Dt "Portal:Ki-su̍t") |  [Kho-ha̍k](https://zh-min-nan.wikipedia.org/wiki/Portal:Kho-ha%CC%8Dk "Portal:Kho-ha̍k") |  [Le̍k-sú](https://zh-min-nan.wikipedia.org/wiki/Portal:Le%CC%8Dk-s%C3%BA "Portal:Le̍k-sú") |  [Siā-hōe](https://zh-min-nan.wikipedia.org/wiki/Portal:Si%C4%81-h%C5%8De "Portal:Siā-hōe") |  [Sò͘-ha̍k](https://zh-min-nan.wikipedia.org/wiki/Portal:S%C3%B2%CD%98-ha%CC%8Dk "Portal:Sò͘-ha̍k") |  [Tē-lí](https://zh-min-nan.wikipedia.org/wiki/Portal:T%C4%93-l%C3%AD "Portal:Tē-lí") |  [Tiat-ha̍k](https://zh-min-nan.wikipedia.org/wiki/Portal:Tiat-ha%CC%8Dk "Portal:Tiat-ha̍k") |  [Toān-kì](https://zh-min-nan.wikipedia.org/wiki/Portal:To%C4%81n-k%C3%AC "Portal:Toān-kì")  
---|---|---|---|---|---|---|---|---  
Súi-khùi ê bûn-chiuⁿ |  Sin-bûn kì-sū  
---|---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Football_in_Bloomington%2C_Indiana%2C_1995.jpg/250px-Football_in_Bloomington%2C_Indiana%2C_1995.jpg)](https://zh-min-nan.wikipedia.org/wiki/t%C3%B3ng-%C3%A0n:Football_in_Bloomington,_Indiana,_1995.jpg) **[Kha-kiû](https://zh-min-nan.wikipedia.org/wiki/Kha-ki%C3%BB "Kha-kiû")** chit jī, it-póaⁿ sī chí **hia̍p-hōe kha-kiû** (Eng-gí: _association football_), che sī thong sè-kài siōng chē lâng sńg, siōng chē lâng khoàⁿ ê kiû-tūi [thé-io̍k ūn-tōng](https://zh-min-nan.wikipedia.org/wiki/Su-p%C3%B3%CD%98-chuh "Su-pó͘-chuh"). Chia só͘ kóng ê hia̍p-hōe kha-kiû, sī chí ha̍h [FIFA](https://zh-min-nan.wikipedia.org/wiki/FIFA "FIFA") (Kok-chè Kha-kiû Hia̍p-hoē Liân-bêng) kok-chè phiau-chún ê kha-kiû hêng-sek; nā pa̍t-khoán kha-kiû, pí-lūn [Bí-kok kha-kiû](https://zh-min-nan.wikipedia.org/wiki/B%C3%AD-kok_kha-ki%C3%BB "Bí-kok kha-kiû") ia̍h [La-gú-bih](https://zh-min-nan.wikipedia.org/wiki/La-g%C3%BA-bih "La-gú-bih"), in liû-hêng ê tē-khu khah iú-hān. Kha-kiû pí-sài ê lâng hun 2 tūi, 1 tūi siōng chē ū 11 ê kiû-oân. That kiû ji̍p-khì kiû-mn̂g khah chē kái ê hit tūi sǹg iâⁿ. Kha-kiû iōng--ê kiû mā hō-chò "[kha-kiû](https://zh-min-nan.wikipedia.org/wiki/Kha-ki%C3%BB_\(ki%C3%BB\) "Kha-kiû \(kiû\)"), chú-iàu khò kha lâi tín-tāng; chóng--sī mā ún-chún chhiú í-goā ê sin-ku pō͘-ūi khì sak. Kò͘ kiû-mn̂g ê kiû-oân sī î-it ē-tàng tī pí-sài-khu lāi-té iōng chhiú bōng kiû ê lâng. (**[Tha̍k choân-phiⁿ...](https://zh-min-nan.wikipedia.org/wiki/Kha-ki%C3%BB "Kha-kiû")**)  **[Chûn-tóng](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:S%C3%BAi-kh%C3%B9i_%C3%AA_b%C3%BBn-chiu%E2%81%BF "Wikipedia:Súi-khùi ê bûn-chiuⁿ")** · **[Thê-miâ](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:S%C3%BAi-kh%C3%B9i_%C3%AA_b%C3%BBn-chiu%E2%81%BF_h%C4%81u-so%C3%A1n "Wikipedia:Súi-khùi ê bûn-chiuⁿ hāu-soán")** |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/%E8%BE%B2%E6%A5%AD%E9%83%A8%E6%9E%97%E6%A5%AD%E7%BD%B22025%E5%B9%B49%E6%9C%886%E6%97%A5%E8%8A%B1%E8%93%AE%E9%A6%AC%E5%A4%AA%E9%9E%8D%E6%BA%AA%E5%A0%B0%E5%A1%9E%E6%B9%96%E7%A9%BA%E6%8B%8D%E5%BD%B1%E5%83%8F.jpg/250px-%E8%BE%B2%E6%A5%AD%E9%83%A8%E6%9E%97%E6%A5%AD%E7%BD%B22025%E5%B9%B49%E6%9C%886%E6%97%A5%E8%8A%B1%E8%93%AE%E9%A6%AC%E5%A4%AA%E9%9E%8D%E6%BA%AA%E5%A0%B0%E5%A1%9E%E6%B9%96%E7%A9%BA%E6%8B%8D%E5%BD%B1%E5%83%8F.jpg)](https://zh-min-nan.wikipedia.org/wiki/t%C3%B3ng-%C3%A0n:%E8%BE%B2%E6%A5%AD%E9%83%A8%E6%9E%97%E6%A5%AD%E7%BD%B22025%E5%B9%B49%E6%9C%886%E6%97%A5%E8%8A%B1%E8%93%AE%E9%A6%AC%E5%A4%AA%E9%9E%8D%E6%BA%AA%E5%A0%B0%E5%A1%9E%E6%B9%96%E7%A9%BA%E6%8B%8D%E5%BD%B1%E5%83%8F.jpg)
  * 2025 nî [9 goe̍h 23 ji̍t](https://zh-min-nan.wikipedia.org/wiki/9_goe%CC%8Dh_23_ji%CC%8Dt "9 goe̍h 23 ji̍t"), [Tâi-oân](https://zh-min-nan.wikipedia.org/wiki/T%C3%A2i-o%C3%A2n "Tâi-oân") [Hoa-liân-koān](https://zh-min-nan.wikipedia.org/wiki/Hoa-li%C3%A2n-ko%C4%81n "Hoa-liân-koān") [Bān-êng-hiong](https://zh-min-nan.wikipedia.org/wiki/B%C4%81n-%C3%AAng-hiong "Bān-êng-hiong") [Fata'an-khe](https://zh-min-nan.wikipedia.org/w/index.php?title=Fata%27an-khe&action=edit&redlink=1 "Fata'an-khe \(iáu-boē siá\)") (馬太鞍溪) **[pang-soaⁿ-ô͘](https://zh-min-nan.wikipedia.org/wiki/Pang-soa%E2%81%BF-%C3%B4%CD%98 "Pang-soaⁿ-ô͘")** (_siōng_) ê ô͘-chúi ek-chhut, tì-kàu soaⁿ-kha ê [Kong-ho̍k-hiong](https://zh-min-nan.wikipedia.org/wiki/Kong-ho%CC%8Dk-hiong "Kong-ho̍k-hiong") téng-tē [chò-tōa-chúi](https://zh-min-nan.wikipedia.org/wiki/Ch%C3%B2-t%C5%8Da-ch%C3%BAi "Chò-tōa-chúi"), kàu 9 goe̍h 28 ji̍t thóng-kè ū 17 ūi kòe-sin.
  * 2025 nî [8 goe̍h 15 ji̍t](https://zh-min-nan.wikipedia.org/wiki/8_goe%CC%8Dh_15_ji%CC%8Dt "8 goe̍h 15 ji̍t"), [Bí-kok](https://zh-min-nan.wikipedia.org/wiki/B%C3%AD-kok "Bí-kok") Chóng-thóng [Donald Trump](https://zh-min-nan.wikipedia.org/wiki/Donald_Trump "Donald Trump") kap [Lō͘-se-a](https://zh-min-nan.wikipedia.org/wiki/L%C5%8D%CD%98-se-a "Lō͘-se-a") Chóng-thóng [Vladimir Putin](https://zh-min-nan.wikipedia.org/wiki/Vladimir_Putin "Vladimir Putin") tī Bí-kok [Alaska-chiu](https://zh-min-nan.wikipedia.org/wiki/Alaska "Alaska") kí-hêng **[ko-chân hōe-gī](https://zh-min-nan.wikipedia.org/wiki/2025_n%C3%AE_B%C3%AD-kok_kap_L%C5%8D%CD%98-se-a_%C3%AA_ko-ch%C3%A2n_h%C5%8De-g%C4%AB "2025 nî Bí-kok kap Lō͘-se-a ê ko-chân hōe-gī")**.
  * 2025 nî [7 goe̍h 26 ji̍t](https://zh-min-nan.wikipedia.org/wiki/7_goe%CC%8Dh_26_ji%CC%8Dt "7 goe̍h 26 ji̍t"), Tâi-oân khí-pān kā Li̍p-hoat-īⁿ lâi-té ê 24 ūi Tē 11 kài ê [Tiong-kok Kok-bîn-tóng](https://zh-min-nan.wikipedia.org/wiki/Tiong-kok_Kok-b%C3%AEn-t%C3%B3ng "Tiong-kok Kok-bîn-tóng") khu-he̍k li̍p-hoat úi-goân kap [Sin-tek-chhī](https://zh-min-nan.wikipedia.org/wiki/Sin-tek-chh%C4%AB "Sin-tek-chhī") Chhī-tiúⁿ pā-bián ê thâu-phiò (sio̍k tī **[Tōa-pā-bián](https://zh-min-nan.wikipedia.org/wiki/T%C5%8Da-p%C4%81-bi%C3%A1n "Tōa-pā-bián")** ê chêng-tōng), kiat-kó lóng bô poàⁿ ê [pā-bián](https://zh-min-nan.wikipedia.org/wiki/P%C4%81-bi%C3%A1n "Pā-bián") thong-kòe.
  * 2025 nî [4 goe̍h 2 ji̍t](https://zh-min-nan.wikipedia.org/wiki/4_goe%CC%8Dh_2_ji%CC%8Dt "4 goe̍h 2 ji̍t"), Bí-kok chóng-thóng [Donald Trump](https://zh-min-nan.wikipedia.org/wiki/Donald_Trump "Donald Trump") chhiam [Tē 14257 Hō Hêng-chèng Bēng-lēng](https://zh-min-nan.wikipedia.org/w/index.php?title=T%C4%93_14257_H%C5%8D_H%C3%AAng-ch%C3%A8ng_B%C4%93ng-l%C4%93ng&action=edit&redlink=1 "Tē 14257 Hō Hêng-chèng Bēng-lēng \(iáu-boē siá\)"), tùi choân-sè-kài tōa-pō͘-hūn kok-ka kap tē-khu, khioh "tùi-téng" _( reciprocal)_ ê **[koan-sòe](https://zh-min-nan.wikipedia.org/wiki/Koan-s%C3%B2e "Koan-sòe")**.
  * 2025 nî [1 goe̍h 7 ji̍t](https://zh-min-nan.wikipedia.org/wiki/1_goe%CC%8Dh_7_ji%CC%8Dt "1 goe̍h 7 ji̍t") khí, [Bí-kok](https://zh-min-nan.wikipedia.org/wiki/B%C3%AD-kok "Bí-kok") [Ka-chiu](https://zh-min-nan.wikipedia.org/wiki/Ka-chiu "Ka-chiu") lâm-pō͘ chē-chē só͘-chāi **[hóe-sio-soaⁿ](https://zh-min-nan.wikipedia.org/wiki/H%C3%B3e-sio-soa%E2%81%BF "Hóe-sio-soaⁿ")** , tì-kàu 5 ūi í-siōng sí-bông, 10 bān lâng í-siông siū thiat-lî.
  * 2024 nî [12 goe̍h 3 ji̍t](https://zh-min-nan.wikipedia.org/wiki/12_goe%CC%8Dh_3_ji%CC%8Dt "12 goe̍h 3 ji̍t"), [Lâm-hân](https://zh-min-nan.wikipedia.org/wiki/L%C3%A2m-h%C3%A2n "Lâm-hân") Chóng-thóng **[Yun Seok-yeol](https://zh-min-nan.wikipedia.org/wiki/Yun_Seok-yeol "Yun Seok-yeol")** (윤석열) tī àm-sî soán-pò͘ [kài-giâm](https://zh-min-nan.wikipedia.org/wiki/K%C3%A0i-gi%C3%A2m "Kài-giâm"), āu-lâi [kok-hōe](https://zh-min-nan.wikipedia.org/wiki/H%C3%A2n-kok_kok-h%C5%8De "Hân-kok kok-hōe") tī kè-tńg-kang ē-poàⁿ-mê kā hió-koat (否決).

  
**[Kî-thaⁿ ê sin-bûn](https://zh-min-nan.wikipedia.org/wiki/Portal:Sin-b%C3%BBn_s%C5%AB-ki%C4%81%E2%81%BF "Portal:Sin-bûn sū-kiāⁿ")**  
Lí kám chai-iáⁿ... |  Tong-nî ê 10 goe̍h 1 ji̍t  
---|---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Doty.jpg/155px-Doty.jpg)](https://zh-min-nan.wikipedia.org/wiki/t%C3%B3ng-%C3%A0n:Doty.jpg)
  * **[Phû-tô-gâ Borgonha Ông-tiâu](https://zh-min-nan.wikipedia.org/wiki/Ph%C3%BB-t%C3%B4-g%C3%A2_Borgonha_%C3%94ng-ti%C3%A2u "Phû-tô-gâ Borgonha Ông-tiâu")** sī [Afonso Henriques](https://zh-min-nan.wikipedia.org/wiki/Afonso_Henriques "Afonso Henriques") kā in lāu-bú [León ê Teresa](https://zh-min-nan.wikipedia.org/wiki/Le%C3%B3n_%C3%AA_Teresa "León ê Teresa") táⁿ-pāi liāu-āu khai-ki--ê?
  * **[Tó chi̍t ūi Bí-kok thoân-kàu-sū](https://zh-min-nan.wikipedia.org/wiki/Elihu_Doty "Elihu Doty")** chhut-pán liáu tē-it phō iōng [Eng-gú](https://zh-min-nan.wikipedia.org/wiki/Eng-g%C3%BA "Eng-gú") choān-siá ê [Pe̍h-ōe-jī](https://zh-min-nan.wikipedia.org/wiki/Pe%CC%8Dh-%C5%8De-j%C4%AB "Pe̍h-ōe-jī") kàu-kho-su? _(siōng)_
  * **[Tó chi̍t ê liân-hō](https://zh-min-nan.wikipedia.org/wiki/Ch%C3%B4ng-cheng "Chông-cheng")** sī [Tiong-kok](https://zh-min-nan.wikipedia.org/wiki/Tiong-kok "Tiong-kok") [Bêng-tiâu](https://zh-min-nan.wikipedia.org/wiki/B%C3%AAng-ti%C3%A2u "Bêng-tiâu") chòe-āu chi̍t ūi [hông-tè](https://zh-min-nan.wikipedia.org/wiki/H%C3%B4ng-t%C3%A8 "Hông-tè") [Ui-chong](https://zh-min-nan.wikipedia.org/wiki/B%C3%AAng_Ui-chong "Bêng Ui-chong") chāi-ūi sî-kî ê [liân-hō](https://zh-min-nan.wikipedia.org/wiki/Li%C3%A2n-h%C5%8D "Liân-hō")?
  * **[Tó chi̍t-ê siâⁿ-chhī](https://zh-min-nan.wikipedia.org/wiki/Groningen "Groningen")** sī [Hô-lân](https://zh-min-nan.wikipedia.org/wiki/H%C3%B4-l%C3%A2n "Hô-lân") [Groningen Séng](https://zh-min-nan.wikipedia.org/wiki/Groningen_S%C3%A9ng "Groningen Séng") ê séng-hōe?
  * **[Tó chi̍t ūi Eng-kok cha-bó͘ koa-chhiú](https://zh-min-nan.wikipedia.org/wiki/Birdy_\(koa-chhi%C3%BA\) "Birdy \(koa-chhiú\)")** tī 12 hòe ê sî-chūn chiū iâⁿ-tio̍h [Open Mic UK](https://zh-min-nan.wikipedia.org/wiki/Open_Mic_UK "Open Mic UK") ê pí-sài koan-kun?
  * **[Tó chi̍t tiâu hô-chhoan](https://zh-min-nan.wikipedia.org/wiki/Mississippi_H%C3%B4 "Mississippi Hô")** ū choân [Pak Bí-chiu](https://zh-min-nan.wikipedia.org/wiki/Pak_B%C3%AD-chiu "Pak Bí-chiu") siāng tōa ê chúi-hē hoān-ûi?
  * [Liân-ha̍p-kok](https://zh-min-nan.wikipedia.org/wiki/Li%C3%A2n-ha%CC%8Dp-kok "Liân-ha̍p-kok") chū [1946 nî](https://zh-min-nan.wikipedia.org/wiki/1946_n%C3%AE "1946 nî") khai-sí sú-iōng **[tó chi̍t ki kî-á](https://zh-min-nan.wikipedia.org/wiki/Li%C3%A2n-ha%CC%8Dp-kok_H%C5%8De-k%C3%AE "Liân-ha̍p-kok Hōe-kî")** chò-ûi tāi-hōe hōe-kî?


  * **[Chûn-tóng](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:L%C3%AD_k%C3%A1m_chai-i%C3%A1%E2%81%BF%E2%80%A6 "Wikipedia:Lí kám chai-iáⁿ…")**
  * **[Kî-thaⁿ sin bûn-chiuⁿ](https://zh-min-nan.wikipedia.org/wiki/Tek-pia%CC%8Dt:%E6%96%B0%E5%85%B6%E9%A0%81%E9%9D%A2 "Tek-pia̍t:新其頁面")**

|  **[10 goe̍h 1 ji̍t](https://zh-min-nan.wikipedia.org/wiki/10_goe%CC%8Dh_1_ji%CC%8Dt "10 goe̍h 1 ji̍t")** : **[Tiong-kok](https://zh-min-nan.wikipedia.org/wiki/Tiong-kok "Tiong-kok")** ê [kok-khèng](https://zh-min-nan.wikipedia.org/w/index.php?title=Kok-kh%C3%A8ng&action=edit&redlink=1 "Kok-khèng \(iáu-boē siá\)")
  * **[Chiân 331 nî](https://zh-min-nan.wikipedia.org/w/index.php?title=Chi%C3%A2n_331_n%C3%AE&action=edit&redlink=1 "Chiân 331 nî \(iáu-boē siá\)"):** [Macedonia](https://zh-min-nan.wikipedia.org/wiki/Macedonia_%C3%94ng-kok "Macedonia Ông-kok") kok-ông [Alexandros 3-sè](https://zh-min-nan.wikipedia.org/wiki/Alexandros_T%C4%81i-%C3%B4ng "Alexandros Tāi-ông") tī [Gaugamela](https://zh-min-nan.wikipedia.org/w/index.php?title=Gaugamela_Chi%C3%A0n-t%C3%B2%CD%98&action=edit&redlink=1 "Gaugamela Chiàn-tò͘ \(iáu-boē siá\)") phah iâⁿ [Pho-su](https://zh-min-nan.wikipedia.org/wiki/Pho-su "Pho-su") [Darius 3-sè](https://zh-min-nan.wikipedia.org/wiki/Darius_3-s%C3%A8 "Darius 3-sè") ê pō͘-tūi.
  * **[1918 nî](https://zh-min-nan.wikipedia.org/wiki/1918_n%C3%AE "1918 nî"):** [A-la-pek Khí-gī](https://zh-min-nan.wikipedia.org/w/index.php?title=A-la-pek_Kh%C3%AD-g%C4%AB&action=edit&redlink=1 "A-la-pek Khí-gī \(iáu-boē siá\)"): [A-la-pek-lâng](https://zh-min-nan.wikipedia.org/wiki/A-la-pek-l%C3%A2ng "A-la-pek-lâng") chiàm-niá [Damascus](https://zh-min-nan.wikipedia.org/wiki/Damascus "Damascus").
  * **[1946 nî](https://zh-min-nan.wikipedia.org/wiki/1946_n%C3%AE "1946 nî"):** [Nürnberg Sím-phoàⁿ](https://zh-min-nan.wikipedia.org/wiki/N%C3%BCrnberg_S%C3%ADm-pho%C3%A0%E2%81%BF "Nürnberg Sím-phoàⁿ") kiat-sok.
  * **[1949 nî](https://zh-min-nan.wikipedia.org/wiki/1949_n%C3%AE "1949 nî"):** [Tiong-kok Kiōng-sán Tóng](https://zh-min-nan.wikipedia.org/wiki/Tiong-kok_Ki%C5%8Dng-s%C3%A1n_T%C3%B3ng "Tiong-kok Kiōng-sán Tóng") ê léng-tō-jîn [Mô͘ Te̍k-tong](https://zh-min-nan.wikipedia.org/wiki/M%C3%B4%CD%98_Te%CC%8Dk-tong "Mô͘ Te̍k-tong") tī [Pak-kiaⁿ](https://zh-min-nan.wikipedia.org/wiki/Pak-kia%E2%81%BF "Pak-kiaⁿ") [Thian-an-mn̂g](https://zh-min-nan.wikipedia.org/wiki/Thian-an-mn%CC%82g "Thian-an-mn̂g") téng-bīn soan-pò͘ sêng-li̍p [Tiong-hoâ Jîn-bîn Kiōng-hô-kok](https://zh-min-nan.wikipedia.org/wiki/Tiong-ho%C3%A2_J%C3%AEn-b%C3%AEn_Ki%C5%8Dng-h%C3%B4-kok "Tiong-hoâ Jîn-bîn Kiōng-hô-kok") _(tô͘)_.


  * Tong-nî ê **[9 goe̍h 30 ji̍t](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:Tong-n%C3%AE_%C3%AA_kin-%C3%A1-ji%CC%8Dt/9_goe%CC%8Dh_30_ji%CC%8Dt "Wikipedia:Tong-nî ê kin-á-ji̍t/9 goe̍h 30 ji̍t")**
  * **[10 goe̍h 1 ji̍t](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:Tong-n%C3%AE_%C3%AA_kin-%C3%A1-ji%CC%8Dt/10_goe%CC%8Dh_1_ji%CC%8Dt "Wikipedia:Tong-nî ê kin-á-ji̍t/10 goe̍h 1 ji̍t")**
  * **[10 goe̍h 2 ji̍t](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:Tong-n%C3%AE_%C3%AA_kin-%C3%A1-ji%CC%8Dt/10_goe%CC%8Dh_2_ji%CC%8Dt "Wikipedia:Tong-nî ê kin-á-ji̍t/10 goe̍h 2 ji̍t")**

  
Te̍k-sek siá-chin |  Se̍k-sāi Wikipedia kap [Holopedia](https://zh-min-nan.wikipedia.org/wiki/Holopedia "Holopedia")  
---|---  
  
  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/Aqueduct_of_Segovia_08.jpg/500px-Aqueduct_of_Segovia_08.jpg)](https://zh-min-nan.wikipedia.org/wiki/t%C3%B3ng-%C3%A0n:Aqueduct_of_Segovia_08.jpg) [Se-pan-gâ](https://zh-min-nan.wikipedia.org/wiki/Se-pan-g%C3%A2 "Se-pan-gâ") [Segovia Séng](https://zh-min-nan.wikipedia.org/wiki/Segovia_S%C3%A9ng "Segovia Séng")--ê [Segovia Chúi-tō͘-kiô](https://zh-min-nan.wikipedia.org/w/index.php?title=Segovia_Ch%C3%BAi-t%C5%8D%CD%98-ki%C3%B4&action=edit&redlink=1 "Segovia Chúi-tō͘-kiô \(iáu-boē siá\)") Hip-siòng: [Bernard Gagnon](https://commons.wikimedia.org/wiki/User:Bgag "commons:User:Bgag") [Commons téng ê ko-phín-chit siòng-phìⁿ](https://commons.wikimedia.org/wiki/Commons:Quality_images/nan "commons:Commons:Quality images/nan") |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Wikipedia-logo-v2-bw.svg/120px-Wikipedia-logo-v2-bw.svg.png)](https://zh-min-nan.wikipedia.org/wiki/t%C3%B3ng-%C3%A0n:Wikipedia-logo-v2-bw.svg) [Wikipedia](https://zh-min-nan.wikipedia.org/wiki/Wikipedia "Wikipedia") sī 1-ê [chū-iû lōe-iông](https://zh-min-nan.wikipedia.org/wiki/Ch%C5%AB-i%C3%BB_l%C5%8De-i%C3%B4ng "Chū-iû lōe-iông") ê [bāng-lō·](https://zh-min-nan.wikipedia.org/wiki/B%C4%81ng-l%C5%8D%C2%B7 "Bāng-lō·") [pek-kho-choân-su](https://zh-min-nan.wikipedia.org/wiki/Pek-kho-cho%C3%A2n-su "Pek-kho-choân-su"). I ê bo̍k-tek sī beh kiàn-li̍p 1 thò "chū-iû", bián-chîⁿ, to-gí ê pek-kho-choân-su. Wikipedia sī bāng-lō· téng siāng chē lâng sú-iōng ê 1-ê chham-khó sèng-chit ê bāng-chām; i ê chu-goân pêng-kin 1 ji̍t hông lia̍h 5-chheng-bān pái [[1]](https://en.wikipedia.org/wiki/Wikipedia#endnote_PopularityRef). Tû-liáu thoân-thóng ê pek-kho-choân-su sû-tiâu í-gōa, iū-koh ū pau-koah tio̍h chú-iàu ê sin-bûn sū-kiāⁿ, [lông-bîn-le̍k](https://zh-min-nan.wikipedia.org/wiki/L%C3%B4ng-b%C3%AEn-le%CC%8Dk "Lông-bîn-le̍k") téng-téng ê lōe-iông.  [Wikimedia Ki-kim-hōe](https://zh-min-nan.wikipedia.org/wiki/Wikimedia_Ki-kim-h%C5%8De "Wikimedia Ki-kim-hōe") chit-ê [bô-tì-ì-beh-thàn-chîⁿ](https://zh-min-nan.wikipedia.org/wiki/B%C3%B4-t%C3%AC-%C3%AC-beh-th%C3%A0n-ch%C3%AE%E2%81%BF "Bô-tì-ì-beh-thàn-chîⁿ") ê tan-ūi tī āu-piah chi-oān it-poaⁿ-sèng ê koán-lí kap chhau-chok. Lōe-iông hong-bīn oân-choân [khai-hòng](https://zh-min-nan.wikipedia.org/wiki/Khai-h%C3%B3ng_l%C5%8De-i%C3%B4ng "Khai-hóng lōe-iông") hō· chèng-lâng ha̍p-chok hoat-tián. Lōe-iông tōa-pō·-hūn sī sè-kài chē-chē kok ê jîn-sū tàu-tīn chhiâu--chhut-lâi ê kiat-kó. Chham-ka ê lâng chū-goān bô tēng-sî khai ka-kī ê sî-kan siá-chok, chè-tô·, siu-kái, chéng-lí, thó-lūn, soan-thoân chit-ê sū-kang.   
Chí-mōe kang-sū  
---  
Wikipedia ê chûn-chāi sī in-ūi ū [Wikimedia Ki-kim-hōe](https://zh-min-nan.wikipedia.org/wiki/Wikimedia "Wikimedia"), chi̍t ê teh koán-lí kok-chióng giân-gí kap bián-hùi lōe-iông hāng-bo̍k ê [hui-êng-lī cho͘-chit](https://zh-min-nan.wikipedia.org/wiki/Hui-%C3%AAng-l%C4%AB_cho%CD%98-chit "Hui-êng-lī cho͘-chit"): |  [![Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/ "Commons") |  **[Commons](https://commons.wikimedia.org/wiki/Th%C3%A2u-ia%CC%8Dh)**   
Chū-iû ê mûi-thé chu-liāu-khò͘ |  [![Wiktionary](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://zh-min-nan.wiktionary.org/wiki/ "Wiktionary") |  **[Wiktionary](https://zh-min-nan.wiktionary.org/)**   
Chū-iû ê jī-tián kap sû-tián  |  [![Wikisource](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://zh-min-nan.wikisource.org/wiki/ "Wikisource") |  **[Wikisource](https://zh-min-nan.wikisource.org/)**   
Chū-iû lōe-iông ê tô͘-su-koán   
---|---|---|---|---|---  
[![Wikispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/ "Wikispecies") |  **[Wikispecies](https://species.wikimedia.org/)**   
Bu̍t-chéng ê bo̍k-lio̍k  |  [![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/ "MediaWiki") |  **[MediaWiki](https://mediawiki.org/)**   
Wiki ê nńg-thé khai-hoat  |  [![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/ "Meta-Wiki") |  **[Meta-Wiki](https://meta.wikimedia.org/)**   
Wiki kang-sū ê hia̍p-tiau   
[![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "Wikidata") |  **[Wikidata](https://www.wikidata.org/)**   
Chū-iû ê tì-sek-khò͘  |  [![Wikibooks](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://incubator.wikimedia.org/wiki/Wb/nan/Th%C3%A2u-ia%CC%8Dh "Wikibooks") |  **[Wikibooks](https://incubator.wikimedia.org/wiki/Wb/nan/Th%C3%A2u-ia%CC%8Dh)**   
Chū-iû ê kàu-kho-su  |  [![Wikinews](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://incubator.wikimedia.org/wiki/Wn/nan/Th%C3%A2u-ia%CC%8Dh "Wikinews") |  **[Wikinews](https://incubator.wikimedia.org/wiki/Wn/nan/Th%C3%A2u-ia%CC%8Dh)**   
Chū-iû lōe-iông ê sin-bûn   
[![Wikiquote](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://incubator.wikimedia.org/wiki/Wq/nan/Th%C3%A2u-ia%CC%8Dh "Wikiquote") |  **[Wikiquote](https://incubator.wikimedia.org/wiki/Wq/nan/Th%C3%A2u-ia%CC%8Dh)**   
Bêng-jîn ê miâ-giân  |  [![Wikiversity](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/60px-Wikiversity_logo_2017.svg.png)](https://en.wikiversity.org/ "Wikiversity") |  **[Wikiversity](https://en.wikiversity.org/)**   
Chū-iû ê ha̍k-si̍p châi-liāu kap oa̍h-tāng  |  [![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://en.wikivoyage.org/ "Wikivoyage") |  **[Wikivoyage](https://en.wikivoyage.org/)**   
Chū-iû ê lí-hêng chí-lâm   
Kî-thaⁿ pán-pún  
---  
Chit-ê pán-pún ê Wikipedia sī ēng [Bân-lâm-gú](https://zh-min-nan.wikipedia.org/wiki/B%C3%A2n-l%C3%A2m-g%C3%BA "Bân-lâm-gú") [Pe̍h-ōe-jī](https://zh-min-nan.wikipedia.org/wiki/Pe%CC%8Dh-%C5%8De-j%C4%AB "Pe̍h-ōe-jī") siá--ê, chū 2004 nî khai-sí, kàu-taⁿ í-keng ū [433,807](https://zh-min-nan.wikipedia.org/wiki/Tek-pia%CC%8Dt:%E7%B5%B1%E8%A8%88 "Tek-pia̍t:統計") phiⁿ bûn-chiuⁿ. Tû-liáu Bân-lâm-hē giân-gú, Wikipedia iáu-koh ū kî-thaⁿ pán-pún--ê; ē-kha ū kúi-nā chióng pán-pún ê liân-kiat. 
  * Chhiau-kòe 1,000,000 phiⁿ bûn-chiuⁿ ê pán-pún: 
    * [Deutsch](https://de.wikipedia.org/wiki/)
    * [English](https://en.wikipedia.org/wiki/)
    * [Español](https://es.wikipedia.org/wiki/)
    * [Français](https://fr.wikipedia.org/wiki/)
    * [Italiano](https://it.wikipedia.org/wiki/)
    * [Nederlands](https://nl.wikipedia.org/wiki/)
    * [日本語](https://ja.wikipedia.org/wiki/)
    * [Polski](https://pl.wikipedia.org/wiki/)
    * [Русский](https://ru.wikipedia.org/wiki/)
    * [Svenska](https://sv.wikipedia.org/wiki/)
    * [Tiếng Việt](https://vi.wikipedia.org/wiki/)
    * [中文](https://zh.wikipedia.org/wiki/)
  * Chhiau-kòe 250,000 phiⁿ bûn-chiuⁿ ê pán-pún: 
    * [العربية](https://ar.wikipedia.org/wiki/)
    * [Bahasa Indonesia](https://id.wikipedia.org/wiki/)
    * [Bahasa Melayu](https://ms.wikipedia.org/wiki/)
    * [Català](https://ca.wikipedia.org/wiki/)
    * [Čeština](https://cs.wikipedia.org/wiki/)
    * [Euskara](https://eu.wikipedia.org/wiki/)
    * [فارسی](https://fa.wikipedia.org/wiki/)
    * [한국어](https://ko.wikipedia.org/wiki/)
    * [Magyar](https://hu.wikipedia.org/wiki/)
    * [Norsk](https://no.wikipedia.org/wiki/)
    * [Português](https://pt.wikipedia.org/wiki/)
    * [Română](https://ro.wikipedia.org/wiki/)
    * [Srpski](https://sr.wikipedia.org/wiki/)
    * [Srpskohrvatski](https://sh.wikipedia.org/wiki/)
    * [Suomi](https://fi.wikipedia.org/wiki/)
    * [Türkçe](https://tr.wikipedia.org/wiki/)
    * [Українська](https://uk.wikipedia.org/wiki/)
  * Chhiau-kòe 50,000 phiⁿ bûn-chiuⁿ ê pán-pún: 
    * [Afrikaans](https://af.wikipedia.org/wiki/)
    * [Bosanski](https://bs.wikipedia.org/wiki/)
    * [Български](https://bg.wikipedia.org/wiki/)
    * [Dansk](https://da.wikipedia.org/wiki/)
    * [Eesti](https://et.wikipedia.org/wiki/)
    * [Ελληνικά](https://el.wikipedia.org/wiki/)
    * [English (simple form)](https://simple.wikipedia.org/wiki/)
    * [Esperanto](https://eo.wikipedia.org/wiki/)
    * [Galego](https://gl.wikipedia.org/wiki/)
    * [עברית](https://he.wikipedia.org/wiki/)
    * [Hrvatski](https://hr.wikipedia.org/wiki/)
    * [Latviešu](https://lv.wikipedia.org/wiki/)
    * [Lietuvių](https://lt.wikipedia.org/wiki/)
    * [Norsk nynorsk](https://nn.wikipedia.org/wiki/)
    * [Slovenčina](https://sk.wikipedia.org/wiki/)
    * [Slovenščina](https://sl.wikipedia.org/wiki/)
    * [ไทย](https://th.wikipedia.org/wiki/)
  * [Hàn-gí-cho̍k](https://zh-min-nan.wikipedia.org/wiki/H%C3%A0n-g%C3%AD-cho%CC%8Dk "Hàn-gí-cho̍k") ê kî-thaⁿ pán-pún: 
    * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/)
    * [贛語](https://gan.wikipedia.org/wiki/)
    * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/)
    * [文言](https://zh-classical.wikipedia.org/wiki/)
    * [吴语](https://wuu.wikipedia.org/wiki/)
    * [粵語](https://zh-yue.wikipedia.org/wiki/)

**[Wikipedia pán-pún ê oân-chéng lia̍t-toaⁿ](https://meta.wikimedia.org/wiki/List_of_Wikipedias "meta:List of Wikipedias")**  
[Embassy, Embajada, 大使館, السفارة, Посольство, Botschaft, Ambassade, 대사관, Tòa đại sứ](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:T%C4%81i-s%C3%A0i-ko%C3%A1n "Wikipedia:Tāi-sài-koán")  
[Án-chóaⁿ tha̍k](https://zh-min-nan.wikipedia.org/wiki/Pang-ch%C4%81n:%C3%81n-ch%C3%B3a%E2%81%BF_tha%CC%8Dk "Pang-chān:Án-chóaⁿ tha̍k") ([How to read](https://zh-min-nan.wikipedia.org/wiki/Pang-ch%C4%81n:How_to_read "Pang-chān:How to read")) · [Án-chóaⁿ phah-jī](https://zh-min-nan.wikipedia.org/wiki/Pang-ch%C4%81n:%C3%81n-ch%C3%B3a%E2%81%BF_phah-j%C4%AB "Pang-chān:Án-chóaⁿ phah-jī") ([How to type POJ](https://zh-min-nan.wikipedia.org/wiki/Pang-ch%C4%81n:%E5%A6%82%E4%BD%95%E8%BC%B8%E5%85%A5%E7%99%BD%E8%A9%B1%E5%AD%97 "Pang-chān:如何輸入白話字")) · [Án-chóaⁿ siá](https://zh-min-nan.wikipedia.org/wiki/Pang-ch%C4%81n:%C3%81n-ch%C3%B3a%E2%81%BF_si%C3%A1 "Pang-chān:Án-chóaⁿ siá")
Lâi-goân: "[https://zh-min-nan.wikipedia.org/w/index.php?title=Thâu-ia̍h&oldid=3110471](https://zh-min-nan.wikipedia.org/w/index.php?title=Th%C3%A2u-ia%CC%8Dh&oldid=3110471)"
56 chióng gí-giân
  * [العربية](https://ar.wikipedia.org/wiki/ "阿拉伯文")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/ "藏文")
  * [Català](https://ca.wikipedia.org/wiki/ "加泰蘭文")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/ "Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/ "車臣文")
  * [Cebuano](https://ceb.wikipedia.org/wiki/ "宿霧文")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/ "宗教斯拉夫文")
  * [Dansk](https://da.wikipedia.org/wiki/ "丹麥文")
  * [Deutsch](https://de.wikipedia.org/wiki/ "德文")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/ "宗卡文")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "希臘文")
  * [English](https://en.wikipedia.org/wiki/ "英文")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "世界文")
  * [Español](https://es.wikipedia.org/wiki/ "西班牙文")
  * [Euskara](https://eu.wikipedia.org/wiki/ "巴斯克文")
  * [Suomi](https://fi.wikipedia.org/wiki/ "芬蘭文")
  * [Français](https://fr.wikipedia.org/wiki/ "法文")
  * [贛語](https://gan.wikipedia.org/wiki/ "贛語")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/ "客家話")
  * [עברית](https://he.wikipedia.org/wiki/ "希伯來文")
  * [हिन्दी](https://hi.wikipedia.org/wiki/ "印地文")
  * [Magyar](https://hu.wikipedia.org/wiki/ "匈牙利文")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "印尼文")
  * [Italiano](https://it.wikipedia.org/wiki/ "義大利文")
  * [日本語](https://ja.wikipedia.org/wiki/ "日文")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/ "高棉文")
  * [한국어](https://ko.wikipedia.org/wiki/ "韓文")
  * [Кыргызча](https://ky.wikipedia.org/wiki/ "吉爾吉斯文")
  * [Latina](https://la.wikipedia.org/wiki/ "拉丁文")
  * [ລາວ](https://lo.wikipedia.org/wiki/ "寮文")
  * [Монгол](https://mn.wikipedia.org/wiki/ "蒙古文")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "馬來文")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "荷蘭文")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "書面挪威文")
  * [Polski](https://pl.wikipedia.org/wiki/ "波蘭文")
  * [Português](https://pt.wikipedia.org/wiki/ "葡萄牙文")
  * [Română](https://ro.wikipedia.org/wiki/ "羅馬尼亞文")
  * [Русский](https://ru.wikipedia.org/wiki/ "俄文")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "塞爾維亞文")
  * [Svenska](https://sv.wikipedia.org/wiki/ "瑞典文")
  * [Sakizaya](https://szy.wikipedia.org/wiki/ "Sakizaya")
  * [Tayal](https://tay.wikipedia.org/wiki/ "Atayal")
  * [ไทย](https://th.wikipedia.org/wiki/ "泰文")
  * [Tagalog](https://tl.wikipedia.org/wiki/ "塔加路族文")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "土耳其文")
  * [Seediq](https://trv.wikipedia.org/wiki/ "太魯閣文")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/ "維吾爾文")
  * [Українська](https://uk.wikipedia.org/wiki/ "烏克蘭文")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "越南文")
  * [Winaray](https://war.wikipedia.org/wiki/ "瓦瑞文")
  * [吴语](https://wuu.wikipedia.org/wiki/ "吳語")
  * [Vahcuengh](https://za.wikipedia.org/wiki/ "壯文")
  * [中文](https://zh.wikipedia.org/wiki/ "中文")
  * [文言](https://zh-classical.wikipedia.org/wiki/ "文言文")
  * [粵語](https://zh-yue.wikipedia.org/wiki/ "粵語")


  * Chit ia̍h siāng bóe tī 2021 nî 12 goe̍h 4 ji̍t (pài-la̍k), 02:50 ū pian-chi̍p--koè.
  * Chiàu ē-kha--ê kui-tēng tō thong-iōng [Creative Commons Attribution-ShareAlike License](https://creativecommons.org/licenses/by-sa/4.0/); kî-thaⁿ kū-thé--ê tiâu-bûn chhiáⁿ lí khoàⁿ [Terms of Use](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use).


  * [Ín-su chèng-chhek](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Koan-hē Wikipedia](https://zh-min-nan.wikipedia.org/wiki/Wikipedia)
  * [Bô-hū-chek seng-bêng](https://zh-min-nan.wikipedia.org/wiki/Wikipedia:It-poa%E2%81%BF_%C3%AA_seng-b%C3%AAng)
  * [行為準則](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Khai-hoat-chiá](https://developer.wikimedia.org)
  * [Thóng-kè](https://stats.wikimedia.org/#/zh-min-nan.wikipedia.org)
  * [Cookie seng-bêng](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Hêng-tōng bô͘-sek](https://zh-min-nan.m.wikipedia.org/w/index.php?title=Th%C3%A2u-ia%CC%8Dh&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://zh-min-nan.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://zh-min-nan.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Chhiau-chhoē
Chhoē
Thâu-ia̍h
[](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh) [](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh) [](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh) [](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh) [](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh) [](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh) [](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh) [](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh)
56 chióng gí-giân [Ke chi̍t-ê toān-lo̍h ](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh)
