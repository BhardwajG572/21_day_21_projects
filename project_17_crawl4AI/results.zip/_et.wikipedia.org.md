[Mine sisu juurde](https://et.wikipedia.org/wiki/Vikipeedia:Esileht#bodyContent)
Peamenüü
Peamenüü
vii külgpaanile peida
Navigeerimine 
  * [Esileht](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Mine esilehele \[z\]")
  * [Juhuslik lehekülg](https://et.wikipedia.org/wiki/Eri:Juhuslik_artikkel "Mine juhuslikule leheküljele \[x\]")
  * [Viimased muudatused](https://et.wikipedia.org/wiki/Eri:Viimased_muudatused "Vikis tehtud viimaste muudatuste loend \[r\]")
  * [Üldine arutelu](https://et.wikipedia.org/wiki/Vikipeedia:%C3%9Cldine_arutelu)
  * [Erileheküljed](https://et.wikipedia.org/wiki/Eri:Erilehek%C3%BCljed)
  * [Juhend](https://et.wikipedia.org/wiki/Juhend:Sisukord "Kuidas redigeerida")
  * [Kontakt](https://et.wikipedia.org/wiki/Vikipeedia:Kontakteeru_meiega)


[ ![](https://et.wikipedia.org/static/images/icons/wikipedia.png) ![Vikipeedia](https://et.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-et.svg) ![](https://et.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-et.svg) ](https://et.wikipedia.org/wiki/Vikipeedia:Esileht)
[Otsing ](https://et.wikipedia.org/wiki/Eri:Otsimine "Otsi vikist \[f\]")
Otsi
Ilme
  * [Anneta](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=et.wikipedia.org&uselang=et)
  * [Loo konto](https://et.wikipedia.org/w/index.php?title=Eri:Konto_loomine&returnto=Vikipeedia%3AEsileht "See pole küll kohustuslik, aga sul tasub konto luua ja sisse logida.")
  * [Logi sisse](https://et.wikipedia.org/w/index.php?title=Eri:Sisselogimine&returnto=Vikipeedia%3AEsileht "See pole küll kohustuslik, aga sul tasub sisse logida. \[o\]")


Isiklikud lehed
  * [Anneta](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=et.wikipedia.org&uselang=et)
  * [Loo konto](https://et.wikipedia.org/w/index.php?title=Eri:Konto_loomine&returnto=Vikipeedia%3AEsileht "See pole küll kohustuslik, aga sul tasub konto luua ja sisse logida.")
  * [Logi sisse](https://et.wikipedia.org/w/index.php?title=Eri:Sisselogimine&returnto=Vikipeedia%3AEsileht "See pole küll kohustuslik, aga sul tasub sisse logida. \[o\]")


[peida]
Oktoober on **[Vikipeedia kunstikuu](https://et.wikipedia.org/wiki/Vikipeedia:Kunstikuu "Vikipeedia:Kunstikuu")**!
#  Vikipeedia:Esileht
  * [Esileht](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Näita projekti lehte \[c\]")
  * [Arutelu](https://et.wikipedia.org/wiki/Vikipeedia_arutelu:Esileht "Arutelu selle lehekülje sisu kohta \[t\]")


eesti
  * [Vaata](https://et.wikipedia.org/wiki/Vikipeedia:Esileht)
  * [Vaata lähteteksti](https://et.wikipedia.org/w/index.php?title=Vikipeedia:Esileht&action=edit "See lehekülg on kaitstud.
Saad vaadata selle lähteteksti. \[e\]")
  * [Näita ajalugu](https://et.wikipedia.org/w/index.php?title=Vikipeedia:Esileht&action=history "Selle lehekülje varasemad redaktsioonid \[h\]")


Tööriistad
Tööriistad
vii külgpaanile peida
Toimingud 
  * [Vaata](https://et.wikipedia.org/wiki/Vikipeedia:Esileht)
  * [Vaata lähteteksti](https://et.wikipedia.org/w/index.php?title=Vikipeedia:Esileht&action=edit)
  * [Näita ajalugu](https://et.wikipedia.org/w/index.php?title=Vikipeedia:Esileht&action=history)


Üldine 
  * [Lingid siia](https://et.wikipedia.org/wiki/Eri:Lingid_siia/Vikipeedia:Esileht "Kõik viki leheküljed, mis siia viitavad \[j\]")
  * [Seotud muudatused](https://et.wikipedia.org/wiki/Eri:Seotud_muudatused/Vikipeedia:Esileht "Viimased muudatused lehekülgedel, millele on siit viidatud \[k\]")
  * [Püsilink](https://et.wikipedia.org/w/index.php?title=Vikipeedia:Esileht&oldid=6795043 "Püsilink lehekülje sellele redaktsioonile")
  * [Lehekülje teave](https://et.wikipedia.org/w/index.php?title=Vikipeedia:Esileht&action=info "Lisateave selle lehekülje kohta")
  * [Hangi lühendatud URL](https://et.wikipedia.org/w/index.php?title=Eri:UrlShortener&url=https%3A%2F%2Fet.wikipedia.org%2Fwiki%2FVikipeedia%3AEsileht)
  * [Laadi alla QR-kood](https://et.wikipedia.org/w/index.php?title=Eri:QrCode&url=https%3A%2F%2Fet.wikipedia.org%2Fwiki%2FVikipeedia%3AEsileht)


Trüki või ekspordi 
  * [Koosta raamat](https://et.wikipedia.org/w/index.php?title=Eri:Raamat&bookcmd=book_creator&referer=Vikipeedia%3AEsileht)
  * [Laadi alla PDF-failina](https://et.wikipedia.org/w/index.php?title=Eri:DownloadAsPdf&page=Vikipeedia%3AEsileht&action=show-download-screen)
  * [Prinditav versioon](https://et.wikipedia.org/w/index.php?title=Vikipeedia:Esileht&printable=yes "Selle lehe trükiversioon \[p\]")


Teistes projektides 
  * [Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Metaviki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Mitmekeelsed Vikitekstid](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Vikiõpikud](https://et.wikibooks.org/wiki/Esileht)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Vikitsitaadid](https://et.wikiquote.org/wiki/Esileht)
  * [Vikitekstid](https://et.wikisource.org/wiki/Esileht)
  * [Vikisõnastik](https://et.wiktionary.org/wiki/Vikis%C3%B5nastik:Esileht)
  * [Andmeüksus](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Link andmehoidla seonduva üksuse juurde \[g\]")


Ilme
vii külgpaanile peida
Allikas: Vikipeedia
Tere tulemast [Vikipeediasse](https://et.wikipedia.org/wiki/Vikipeedia "Vikipeedia"),   
vabasse veebientsüklopeediasse
Käsilolevaid artikleid: **[254 984](https://et.wikipedia.org/wiki/Eri:Arvandmestik "Eri:Arvandmestik")**  
Kaastöölisi sel kuul: **[1117](https://et.wikipedia.org/wiki/Eri:Teguskasutajad "Eri:Teguskasutajad")**  
**[Teemaportaalid](https://et.wikipedia.org/wiki/Vikipeedia:Portaalid "Vikipeedia:Portaalid")**
  * [Sissejuhatus](https://et.wikipedia.org/wiki/Vikipeedia:Sissejuhatus "Vikipeedia:Sissejuhatus")
  * [Uuele kaastöölisele](https://et.wikipedia.org/wiki/Vikipeedia:Uuele_kaast%C3%B6%C3%B6lisele "Vikipeedia:Uuele kaastöölisele")
  * [KKK](https://et.wikipedia.org/wiki/Vikipeedia:KKK "Vikipeedia:KKK")
  * [Põhimõtted](https://et.wikipedia.org/wiki/Vikipeedia:P%C3%B5him%C3%B5tted "Vikipeedia:Põhimõtted")
  * [Vormistusreeglid](https://et.wikipedia.org/wiki/Vikipeedia:Vormistusreeglid "Vikipeedia:Vormistusreeglid")
  * [Redigeerimisjuhend](https://et.wikipedia.org/wiki/Juhend:Lehek%C3%BClje_muutmine "Juhend:Lehekülje muutmine")
  * [Kogukonnavärav](https://et.wikipedia.org/wiki/Vikipeedia:Kogukonnav%C3%A4rav "Vikipeedia:Kogukonnavärav")
  * [Kõik artiklid](https://et.wikipedia.org/wiki/Eri:K%C3%B5ik_lehek%C3%BCljed "Eri:Kõik leheküljed")


[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/HS_Cscr-featured.svg/40px-HS_Cscr-featured.svg.png)](https://et.wikipedia.org/wiki/Fail:HS_Cscr-featured.svg)
Nädala artikkel
[![Paide ordulinnuse varemed](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Paide_ordulinnuse_varemed.JPG/250px-Paide_ordulinnuse_varemed.JPG)](https://et.wikipedia.org/wiki/Fail:Paide_ordulinnuse_varemed.JPG "Paide ordulinnuse varemed")Paide ordulinnuse varemed
**[Paide piiramine](https://et.wikipedia.org/wiki/Paide_piiramine_\(1572%E2%80%931573\) "Paide piiramine \(1572–1573\)")** toimus [1572](https://et.wikipedia.org/wiki/1572 "1572"). aasta detsembrist kuni [1. jaanuarini](https://et.wikipedia.org/wiki/1._jaanuar "1. jaanuar") [1573](https://et.wikipedia.org/wiki/1573 "1573") [Liivi sõja](https://et.wikipedia.org/wiki/Liivi_s%C3%B5da "Liivi sõda") ajal. [Moskva tsaaririigi](https://et.wikipedia.org/wiki/Moskva_tsaaririik "Moskva tsaaririik") väed vallutasid [Rootsile](https://et.wikipedia.org/wiki/Rootsi "Rootsi") kuulunud [Paide linnuse](https://et.wikipedia.org/wiki/Paide_linnus "Paide linnus"). 
[16. detsembril](https://et.wikipedia.org/wiki/16._detsember "16. detsember") 1572 suundusid Rootsi väed [Claes Åkesson Totti](https://et.wikipedia.org/wiki/Claes_%C3%85kesson_Tott "Claes Åkesson Tott") juhtimisel [Tallinnast](https://et.wikipedia.org/wiki/Tallinn "Tallinn") ringiga läbi [Märjamaa](https://et.wikipedia.org/wiki/M%C3%A4rjamaa "Märjamaa") ja [Viljandi](https://et.wikipedia.org/wiki/Viljandi "Viljandi") [Põltsamaad](https://et.wikipedia.org/wiki/P%C3%B5ltsamaa "Põltsamaa") piirama. Kaks [kartauni](https://et.wikipedia.org/wiki/Kartaun "Kartaun") koos [püssirohuga](https://et.wikipedia.org/wiki/P%C3%BCssirohi "Püssirohi") otsustati saata otse läbi [Paide](https://et.wikipedia.org/wiki/Paide "Paide"). Sinna nad küll ei jõudnud, saabudes alles [jõulupühadeks](https://et.wikipedia.org/wiki/J%C3%B5ulud "Jõulud") [Uuemõisa](https://et.wikipedia.org/wiki/Kose-Uuem%C3%B5isa "Kose-Uuemõisa"). 
Samal ajal oli [Liivimaale](https://et.wikipedia.org/wiki/Vana-Liivimaa "Vana-Liivimaa") saabunud [Ivan IV](https://et.wikipedia.org/wiki/Ivan_IV "Ivan IV") koos oma kahe poja ja suure sõjaväega. Tallinnas ja Paides paiknenud Rootsi väed seda ei teadnud. Rootslased olid veendunud, et tsaari väed ei julge maale tulla, kuna Liivimaal viibis parasjagu suur Rootsi kuninga vägi, mistõttu ei pandud rõhku [maakuulamisele](https://et.wikipedia.org/wiki/Maakuulamine "Maakuulamine") ega valvele. 
Peagi oli Ivan IV oma vägedega [Rakvere](https://et.wikipedia.org/wiki/Rakvere "Rakvere") all, kuid sellest ei teadnud midagi Tott ega tallinlased. Paides teati moskoviitide kohalolekut, kuid arvati, et see on mõni väiksem salk, kes Uuemõisa suurtükke endale tahab saada. Paide linnuse asevalitseja [Hans Boije](https://et.wikipedia.org/w/index.php?title=Hans_Boije&action=edit&redlink=1 "Hans Boije \(pole veel kirjutatud\)") otsustas seetõttu saata suurema osa linnuse garnisonist suurtükkidele vastu, jättes linnusesse umbes 50 sõjameest, kellele olid lisaks linnusesse pagenud talupojad. **[Loe edasi ...](https://et.wikipedia.org/wiki/Paide_piiramine_\(1572%E2%80%931573\) "Paide piiramine \(1572–1573\)")**
[Arhiiv](https://et.wikipedia.org/wiki/Vikipeedia:N%C3%A4dala_artiklid_2025 "Vikipeedia:Nädala artiklid 2025")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/HSVissteduatt.svg/40px-HSVissteduatt.svg.png)](https://et.wikipedia.org/wiki/Fail:HSVissteduatt.svg)
Kas teadsid?
[![Raivo Raigna \(2020\)](https://upload.wikimedia.org/wikipedia/et/thumb/3/3c/PA251437.JPG/120px-PA251437.JPG)](https://et.wikipedia.org/wiki/Fail:PA251437.JPG "Raivo Raigna \(2020\)")Raivo Raigna (2020)
  * [1. oktoobril](https://et.wikipedia.org/wiki/1._oktoober "1. oktoober") 225 aastat tagasi sündis [saami päritolu](https://et.wikipedia.org/wiki/Saamid "Saamid") [Soome](https://et.wikipedia.org/wiki/Soome "Soome") [jutlustaja](https://et.wikipedia.org/wiki/Jutlus "Jutlus") ja usu-uuendaja **[Lars Levi Laestadius](https://et.wikipedia.org/wiki/Lars_Levi_Laestadius "Lars Levi Laestadius")**.
  * [3. oktoobril](https://et.wikipedia.org/wiki/3._oktoober "3. oktoober") saab 70-aastaseks [ajakirjanik](https://et.wikipedia.org/wiki/Ajakirjanik "Ajakirjanik") ja [mälumängur](https://et.wikipedia.org/wiki/M%C3%A4lum%C3%A4ng "Mälumäng") **[Raivo Raigna](https://et.wikipedia.org/wiki/Raivo_Raigna "Raivo Raigna")** (pildil).
  * [4. oktoobril](https://et.wikipedia.org/wiki/4._oktoober "4. oktoober") 125 aastat tagasi sündis [kirjanik](https://et.wikipedia.org/wiki/Kirjanik "Kirjanik"), [Rahvuskogu](https://et.wikipedia.org/wiki/Rahvuskogu "Rahvuskogu") ja [I Riigivolikogu](https://et.wikipedia.org/wiki/I_Riigivolikogu "I Riigivolikogu") liige **[August Mälk](https://et.wikipedia.org/wiki/August_M%C3%A4lk "August Mälk")**.
  * 4. oktoobril 125 aastat tagasi sündis [õigusteadlane](https://et.wikipedia.org/wiki/%C3%95igusteadus "Õigusteadus") **[Tatjana Poska-Laaman](https://et.wikipedia.org/wiki/Tatjana_Poska-Laaman "Tatjana Poska-Laaman")** , [Jaan Poska](https://et.wikipedia.org/wiki/Jaan_Poska "Jaan Poska") tütar.
  * 4. oktoobril 120 aastat tagasi sündis [maalikunstnik](https://et.wikipedia.org/wiki/Maalikunst "Maalikunst") **[Hedda Hacker](https://et.wikipedia.org/wiki/Hedda_Hacker "Hedda Hacker")** , [Marie Underi](https://et.wikipedia.org/wiki/Marie_Under "Marie Under") tütar.
  * 4. oktoobril saab 75-aastaseks [keeleteadlane](https://et.wikipedia.org/wiki/Keeleteadus "Keeleteadus") **[Peep Nemvalts](https://et.wikipedia.org/wiki/Peep_Nemvalts "Peep Nemvalts")**.


[2. oktoober ajaloos](https://et.wikipedia.org/wiki/2._oktoober#S%C3%BCndmused "2. oktoober") **·** [Arhiiv](https://et.wikipedia.org/wiki/Vikipeedia:Kas_teadsid_2025 "Vikipeedia:Kas teadsid 2025")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/HSBild.svg/40px-HSBild.svg.png)](https://et.wikipedia.org/wiki/Fail:HSBild.svg)
Nädala pilt
[![Viljandi linnusepargi rippsild \(2024\)](https://upload.wikimedia.org/wikipedia/commons/thumb/b/bb/Viljandi_linnusepargi_rippsild_2024_01.jpg/500px-Viljandi_linnusepargi_rippsild_2024_01.jpg)](https://et.wikipedia.org/wiki/Fail:Viljandi_linnusepargi_rippsild_2024_01.jpg "Viljandi linnusepargi rippsild \(2024\)")
**[Rippsild](https://et.wikipedia.org/wiki/Rippsild "Rippsild")** on [sillatüüp](https://et.wikipedia.org/wiki/Sild "Sild"), mille puhul [sillatekk](https://et.wikipedia.org/w/index.php?title=Sillatekk&action=edit&redlink=1 "Sillatekk \(pole veel kirjutatud\)") (silla liiklust kandev osa) ripub.
[1931](https://et.wikipedia.org/wiki/1931 "1931"). aastal paigaldati [Viljandis](https://et.wikipedia.org/wiki/Viljandi "Viljandi") üle [Kaevumäe](https://et.wikipedia.org/wiki/Kaevum%C3%A4gi "Kaevumägi") oru [Viljandi rippsild](https://et.wikipedia.org/wiki/Viljandi_rippsild "Viljandi rippsild"), mille kinkis linnale endine [Tarvastu](https://et.wikipedia.org/wiki/Tarvastu_m%C3%B5is "Tarvastu mõis") mõisnik [Karl von Mensenkampff](https://et.wikipedia.org/wiki/Karl_von_Mensenkampff "Karl von Mensenkampff"). 
Autor: [Vaido Otsar](https://et.wikipedia.org/wiki/Kasutaja:Vaido_Otsar "Kasutaja:Vaido Otsar")
[Arhiiv](https://et.wikipedia.org/wiki/Vikipeedia:N%C3%A4dala_pildid_2025 "Vikipeedia:Nädala pildid 2025")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/W-circle.svg/40px-W-circle.svg.png)](https://et.wikipedia.org/wiki/Fail:W-circle.svg)
Vikipeediast
**[Vikipeedia](https://et.wikipedia.org/wiki/Vikipeedia "Vikipeedia")** on [paljukeelne](https://meta.wikimedia.org/wiki/List_of_Wikipedias#All_Wikipedias_ordered_by_number_of_articles "meta:List of Wikipedias") [võrguentsüklopeedia](https://et.wikipedia.org/wiki/Vikipeedia:Sissejuhatus "Vikipeedia:Sissejuhatus"), mida kõik saavad vabalt kasutada ning täiendada ja parandada. 
Esimesena alustas 2001. aasta jaanuaris [ingliskeelne Vikipeedia](https://et.wikipedia.org/wiki/Ingliskeelne_Vikipeedia "Ingliskeelne Vikipeedia"). [Eestikeelne Vikipeedia](https://et.wikipedia.org/wiki/Eestikeelne_Vikipeedia "Eestikeelne Vikipeedia") alustas 2002. aasta augustis. 
**Sinised** lingid viivad olemasolevate artikliteni; **punaste** linkide puhul on artikkel ette nähtud, kuid see tuleb alles kirjutada. Punasele lingile klõpsates jõuate lehele, millel saate alustada uut artiklit. 
[Tee julgelt parandusi](https://et.wikipedia.org/wiki/Vikipeedia:Tehke_julgelt_parandusi "Vikipeedia:Tehke julgelt parandusi")! Muudatused on kohe nähtavad, sisselogimine ei ole kohustuslik. Vaadake [redigeerimisjuhendit](https://et.wikipedia.org/wiki/Juhend:Lehek%C3%BClje_muutmine "Juhend:Lehekülje muutmine"), [korduma kippuvaid küsimusi](https://et.wikipedia.org/wiki/Vikipeedia:KKK "Vikipeedia:KKK") ja [teisi abilehti](https://et.wikipedia.org/wiki/Juhend:Sisukord "Juhend:Sisukord") ning hakake kirjutama! Harjutamiseks võib kasutada ka [liivakasti](https://et.wikipedia.org/wiki/Vikipeedia:Liivakast "Vikipeedia:Liivakast"). Kirjutamisel soovitame eeskujuks võtta siinse kogukonna poolt [headeks valitud artikleid](https://et.wikipedia.org/wiki/Vikipeedia:Head_artiklid "Vikipeedia:Head artiklid"). 
Vahepeal tehtut näeb [viimaste muudatuste lehelt](https://et.wikipedia.org/wiki/Eri:Viimased_muudatused "Eri:Viimased muudatused"). 
Kui artiklis jäi midagi arusaamatuks, siis postitage oma küsimused vastava artikli arutelulehele, kuhu pääsete vastava artikli päisest. Arutelulehele postitamiseks kasutage päiselinki "Muuda" või "Lisa teema". 
Uue artikli alustamiseks võid ka soovitud pealkirja siia sisestada: 
  

Can't speak Estonian but have something to say? Tell it [here](https://et.wikipedia.org/wiki/Vikipeedia_arutelu:Saatkond "Vikipeedia arutelu:Saatkond").
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/HSPortal.svg/40px-HSPortal.svg.png)](https://et.wikipedia.org/wiki/Fail:HSPortal.svg)
Portaalid
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Crystal_Clear_app_date.png/40px-Crystal_Clear_app_date.png)](https://et.wikipedia.org/wiki/Fail:Crystal_Clear_app_date.png)
**[Ajalugu](https://et.wikipedia.org/wiki/Portaal:Ajalugu "Portaal:Ajalugu")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/WikiProjectEstonia_cropped.png/40px-WikiProjectEstonia_cropped.png)](https://et.wikipedia.org/wiki/Fail:WikiProjectEstonia_cropped.png)
**[Eesti](https://et.wikipedia.org/wiki/Portaal:Eesti "Portaal:Eesti")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Crystal_Clear_app_internet.png/40px-Crystal_Clear_app_internet.png)](https://et.wikipedia.org/wiki/Fail:Crystal_Clear_app_internet.png)
**[Geograafia](https://et.wikipedia.org/wiki/Portaal:Geograafia "Portaal:Geograafia")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Gnome-applications-graphics.svg/40px-Gnome-applications-graphics.svg.png)](https://et.wikipedia.org/wiki/Fail:Gnome-applications-graphics.svg)
**[Kaunid kunstid](https://et.wikipedia.org/wiki/Portaal:Kaunid_kunstid "Portaal:Kaunid kunstid")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Nuvola_apps_edu_science.svg/40px-Nuvola_apps_edu_science.svg.png)](https://et.wikipedia.org/wiki/Fail:Nuvola_apps_edu_science.svg)
**[Loodusteadused](https://et.wikipedia.org/wiki/Portaal:Loodusteadused "Portaal:Loodusteadused")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Emoji_u1f691.svg/40px-Emoji_u1f691.svg.png)](https://et.wikipedia.org/wiki/Fail:Emoji_u1f691.svg)
**[Meditsiin](https://et.wikipedia.org/wiki/Portaal:Meditsiin "Portaal:Meditsiin")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Religion_icon.svg/40px-Religion_icon.svg.png)](https://et.wikipedia.org/wiki/Fail:Religion_icon.svg)
**[Religioon](https://et.wikipedia.org/wiki/Portaal:Religioon "Portaal:Religioon")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Emoji_u1f3be.svg/40px-Emoji_u1f3be.svg.png)](https://et.wikipedia.org/wiki/Fail:Emoji_u1f3be.svg)
**[Sport](https://et.wikipedia.org/wiki/Portaal:Sport "Portaal:Sport")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/AWB_logo_draft.png/40px-AWB_logo_draft.png)](https://et.wikipedia.org/wiki/Fail:AWB_logo_draft.png)
**[Tehnika](https://et.wikipedia.org/wiki/Portaal:Tehnika "Portaal:Tehnika")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/64/Crystal_Clear_app_Community_Help.png/40px-Crystal_Clear_app_Community_Help.png)](https://et.wikipedia.org/wiki/Fail:Crystal_Clear_app_Community_Help.png)
**[Ühiskond](https://et.wikipedia.org/wiki/Portaal:%C3%9Chiskond "Portaal:Ühiskond")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Crystal_Clear_app_Login_Manager.svg/40px-Crystal_Clear_app_Login_Manager.svg.png)](https://et.wikipedia.org/wiki/Fail:Crystal_Clear_app_Login_Manager.svg)
**[Biograafiad](https://et.wikipedia.org/wiki/Portaal:Biograafiad "Portaal:Biograafiad")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Crystal_Clear_app_ksirtet.svg/40px-Crystal_Clear_app_ksirtet.svg.png)](https://et.wikipedia.org/wiki/Fail:Crystal_Clear_app_ksirtet.svg)
**[Filosoofia](https://et.wikipedia.org/wiki/Portaal:Filosoofia "Portaal:Filosoofia")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/Crystal_Clear_app_linuxconf.svg/40px-Crystal_Clear_app_linuxconf.svg.png)](https://et.wikipedia.org/wiki/Fail:Crystal_Clear_app_linuxconf.svg)
**[Infotehnoloogia](https://et.wikipedia.org/wiki/Portaal:Informaatika_ja_infotehnoloogia "Portaal:Informaatika ja infotehnoloogia")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5d/Crystal_Clear_app_wp.png/40px-Crystal_Clear_app_wp.png)](https://et.wikipedia.org/wiki/Fail:Crystal_Clear_app_wp.png)
**[Keel](https://et.wikipedia.org/wiki/Portaal:Keel "Portaal:Keel")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Racine_carr%C3%A9e_bleue.svg/40px-Racine_carr%C3%A9e_bleue.svg.png)](https://et.wikipedia.org/wiki/Fail:Racine_carr%C3%A9e_bleue.svg)
**[Matemaatika](https://et.wikipedia.org/wiki/Portaal:Matemaatika "Portaal:Matemaatika")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Crystal_Clear_app_aim3.png/40px-Crystal_Clear_app_aim3.png)](https://et.wikipedia.org/wiki/Fail:Crystal_Clear_app_aim3.png)
**[Psühholoogia](https://et.wikipedia.org/wiki/Portaal:Ps%C3%BChholoogia "Portaal:Psühholoogia")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Social_sciences.svg/40px-Social_sciences.svg.png)](https://et.wikipedia.org/wiki/Fail:Social_sciences.svg)
**[Sotsiaalteadused](https://et.wikipedia.org/wiki/Portaal:Sotsiaalteadused "Portaal:Sotsiaalteadused")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Crystal_Clear_app_pysol.png/40px-Crystal_Clear_app_pysol.png)](https://et.wikipedia.org/wiki/Fail:Crystal_Clear_app_pysol.png)
**[Sümboolika](https://et.wikipedia.org/wiki/Portaal:S%C3%BCmboolika "Portaal:Sümboolika")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/52/Fxemoji_u1F345.svg/40px-Fxemoji_u1F345.svg.png)](https://et.wikipedia.org/wiki/Fail:Fxemoji_u1F345.svg)
**[Toit](https://et.wikipedia.org/wiki/Portaal:Toit "Portaal:Toit")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/Crystal_Clear_app_logout.png/40px-Crystal_Clear_app_logout.png)](https://et.wikipedia.org/wiki/Fail:Crystal_Clear_app_logout.png)
**[Kõik portaalid](https://et.wikipedia.org/wiki/Vikipeedia:Portaalid "Vikipeedia:Portaalid")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Wikimedia-logo-circle.svg/40px-Wikimedia-logo-circle.svg.png)](https://et.wikipedia.org/wiki/Fail:Wikimedia-logo-circle.svg)
Sõsarprojektid
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://et.wikipedia.org/wiki/Fail:Wiktionary-logo.svg)
**[Vikisõnastik](https://et.wiktionary.org/wiki/ "wikt:")**  
Vaba sõnastik
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://et.wikipedia.org/wiki/Fail:Wikisource-logo.svg)
**[Vikitekstid](https://et.wikisource.org/wiki/ "s:")**  
Vabad tekstid
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://et.wikipedia.org/wiki/Fail:Wikiquote-logo.svg)
**[Vikitsitaadid](https://et.wikiquote.org/wiki/ "q:")**  
Tsitaadikogu
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)](https://et.wikipedia.org/wiki/Fail:Wikiversity-logo.svg)
**[Vikiülikool](https://beta.wikiversity.org/wiki/Esileht?uselang=et)**  
Õpikeskkond
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://et.wikipedia.org/wiki/Fail:Wikibooks-logo.svg)
**[Vikiõpikud](https://et.wikibooks.org/wiki/ "b:")**  
Vabad õpikud
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/WikiSpecies_notext.svg/40px-WikiSpecies_notext.svg.png)](https://et.wikipedia.org/wiki/Fail:WikiSpecies_notext.svg)
**[WikiSpecies](https://species.wikimedia.org/wiki/?uselang=et)**  
Elusolendite nimistu
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://et.wikipedia.org/wiki/Fail:Commons-logo.svg)
**[Commons](https://commons.wikimedia.org/wiki/?uselang=et)**  
Failivaramu
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://et.wikipedia.org/wiki/Fail:Wikinews-logo.svg)
**[Vikiuudised](https://et.wikinews.org/wiki/ "n:")**  
Vabad uudised
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://et.wikipedia.org/wiki/Fail:Wikidata-logo.svg)
**[Wikidata](https://www.wikidata.org/wiki/?uselang=et)**  
Andmebaas
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Wikivoyage-logo.svg/40px-Wikivoyage-logo.svg.png)](https://et.wikipedia.org/wiki/Fail:Wikivoyage-logo.svg)
**[Vikireisid](https://en.wikipedia.org/wiki/voy: "en:voy:")**  
Reisijuht
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://et.wikipedia.org/wiki/Fail:Wikimedia_Community_Logo.svg)
**[Metaviki](https://meta.wikimedia.org/wiki/Main_Page/et "m:Main Page/et")**  
Koordinatsioon
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/HS_geo.svg/40px-HS_geo.svg.png)](https://et.wikipedia.org/wiki/Fail:HS_geo.svg)
Vikipeediad teistes keeltes
**üle 1 000 000 artikliga Vikipeediad**
  * [araabia (العربية)](https://ar.wikipedia.org/wiki/ "ar:")
  * [Egiptuse araabia (مصرى)](https://arz.wikipedia.org/wiki/ "arz:")
  * [hiina (中文)](https://zh.wikipedia.org/wiki/ "zh:")
  * [hispaania (español)](https://es.wikipedia.org/wiki/ "es:")
  * [hollandi (Nederlands)](https://nl.wikipedia.org/wiki/ "nl:")
  * [inglise (English)](https://en.wikipedia.org/wiki/ "en:")
  * [itaalia (italiano)](https://it.wikipedia.org/wiki/ "it:")
  * [jaapani (日本語)](https://ja.wikipedia.org/wiki/ "ja:")
  * [poola (polski)](https://pl.wikipedia.org/wiki/ "pl:")
  * [portugali (português)](https://pt.wikipedia.org/wiki/ "pt:")
  * [prantsuse (français)](https://fr.wikipedia.org/wiki/ "fr:")
  * [pärsia (فارسی)](https://fa.wikipedia.org/wiki/ "fa:")
  * [rootsi (svenska)](https://sv.wikipedia.org/wiki/ "sv:")
  * [saksa (Deutsch)](https://de.wikipedia.org/wiki/ "de:")
  * [sebu (Cebuano)](https://ceb.wikipedia.org/wiki/ "ceb:")
  * [ukraina (українська)](https://uk.wikipedia.org/wiki/ "uk:")
  * [varai (Winaray)](https://war.wikipedia.org/wiki/ "war:")
  * [vene (русский)](https://ru.wikipedia.org/wiki/ "ru:")
  * [vietnami (Tiếng Việt)](https://vi.wikipedia.org/wiki/ "vi:")


**üle 500 000 artikliga Vikipeediad**
  * [indoneesia (Bahasa Indonesia)](https://id.wikipedia.org/wiki/ "id:")
  * [katalaani (català)](https://ca.wikipedia.org/wiki/ "ca:")
  * [korea (한국어)](https://ko.wikipedia.org/wiki/ "ko:")
  * [norra (norsk)](https://no.wikipedia.org/wiki/ "no:")
  * [serbia (српски / srpski)](https://sr.wikipedia.org/wiki/ "sr:")
  * [soome (suomi)](https://fi.wikipedia.org/wiki/ "fi:")
  * [tatari (татарча / tatarça)](https://tt.wikipedia.org/wiki/ "tt:")
  * [tšehhi (čeština)](https://cs.wikipedia.org/wiki/ "cs:")
  * [tšetšeeni (нохчийн)](https://ce.wikipedia.org/wiki/ "ce:")
  * [türgi (Türkçe)](https://tr.wikipedia.org/wiki/ "tr:")
  * [ungari (magyar)](https://hu.wikipedia.org/wiki/ "hu:")


**üle 200 000 artikliga Vikipeediad**
  * [armeenia (հայերեն)](https://hy.wikipedia.org/wiki/ "hy:")
  * [aserbaidžaani (azərbaycanca)](https://az.wikipedia.org/wiki/ "az:")
  * [baski (euskara)](https://eu.wikipedia.org/wiki/ "eu:")
  * [bulgaaria (български)](https://bg.wikipedia.org/wiki/ "bg:")
  * eesti (eesti)
  * [esperanto (Esperanto)](https://eo.wikipedia.org/wiki/ "eo:")
  * [galeegi (galego)](https://gl.wikipedia.org/wiki/ "gl:")
  * [heebrea (עברית)](https://he.wikipedia.org/wiki/ "he:")
  * [horvaadi (hrvatski)](https://hr.wikipedia.org/wiki/ "hr:")
  * [kasahhi (қазақша)](https://kk.wikipedia.org/wiki/ "kk:")
  * [kreeka (Ελληνικά)](https://el.wikipedia.org/wiki/ "el:")
  * [kõmri (Cymraeg)](https://cy.wikipedia.org/wiki/ "cy:")
  * [lihtsustatud inglise (Simple English)](https://simple.wikipedia.org/wiki/ "simple:")
  * [leedu (lietuvių)](https://lt.wikipedia.org/wiki/ "lt:")
  * [lõunaaserbaidžaani (تۆرکجه)](https://azb.wikipedia.org/wiki/ "azb:")
  * [lõuna-_min_ 'i (閩南語 / Bân-lâm-gí)](https://zh-min-nan.wikipedia.org/wiki/ "zh-min-nan:")
  * [malai (Bahasa Melayu)](https://ms.wikipedia.org/wiki/ "ms:")
  * [minangkabau (Minangkabau)](https://min.wikipedia.org/wiki/ "min:")
  * [rumeenia (română)](https://ro.wikipedia.org/wiki/ "ro:")
  * [serbia-horvaadi (srpskohrvatski / српскохрватски)](https://sh.wikipedia.org/wiki/ "sh:")
  * [slovaki (slovenčina)](https://sk.wikipedia.org/wiki/ "sk:")
  * [taani (dansk)](https://da.wikipedia.org/wiki/ "da:")
  * [urdu (اردو)](https://ur.wikipedia.org/wiki/ "ur:")
  * [usbeki (oʻzbekcha / ўзбекча)](https://uz.wikipedia.org/wiki/ "uz:")
  * [valgevene (беларуская)](https://be.wikipedia.org/wiki/ "be:")


**Vikipeedia soome-ugri keeltes**
  * eesti (eesti)
  * [ersa (эрзянь)](https://myv.wikipedia.org/wiki/ "myv:")
  * [inarisaami (anarâškielâ)](https://smn.wikipedia.org/wiki/ "smn:")
  * [komi (коми)](https://kv.wikipedia.org/wiki/ "kv:")
  * [livviko (livvinkarjala)](https://olo.wikipedia.org/wiki/ "olo:")
  * [mokša (мокшень)](https://mdf.wikipedia.org/wiki/ "mdf:")
  * [mäemari (кырык мары)](https://mrj.wikipedia.org/wiki/ "mrj:")
  * [niidumari (олык марий)](https://mhr.wikipedia.org/wiki/ "mhr:")
  * [permikomi (перем коми)](https://koi.wikipedia.org/wiki/ "koi:")
  * [põhjasaami (davvisámegiella)](https://se.wikipedia.org/wiki/ "se:")
  * [soome (suomi)](https://fi.wikipedia.org/wiki/ "fi:")
  * [udmurdi (удмурт)](https://udm.wikipedia.org/wiki/ "udm:")
  * [ungari (magyar)](https://hu.wikipedia.org/wiki/ "hu:")
  * [vepsa (vepsän kel’)](https://vep.wikipedia.org/wiki/ "vep:")
  * [võru (võro)](https://fiu-vro.wikipedia.org/wiki/ "fiu-vro:")


**[Kõik keeled...](https://meta.wikimedia.org/wiki/List_of_Wikipedias "m:List of Wikipedias")**
Pärit leheküljelt "[https://et.wikipedia.org/w/index.php?title=Vikipeedia:Esileht&oldid=6795043](https://et.wikipedia.org/w/index.php?title=Vikipeedia:Esileht&oldid=6795043)"
353 keelt
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – atšehi")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – adõgee")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – kabardi-tšerkessi")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – afrikaani")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – šveitsisaksa")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – altai")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – amhara")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – Inari saami")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – angika")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – vanainglise")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – abhaasi")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – araabia")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – aragoni")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – aramea")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – läänearmeenia")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – aromuuni")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – frankoprovansi")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – assami")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – astuuria")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – atikameki")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – avadhi")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – guaranii")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – avaari")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – aimara")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – aserbaidžaani")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – lõunaaserbaidžaani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – gorontalo")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama – indoneesia")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – malai")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – bali")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – bambara")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – bengali")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – bandžari")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – lõunamini")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasi murre")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – baškiiri")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – valgevene")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – valgevene \(taraškievitsa\)")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – madura")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – bihaari")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – keskbikoli")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – bislama")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – baieri")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – tiibeti")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – bosnia")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – bretooni")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – bugi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница – bulgaaria")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – burjaadi")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – katalaani")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – sebu")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – tšuvaši")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana – tšehhi")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – tšamorro")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Zamboanga tšavakano")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – njandža")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – šona")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – tumbuka")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – tšokto")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – korsika")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – kõmri")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – dagbani")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside – taani")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – Maroko araabia")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – põhjasaami")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – Pennsylvania saksa")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – saksa")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – maldiivi")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – navaho")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – alamsorbi")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – dzongkha")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – maršalli")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – kreeka")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – emiilia-romanja")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – inglise")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – ersa")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – hispaania")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – esperanto")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – estremenju")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala – baski")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – eve")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – farefare")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – pärsia")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – Fidži hindi")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – fääri")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal – prantsuse")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – läänefriisi")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – fula")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – friuuli")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – iiri")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – mänksi")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – samoa")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – gagauusi")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – gaeli")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – galeegi")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – inguši")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – kani")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – kikuju")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – gilaki")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – gudžarati")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – gooti")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goa konkani")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – hakka")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – kalmõki")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – korea")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – hausa")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – havai")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ – armeenia")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – hindi")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – hirimotu")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – ülemsorbi")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – horvaadi")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – ido")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – ibo")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – iloko")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – bišnuprija")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – interlingua")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – interlingue")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – inuktituti")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – injupiaki")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – osseedi")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – koosa")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – suulu")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – islandi")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – itaalia")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – heebrea")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – jaava")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – kabije")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – grööni")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – kannada")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – kanuri")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – pampanga")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – karatšai-balkaari")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – gruusia")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – kašmiiri")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – kašuubi")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – kasahhi")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – korni")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – ruanda")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – kirgiisi")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – rundi")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – mäemari")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – suahiili")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – komi")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – kongo")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – Kotava")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – haiti")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Guajaana kreoolkeel")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – kurdi")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – kvanjama")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – ladiini")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – ladiino")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – laki")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – lao")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima – ladina")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – põhjaluri")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – latgali")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – läti")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – tonga")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – letseburgi")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – lesgi")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – leedu")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – niasi")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – liguuri")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – limburgi")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – lingala")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – Lingua Franca Nova")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – livviko")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – ložban")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – ganda")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – lombardi")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – ungari")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – maithili")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – makedoonia")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – malagassi")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – malajalami")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – malta")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – maoori")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – marathi")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – megreli")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – Egiptuse araabia")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – mazandaraani")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – manipuri")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – fanti")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – minangkabau")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – idamini")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – miranda")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – mokša")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – mongoli")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – maskogi")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – birma")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – nahua")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – Nigeeria pidžinkeel")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – fidži")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina – hollandi")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – Hollandi alamsaksa")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – krii")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – nepali")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – nevari")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – jaapani")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – napoli")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – nkoo")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – tšetšeeni")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – põhjafriisi")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – norfuki")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – norra bokmål")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – uusnorra")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Normandia")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – noviaal")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – oksitaani")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – niidumari")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – oria")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – oromo")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – ndonga")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – herero")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – usbeki")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – pandžabi")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – paali")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – Pfalzi")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – pangasinani")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – amise")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – lahnda")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – paoo")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – papiamento")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – puštu")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – Jamaica kreoolkeel")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – permikomi")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – khmeeri")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – šani")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – moni")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – pikardi")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – piemonte")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – paivani")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – alamsaksa")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – poola")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – pontose")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – portugali")
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – afari")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – karakalpaki")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – krimmitatari")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – tahiti")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – kölni")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – rumeenia")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Valahhia mustlaskeel")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – romanši")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – ketšua")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – russiini")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – vene")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – jakuudi")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – sanskriti")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – sango")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – santali")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – seraiki")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – sardi")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – šoti")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – taroko")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – saterfriisi")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – lõunasotho")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – põhjasotho")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – tsvana")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – albaania")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – sitsiilia")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – singali")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – lihtsustatud inglise")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – sindhi")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – svaasi")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – slovaki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – sloveeni")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – kirikuslaavi")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – sileesia")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – somaali")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – sorani")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – sranani")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – serbia")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – serbia-horvaadi")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – sunda")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – soome")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – rootsi")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – šilha")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – tagalogi")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – tamili")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – kabiili")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – tatari")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – atajali")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – telugu")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – tetumi")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – dinka")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – tai")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – vietnami")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – tigrinja")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – tadžiki")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – uusmelaneesia")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – tšerokii")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – šaieeni")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – venda")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – tulu")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – türgi")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – türkmeeni")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – tvii")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – tjapi")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – tõva")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – udmurdi")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – ukraina")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – urdu")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – uiguuri")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – tšuangi")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – veneti")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – vepsa")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – volapüki")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – võru")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – vallooni")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – klassikaline hiina")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – lääneflaami")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – varai")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – vajuu")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – volofi")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – uu")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – tsonga")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – jidiši")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – joruba")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – kantoni")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – dõmli")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – zeelandi")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – žemaidi")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 – hiina")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – obolo")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – bataki")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – lääneranniku badžau")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – betavi")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Mandailingi bataki")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – dagaari")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – keskdusuni")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – foni")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghana pidžinkeel")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – ibani")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – igala")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – more")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – lõunandebele")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – arakani")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannoonia russiini")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – siloti")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – tai-nõa")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – tigree")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – talõši")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – tamasikti \(Maroko\)")


[Muuda linke](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Muuda keelelinke")
  * Selle lehekülje viimane muutmine: 8. jaanuar 2025, kell 12:22.
  * Tekst on kasutatav vastavalt Creative Commonsi litsentsile "[Autorile viitamine + jagamine samadel tingimustel](https://creativecommons.org/licenses/by-sa/4.0/deed.et)"; sellele võivad lisanduda täiendavad tingimused. Täpsemalt vaata [Wikimedia kasutamistingimustest](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use).


  * [Andmekaitsepõhimõtted](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Tiitelandmed](https://et.wikipedia.org/wiki/Vikipeedia:Tiitelandmed)
  * [Lahtiütlused](https://et.wikipedia.org/wiki/Vikipeedia:%C3%9Cldine_lahti%C3%BCtlus)
  * [Käitumisjuhis](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Arendajad](https://developer.wikimedia.org)
  * [Arvandmed](https://stats.wikimedia.org/#/et.wikipedia.org)
  * [Küpsiste avaldus](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Mobiilivaade](https://et.m.wikipedia.org/w/index.php?title=Vikipeedia:Esileht&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://et.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://et.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Otsing
Otsi
Vikipeedia:Esileht
[](https://et.wikipedia.org/wiki/Vikipeedia:Esileht) [](https://et.wikipedia.org/wiki/Vikipeedia:Esileht) [](https://et.wikipedia.org/wiki/Vikipeedia:Esileht) [](https://et.wikipedia.org/wiki/Vikipeedia:Esileht) [](https://et.wikipedia.org/wiki/Vikipeedia:Esileht) [](https://et.wikipedia.org/wiki/Vikipeedia:Esileht) [](https://et.wikipedia.org/wiki/Vikipeedia:Esileht) [](https://et.wikipedia.org/wiki/Vikipeedia:Esileht)
353 keelt [Lisa teema ](https://et.wikipedia.org/wiki/Vikipeedia:Esileht)
