[Перайсці да зместу](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0#bodyContent)
Галоўнае меню
Галоўнае меню
перанесці да бакавой панэлі схаваць
Навігацыя 
  * [Галоўная старонка](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Адкрыць Галоўную старонку \[z\]")
  * [Супольнасць](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%A1%D1%83%D0%BF%D0%BE%D0%BB%D1%8C%D0%BD%D0%B0%D1%81%D1%86%D1%8C "Пра праект, чым можна заняцца, дзе што шукаць")
  * [Апошнія змены](https://be.wikipedia.org/wiki/%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:RecentChanges "Пералік нядаўніх змяненняў у віксе. \[r\]")
  * [Новыя старонкі](https://be.wikipedia.org/wiki/%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:NewPages)
  * [Форум](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%A4%D0%BE%D1%80%D1%83%D0%BC)
  * [Выпадковая старонка](https://be.wikipedia.org/wiki/%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:Random "Паказаць выпадковую старонку \[x\]")
  * [Даведка](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%94%D0%B0%D0%B2%D0%B5%D0%B4%D0%BA%D0%B0 "Дзе можна атрымаць тлумачэнні.")
  * [Паведаміць пра памылку](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%9F%D0%B0%D0%B2%D0%B5%D0%B4%D0%B0%D0%BC%D0%BB%D0%B5%D0%BD%D0%BD%D1%96_%D0%BF%D1%80%D0%B0_%D0%BF%D0%B0%D0%BC%D1%8B%D0%BB%D0%BA%D1%96)


[ ![](https://be.wikipedia.org/static/images/icons/wikipedia.png) ![Вікіпедыя](https://be.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-be.svg) ![](https://be.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-be.svg) ](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0)
[Пошук ](https://be.wikipedia.org/wiki/%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:Search "Знайсці ў Вікіпедыі \[f\]")
Пошук
Выгляд
  * [Ахвяраваць](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=be.wikipedia.org&uselang=be)
  * [Стварыць уліковы запіс](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:CreateAccount&returnto=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F+%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Вам прапануецца стварыць уліковы запіс і ўвайсці ў сістэму, але гэта не абавязкова")
  * [Увайсці](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:UserLogin&returnto=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F+%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Вам прапануецца ўвайсці ў сістэму, але гэта неабавязкова. \[o\]")


Асабістыя інструменты
  * [Ахвяраваць](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=be.wikipedia.org&uselang=be)
  * [Стварыць уліковы запіс](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:CreateAccount&returnto=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F+%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Вам прапануецца стварыць уліковы запіс і ўвайсці ў сістэму, але гэта не абавязкова")
  * [Увайсці](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:UserLogin&returnto=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F+%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Вам прапануецца ўвайсці ў сістэму, але гэта неабавязкова. \[o\]")


[не паказваць]
# Галоўная старонка
**Праверана**
  * [Галоўная старонка](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Паказаць уласна змест старонкі \[c\]")
  * [Размовы](https://be.wikipedia.org/wiki/%D0%A0%D0%B0%D0%B7%D0%BC%D0%BE%D0%B2%D1%8B:%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Размовы пра змест гэтай старонкі \[t\]")


беларуская
  * [Чытаць](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0)
  * [Паказаць зыходны тэкст](https://be.wikipedia.org/w/index.php?title=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&action=edit "Гэтая старонка ахоўваецца, але можна паглядзець яе зыходны тэкст. \[e\]")
  * [Паказаць гісторыю](https://be.wikipedia.org/w/index.php?title=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&action=history "Ранейшыя версіі гэтай старонкі. \[h\]")


Інструменты
Інструменты
перанесці да бакавой панэлі схаваць
Дзеянні 
  * [Чытаць](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0)
  * [Паказаць зыходны тэкст](https://be.wikipedia.org/w/index.php?title=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&action=edit)
  * [Паказаць гісторыю](https://be.wikipedia.org/w/index.php?title=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&action=history)


Агульныя 
  * [Сюды спасылаюцца](https://be.wikipedia.org/wiki/%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:WhatLinksHere/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Спіс вікістаронак, якія спасылаюцца сюды \[j\]")
  * [Звязаныя праўкі](https://be.wikipedia.org/wiki/%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:RecentChangesLinked/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Нядаўнія змены ў старонках, на якія спасылаецца гэтая старонка \[k\]")
  * [Нязменная спасылка](https://be.wikipedia.org/w/index.php?title=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&oldid=4918424 "Нязменная спасылка на гэтую версію гэтай старонкі")
  * [Звесткі пра старонку](https://be.wikipedia.org/w/index.php?title=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&action=info "Больш звестак пра гэту старонку")
  * [Цытаваць гэту старонку](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:CiteThisPage&page=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&id=4918424&wpFormIdentifier=titleform "Інфармацыя пра тое, як цытаваць гэтую старонку")
  * [Атрымаць скарочаны URL-адрас](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:UrlShortener&url=https%3A%2F%2Fbe.wikipedia.org%2Fwiki%2F%25D0%2593%25D0%25B0%25D0%25BB%25D0%25BE%25D1%259E%25D0%25BD%25D0%25B0%25D1%258F_%25D1%2581%25D1%2582%25D0%25B0%25D1%2580%25D0%25BE%25D0%25BD%25D0%25BA%25D0%25B0)
  * [Спампаваць QR-код](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:QrCode&url=https%3A%2F%2Fbe.wikipedia.org%2Fwiki%2F%25D0%2593%25D0%25B0%25D0%25BB%25D0%25BE%25D1%259E%25D0%25BD%25D0%25B0%25D1%258F_%25D1%2581%25D1%2582%25D0%25B0%25D1%2580%25D0%25BE%25D0%25BD%25D0%25BA%25D0%25B0)


Друк/экспарт 
  * [Стварыць кнігу](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:Book&bookcmd=book_creator&referer=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F+%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0)
  * [Спампаваць як PDF](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:DownloadAsPdf&page=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&action=show-download-screen)
  * [Для друку](https://be.wikipedia.org/w/index.php?title=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&printable=yes "Друкавальная версія гэтай старонкі \[p\]")


У іншых праектах 
  * [Вікісховішча](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [МедыяВікі](https://www.mediawiki.org/wiki/MediaWiki)
  * [МетаВікі](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Шматмоўныя Вікікрыніцы](https://wikisource.org/wiki/Main_Page)
  * [Віківіды](https://species.wikimedia.org/wiki/Main_Page)
  * [Вікікнігі](https://be.wikibooks.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0)
  * [Вікіданыя](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Вікіцытатнік](https://be.wikiquote.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0)
  * [Вікікрыніцы](https://be.wikisource.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0)
  * [Вікіслоўнік](https://be.wiktionary.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0)
  * [Элемент Вікіданых](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Спасылка на звязаны элемент рэпазітара даных \[g\]")


Выгляд
перанесці да бакавой панэлі схаваць
З Вікіпедыі, свабоднай энцыклапедыі
## Статус версіі старонкі
Гэта дагледжаная версія старонкі
Гэта [апублікаваная версія](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%94%D0%BE%D0%B3%D0%BB%D1%8F%D0%B4 "Вікіпедыя:Догляд"), [дагледжаная](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:Log&type=review&page=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0) _18 студзеня 2025_.
Вітаем у [Вікіпедыі](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F "Вікіпедыя"), [свабоднай](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%A8%D1%82%D0%BE_%D1%82%D0%B0%D0%BA%D0%BE%D0%B5_%D1%81%D0%B2%D0%B0%D0%B1%D0%BE%D0%B4%D0%BD%D0%B0%D1%8F_%D1%8D%D0%BD%D1%86%D1%8B%D0%BA%D0%BB%D0%B0%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F "Вікіпедыя:Што такое свабодная энцыклапедыя") [энцыклапедыі](https://be.wikipedia.org/wiki/%D0%AD%D0%BD%D1%86%D1%8B%D0%BA%D0%BB%D0%B0%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F "Энцыклапедыя"),  
правіць якую можа кожны і кожная. 
[1 кастрычніка](https://be.wikipedia.org/wiki/1_%D0%BA%D0%B0%D1%81%D1%82%D1%80%D1%8B%D1%87%D0%BD%D1%96%D0%BA%D0%B0 "1 кастрычніка") [2025](https://be.wikipedia.org/wiki/2025 "2025") года  
**[256 263](https://be.wikipedia.org/wiki/%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:Statistics "Адмысловае:Statistics")** артыкулы на [беларускай мове](https://be.wikipedia.org/wiki/%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D0%BA%D0%B0%D1%8F_%D0%BC%D0%BE%D0%B2%D0%B0 "Беларуская мова")  
**[Парталы](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%9F%D0%B0%D1%80%D1%82%D0%B0%D0%BB%D1%8B "Вікіпедыя:Парталы")**
[Зборы асноўных правіл Вікіпедыі](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%A1%D0%BF%D1%96%D1%81_%D0%BF%D1%80%D0%B0%D0%B2%D1%96%D0%BB_%D1%96_%D1%80%D1%8D%D0%BA%D0%B0%D0%BC%D0%B5%D0%BD%D0%B4%D0%B0%D1%86%D1%8B%D0%B9 "Вікіпедыя:Спіс правіл і рэкамендацый") • [Як шукаць інфармацыю](https://be.wikipedia.org/wiki/%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:Search "Адмысловае:Search") • [Як пісаць артыкулы](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%AF%D0%BA_%D1%81%D1%82%D0%B2%D0%B0%D1%80%D0%B0%D1%86%D1%8C_%D0%B0%D1%80%D1%82%D1%8B%D0%BA%D1%83%D0%BB "Вікіпедыя:Як ствараць артыкул") • [Як ілюстраваць артыкулы](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%92%D1%8B%D1%8F%D0%B2%D1%8B "Вікіпедыя:Выявы")
[![Кшыштаф Кеслёўскі](https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Krzysztof_Kie%C5%9Blowski.jpg/120px-Krzysztof_Kie%C5%9Blowski.jpg)](https://be.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Krzysztof_Kie%C5%9Blowski.jpg "Кшыштаф Кеслёўскі")Кшыштаф Кеслёўскі
**«[Requiem for my friend](https://be.wikipedia.org/wiki/Requiem_for_my_friend "Requiem for my friend")»** або **«Requiem dla mojego przyjaciela»** ([па-беларуску](https://be.wikipedia.org/wiki/%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D0%BA%D0%B0%D1%8F_%D0%BC%D0%BE%D0%B2%D0%B0 "Беларуская мова"): Рэквіем па маім сябры) — альбом [Збігнева Прайснера](https://be.wikipedia.org/wiki/%D0%97%D0%B1%D1%96%D0%B3%D0%BD%D0%B5%D1%9E_%D0%9F%D1%80%D0%B0%D0%B9%D1%81%D0%BD%D0%B5%D1%80 "Збігнеў Прайснер"), першая буйнамаштабная праца кампазітара, створаная адмыслова для студыйнага запісу і публічнага выканання. Паводле першапачатковай задумы твор мусіў быць тэатралізаваным канцэртам на музыку Прайснера, сцэнарый да якога напіша [Кшыштаф Пясевіч](https://be.wikipedia.org/wiki/%D0%9A%D1%88%D1%8B%D1%88%D1%82%D0%B0%D1%84_%D0%9F%D1%8F%D1%81%D0%B5%D0%B2%D1%96%D1%87 "Кшыштаф Пясевіч"), а зрэжысіруе [Кшыштаф Кеслёўскі](https://be.wikipedia.org/wiki/%D0%9A%D1%88%D1%8B%D1%88%D1%82%D0%B0%D1%84_%D0%9A%D0%B5%D1%81%D0%BB%D1%91%D1%9E%D1%81%D0%BA%D1%96 "Кшыштаф Кеслёўскі"). Аднак пасля заўчаснай смерці апошняга ў 1996 годзе, задуманы твор пераўтварыўся ў [рэквіем](https://be.wikipedia.org/wiki/%D0%A0%D1%8D%D0%BA%D0%B2%D1%96%D0%B5%D0%BC_\(%D0%BC%D1%83%D0%B7%D1%8B%D0%BA%D0%B0\) "Рэквіем \(музыка\)"), прысвечаны памяці рэжысёра. 
Прэм’ера _«Рэквіема»_ адбылася 1 кастрычніка [1998](https://be.wikipedia.org/wiki/1998 "1998") года ў [Вялікім тэатры Варшавы](https://be.wikipedia.org/wiki/%D0%92%D1%8F%D0%BB%D1%96%D0%BA%D1%96_%D1%82%D1%8D%D0%B0%D1%82%D1%80_\(%D0%92%D0%B0%D1%80%D1%88%D0%B0%D0%B2%D0%B0\) "Вялікі тэатр \(Варшава\)"). 19 сакавіка [1999](https://be.wikipedia.org/wiki/1999 "1999") года ў Лондане прайшла вялікая брытанская прэм’ера твора _([далей…](https://be.wikipedia.org/wiki/Requiem_for_my_friend "Requiem for my friend"))_. 
[Артыкулы дня](https://be.wikipedia.org/wiki/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD:%D0%92%D1%8B%D0%B1%D1%80%D0%B0%D0%BD%D1%8B_%D0%B7%D0%BC%D0%B5%D1%81%D1%82 "Шаблон:Выбраны змест") · [Выдатныя артыкулы](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%92%D1%8B%D0%B4%D0%B0%D1%82%D0%BD%D1%8B%D1%8F_%D0%B0%D1%80%D1%82%D1%8B%D0%BA%D1%83%D0%BB%D1%8B "Вікіпедыя:Выдатныя артыкулы") · [Добрыя артыкулы](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%94%D0%BE%D0%B1%D1%80%D1%8B%D1%8F_%D0%B0%D1%80%D1%82%D1%8B%D0%BA%D1%83%D0%BB%D1%8B "Вікіпедыя:Добрыя артыкулы") · [Выдатныя спісы](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%92%D1%8B%D0%B4%D0%B0%D1%82%D0%BD%D1%8B%D1%8F_%D1%81%D0%BF%D1%96%D1%81%D1%8B "Вікіпедыя:Выдатныя спісы")
  * [Алелі](https://be.wikipedia.org/wiki/%D0%90%D0%BB%D0%B5%D0%BB%D1%96 "Алелі") могуць распаўсюджвацца **[аўтастопам](https://be.wikipedia.org/wiki/%D0%93%D0%B5%D0%BD%D0%B5%D1%82%D1%8B%D1%87%D0%BD%D1%8B_%D0%B0%D1%9E%D1%82%D0%B0%D1%81%D1%82%D0%BE%D0%BF "Генетычны аўтастоп")**.
  * [Від](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%B4,_%D0%B1%D1%96%D1%8F%D0%BB%D0%BE%D0%B3%D1%96%D1%8F "Від, біялогія") **[павукоў-вегетарыянцаў](https://be.wikipedia.org/wiki/Bagheera_kiplingi "Bagheera kiplingi")** быў названы ў гонар [пісьменніка](https://be.wikipedia.org/wiki/%D0%94%D0%B6%D0%BE%D0%B7%D0%B5%D1%84_%D0%A0%D1%8D%D0%B4%D0%B7%D1%8C%D1%8F%D1%80%D0%B4_%D0%9A%D1%96%D0%BF%D0%BB%D1%96%D0%BD%D0%B3 "Джозеф Рэдзьярд Кіплінг") і [выдуманай](https://en.wikipedia.org/wiki/Bagheera "en:Bagheera") (англ.) ([бел.](https://be.wikipedia.org/w/index.php?title=%D0%91%D0%B0%D0%B3%D1%96%D1%80%D0%B0&action=edit&redlink=1 "Багіра \(няма такой старонкі\)") [пантэры](https://be.wikipedia.org/wiki/%D0%9F%D0%B0%D0%BD%D1%82%D1%8D%D1%80%D1%8B "Пантэры").
  * Сярод фігур манумента «**[Тысячагоддзе Расіі](https://be.wikipedia.org/wiki/%D0%A2%D1%8B%D1%81%D1%8F%D1%87%D0%B0%D0%B3%D0%BE%D0%B4%D0%B4%D0%B7%D0%B5_%D0%A0%D0%B0%D1%81%D1%96%D1%96 "Тысячагоддзе Расіі")** » ёсць чацвёра [вялікіх князёў літоўскіх](https://be.wikipedia.org/wiki/%D0%92%D1%8F%D0%BB%D1%96%D0%BA%D1%96_%D0%BA%D0%BD%D1%8F%D0%B7%D1%8C_%D0%BB%D1%96%D1%82%D0%BE%D1%9E%D1%81%D0%BA%D1%96 "Вялікі князь літоўскі").
  * Ля вытокаў [сацыяльнай](https://be.wikipedia.org/wiki/%D0%A1%D0%B0%D1%86%D1%8B%D1%8F%D0%BB%D1%8C%D0%BD%D0%B0%D1%8F_%D0%BF%D1%81%D1%96%D1%85%D0%B0%D0%BB%D0%BE%D0%B3%D1%96%D1%8F "Сацыяльная псіхалогія") і карэкцыйнай псіхалогіі ў [Бразіліі](https://be.wikipedia.org/wiki/%D0%91%D1%80%D0%B0%D0%B7%D1%96%D0%BB%D1%96%D1%8F "Бразілія") стаяла **[ўраджэнка](https://be.wikipedia.org/wiki/%D0%90%D0%BB%D0%B5%D0%BD%D0%B0_%D0%A3%D0%BB%D0%B0%D0%B4%D0%B7%D1%96%D0%BC%D1%96%D1%80%D0%B0%D1%9E%D0%BD%D0%B0_%D0%90%D0%BD%D1%86%D1%96%D0%BF%D0%B0%D0%B2%D0%B0 "Алена Уладзіміраўна Анціпава")** [Гродна](https://be.wikipedia.org/wiki/%D0%93%D1%80%D0%BE%D0%B4%D0%BD%D0%B0 "Гродна").
  * У выніку **[найбуйнейшага акту экалагічнай вайны ў гісторыі](https://be.wikipedia.org/wiki/%D0%9F%D0%B0%D0%B2%D0%BE%D0%B4%D0%BA%D0%B0_%D0%BD%D0%B0_%D0%A5%D1%83%D0%B0%D0%BD%D1%85%D1%8D_1938_%D0%B3%D0%BE%D0%B4%D0%B0 "Паводка на Хуанхэ 1938 года")** загінула прынамсі пяцьсот тысяч чалавек.
  * Асновай **[кейнсіянства](https://be.wikipedia.org/wiki/%D0%9A%D0%B5%D0%B9%D0%BD%D1%81%D1%96%D1%8F%D0%BD%D1%81%D1%82%D0%B2%D0%B0 "Кейнсіянства")** з'яўляецца ідэя, што рынкі не заўсёды здольныя самастойна забяспечыць [поўную занятасць](https://be.wikipedia.org/wiki/%D0%9F%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D0%B7%D0%B0%D0%BD%D1%8F%D1%82%D0%B0%D1%81%D1%86%D1%8C "Поўная занятасць") і стабільны эканамічны рост.
  * У [Паўднёвай Карэі](https://be.wikipedia.org/wiki/%D0%A0%D1%8D%D1%81%D0%BF%D1%83%D0%B1%D0%BB%D1%96%D0%BA%D0%B0_%D0%9A%D0%B0%D1%80%D1%8D%D1%8F "Рэспубліка Карэя") арганізавалі **[кампанію па зборы](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D0%BC%D0%BF%D0%B0%D0%BD%D1%96%D1%8F_%D0%BF%D0%B0_%D0%B7%D0%B1%D0%BE%D1%80%D1%8B_%D0%B7%D0%BE%D0%BB%D0%B0%D1%82%D0%B0 "Кампанія па зборы золата")** [золата](https://be.wikipedia.org/wiki/%D0%97%D0%BE%D0%BB%D0%B0%D1%82%D0%B0 "Золата") дзеля пераадолення [фінансавага крызісу](https://en.wikipedia.org/wiki/1997_Asian_financial_crisis "en:1997 Asian financial crisis") (англ.) ([бел.](https://be.wikipedia.org/w/index.php?title=%D0%90%D0%B7%D1%96%D1%8F%D1%86%D0%BA%D1%96_%D1%84%D1%96%D0%BD%D0%B0%D0%BD%D1%81%D0%B0%D0%B2%D1%8B_%D0%BA%D1%80%D1%8B%D0%B7%D1%96%D1%81&action=edit&redlink=1 "Азіяцкі фінансавы крызіс \(няма такой старонкі\)").


[Падрыхтоўка](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%9F%D1%80%D0%B0%D0%B5%D0%BA%D1%82:%D0%A6%D1%96_%D0%B2%D0%B5%D0%B4%D0%B0%D0%B5%D1%86%D0%B5_%D0%B2%D1%8B/%D0%9F%D0%B0%D0%B4%D1%80%D1%8B%D1%85%D1%82%D0%BE%D1%9E%D0%BA%D0%B0 "Вікіпедыя:Праект:Ці ведаеце вы/Падрыхтоўка") · [Прагляд](https://be.wikipedia.org/wiki/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD:%D0%A6%D1%96_%D0%B2%D0%B5%D0%B4%D0%B0%D0%B5%D1%86%D0%B5_%D0%B2%D1%8B "Шаблон:Ці ведаеце вы") · [Архіў](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%9F%D1%80%D0%B0%D0%B5%D0%BA%D1%82:%D0%A6%D1%96_%D0%B2%D0%B5%D0%B4%D0%B0%D0%B5%D1%86%D0%B5_%D0%B2%D1%8B/%D0%9F%D0%B0%D0%B4%D1%80%D1%8B%D1%85%D1%82%D0%BE%D1%9E%D0%BA%D0%B0/%D0%90%D1%80%D1%85%D1%96%D1%9E "Вікіпедыя:Праект:Ці ведаеце вы/Падрыхтоўка/Архіў")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Citizen-Einstein.jpg/330px-Citizen-Einstein.jpg)](https://be.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Citizen-Einstein.jpg)  
[Альберт Эйнштэйн](https://be.wikipedia.org/wiki/%D0%90%D0%BB%D1%8C%D0%B1%D0%B5%D1%80%D1%82_%D0%AD%D0%B9%D0%BD%D1%88%D1%82%D1%8D%D0%B9%D0%BD "Альберт Эйнштэйн") прымае амерканскае грамадзянства, 1940 год.
[Выявы дня](https://be.wikipedia.org/wiki/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD:%D0%92%D1%8B%D1%8F%D0%B2%D1%8B_%D0%B4%D0%BD%D1%8F "Шаблон:Выявы дня")
  * Па выніках парламенцкіх выбараў у [Малдове](https://be.wikipedia.org/wiki/%D0%9C%D0%B0%D0%BB%D0%B4%D0%BE%D0%B2%D0%B0 "Малдова") партыя «**[Дзеянне і салідарнасць](https://be.wikipedia.org/wiki/%D0%9F%D0%B0%D1%80%D1%82%D1%8B%D1%8F_%C2%AB%D0%94%D0%B7%D0%B5%D1%8F%D0%BD%D0%BD%D0%B5_%D1%96_%D1%81%D0%B0%D0%BB%D1%96%D0%B4%D0%B0%D1%80%D0%BD%D0%B0%D1%81%D1%86%D1%8C%C2%BB "Партыя «Дзеянне і салідарнасць»")** » захавала большасць у [парламенце](https://be.wikipedia.org/wiki/%D0%9F%D0%B0%D1%80%D0%BB%D0%B0%D0%BC%D0%B5%D0%BD%D1%82_%D0%9C%D0%B0%D0%BB%D0%B4%D0%BE%D0%B2%D1%8B "Парламент Малдовы"). _(28 верасня)_
  * [Польшча](https://be.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BB%D1%8C%D1%88%D1%87%D0%B0 "Польшча") адкрыла [мяжу з Беларуссю](https://be.wikipedia.org/wiki/%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D0%BA%D0%B0-%D0%BF%D0%BE%D0%BB%D1%8C%D1%81%D0%BA%D0%B0%D1%8F_%D0%B3%D1%80%D0%B0%D0%BD%D1%96%D1%86%D0%B0 "Беларуска-польская граніца") пасля вучэнняў **«[Захад-2025](https://be.wikipedia.org/wiki/%D0%97%D0%B0%D1%85%D0%B0%D0%B4-2025 "Захад-2025")»**. _(25 верасня)_
  * Узнагарода «**[Залаты мяч](https://be.wikipedia.org/wiki/%D0%97%D0%B0%D0%BB%D0%B0%D1%82%D1%8B_%D0%BC%D1%8F%D1%87 "Залаты мяч")** » прысуджана [Усману Дэмбеле](https://be.wikipedia.org/wiki/%D0%A3%D1%81%D0%BC%D0%B0%D0%BD_%D0%94%D1%8D%D0%BC%D0%B1%D0%B5%D0%BB%D0%B5 "Усман Дэмбеле") (сярод мужчын) і [Айтане Банмаці](https://be.wikipedia.org/wiki/%D0%90%D0%B9%D1%82%D0%B0%D0%BD%D0%B0_%D0%91%D0%B0%D0%BD%D0%BC%D0%B0%D1%86%D1%96 "Айтана Банмаці") (сярод жанчын). _(22 верасня)_


[Іншыя актуальныя падзеі](https://be.wikipedia.org/wiki/%D0%9F%D0%B0%D1%80%D1%82%D0%B0%D0%BB:%D0%90%D0%BA%D1%82%D1%83%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D1%8F_%D0%BF%D0%B0%D0%B4%D0%B7%D0%B5%D1%96 "Партал:Актуальныя падзеі") · [Падрыхтоўка](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%9F%D1%80%D0%B0%D0%B5%D0%BA%D1%82:%D0%9D%D0%B0%D0%B2%D1%96%D0%BD%D1%8B/%D0%9F%D0%B0%D0%B4%D1%80%D1%8B%D1%85%D1%82%D0%BE%D1%9E%D0%BA%D0%B0 "Вікіпедыя:Праект:Навіны/Падрыхтоўка") · [Прагляд](https://be.wikipedia.org/wiki/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD:%D0%90%D0%BF%D0%BE%D1%88%D0%BD%D1%96%D1%8F_%D0%BD%D0%B0%D0%B2%D1%96%D0%BD%D1%8B "Шаблон:Апошнія навіны") · [Архіў](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%9F%D1%80%D0%B0%D0%B5%D0%BA%D1%82:%D0%9D%D0%B0%D0%B2%D1%96%D0%BD%D1%8B/%D0%90%D1%80%D1%85%D1%96%D1%9E "Вікіпедыя:Праект:Навіны/Архіў")
**[1 кастрычніка](https://be.wikipedia.org/wiki/1_%D0%BA%D0%B0%D1%81%D1%82%D1%80%D1%8B%D1%87%D0%BD%D1%96%D0%BA%D0%B0 "1 кастрычніка")**      [![Сцяг ААН](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Flag_of_the_United_Nations.svg/40px-Flag_of_the_United_Nations.svg.png)](https://be.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Flag_of_the_United_Nations.svg "Сцяг ААН") [ААН](https://be.wikipedia.org/wiki/%D0%90%D1%80%D0%B3%D0%B0%D0%BD%D1%96%D0%B7%D0%B0%D1%86%D1%8B%D1%8F_%D0%90%D0%B1%E2%80%99%D1%8F%D0%B4%D0%BD%D0%B0%D0%BD%D1%8B%D1%85_%D0%9D%D0%B0%D1%86%D1%8B%D0%B9 "Арганізацыя Аб’яднаных Нацый"): Міжнародны дзень пажылых людзей      [![Сцяг Кіпра](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Flag_of_Cyprus.svg/40px-Flag_of_Cyprus.svg.png)](https://be.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Flag_of_Cyprus.svg "Сцяг Кіпра") [Кіпр](https://be.wikipedia.org/wiki/%D0%9A%D1%96%D0%BF%D1%80 "Кіпр"): Дзень незалежнасці (1960)      [![Сцяг Кітая](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Flag_of_the_People%27s_Republic_of_China.svg/40px-Flag_of_the_People%27s_Republic_of_China.svg.png)](https://be.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Flag_of_the_People%27s_Republic_of_China.svg "Сцяг Кітая") [Кітай](https://be.wikipedia.org/wiki/%D0%9A%D1%96%D1%82%D0%B0%D0%B9 "Кітай"): Дзень абвяшчэння КНР ([1949](https://be.wikipedia.org/wiki/1949 "1949"))      [![Сцяг Нігерыі](https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/Flag_of_Nigeria.svg/40px-Flag_of_Nigeria.svg.png)](https://be.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Flag_of_Nigeria.svg "Сцяг Нігерыі") [Нігерыя](https://be.wikipedia.org/wiki/%D0%9D%D1%96%D0%B3%D0%B5%D1%80%D1%8B%D1%8F "Нігерыя"): Дзень незалежнасці (1960)
  * [1386](https://be.wikipedia.org/wiki/1386 "1386"): Заснаваны [Гайдэльбергскі ўніверсітэт](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%B9%D0%B4%D1%8D%D0%BB%D1%8C%D0%B1%D0%B5%D1%80%D0%B3%D1%81%D0%BA%D1%96_%D1%9E%D0%BD%D1%96%D0%B2%D0%B5%D1%80%D1%81%D1%96%D1%82%D1%8D%D1%82 "Гайдэльбергскі ўніверсітэт"), старэйшы на тэрыторыі [Германіі](https://be.wikipedia.org/wiki/%D0%93%D0%B5%D1%80%D0%BC%D0%B0%D0%BD%D1%96%D1%8F "Германія").
  * [1653](https://be.wikipedia.org/wiki/1653 "1653"): Земскі сабор у Маскве ўхваліў [вайну з Рэччу Паспалітай](https://be.wikipedia.org/wiki/%D0%92%D0%B0%D0%B9%D0%BD%D0%B0_%D0%A0%D0%B0%D1%81%D1%96%D1%96_%D0%B7_%D0%A0%D1%8D%D1%87%D1%87%D1%83_%D0%9F%D0%B0%D1%81%D0%BF%D0%B0%D0%BB%D1%96%D1%82%D0%B0%D0%B9_\(1654%E2%80%941667\) "Вайна Расіі з Рэччу Паспалітай \(1654—1667\)") ў падтрымку казацкага гетмана [Багдана Хмяльніцкага](https://be.wikipedia.org/wiki/%D0%91%D0%B0%D0%B3%D0%B4%D0%B0%D0%BD_%D0%9C%D1%96%D1%85%D0%B0%D0%B9%D0%BB%D0%B0%D0%B2%D1%96%D1%87_%D0%A5%D0%BC%D1%8F%D0%BB%D1%8C%D0%BD%D1%96%D1%86%D0%BA%D1%96 "Багдан Міхайлавіч Хмяльніцкі").
  * [1817](https://be.wikipedia.org/wiki/1817 "1817"): У [Віленскім універсітэце](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BB%D1%8C%D0%BD%D1%8E%D1%81%D0%BA%D1%96_%D1%9E%D0%BD%D1%96%D0%B2%D0%B5%D1%80%D1%81%D1%96%D1%82%D1%8D%D1%82 "Вільнюскі ўніверсітэт") заснаванае тайнае студэнцкае патрыятычнае [таварыства філаматаў](https://be.wikipedia.org/wiki/%D0%A2%D0%B0%D0%B2%D0%B0%D1%80%D1%8B%D1%81%D1%82%D0%B2%D0%B0_%D1%84%D1%96%D0%BB%D0%B0%D0%BC%D0%B0%D1%82%D0%B0%D1%9E "Таварыства філаматаў").
  * [1831](https://be.wikipedia.org/wiki/1831 "1831"): Расійскі імператар выдаў указ пра перавод [шляхты](https://be.wikipedia.org/wiki/%D0%A8%D0%BB%D1%8F%D1%85%D1%82%D0%B0 "Шляхта"), не зацверджанай Дэпартаментам герольдыі, з дваранскага саслоўя.
  * [1869](https://be.wikipedia.org/wiki/1869 "1869"): У [Вене](https://be.wikipedia.org/wiki/%D0%92%D0%B5%D0%BD%D0%B0 "Вена") выйшлі першыя [паштоўкі](https://be.wikipedia.org/wiki/%D0%9F%D0%B0%D1%88%D1%82%D0%BE%D1%9E%D0%BA%D0%B0 "Паштоўка").
  * [1936](https://be.wikipedia.org/wiki/1936 "1936"): [Франсіска Франка](https://be.wikipedia.org/wiki/%D0%A4%D1%80%D0%B0%D0%BD%D1%81%D1%96%D1%81%D0%BA%D0%B0_%D0%A4%D1%80%D0%B0%D0%BD%D0%BA%D0%B0 "Франсіска Франка") прызначаны [хунтай](https://be.wikipedia.org/wiki/%D0%A5%D1%83%D0%BD%D1%82%D0%B0 "Хунта") кіраўніком ураду [Іспаніі](https://be.wikipedia.org/wiki/%D0%86%D1%81%D0%BF%D0%B0%D0%BD%D1%96%D1%8F "Іспанія").
  * [1940](https://be.wikipedia.org/wiki/1940 "1940"): [Альберт Эйнштэйн](https://be.wikipedia.org/wiki/%D0%90%D0%BB%D1%8C%D0%B1%D0%B5%D1%80%D1%82_%D0%AD%D0%B9%D0%BD%D1%88%D1%82%D1%8D%D0%B9%D0%BD "Альберт Эйнштэйн") атрымлівае сертыфікат аб амерыканскім грамадзянстве.
  * [1946](https://be.wikipedia.org/wiki/1946 "1946"): Завяршыўся [Нюрнбергскі працэс](https://be.wikipedia.org/wiki/%D0%9D%D1%8E%D1%80%D0%BD%D0%B1%D0%B5%D1%80%D0%B3%D1%81%D0%BA%D1%96_%D0%BF%D1%80%D0%B0%D1%86%D1%8D%D1%81 "Нюрнбергскі працэс").
  * [1969](https://be.wikipedia.org/wiki/1969 "1969"): Адкрыты [Пекінскі метрапалітэн](https://be.wikipedia.org/wiki/%D0%9F%D0%B5%D0%BA%D1%96%D0%BD%D1%81%D0%BA%D1%96_%D0%BC%D0%B5%D1%82%D1%80%D0%B0%D0%BF%D0%B0%D0%BB%D1%96%D1%82%D1%8D%D0%BD "Пекінскі метрапалітэн").


[Іншыя падзеі](https://be.wikipedia.org/wiki/1_%D0%BA%D0%B0%D1%81%D1%82%D1%80%D1%8B%D1%87%D0%BD%D1%96%D0%BA%D0%B0 "1 кастрычніка") · [Прагляд](https://be.wikipedia.org/wiki/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD:%D0%9F%D0%B0%D0%B4%D0%B7%D0%B5%D1%96_1_%D0%BA%D0%B0%D1%81%D1%82%D1%80%D1%8B%D1%87%D0%BD%D1%96%D0%BA%D0%B0 "Шаблон:Падзеі 1 кастрычніка")
  * 28 ліпеня 2025 — У Беларускай Вікіпедыі створаны [255 000-ы артыкул](https://be.wikipedia.org/wiki/%D0%92%D1%8B%D0%BF%D0%B0%D0%B4%D0%B0%D0%BA_\(%D1%84%D1%96%D0%BB%D1%8C%D0%BC,_1981\) "Выпадак \(фільм, 1981\)").
  * 20 чэрвеня 2025 — У Беларускай Вікіпедыі зроблена 5 000 000 правак.


[Больш пра Вікіжыццё](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%A1%D1%83%D0%BF%D0%BE%D0%BB%D1%8C%D0%BD%D0%B0%D1%81%D1%86%D1%8C/%D0%92%D1%96%D0%BA%D1%96%D0%B6%D1%8B%D1%86%D1%86%D1%91 "Вікіпедыя:Супольнасць/Вікіжыццё") · [Прагляд](https://be.wikipedia.org/wiki/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD:%D0%92%D1%96%D0%BA%D1%96%D1%81%D1%82%D1%83%D0%B6%D0%BA%D0%B0 "Шаблон:Вікістужка") · [Архіў](https://be.wikipedia.org/wiki/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD:%D0%92%D1%96%D0%BA%D1%96%D1%81%D1%82%D1%83%D0%B6%D0%BA%D0%B0/%D0%90%D1%80%D1%85%D1%96%D1%9E "Шаблон:Вікістужка/Архіў")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/P_globe-transparent.svg/40px-P_globe-transparent.svg.png)
**[Прырода](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9F%D1%80%D1%8B%D1%80%D0%BE%D0%B4%D0%B0 "Катэгорыя:Прырода")**
    * [Жыццё](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%96%D1%8B%D1%86%D1%86%D1%91 "Катэгорыя:Жыццё")
    * [Зямля](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%97%D1%8F%D0%BC%D0%BB%D1%8F "Катэгорыя:Зямля")
    * [Космас](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9A%D0%BE%D1%81%D0%BC%D0%B0%D1%81 "Катэгорыя:Космас")
    * [Матэрыя](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9C%D0%B0%D1%82%D1%8D%D1%80%D1%8B%D1%8F "Катэгорыя:Матэрыя")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Social_sciences.svg/40px-Social_sciences.svg.png)
**[Грамадства](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%93%D1%80%D0%B0%D0%BC%D0%B0%D0%B4%D1%81%D1%82%D0%B2%D0%B0 "Катэгорыя:Грамадства")**
    * [Народы](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9D%D0%B0%D1%80%D0%BE%D0%B4%D1%8B "Катэгорыя:Народы")
    * [Мовы](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9C%D0%BE%D0%B2%D1%8B "Катэгорыя:Мовы")
    * [Краіны](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9A%D1%80%D0%B0%D1%96%D0%BD%D1%8B "Катэгорыя:Краіны")
    * [Палітыка](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9F%D0%B0%D0%BB%D1%96%D1%82%D1%8B%D0%BA%D0%B0 "Катэгорыя:Палітыка")
    * [Сям’я](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%A1%D1%8F%D0%BC%E2%80%99%D1%8F "Катэгорыя:Сям’я")
    * [Эканоміка](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%AD%D0%BA%D0%B0%D0%BD%D0%BE%D0%BC%D1%96%D0%BA%D0%B0 "Катэгорыя:Эканоміка")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/P_Belarus.svg/40px-P_Belarus.svg.png)
**[Беларусы](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D1%8B "Катэгорыя:Беларусы")**
    * [Краіна](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D1%8C "Катэгорыя:Беларусь")
    * [Гісторыя](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%93%D1%96%D1%81%D1%82%D0%BE%D1%80%D1%8B%D1%8F_%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D1%96 "Катэгорыя:Гісторыя Беларусі")
    * [Мова](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D0%BA%D0%B0%D1%8F_%D0%BC%D0%BE%D0%B2%D0%B0 "Катэгорыя:Беларуская мова")
    * [Культура](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D0%BA%D0%B0%D1%8F_%D0%BA%D1%83%D0%BB%D1%8C%D1%82%D1%83%D1%80%D0%B0 "Катэгорыя:Беларуская культура")
    * [Постаці](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9F%D0%BE%D1%81%D1%82%D0%B0%D1%86%D1%96_%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D1%96 "Катэгорыя:Постаці Беларусі")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/P_history.svg/40px-P_history.svg.png)
**[Гісторыя](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%93%D1%96%D1%81%D1%82%D0%BE%D1%80%D1%8B%D1%8F "Катэгорыя:Гісторыя")**
    * [Падзеі](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9F%D0%B0%D0%B4%D0%B7%D0%B5%D1%96 "Катэгорыя:Падзеі")
    * [Перыяды](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%93%D1%96%D1%81%D1%82%D0%B0%D1%80%D1%8B%D1%87%D0%BD%D1%8B%D1%8F_%D0%BF%D0%B5%D1%80%D1%8B%D1%8F%D0%B4%D1%8B "Катэгорыя:Гістарычныя перыяды")
    * [Гістарычныя вобласці](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%93%D1%96%D1%81%D1%82%D0%B0%D1%80%D1%8B%D1%87%D0%BD%D1%8B%D1%8F_%D0%B2%D0%BE%D0%B1%D0%BB%D0%B0%D1%81%D1%86%D1%96 "Катэгорыя:Гістарычныя вобласці")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/P_human_body.svg/40px-P_human_body.svg.png)
**[Чалавек](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%A7%D0%B0%D0%BB%D0%B0%D0%B2%D0%B5%D0%BA "Катэгорыя:Чалавек")**
    * [Асобы](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%90%D1%81%D0%BE%D0%B1%D1%8B "Катэгорыя:Асобы")
    * [Антрапалогія](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%90%D0%BD%D1%82%D1%80%D0%B0%D0%BF%D0%B0%D0%BB%D0%BE%D0%B3%D1%96%D1%8F "Катэгорыя:Антрапалогія")
    * [Веды](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%92%D0%B5%D0%B4%D1%8B "Катэгорыя:Веды")
    * [Філасофія](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%A4%D1%96%D0%BB%D0%B0%D1%81%D0%BE%D1%84%D1%96%D1%8F "Катэгорыя:Філасофія")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/P_parthenon.svg/40px-P_parthenon.svg.png)
**[Культура](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9A%D1%83%D0%BB%D1%8C%D1%82%D1%83%D1%80%D0%B0 "Катэгорыя:Культура")**
    * [Архітэктура](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%90%D1%80%D1%85%D1%96%D1%82%D1%8D%D0%BA%D1%82%D1%83%D1%80%D0%B0 "Катэгорыя:Архітэктура")
    * [Літаратура](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9B%D1%96%D1%82%D0%B0%D1%80%D0%B0%D1%82%D1%83%D1%80%D0%B0 "Катэгорыя:Літаратура")
    * [Мастацтва](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9C%D0%B0%D1%81%D1%82%D0%B0%D1%86%D1%82%D0%B2%D0%B0 "Катэгорыя:Мастацтва")
    * [Рэлігія](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%A0%D1%8D%D0%BB%D1%96%D0%B3%D1%96%D1%8F "Катэгорыя:Рэлігія")
    * [Спорт](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%A1%D0%BF%D0%BE%D1%80%D1%82 "Катэгорыя:Спорт")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/P_chemistry.svg/40px-P_chemistry.svg.png)
**[Навука](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9D%D0%B0%D0%B2%D1%83%D0%BA%D0%B0 "Катэгорыя:Навука")**
    * [Астраномія](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%90%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%BE%D0%BC%D1%96%D1%8F "Катэгорыя:Астраномія")
    * [Біялогія](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%91%D1%96%D1%8F%D0%BB%D0%BE%D0%B3%D1%96%D1%8F "Катэгорыя:Біялогія")
    * [Геалогія](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%93%D0%B5%D0%B0%D0%BB%D0%BE%D0%B3%D1%96%D1%8F "Катэгорыя:Геалогія")
    * [Матэматыка](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9C%D0%B0%D1%82%D1%8D%D0%BC%D0%B0%D1%82%D1%8B%D0%BA%D0%B0 "Катэгорыя:Матэматыка")
    * [Фізіка](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%A4%D1%96%D0%B7%D1%96%D0%BA%D0%B0 "Катэгорыя:Фізіка")
    * [Хімія](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%A5%D1%96%D0%BC%D1%96%D1%8F "Катэгорыя:Хімія")
    * [Гуманітарныя навукі](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%93%D1%83%D0%BC%D0%B0%D0%BD%D1%96%D1%82%D0%B0%D1%80%D0%BD%D1%8B%D1%8F_%D0%BD%D0%B0%D0%B2%D1%83%D0%BA%D1%96 "Катэгорыя:Гуманітарныя навукі")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/P_train.svg/40px-P_train.svg.png)
**[Тэхніка](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%A2%D1%8D%D1%85%D0%BD%D1%96%D0%BA%D0%B0 "Катэгорыя:Тэхніка")**
    * [Абсталяванне](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%90%D0%B1%D1%81%D1%82%D0%B0%D0%BB%D1%8F%D0%B2%D0%B0%D0%BD%D0%BD%D0%B5 "Катэгорыя:Абсталяванне")
    * [Зброя](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%97%D0%B1%D1%80%D0%BE%D1%8F "Катэгорыя:Зброя")
    * [Інфарматыка](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%86%D0%BD%D1%84%D0%B0%D1%80%D0%BC%D0%B0%D1%82%D1%8B%D0%BA%D0%B0 "Катэгорыя:Інфарматыка")
    * [Космас](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%9A%D0%B0%D1%81%D0%BC%D1%96%D1%87%D0%BD%D0%B0%D1%8F_%D1%82%D1%8D%D1%85%D0%BD%D1%96%D0%BA%D0%B0 "Катэгорыя:Касмічная тэхніка")
    * [Транспарт](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%A2%D1%80%D0%B0%D0%BD%D1%81%D0%BF%D0%B0%D1%80%D1%82%D0%BD%D1%8B%D1%8F_%D1%81%D1%80%D0%BE%D0%B4%D0%BA%D1%96 "Катэгорыя:Транспартныя сродкі")
    * [Электроніка](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%AD%D0%BB%D0%B5%D0%BA%D1%82%D1%80%D0%BE%D0%BD%D1%96%D0%BA%D0%B0 "Катэгорыя:Электроніка")


  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)
[**Вікіслоўнік**](https://be.wiktionary.org/wiki/ "wikt:")  
Слоўнікі і тэзаўрус
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)
[**Вікікнігі**](https://be.wikibooks.org/wiki/ "b:")  
Падручнікі і дапаможнікі
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)
[**Вікіданыя**](https://www.wikidata.org/wiki/ "d:")  
База ведаў
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)
[**Вікіцытатнік**](https://be.wikiquote.org/wiki/ "q:")  
Зборнік цытат
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)
[**Вікікрыніцы**](https://be.wikisource.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "s:Галоўная старонка")  
База тэкставых крыніц
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)
[**Віківіды**](https://species.wikimedia.org/wiki/ "wikispecies:")  
Слоўнік біялагічных відаў
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)
[**Вікінавіны**](https://en.wikinews.org/wiki/ "wikinews:")  
Свабодныя навіны
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)
[**Вікісховішча**](https://commons.wikimedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F "commons:Галоўная")  
Мультымедыйныя файлы
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)
[**Метавікі**](https://meta.wikimedia.org/wiki/ "m:")  
Каардынацыя Вікіпраектаў
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)
[MediaWiki](https://www.mediawiki.org/wiki/ "mw:")  
Праграмнае забеспячэнне Вікіпраектаў


  

Узята з "[https://be.wikipedia.org/w/index.php?title=Галоўная_старонка&oldid=4918424](https://be.wikipedia.org/w/index.php?title=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&oldid=4918424)"
[Катэгорыі](https://be.wikipedia.org/wiki/%D0%90%D0%B4%D0%BC%D1%8B%D1%81%D0%BB%D0%BE%D0%B2%D0%B0%D0%B5:Categories "Адмысловае:Categories"): 
  * [Шаблоны:Падзеі паводле дат](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD%D1%8B:%D0%9F%D0%B0%D0%B4%D0%B7%D0%B5%D1%96_%D0%BF%D0%B0%D0%B2%D0%BE%D0%B4%D0%BB%D0%B5_%D0%B4%D0%B0%D1%82 "Катэгорыя:Шаблоны:Падзеі паводле дат")
  * [Беларуская Вікіпедыя](https://be.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D1%8D%D0%B3%D0%BE%D1%80%D1%8B%D1%8F:%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D0%BA%D0%B0%D1%8F_%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F "Катэгорыя:Беларуская Вікіпедыя")


17 моў
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/ "Belarusian \(Taraškievica orthography\)")
  * [Deutsch](https://de.wikipedia.org/wiki/ "нямецкая")
  * [English](https://en.wikipedia.org/wiki/ "англійская")
  * [Español](https://es.wikipedia.org/wiki/ "іспанская")
  * [Français](https://fr.wikipedia.org/wiki/ "французская")
  * [Italiano](https://it.wikipedia.org/wiki/ "італьянская")
  * [日本語](https://ja.wikipedia.org/wiki/ "японская")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "літоўская")
  * [Latviešu](https://lv.wikipedia.org/wiki/ "латышская")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "нідэрландская")
  * [Polski](https://pl.wikipedia.org/wiki/ "польская")
  * [Português](https://pt.wikipedia.org/wiki/ "партугальская")
  * [Русский](https://ru.wikipedia.org/wiki/ "руская")
  * [Svenska](https://sv.wikipedia.org/wiki/ "шведская")
  * [Українська](https://uk.wikipedia.org/wiki/ "украінская")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "в’етнамская")
  * [中文](https://zh.wikipedia.org/wiki/ "кітайская")


  * Апошняе змяненне старонкі адбылося 21:44, 18 студзеня 2025.
  * Тэкст даступны на ўмовах [ліцэнзіі Creative Commons Attribution-ShareAlike](https://creativecommons.org/licenses/by-sa/4.0/deed.be), у асобных выпадках могуць дзейнічаць дадатковыя ўмовы. Падрабязней гл. [Умовы выкарыстання](https://foundation.wikimedia.org/wiki/%D0%A3%D0%BC%D0%BE%D0%B2%D1%8B_%D0%B2%D1%8B%D0%BA%D0%B0%D1%80%D1%8B%D1%81%D1%82%D0%B0%D0%BD%D0%BD%D1%8F).


  * [Палітыка прыватнасці](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Пра Вікіпедыю](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%A8%D1%82%D0%BE_%D1%82%D0%B0%D0%BA%D0%BE%D0%B5_%D1%81%D0%B2%D0%B0%D0%B1%D0%BE%D0%B4%D0%BD%D0%B0%D1%8F_%D1%8D%D0%BD%D1%86%D1%8B%D0%BA%D0%BB%D0%B0%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F)
  * [Адмова ад адказнасці](https://be.wikipedia.org/wiki/%D0%92%D1%96%D0%BA%D1%96%D0%BF%D0%B5%D0%B4%D1%8B%D1%8F:%D0%90%D0%B4%D0%BC%D0%BE%D0%B2%D0%B0_%D0%B0%D0%B4_%D0%B0%D0%B4%D0%BA%D0%B0%D0%B7%D0%BD%D0%B0%D1%81%D1%86%D1%96)
  * [Кодэкс паводзін](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Распрацоўшчыкі](https://developer.wikimedia.org)
  * [Статыстыка](https://stats.wikimedia.org/#/be.wikipedia.org)
  * [Заява пра cookie](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Мабільная версія](https://be.m.wikipedia.org/w/index.php?title=%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://be.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://be.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Пошук
Пошук
Галоўная старонка
[](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0) [](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0) [](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0) [](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0) [](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0) [](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0) [](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0) [](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0)
17 моў [Дадаць тэму ](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0)
