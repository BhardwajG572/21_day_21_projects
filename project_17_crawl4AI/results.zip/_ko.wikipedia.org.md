[](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8#bodyContent)
주 메뉴
주 메뉴
사이드바로 이동 숨기기
둘러보기 
  * [대문](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "대문으로 가기 \[alt-z\]")
  * [최근 바뀜](https://ko.wikipedia.org/wiki/%ED%8A%B9%EC%88%98:%EC%B5%9C%EA%B7%BC%EB%B0%94%EB%80%9C "위키의 최근 바뀐 목록 \[alt-r\]")
  * [요즘 화제](https://ko.wikipedia.org/wiki/%ED%8F%AC%ED%84%B8:%EC%9A%94%EC%A6%98_%ED%99%94%EC%A0%9C "최근의 소식 알아 보기")
  * [임의의 문서로](https://ko.wikipedia.org/wiki/%ED%8A%B9%EC%88%98:%EC%9E%84%EC%9D%98%EB%AC%B8%EC%84%9C "무작위로 선택된 문서 불러오기 \[alt-x\]")


사용자 모임 
  * [사랑방](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%82%AC%EB%9E%91%EB%B0%A9)
  * [사용자 모임](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%82%AC%EC%9A%A9%EC%9E%90_%EB%AA%A8%EC%9E%84 "위키백과 참여자를 위한 토론/대화 공간입니다.")
  * [관리 요청](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%9A%94%EC%B2%AD)


편집 안내 
  * [소개](https://ko.wikipedia.org/wiki/%EB%8F%84%EC%9B%80%EB%A7%90:%EC%86%8C%EA%B0%9C)
  * [도움말](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8F%84%EC%9B%80%EB%A7%90 "도움말")
  * [정책과 지침](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A7%80%EC%B9%A8)
  * [질문방](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%A7%88%EB%AC%B8%EB%B0%A9)


[ ![](https://ko.wikipedia.org/static/images/icons/wikipedia.png) ![위키백과](https://ko.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-ko.svg) ![](https://ko.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-ko.svg) ](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8)
[검색 ](https://ko.wikipedia.org/wiki/%ED%8A%B9%EC%88%98:%EA%B2%80%EC%83%89 "위키백과 검색 \[alt-f\]")
검색
보이기
보이기
사이드바로 이동 숨기기
글
  * 작음
표준
큼

이 페이지는 항상 작은 글꼴 크기를 사용합니다.
너비
  * 표준
넓게

콘텐츠는 브라우저 창에 맞도록 최대한 넓게 맞춥니다.
색 (베타)
  * 자동
라이트
다크

이 페이지는 항상 라이트 모드입니다.
  * [기부](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ko.wikipedia.org&uselang=ko)
  * [계정 만들기](https://ko.wikipedia.org/w/index.php?title=%ED%8A%B9%EC%88%98:%EA%B3%84%EC%A0%95%EB%A7%8C%EB%93%A4%EA%B8%B0&returnto=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC%3A%EB%8C%80%EB%AC%B8 "계정을 만들고 로그인하는 것이 좋습니다. 하지만 필수는 아닙니다")
  * [로그인](https://ko.wikipedia.org/w/index.php?title=%ED%8A%B9%EC%88%98:%EB%A1%9C%EA%B7%B8%EC%9D%B8&returnto=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC%3A%EB%8C%80%EB%AC%B8 "위키백과에 로그인하면 여러가지 편리한 기능을 사용할 수 있습니다. \[alt-o\]")


개인 도구
  * [기부](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ko.wikipedia.org&uselang=ko)
  * [계정 만들기](https://ko.wikipedia.org/w/index.php?title=%ED%8A%B9%EC%88%98:%EA%B3%84%EC%A0%95%EB%A7%8C%EB%93%A4%EA%B8%B0&returnto=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC%3A%EB%8C%80%EB%AC%B8 "계정을 만들고 로그인하는 것이 좋습니다. 하지만 필수는 아닙니다")
  * [로그인](https://ko.wikipedia.org/w/index.php?title=%ED%8A%B9%EC%88%98:%EB%A1%9C%EA%B7%B8%EC%9D%B8&returnto=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC%3A%EB%8C%80%EB%AC%B8 "위키백과에 로그인하면 여러가지 편리한 기능을 사용할 수 있습니다. \[alt-o\]")


#  위키백과:대문
  * [대문](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "프로젝트 문서 보기 \[alt-c\]")
  * [토론](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC%ED%86%A0%EB%A1%A0:%EB%8C%80%EB%AC%B8 "문서의 내용에 대한 토론 문서 \[alt-t\]")


한국어
  * [읽기](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8)
  * [원본 보기](https://ko.wikipedia.org/w/index.php?title=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8&action=edit "이 문서가 보호되어 있습니다.
문서의 원본을 볼 수 있습니다. \[alt-e\]")
  * [역사 보기](https://ko.wikipedia.org/w/index.php?title=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8&action=history "이 문서의 과거 편집 내역입니다. \[alt-h\]")


도구
도구
사이드바로 이동 숨기기
동작 
  * [읽기](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8)
  * [원본 보기](https://ko.wikipedia.org/w/index.php?title=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8&action=edit)
  * [역사 보기](https://ko.wikipedia.org/w/index.php?title=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8&action=history)


일반 
  * [여기를 가리키는 문서](https://ko.wikipedia.org/wiki/%ED%8A%B9%EC%88%98:%EA%B0%80%EB%A6%AC%ED%82%A4%EB%8A%94%EB%AC%B8%EC%84%9C/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "여기를 가리키는 모든 위키 문서의 목록 \[alt-j\]")
  * [가리키는 글의 최근 바뀜](https://ko.wikipedia.org/wiki/%ED%8A%B9%EC%88%98:%EB%A7%81%ED%81%AC%EC%B5%9C%EA%B7%BC%EB%B0%94%EB%80%9C/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "이 문서에서 링크한 문서의 최근 바뀜 \[alt-k\]")
  * [파일 올리기](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%ED%8C%8C%EC%9D%BC_%EC%98%AC%EB%A6%AC%EA%B8%B0 "파일 올리기 \[alt-u\]")
  * [고유 링크](https://ko.wikipedia.org/w/index.php?title=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8&oldid=40156846 "이 문서의 이 판에 대한 고유 링크")
  * [문서 정보](https://ko.wikipedia.org/w/index.php?title=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8&action=info "이 문서에 대한 자세한 정보")
  * [축약된 URL 얻기](https://ko.wikipedia.org/w/index.php?title=%ED%8A%B9%EC%88%98:UrlShortener&url=https%3A%2F%2Fko.wikipedia.org%2Fwiki%2F%25EC%259C%2584%25ED%2582%25A4%25EB%25B0%25B1%25EA%25B3%25BC%3A%25EB%258C%2580%25EB%25AC%25B8)
  * [QR코드 다운로드](https://ko.wikipedia.org/w/index.php?title=%ED%8A%B9%EC%88%98:QrCode&url=https%3A%2F%2Fko.wikipedia.org%2Fwiki%2F%25EC%259C%2584%25ED%2582%25A4%25EB%25B0%25B1%25EA%25B3%25BC%3A%25EB%258C%2580%25EB%25AC%25B8)


인쇄/내보내기 
  * [책 만들기](https://ko.wikipedia.org/w/index.php?title=%ED%8A%B9%EC%88%98:%EC%B1%85&bookcmd=book_creator&referer=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC%3A%EB%8C%80%EB%AC%B8)
  * [PDF로 다운로드](https://ko.wikipedia.org/w/index.php?title=%ED%8A%B9%EC%88%98:DownloadAsPdf&page=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC%3A%EB%8C%80%EB%AC%B8&action=show-download-screen)
  * [인쇄용 판](https://ko.wikipedia.org/w/index.php?title=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8&printable=yes "이 문서의 인쇄용 판 \[alt-p\]")


다른 프로젝트 
  * [위키미디어 공용](https://commons.wikimedia.org/wiki/Main_Page)
  * [위키미디어 재단](https://foundation.wikimedia.org/wiki/Home)
  * [미디어위키](https://www.mediawiki.org/wiki/MediaWiki)
  * [메타위키](https://meta.wikimedia.org/wiki/Main_Page)
  * [위키미디어 아웃리치](https://outreach.wikimedia.org/wiki/Main_Page)
  * [다언어 위키문헌](https://wikisource.org/wiki/Main_Page)
  * [위키생물종](https://species.wikimedia.org/wiki/Main_Page)
  * [위키책](https://ko.wikibooks.org/wiki/%EC%9C%84%ED%82%A4%EC%B1%85:%EB%8C%80%EB%AC%B8)
  * [위키데이터](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [위키함수](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [위키뉴스](https://ko.wikinews.org/wiki/%EC%9C%84%ED%82%A4%EB%89%B4%EC%8A%A4:%EB%8C%80%EB%AC%B8)
  * [위키인용집](https://ko.wikiquote.org/wiki/%EC%9C%84%ED%82%A4%EC%9D%B8%EC%9A%A9%EC%A7%91:%EB%93%A4%EB%A8%B8%EB%A6%AC)
  * [위키문헌](https://ko.wikisource.org/wiki/%EC%9C%84%ED%82%A4%EB%AC%B8%ED%97%8C:%EB%8C%80%EB%AC%B8)
  * [위키배움터](https://ko.wikiversity.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B0%EC%9B%80%ED%84%B0:%EB%8C%80%EB%AC%B8)
  * [위키낱말사전](https://ko.wiktionary.org/wiki/%EC%9C%84%ED%82%A4%EB%82%B1%EB%A7%90%EC%82%AC%EC%A0%84:%EB%8C%80%EB%AC%B8)
  * [위키데이터 항목](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "데이터 저장소에 연결된 항목을 가리키는 링크 \[alt-g\]")


[위키백과](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%86%8C%EA%B0%9C "위키백과:소개")
우리 모두가 만들어가는 자유 백과사전  
문서 [**722,549**](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%ED%86%B5%EA%B3%84 "위키백과:통계")개와 최근 기여자 **[7,031](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%ED%86%B5%EA%B3%84 "위키백과:통계")** 명
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/XEIcon_xi-group.svg/40px-XEIcon_xi-group.svg.png)](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%82%AC%EB%9E%91%EB%B0%A9 "위키백과:사랑방")
[사랑방](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%82%AC%EB%9E%91%EB%B0%A9 "위키백과:사랑방")  
다른 분들과 의견을 교환해봐요!
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/XEIcon_xi-message.svg/40px-XEIcon_xi-message.svg.png)](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%A7%88%EB%AC%B8%EB%B0%A9 "위키백과:질문방")
[질문방](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%A7%88%EB%AC%B8%EB%B0%A9 "위키백과:질문방")  
지침으로 해소되지 않는 의문을 풀어봐요!
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Group_half.svg/40px-Group_half.svg.png)](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%82%AC%EC%9A%A9%EC%9E%90_%EB%AA%A8%EC%9E%84 "위키백과:사용자 모임")
[사용자 모임](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%82%AC%EC%9A%A9%EC%9E%90_%EB%AA%A8%EC%9E%84 "위키백과:사용자 모임")  
커뮤니티 포털에 방문해 보세요!
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/XEIcon_xi-library-bookmark.svg/40px-XEIcon_xi-library-bookmark.svg.png)](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A7%80%EC%B9%A8 "위키백과:정책과 지침")
[정책과 지침](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A7%80%EC%B9%A8 "위키백과:정책과 지침")  
편집하시기 전에 한번 읽어주세요!
**[위키백과 참여하기](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC%EC%97%90_%EC%B0%B8%EC%97%AC%ED%95%98%EA%B8%B0 "위키백과:위키백과에 참여하기")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/XEIcon_xi-heart.svg/40px-XEIcon_xi-heart.svg.png)](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%ED%99%98%EC%98%81%ED%95%A9%EB%8B%88%EB%8B%A4 "위키백과:환영합니다")
[환영합니다!](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%ED%99%98%EC%98%81%ED%95%A9%EB%8B%88%EB%8B%A4 "위키백과:환영합니다")  
위키백과는 여러분을 환영합니다.  
이것부터 시작해 볼까요?
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Book_sans_information.svg/40px-Book_sans_information.svg.png)](https://ko.wikipedia.org/wiki/%EB%8F%84%EC%9B%80%EB%A7%90:%EC%86%8C%EA%B0%9C "도움말:소개")
[위키백과 길라잡이](https://ko.wikipedia.org/wiki/%EB%8F%84%EC%9B%80%EB%A7%90:%EC%86%8C%EA%B0%9C "도움말:소개")  
여러분을 위키인으로 만들어줄 가이드북!
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Document_sans_add.svg/40px-Document_sans_add.svg.png)](https://ko.wikipedia.org/wiki/%EB%8F%84%EC%9B%80%EB%A7%90:%EC%83%88_%EB%AC%B8%EC%84%9C_%EB%A7%8C%EB%93%A4%EA%B8%B0 "도움말:새 문서 만들기")
[새 문서 만들기 도움말](https://ko.wikipedia.org/wiki/%EB%8F%84%EC%9B%80%EB%A7%90:%EC%83%88_%EB%AC%B8%EC%84%9C_%EB%A7%8C%EB%93%A4%EA%B8%B0 "도움말:새 문서 만들기")  
새 문서를 만드는 방법에 대해 안내합니다.
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Document_text_edit.svg/40px-Document_text_edit.svg.png)](https://ko.wikipedia.org/wiki/%EB%8F%84%EC%9B%80%EB%A7%90:%EB%AC%B8%EC%84%9C_%ED%8E%B8%EC%A7%91%ED%95%98%EA%B8%B0 "도움말:문서 편집하기")
[문서 편집 도움말](https://ko.wikipedia.org/wiki/%EB%8F%84%EC%9B%80%EB%A7%90:%EB%AC%B8%EC%84%9C_%ED%8E%B8%EC%A7%91%ED%95%98%EA%B8%B0 "도움말:문서 편집하기")  
문서를 편집하는 방법에 대해 안내합니다.
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/PICOL_icon_Image_add.svg/40px-PICOL_icon_Image_add.svg.png)](https://ko.wikipedia.org/wiki/%EB%8F%84%EC%9B%80%EB%A7%90:%EA%B7%B8%EB%A6%BC_%EC%98%AC%EB%A6%AC%EA%B8%B0 "도움말:그림 올리기")
[그림 올리기 도움말](https://ko.wikipedia.org/wiki/%EB%8F%84%EC%9B%80%EB%A7%90:%EA%B7%B8%EB%A6%BC_%EC%98%AC%EB%A6%AC%EA%B8%B0 "도움말:그림 올리기")  
그림을 올리는 방법에 대해 안내합니다.
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/XEIcon_xi-building.svg/40px-XEIcon_xi-building.svg.png)](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%A7%80%EC%9B%90_%EB%8B%A8%EC%B2%B4 "위키백과:지원 단체")
[지원 단체](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%A7%80%EC%9B%90_%EB%8B%A8%EC%B2%B4 "위키백과:지원 단체")  
위키백과 커뮤니티를 지원하는 단체는?
**[위키백과 소개](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%86%8C%EA%B0%9C "위키백과:소개")**
**[위키백과](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC "위키백과")** 는 [위키](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4 "위키")를 이용하여 전 세계 사람들이 함께 만들어가는 [웹 기반](https://ko.wikipedia.org/wiki/%EC%9B%94%EB%93%9C_%EC%99%80%EC%9D%B4%EB%93%9C_%EC%9B%B9 "월드 와이드 웹")의 다언어 [백과사전](https://ko.wikipedia.org/wiki/%EB%B0%B1%EA%B3%BC%EC%82%AC%EC%A0%84 "백과사전")입니다. 위키백과는 [중립적](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%A4%91%EB%A6%BD%EC%A0%81_%EC%8B%9C%EA%B0%81 "위키백과:중립적 시각")이고 [검증 가능](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%ED%99%95%EC%9D%B8_%EA%B0%80%EB%8A%A5 "위키백과:확인 가능")한 [자유 콘텐츠](https://ko.wikipedia.org/wiki/%EC%9E%90%EC%9C%A0_%EC%BD%98%ED%85%90%EC%B8%A0 "자유 콘텐츠") 백과사전의 제공을 목적으로 하는 프로젝트로, 누구나 참여하여 문서를 수정하고 발전시킬 수 있습니다. 
위키백과는 [다섯 가지 기본 원칙](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8B%A4%EC%84%AF_%EC%9B%90%EC%B9%99 "위키백과:다섯 원칙")에 따라 운영됩니다. 모든 문서는 [크리에이티브 커먼즈 저작자표시-동일조건변경허락 4.0](https://creativecommons.org/licenses/by-sa/4.0/deed.ko)에 따라 사용할 수 있으며, 복사, 수정과 배포가 자유롭고 상업적 목적의 사용도 가능합니다. 
**[오늘의 그림](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%98%A4%EB%8A%98%EC%9D%98_%EA%B7%B8%EB%A6%BC "위키백과:오늘의 그림")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg/330px-Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)](https://commons.wikimedia.org/wiki/File:Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)
위 그림은 [위키미디어 공용](https://commons.wikimedia.org/wiki/Commons:Picture_of_the_day/ko "commons:Commons:Picture of the day/ko")에서 가져왔습니다.
**[더 보기...](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%98%A4%EB%8A%98%EC%9D%98_%EA%B7%B8%EB%A6%BC/%EC%97%AD%EC%82%AC "위키백과:오늘의 그림/역사")**
**[알찬 글: 엑스박스 360](https://ko.wikipedia.org/wiki/%EC%97%91%EC%8A%A4%EB%B0%95%EC%8A%A4_360 "엑스박스 360")**
[ 더 보기](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%95%8C%EC%B0%AC_%EA%B8%80 "위키백과:알찬 글")
[![엑스박스 360](https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Xbox_360_S.png/120px-Xbox_360_S.png)](https://commons.wikimedia.org/wiki/File:Xbox_360_S.png "엑스박스 360")엑스박스 360
**[엑스박스 360](https://ko.wikipedia.org/wiki/%EC%97%91%EC%8A%A4%EB%B0%95%EC%8A%A4_360 "엑스박스 360")**(Xbox 360)은 [마이크로소프트](https://ko.wikipedia.org/wiki/%EB%A7%88%EC%9D%B4%ED%81%AC%EB%A1%9C%EC%86%8C%ED%94%84%ED%8A%B8 "마이크로소프트")가 [엑스박스](https://ko.wikipedia.org/wiki/%EC%97%91%EC%8A%A4%EB%B0%95%EC%8A%A4 "엑스박스")에 이어 두 번째로 개발한 [가정용 게임기](https://ko.wikipedia.org/wiki/%EA%B0%80%EC%A0%95%EC%9A%A9_%EA%B2%8C%EC%9E%84%EA%B8%B0 "가정용 게임기")이다. 
하드웨어와 연계된 [엑스박스 라이브](https://ko.wikipedia.org/wiki/%EC%97%91%EC%8A%A4%EB%B0%95%EC%8A%A4_%EB%9D%BC%EC%9D%B4%EB%B8%8C "엑스박스 라이브") 서비스로 플레이어들이 온라인에서 대전하거나 [아케이드 게임](https://ko.wikipedia.org/wiki/%EC%95%84%EC%BC%80%EC%9D%B4%EB%93%9C_%EA%B2%8C%EC%9E%84 "아케이드 게임"), 게임 데모, 트레일러 같은 콘텐츠를 다운로드할 수 있으며 [윈도 미디어 센터](https://ko.wikipedia.org/wiki/%EC%9C%88%EB%8F%84_%EB%AF%B8%EB%94%94%EC%96%B4_%EC%84%BC%ED%84%B0 "윈도 미디어 센터")와 연계된 멀티미디어 기능, 거의 모든 게임을 고화질로 즐기거나 마켓플레이스를 통해 [영화](https://ko.wikipedia.org/wiki/%EC%98%81%ED%99%94 "영화")를 대여할 수 있으며, [HD-DVD](https://ko.wikipedia.org/wiki/HD-DVD "HD-DVD") 플레이어를 별도로 설치하면 HD-DVD 영화를 볼 수 있다. [소니](https://ko.wikipedia.org/wiki/%EC%86%8C%EB%8B%88 "소니")의 [플레이스테이션 3](https://ko.wikipedia.org/wiki/%ED%94%8C%EB%A0%88%EC%9D%B4%EC%8A%A4%ED%85%8C%EC%9D%B4%EC%85%98_3 "플레이스테이션 3"), [닌텐도](https://ko.wikipedia.org/wiki/%EB%8B%8C%ED%85%90%EB%8F%84 "닌텐도")의 [Wii](https://ko.wikipedia.org/wiki/Wii "Wii")와 동시기에 경쟁했다. 
2005년 5월에 [MTV](https://ko.wikipedia.org/wiki/MTV "MTV")를 통해 공개되었으며 같은 달에 열린 [E3](https://ko.wikipedia.org/wiki/%EC%9D%BC%EB%A0%89%ED%8A%B8%EB%A1%9C%EB%8B%89_%EC%97%94%ED%84%B0%ED%85%8C%EC%9D%B8%EB%A8%BC%ED%8A%B8_%EC%97%91%EC%8A%A4%ED%8F%AC "일렉트로닉 엔터테인먼트 엑스포")를 통해 발매와 게임에 대한 정보를 공개했다. [미국](https://ko.wikipedia.org/wiki/%EB%AF%B8%EA%B5%AD "미국")에서는 2005년 11월에, [유럽](https://ko.wikipedia.org/wiki/%EC%9C%A0%EB%9F%BD "유럽")에서는 12월 2일, [일본](https://ko.wikipedia.org/wiki/%EC%9D%BC%EB%B3%B8 "일본")에서는 12월 10일, [대한민국](https://ko.wikipedia.org/wiki/%EB%8C%80%ED%95%9C%EB%AF%BC%EA%B5%AD "대한민국")에서는 2006년 2월 24일에 발매되었으며 2016년 4월 20일에 단종되었다. 전 세계에서 약 8,400만 대가 판매되었다.
* * *
**[좋은 글: 강릉원주대학교](https://ko.wikipedia.org/wiki/%EA%B0%95%EB%A6%89%EC%9B%90%EC%A3%BC%EB%8C%80%ED%95%99%EA%B5%90 "강릉원주대학교")**
[ 더 보기](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%A2%8B%EC%9D%80_%EA%B8%80 "위키백과:좋은 글")
* * *
**[알찬 목록: 대훈위 금척대수장](https://ko.wikipedia.org/wiki/%EB%8C%80%ED%9B%88%EC%9C%84_%EA%B8%88%EC%B2%99%EB%8C%80%EC%88%98%EC%9E%A5 "대훈위 금척대수장")**
[ 더 보기](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%95%8C%EC%B0%AC_%EB%AA%A9%EB%A1%9D "위키백과:알찬 목록")
**[새로 들어온 소식](https://ko.wikipedia.org/wiki/%ED%8F%AC%ED%84%B8:%EC%9A%94%EC%A6%98_%ED%99%94%EC%A0%9C "포털:요즘 화제")**
[ 이게 뭔가요?](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%83%88%EB%A1%9C_%EB%93%A4%EC%96%B4%EC%98%A8_%EC%86%8C%EC%8B%9D "위키백과:새로 들어온 소식")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Nicolas_Sarkozy_%28September_1%2C_2011%29.jpg/120px-Nicolas_Sarkozy_%28September_1%2C_2011%29.jpg)](https://commons.wikimedia.org/wiki/File:Nicolas_Sarkozy_\(September_1,_2011\).jpg)
  * [10월 1일](https://ko.wikipedia.org/wiki/10%EC%9B%94_1%EC%9D%BC "10월 1일"), [동물학자](https://ko.wikipedia.org/wiki/%EB%8F%99%EB%AC%BC%ED%95%99%EC%9E%90 "동물학자")이자 [영장류학자](https://ko.wikipedia.org/wiki/%EC%98%81%EC%9E%A5%EB%A5%98%ED%95%99%EC%9E%90 "영장류학자")인 **[제인 구달](https://ko.wikipedia.org/wiki/%EC%A0%9C%EC%9D%B8_%EA%B5%AC%EB%8B%AC "제인 구달")** 이 91세의 나이로 사망하였다.
  * [9월 25일](https://ko.wikipedia.org/wiki/9%EC%9B%94_25%EC%9D%BC "9월 25일"), **[니콜라 사르코지](https://ko.wikipedia.org/wiki/%EB%8B%88%EC%BD%9C%EB%9D%BC_%EC%82%AC%EB%A5%B4%EC%BD%94%EC%A7%80 "니콜라 사르코지")** 전 [프랑스](https://ko.wikipedia.org/wiki/%ED%94%84%EB%9E%91%EC%8A%A4 "프랑스") 대통령(사진)이 부패 혐의로 유죄 판결을 받고 징역 5년을 선고받았다.
  * [9월 25일](https://ko.wikipedia.org/wiki/9%EC%9B%94_25%EC%9D%BC "9월 25일"), **[태풍 라가사](https://ko.wikipedia.org/wiki/%ED%83%9C%ED%92%8D_%EB%9D%BC%EA%B0%80%EC%82%AC "태풍 라가사")** 가 [타이완](https://ko.wikipedia.org/wiki/%EC%A4%91%ED%99%94%EB%AF%BC%EA%B5%AD "중화민국")과 [필리핀](https://ko.wikipedia.org/wiki/%ED%95%84%EB%A6%AC%ED%95%80 "필리핀")에 영향을 미쳐 최소한 25명이 사망했다.
  * [9월 21일](https://ko.wikipedia.org/wiki/9%EC%9B%94_21%EC%9D%BC "9월 21일"), [영국](https://ko.wikipedia.org/wiki/%EC%98%81%EA%B5%AD "영국"), [오스트레일리아](https://ko.wikipedia.org/wiki/%EC%98%A4%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%9D%BC%EB%A6%AC%EC%95%84 "오스트레일리아"), [캐나다](https://ko.wikipedia.org/wiki/%EC%BA%90%EB%82%98%EB%8B%A4 "캐나다"), [포르투갈](https://ko.wikipedia.org/wiki/%ED%8F%AC%EB%A5%B4%ED%88%AC%EA%B0%88 "포르투갈") 정부가 [제80차 유엔 총회](https://ko.wikipedia.org/wiki/%EC%A0%9C80%EC%B0%A8_%EC%9C%A0%EC%97%94_%EC%B4%9D%ED%9A%8C "제80차 유엔 총회")에서 [팔레스타인](https://ko.wikipedia.org/wiki/%ED%8C%94%EB%A0%88%EC%8A%A4%ED%83%80%EC%9D%B8 "팔레스타인")을 독립국으로 **[승인](https://ko.wikipedia.org/wiki/%ED%8C%94%EB%A0%88%EC%8A%A4%ED%83%80%EC%9D%B8%EC%9D%98_%EA%B5%AD%EC%A0%9C%EC%A0%81_%EC%8A%B9%EC%9D%B8 "팔레스타인의 국제적 승인")** 했다.
  * [9월 17일](https://ko.wikipedia.org/wiki/9%EC%9B%94_17%EC%9D%BC "9월 17일"), [사우디아라비아](https://ko.wikipedia.org/wiki/%EC%82%AC%EC%9A%B0%EB%94%94%EC%95%84%EB%9D%BC%EB%B9%84%EC%95%84 "사우디아라비아")와 [파키스탄](https://ko.wikipedia.org/wiki/%ED%8C%8C%ED%82%A4%EC%8A%A4%ED%83%84 "파키스탄")이 서로를 공격으로부터 방어하기 위한 전략 상호 방위 협정을 맺었다.



[진행 중](https://ko.wikipedia.org/wiki/%ED%8F%AC%ED%84%B8:%EC%9A%94%EC%A6%98_%ED%99%94%EC%A0%9C "포털:요즘 화제")
    [이스라엘-하마스 전쟁](https://ko.wikipedia.org/wiki/%EC%9D%B4%EC%8A%A4%EB%9D%BC%EC%97%98-%ED%95%98%EB%A7%88%EC%8A%A4_%EC%A0%84%EC%9F%81 "이스라엘-하마스 전쟁")     [M23 공세](https://ko.wikipedia.org/wiki/M23_%EA%B3%B5%EC%84%B8 "M23 공세")     [수단 내전](https://ko.wikipedia.org/wiki/%EC%88%98%EB%8B%A8_%EB%82%B4%EC%A0%84_\(2023%EB%85%84~%ED%98%84%EC%9E%AC\) "수단 내전 \(2023년~현재\)")     [러시아의 우크라이나 침공](https://ko.wikipedia.org/wiki/%EB%9F%AC%EC%8B%9C%EC%95%84%EC%9D%98_%EC%9A%B0%ED%81%AC%EB%9D%BC%EC%9D%B4%EB%82%98_%EC%B9%A8%EA%B3%B5 "러시아의 우크라이나 침공")     [미얀마 내전](https://ko.wikipedia.org/wiki/%EB%AF%B8%EC%96%80%EB%A7%88_%EB%82%B4%EC%A0%84_\(2021%EB%85%84~%ED%98%84%EC%9E%AC\) "미얀마 내전 \(2021년~현재\)") 

[최근 부고](https://ko.wikipedia.org/wiki/2025%EB%85%84_%EC%A3%BD%EC%9D%8C "2025년 죽음")
    [제인 구달](https://ko.wikipedia.org/wiki/%EC%A0%9C%EC%9D%B8_%EA%B5%AC%EB%8B%AC "제인 구달")     [김주영](https://ko.wikipedia.org/wiki/%EA%B9%80%EC%A3%BC%EC%98%81_\(1952%EB%85%84\) "김주영 \(1952년\)")     [조희욱](https://ko.wikipedia.org/wiki/%EC%A1%B0%ED%9D%AC%EC%9A%B1 "조희욱")     [길형보](https://ko.wikipedia.org/wiki/%EA%B8%B8%ED%98%95%EB%B3%B4 "길형보")     [조종익](https://ko.wikipedia.org/wiki/%EC%A1%B0%EC%A2%85%EC%9D%B5 "조종익")
**[오늘의 역사](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%98%A4%EB%8A%98%EC%9D%98_%EC%97%AD%EC%82%AC "위키백과:오늘의 역사")**
[어제](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%98%A4%EB%8A%98%EC%9D%98_%EC%97%AD%EC%82%AC/10%EC%9B%94_1%EC%9D%BC "위키백과:오늘의 역사/10월 1일")[내일](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%98%A4%EB%8A%98%EC%9D%98_%EC%97%AD%EC%82%AC/10%EC%9B%94_3%EC%9D%BC "위키백과:오늘의 역사/10월 3일")
[![자크 카르티에](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Jacques_Cartier_1851-1852.jpg/120px-Jacques_Cartier_1851-1852.jpg)](https://commons.wikimedia.org/wiki/File:Jacques_Cartier_1851-1852.jpg "자크 카르티에")자크 카르티에
**[10월 2일](https://ko.wikipedia.org/wiki/10%EC%9B%94_2%EC%9D%BC "10월 2일")** : [기니](https://ko.wikipedia.org/wiki/%EA%B8%B0%EB%8B%88 "기니")의 **[독립기념일](https://ko.wikipedia.org/wiki/%EB%8F%85%EB%A6%BD%EA%B8%B0%EB%85%90%EC%9D%BC "독립기념일")**
  * [1535년](https://ko.wikipedia.org/wiki/1535%EB%85%84 "1535년") - [프랑스](https://ko.wikipedia.org/wiki/%ED%94%84%EB%9E%91%EC%8A%A4 "프랑스")의 탐험가 **[자크 카르티에](https://ko.wikipedia.org/wiki/%EC%9E%90%ED%81%AC_%EC%B9%B4%EB%A5%B4%ED%8B%B0%EC%97%90 "자크 카르티에")**(그림)가 [세인트로렌스강](https://ko.wikipedia.org/wiki/%EC%84%B8%EC%9D%B8%ED%8A%B8%EB%A1%9C%EB%A0%8C%EC%8A%A4%EA%B0%95 "세인트로렌스강")을 거슬러 올라가 지금의 [몬트리올](https://ko.wikipedia.org/wiki/%EB%AA%AC%ED%8A%B8%EB%A6%AC%EC%98%AC "몬트리올")에 도착하다.
  * [1835년](https://ko.wikipedia.org/wiki/1835%EB%85%84 "1835년") - [텍사스 혁명](https://ko.wikipedia.org/wiki/%ED%85%8D%EC%82%AC%EC%8A%A4_%ED%98%81%EB%AA%85 "텍사스 혁명"): **[곤살레스 전투](https://ko.wikipedia.org/wiki/%EA%B3%A4%EC%82%B4%EB%A0%88%EC%8A%A4_%EC%A0%84%ED%88%AC "곤살레스 전투")** 가 발발하다.
  * [1869년](https://ko.wikipedia.org/wiki/1869%EB%85%84 "1869년") - **[마하트마 간디](https://ko.wikipedia.org/wiki/%EB%A7%88%ED%95%98%ED%8A%B8%EB%A7%88_%EA%B0%84%EB%94%94 "마하트마 간디")** 가 태어나다.
  * [1950년](https://ko.wikipedia.org/wiki/1950%EB%85%84 "1950년") - [찰스 슐츠](https://ko.wikipedia.org/wiki/%EC%B0%B0%EC%8A%A4_%EC%8A%90%EC%B8%A0 "찰스 슐츠")가 [찰리 브라운](https://ko.wikipedia.org/wiki/%EC%B0%B0%EB%A6%AC_%EB%B8%8C%EB%9D%BC%EC%9A%B4 "찰리 브라운")과 [스누피](https://ko.wikipedia.org/wiki/%EC%8A%A4%EB%88%84%ED%94%BC "스누피")로 유명한 《**[피너츠](https://ko.wikipedia.org/wiki/%ED%94%BC%EB%84%88%EC%B8%A0 "피너츠")** 》 연재를 시작하다.
  * [1997년](https://ko.wikipedia.org/wiki/1997%EB%85%84 "1997년") - **[암스테르담 조약](https://ko.wikipedia.org/wiki/%EC%95%94%EC%8A%A4%ED%85%8C%EB%A5%B4%EB%8B%B4_%EC%A1%B0%EC%95%BD "암스테르담 조약")** 이 체결되다.
  * [2008년](https://ko.wikipedia.org/wiki/2008%EB%85%84 "2008년") - [대한민국](https://ko.wikipedia.org/wiki/%EB%8C%80%ED%95%9C%EB%AF%BC%EA%B5%AD "대한민국")의 영화배우 겸 탤런트 **[최진실](https://ko.wikipedia.org/wiki/%EC%B5%9C%EC%A7%84%EC%8B%A4 "최진실")** 이 자택에서 자살하다.


다른 날짜: [10월 1일](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%98%A4%EB%8A%98%EC%9D%98_%EC%97%AD%EC%82%AC/10%EC%9B%94_1%EC%9D%BC "위키백과:오늘의 역사/10월 1일") - **10월 2일** - [10월 3일](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%98%A4%EB%8A%98%EC%9D%98_%EC%97%AD%EC%82%AC/10%EC%9B%94_3%EC%9D%BC "위키백과:오늘의 역사/10월 3일")
**[더 보기...](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%98%A4%EB%8A%98%EC%9D%98_%EC%97%AD%EC%82%AC/10%EC%9B%94 "위키백과:오늘의 역사/10월")**
**[알고 계십니까](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%95%8C%EA%B3%A0_%EA%B3%84%EC%8B%AD%EB%8B%88%EA%B9%8C/%EC%97%AD%EC%82%AC "위키백과:알고 계십니까/역사")**
[ 이게 뭔가요?](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%95%8C%EA%B3%A0_%EA%B3%84%EC%8B%AD%EB%8B%88%EA%B9%8C "위키백과:알고 계십니까")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Assiani_Knotel2.jpg/250px-Assiani_Knotel2.jpg)](https://commons.wikimedia.org/wiki/File:Assiani_Knotel2.jpg)
  * [미국 독립 전쟁](https://ko.wikipedia.org/wiki/%EB%AF%B8%EA%B5%AD_%EB%8F%85%EB%A6%BD_%EC%A0%84%EC%9F%81 "미국 독립 전쟁") 당시 영국 편에서 섰던 독일인에 대해 미국인들은 "**[헤센병](https://ko.wikipedia.org/wiki/%ED%97%A4%EC%84%BC%EB%B3%91 "헤센병")** "(그림)이라고 불렀습니다. 이는 미군이 싸웠던 주요 군인들의 국적이 [헤센카셀 방백국](https://ko.wikipedia.org/wiki/%ED%97%A4%EC%84%BC%EC%B9%B4%EC%85%80_%EB%B0%A9%EB%B0%B1%EA%B5%AD "헤센카셀 방백국")과 [헤센하나우 백국](https://ko.wikipedia.org/wiki/%ED%97%A4%EC%84%BC%ED%95%98%EB%82%98%EC%9A%B0_%EB%B0%B1%EA%B5%AD "헤센하나우 백국")에서 왔기 때문입니다.
  * **[을축년 대홍수](https://ko.wikipedia.org/wiki/%EC%9D%84%EC%B6%95%EB%85%84_%EB%8C%80%ED%99%8D%EC%88%98 "을축년 대홍수")** 는 1925년 발생한 대홍수이지만, 이 홍수를 통해 현재 서울 동부의 여러 역사 유적이 발견되었습니다. 대표적으로 이 때 발견된 유적에는 [풍납토성](https://ko.wikipedia.org/wiki/%ED%92%8D%EB%82%A9%ED%86%A0%EC%84%B1 "풍납토성")과 [암사동 선사주거지](https://ko.wikipedia.org/wiki/%EC%95%94%EC%82%AC%EB%8F%99_%EC%84%A0%EC%82%AC%EC%A3%BC%EA%B1%B0%EC%A7%80 "암사동 선사주거지") 등이 있습니다.
  * **[남양주시](https://ko.wikipedia.org/wiki/%EB%82%A8%EC%96%91%EC%A3%BC%EC%8B%9C "남양주시")** 의 지명은 양주군의 남쪽이라는 뜻에서 유래했습니다. [양주목](https://ko.wikipedia.org/wiki/%EC%96%91%EC%A3%BC%EA%B5%B0 "양주군")이 설치된 1506년부터 1980년 남양주군 분리 때까지 양주와 남양주는 하나의 행정 체계인 양주로 묶여 있었습니다.
  * 남성용 소변기와 같이 여성이 소변을 빠르게 볼 수 있도록 디자인된 **[여성용 소변기](https://ko.wikipedia.org/wiki/%EC%97%AC%EC%84%B1%EC%9A%A9_%EC%86%8C%EB%B3%80%EA%B8%B0 "여성용 소변기")** 도 출시되고 있습니다.
  * **[토요타 전쟁](https://ko.wikipedia.org/wiki/%ED%86%A0%EC%9A%94%ED%83%80_%EC%A0%84%EC%9F%81 "토요타 전쟁")** 은 [차드-리비아 전쟁](https://ko.wikipedia.org/wiki/%EC%B0%A8%EB%93%9C-%EB%A6%AC%EB%B9%84%EC%95%84_%EC%A0%84%EC%9F%81 "차드-리비아 전쟁")의 마지막 전선으로, 참여한 군대가 주요 차량으로 [토요타 자동차](https://ko.wikipedia.org/wiki/%ED%86%A0%EC%9A%94%ED%83%80_%EC%9E%90%EB%8F%99%EC%B0%A8 "토요타 자동차")에서 생산된 차량을 사용해서 이 이름이 붙었습니다.


**[자매 프로젝트](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%9E%90%EB%A7%A4_%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8 "위키백과:자매 프로젝트")**
위키백과는 비영리 단체인 [위키미디어 재단](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%AF%B8%EB%94%94%EC%96%B4_%EC%9E%AC%EB%8B%A8 "위키미디어 재단")이 운영하고 있습니다. 위키미디어 재단은 그 밖의 다른 [프로젝트](https://meta.wikimedia.org/wiki/Complete_list_of_Wikimedia_projects "meta:Complete list of Wikimedia projects")도 운영하고 있습니다. 
[![메타위키](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Wikimedia_Community_Logo_optimized.svg/40px-Wikimedia_Community_Logo_optimized.svg.png)](https://meta.wikimedia.org/wiki/%EB%8C%80%EB%AC%B8 "메타위키")
**[메타위키](https://meta.wikimedia.org/wiki/%EB%8C%80%EB%AC%B8 "m:대문")**  
자매 프로젝트 관리 
[![미디어위키](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/MediaWiki/ko "미디어위키")
**[미디어위키](https://www.mediawiki.org/wiki/MediaWiki/ko "mw:MediaWiki/ko")**  
위키 소프트웨어 개발
[![위키낱말사전](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Wiktionary-logo-ko-without-text.svg/60px-Wiktionary-logo-ko-without-text.svg.png)](https://ko.wiktionary.org/wiki/ "위키낱말사전")
**[위키낱말사전](https://ko.wiktionary.org/wiki/ "wikt:")**  
낱말과 관용구 
[![위키뉴스](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://ko.wikinews.org/wiki/ "위키뉴스")
**[위키뉴스](https://ko.wikinews.org/wiki/ "n:")**  
자유 컨텐츠 뉴스 
[![위키데이터](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/Wikidata:%EB%8C%80%EB%AC%B8 "위키데이터")
**[위키데이터](https://www.wikidata.org/wiki/Wikidata:%EB%8C%80%EB%AC%B8 "d:Wikidata:대문")**  
열린 지식 베이스 
[![위키문헌](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://ko.wikisource.org/wiki/ "위키문헌")
**[위키문헌](https://ko.wikisource.org/wiki/ "s:")**  
자유 컨텐츠 도서관 
[![위키미디어 공용](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/%EB%8C%80%EB%AC%B8 "위키미디어 공용")
**[위키미디어 공용](https://commons.wikimedia.org/wiki/%EB%8C%80%EB%AC%B8 "commons:대문")**  
열린 미디어 저장소 
[![위키배움터](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/40px-Wikiversity_logo_2017.svg.png)](https://ko.wikiversity.org/wiki/ "위키배움터")
**[위키배움터](https://ko.wikiversity.org/wiki/ "v:")**  
열린 학습 공간 
[![위키생물종](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/%EB%8C%80%EB%AC%B8 "위키생물종")
**[위키생물종](https://species.wikimedia.org/wiki/%EB%8C%80%EB%AC%B8 "wikispecies:대문")**  
생물 분류 도감 
[![위키여행](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://ko.wikivoyage.org/wiki/ "위키여행")
**[위키여행](https://ko.wikivoyage.org/wiki/ "voy:")**(시험판)  
열린 여행 가이드 
[![위키인용집](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://ko.wikiquote.org/wiki/ "위키인용집")
**[위키인용집](https://ko.wikiquote.org/wiki/ "q:")**  
인용 모음집 
[![위키책](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://ko.wikibooks.org/wiki/ "위키책")
**[위키책](https://ko.wikibooks.org/wiki/ "b:")**  
교과서와 참고서 
[위키백과 언어 전체 목록](https://meta.wikimedia.org/wiki/List_of_Wikipedias/ko "meta:List of Wikipedias/ko")
원본 주소 "[https://ko.wikipedia.org/w/index.php?title=위키백과:대문&oldid=40156846](https://ko.wikipedia.org/w/index.php?title=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8&oldid=40156846)"
49개 언어
  * [العربية](https://ar.wikipedia.org/wiki/ "아랍어")
  * [Български](https://bg.wikipedia.org/wiki/ "불가리아어")
  * [Català](https://ca.wikipedia.org/wiki/ "카탈로니아어")
  * [Нохчийн](https://ce.wikipedia.org/wiki/ "체첸어")
  * [Cebuano](https://ceb.wikipedia.org/wiki/ "세부아노어")
  * [Čeština](https://cs.wikipedia.org/wiki/ "체코어")
  * [Dansk](https://da.wikipedia.org/wiki/ "덴마크어")
  * [Deutsch](https://de.wikipedia.org/wiki/ "독일어")
  * [English](https://en.wikipedia.org/wiki/ "영어")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "에스페란토어")
  * [Español](https://es.wikipedia.org/wiki/ "스페인어")
  * [Eesti](https://et.wikipedia.org/wiki/ "에스토니아어")
  * [Euskara](https://eu.wikipedia.org/wiki/ "바스크어")
  * [فارسی](https://fa.wikipedia.org/wiki/ "페르시아어")
  * [Suomi](https://fi.wikipedia.org/wiki/ "핀란드어")
  * [Français](https://fr.wikipedia.org/wiki/ "프랑스어")
  * [Galego](https://gl.wikipedia.org/wiki/ "갈리시아어")
  * [עברית](https://he.wikipedia.org/wiki/ "히브리어")
  * [हिन्दी](https://hi.wikipedia.org/wiki/ "힌디어")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "크로아티아어")
  * [Magyar](https://hu.wikipedia.org/wiki/ "헝가리어")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "인도네시아어")
  * [Italiano](https://it.wikipedia.org/wiki/ "이탈리아어")
  * [日本語](https://ja.wikipedia.org/wiki/ "일본어")
  * [Қазақша](https://kk.wikipedia.org/wiki/ "카자흐어")
  * [Latina](https://la.wikipedia.org/wiki/ "라틴어")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "리투아니아어")
  * [Minangkabau](https://min.wikipedia.org/wiki/ "미낭카바우어")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "말레이어")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "네덜란드어")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "노르웨이어\(니노르스크\)")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "노르웨이어\(보크말\)")
  * [Polski](https://pl.wikipedia.org/wiki/ "폴란드어")
  * [Português](https://pt.wikipedia.org/wiki/ "포르투갈어")
  * [Română](https://ro.wikipedia.org/wiki/ "루마니아어")
  * [Русский](https://ru.wikipedia.org/wiki/ "러시아어")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "세르비아-크로아티아어")
  * [Simple English](https://simple.wikipedia.org/wiki/ "쉬운 영어")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "슬로바키아어")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "슬로베니아어")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "세르비아어")
  * [Svenska](https://sv.wikipedia.org/wiki/ "스웨덴어")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "튀르키예어")
  * [Українська](https://uk.wikipedia.org/wiki/ "우크라이나어")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/ "우즈베크어")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "베트남어")
  * [Volapük](https://vo.wikipedia.org/wiki/ "볼라퓌크어")
  * [Winaray](https://war.wikipedia.org/wiki/ "와라이어")
  * [中文](https://zh.wikipedia.org/wiki/ "중국어")


  * 이 문서는 2025년 6월 28일 (토) 00:07에 마지막으로 편집되었습니다.
  * 모든 문서는 [크리에이티브 커먼즈 저작자표시-동일조건변경허락 4.0](https://creativecommons.org/licenses/by-sa/4.0/deed.ko)에 따라 사용할 수 있으며, 추가적인 조건이 적용될 수 있습니다. 자세한 내용은 [이용 약관](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use/ko)을 참고하십시오.  
Wikipedia®는 미국 및 다른 국가에 등록되어 있는 [Wikimedia Foundation, Inc.](https://www.wikimediafoundation.org) 소유의 등록 상표입니다.


  * [개인정보처리방침](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [위키백과 소개](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EC%86%8C%EA%B0%9C)
  * [면책 조항](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%A9%B4%EC%B1%85_%EC%A1%B0%ED%95%AD)
  * [행동 강령](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [개발자](https://developer.wikimedia.org)
  * [통계](https://stats.wikimedia.org/#/ko.wikipedia.org)
  * [쿠키 정책](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [](https://ko.m.wikipedia.org/w/index.php?title=%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8&mobileaction=toggle_view_mobile)
  * [미리보기 설정 수정](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8)


검색
검색
위키백과:대문
[](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8) [](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8) [](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8) [](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8) [](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8) [](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8) [](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8) [](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8)
49개 언어 [새 주제 ](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8)
![](https://upload.wikimedia.org/wikipedia/commons/2/2e/Up_%2889591%29_-_The_Noun_Project.svg)
  *[**722,549**]: 넘겨주기와 막다른 문서를 제외한 모든 글의 수
