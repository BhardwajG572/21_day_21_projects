[انتقل إلى المحتوى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87#bodyContent)
القائمة الرئيسية
القائمة الرئيسية
انقل للشريط الجانبي أخف
استكشاف 
  * [الصفحه الرئيسيه](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "زور الصفحه الرئيسيه \[alt-z\]")
  * [بوابات ويكيبيديا مصرى](https://arz.wikipedia.org/wiki/%D8%AA%D8%B5%D9%86%D9%8A%D9%81:%D8%A8%D9%88%D8%A7%D8%A8%D8%A7%D8%AA)
  * [اخر التعديلات](https://arz.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A7%D8%AE%D8%B1_%D8%AA%D8%B9%D8%AF%D9%8A%D9%84%D8%A7%D8%AA "ليستة التعديلات الاخرانيه فى الويكى \[alt-r\]")
  * [صفحة عشوائيه](https://arz.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%B9%D8%B4%D9%88%D8%A7%D8%A6%D9%89 "لوّد صفحه عشوائيه \[alt-x\]")
  * [مساعده](https://arz.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D9%85%D8%AD%D8%AA%D9%88%D9%8A%D8%A7%D8%AA "لو محتاج مساعده بص هنا")


تواصل 
  * [صالون المناقشه](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B5%D8%A7%D9%84%D9%88%D9%86_%D8%A7%D9%84%D9%85%D9%86%D8%A7%D9%82%D8%B4%D9%87)
  * [طريقة الكتابه](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B7%D8%B1%D9%8A%D9%82%D8%A9_%D8%A7%D9%84%D9%83%D8%AA%D8%A7%D8%A8%D9%87)
  * [احداث دلوقتى](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D8%AD%D8%AF%D8%A7%D8%AB_%D8%AF%D9%84%D9%88%D9%82%D8%AA%D9%89 "شوف معلومات على الاحداث اللى بتحصل دلوقتى")
  * [صفح مخصوصه](https://arz.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%B5%D9%81%D8%AD_%D9%85%D8%AE%D8%B5%D9%88%D8%B5%D9%87)


[ ![](https://arz.wikipedia.org/static/images/icons/wikipedia.png) ![ويكيبيديا](https://arz.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-ar.svg) ![](https://arz.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-arz.svg) ](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87)
[تدوير ](https://arz.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%AA%D8%AF%D9%88%D9%8A%D8%B1 "دور فى ويكيبيديا \[alt-f\]")
تدوير
المظهر
المظهر
انقل للشريط الجانبي أخف
النص
  * صغير
قياسي
كبير

تستخدم هذه الصفحة دائمًا حجم خط صغير
العرض
  * قياسي
عريض

المحتوى متوسّع قدر الإمكان لنافذة المتصفّح الخاص بك.
  * [التبرعات](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=arz.wikipedia.org&uselang=arz)
  * [افتح حساب](https://arz.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%A7%D8%A8%D8%AA%D8%AF%D9%89_%D8%AD%D8%B3%D8%A7%D8%A8&returnto=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87+%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "نشجعك على عمل حساب وتسجيل دخولك; لكنه مش  ضروري")
  * [دخول](https://arz.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%AF%D8%AE%D9%88%D9%84_%D8%A7%D9%84%D9%8A%D9%88%D8%B2%D8%B1&returnto=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87+%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "يستحسن تسجل دخولك; لكن, ده مش اجبارى \[alt-o\]")


ادوات شخصيه
  * [التبرعات](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=arz.wikipedia.org&uselang=arz)
  * [افتح حساب](https://arz.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%A7%D8%A8%D8%AA%D8%AF%D9%89_%D8%AD%D8%B3%D8%A7%D8%A8&returnto=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87+%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "نشجعك على عمل حساب وتسجيل دخولك; لكنه مش  ضروري")
  * [دخول](https://arz.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%AF%D8%AE%D9%88%D9%84_%D8%A7%D9%84%D9%8A%D9%88%D8%B2%D8%B1&returnto=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87+%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "يستحسن تسجل دخولك; لكن, ده مش اجبارى \[alt-o\]")


# الصفحه الرئيسيه
  * [الصفحه الرئيسيه](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "اعرض صفحة المحتوى \[alt-c\]")
  * [مناقشه](https://arz.wikipedia.org/wiki/%D9%86%D9%82%D8%A7%D8%B4:%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "مناقشة صفحة الموضوع \[alt-t\]")


مصرى
  * [قرايه](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87)
  * [عرض المصدر](https://arz.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&action=edit "الصفحه دى محميه.
ممكن تشوف مصدرها. \[alt-e\]")
  * [استعراض التاريخ](https://arz.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&action=history "نسخ قديمه من الصفحه دى \[alt-h\]")
  * [![](https://upload.wikimedia.org/wikipedia/commons/1/10/Reload_icon_-_Green.svg)](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87%20%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87?action=purge "تفضيه الكاش")


علبة العده
أدوات
انقل للشريط الجانبي أخف
إجراءات 
  * [قرايه](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87)
  * [عرض المصدر](https://arz.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&action=edit)
  * [استعراض التاريخ](https://arz.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&action=history)
  * [تفضيه الكاش](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87?action=purge)


عام 
  * [ايه بيوصل هنا](https://arz.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A7%D9%8A%D9%87_%D8%A8%D9%8A%D9%88%D8%B5%D9%84_%D9%87%D9%86%D8%A7/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "ليستة كل الصفح اللى بتوصل هنا \[alt-j\]")
  * [تعديلات ليها علاقه](https://arz.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A7%D8%AC%D8%AF%D8%AF_%D8%A7%D9%84%D8%AA%D8%BA%D9%8A%D9%8A%D8%B1%D8%A7%D8%AA_%D8%A7%D9%84%D9%84%D9%89_%D9%85%D8%B9%D9%85%D9%88%D9%84_%D9%84%D9%8A%D9%87%D8%A7_%D9%84%D9%8A%D9%86%D9%83/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "اخر التغييرات فى صفح معمول ليها لينك من الصفحه دى \[alt-k\]")
  * [ارفع فايل (upload file)](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=arz "ارفع فايلات \(upload files\) \[alt-u\]")
  * [لينك دايم](https://arz.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&oldid=12248946 "لينك دايم للنسخه دى من الصفحه")
  * [معلومات عن الصفحه](https://arz.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&action=info "المزيد من المعلومات عن هذه الصفحة")
  * [استشهد بالصفحة دى](https://arz.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%A7%D8%B3%D8%AA%D8%B4%D9%87%D8%A7%D8%AF&page=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&id=12248946&wpFormIdentifier=titleform "معلومات عن ازاى الاستشهاد بالصفحة")
  * [احصل على مسار مختصر](https://arz.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%AA%D9%82%D8%B5%D9%8A%D8%B1_%D8%A7%D9%84%D9%85%D8%B3%D8%A7%D8%B1&url=https%3A%2F%2Farz.wikipedia.org%2Fwiki%2F%25D8%25A7%25D9%2584%25D8%25B5%25D9%2581%25D8%25AD%25D9%2587_%25D8%25A7%25D9%2584%25D8%25B1%25D8%25A6%25D9%258A%25D8%25B3%25D9%258A%25D9%2587)
  * [تنزيل رمز الاستجابة السريعة](https://arz.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:QrCode&url=https%3A%2F%2Farz.wikipedia.org%2Fwiki%2F%25D8%25A7%25D9%2584%25D8%25B5%25D9%2581%25D8%25AD%25D9%2587_%25D8%25A7%25D9%2584%25D8%25B1%25D8%25A6%25D9%258A%25D8%25B3%25D9%258A%25D9%2587)
  * [تعديل الروابط ما بين اللغات](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "تعديل الروابط ما بين اللغات")


اطبع/صدّر 
  * [إعمل كتاب](https://arz.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D9%83%D8%AA%D8%A7%D8%A8&bookcmd=book_creator&referer=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87+%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87)
  * [تنزيل PDF](https://arz.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:DownloadAsPdf&page=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&action=show-download-screen)
  * [نسخه للطبع](https://arz.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&printable=yes "نسخه تنفع تتطبع للصفحه دى \[alt-p\]")


مشاريع تانيه 
  * [ويكيميديا كومنز](https://commons.wikimedia.org/wiki/Main_Page)
  * [مؤسسة ويكيميديا](https://foundation.wikimedia.org/wiki/Home)
  * [ميدياويكي](https://www.mediawiki.org/wiki/MediaWiki)
  * [ميتاويكي](https://meta.wikimedia.org/wiki/Main_Page)
  * [التواصل مع ويكيميديا](https://outreach.wikimedia.org/wiki/Main_Page)
  * [ويكي مصدر متعدد اللغات](https://wikisource.org/wiki/Main_Page)
  * [ويكي الأنواع](https://species.wikimedia.org/wiki/Main_Page)
  * [ويكيداتا](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [ويكي الدوال](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [عنصر ويكيداتا](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "الربط بعنصر مرتبط ف مستودع البيانات \[alt-g\]")


من ويكيبيديا، الموسوعه الحره
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/WelcomeToEgyptianWikipedia.png/500px-WelcomeToEgyptianWikipedia.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:WelcomeToEgyptianWikipedia.png)
مشروع [موسوعه](https://arz.wikipedia.org/wiki/%D9%85%D9%88%D8%B3%D9%88%D8%B9%D9%87 "موسوعه") حره اى حد ممكن يساهم فى كتابتها. 
● [ويكيبيديا](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7 "ويكيبيديا") ● [اسئله متكرره](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D8%B3%D8%A6%D9%84%D9%87_%D9%85%D8%AA%D9%83%D8%B1%D8%B1%D9%87 "ويكيبيديا:اسئله متكرره") ● [صالون المناقشه](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B5%D8%A7%D9%84%D9%88%D9%86_%D8%A7%D9%84%D9%85%D9%86%D8%A7%D9%82%D8%B4%D9%87 "ويكيبيديا:صالون المناقشه") ● [طريقة الكتابه](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B7%D8%B1%D9%8A%D9%82%D8%A9_%D8%A7%D9%84%D9%83%D8%AA%D8%A7%D8%A8%D9%87 "ويكيبيديا:طريقة الكتابه") ● [قواعد](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D9%84%D8%AE%D9%85%D8%B3_%D9%82%D9%88%D8%A7%D8%B9%D8%AF "ويكيبيديا:الخمس قواعد") ● [احصاءات](https://stats.wikimedia.org/v2/#/arz.wikipedia.org "stats:v2/") ● [**تفضية كاش الصفحه**](https://arz.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&action=purge#TemplateData)
**لغاية[2 اكتوبر](https://arz.wikipedia.org/wiki/2_%D8%A7%D9%83%D8%AA%D9%88%D8%A8%D8%B1 "2 اكتوبر") [2025](https://arz.wikipedia.org/wiki/2025 "2025") ميلادى - 22 [توت](https://arz.wikipedia.org/wiki/%D8%AA%D9%88%D8%AA_\(%D8%B4%D9%87%D8%B1\) "توت \(شهر\)") 1742 مصرى**
[ويكيبيديا مصرى](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7_%D9%85%D8%B5%D8%B1%D9%89 "ويكيبيديا مصرى") فيها **[1,629,143](https://arz.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A7%D8%AD%D8%B5%D8%A7%D8%A6%D9%8A%D8%A7%D8%AA "خاص:احصائيات")** مقاله مكتوبه [بالمصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D9%87_%D8%A7%D9%84%D9%85%D8%B5%D8%B1%D9%8A%D9%87_%D8%A7%D9%84%D8%AD%D8%AF%D9%8A%D8%AB%D9%87 "اللغه المصريه الحديثه"). 
احتمال ان الصفحه اللى بتدور عليها موجوده, ممكن [تدور](https://arz.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%AA%D8%AF%D9%88%D9%8A%D8%B1 "خاص:تدوير") عليها او تعملها. 
**ممكن تبتدى مقاله جديده هنا**
* * *
For Non "Masri" Speakers, [click here to read the introduction in English](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:Introduction_in_English "ويكيبيديا:Introduction in English")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/HSutvald2.svg/40px-HSutvald2.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:HSutvald2.svg) **مقاله مختاره**
* * *
**عباس محمود العقاد** ( [اسوان](https://arz.wikipedia.org/wiki/%D8%A7%D8%B3%D9%88%D8%A7%D9%86 "اسوان") ، [مصر](https://arz.wikipedia.org/wiki/%D9%85%D8%B5%D8%B1 "مصر") ، [1889](https://arz.wikipedia.org/wiki/1889 "1889")- [القاهره](https://arz.wikipedia.org/w/index.php?title=%D9%84%D9%82%D8%A7%D9%87%D8%B1%D9%87&action=edit&redlink=1 "لقاهره \(الصفحه مالهاش وجود\)") [،1964](https://arz.wikipedia.org/wiki/1964 "1964")) اديب ومفكر وصحفى وشاعر [مصرى](https://arz.wikipedia.org/wiki/%D9%85%D8%B5%D8%B1%D9%8A%D9%8A%D9%86 "مصريين") قال ان اجداده كانو [أكراد](https://arz.wikipedia.org/wiki/%D8%A7%D9%83%D8%B1%D8%A7%D8%AF "اكراد"). 
ولد عباس العقاد فى اسوان فى جنوب مصر و بعد ما خلص المدرسه الابتدائى اشتغل فى وظيفه كتابيه و بعدين سابها و اهتم بتثقيف نفسه بنفسه بالقرايه و اشتغل فى الصحافه. فى سنة 1916 نشر ديوان شعرى و بعد كده اتوالت مجموعاته الشعريه " وحى الاربعين " ، و " هدية الكروان " ، و " عابر سبيل " ، و " أعاصير مغرب ". و فى سنة 1921 اصدر مع [ابراهيم عبد القادر المازنى](https://arz.wikipedia.org/wiki/%D8%A7%D8%A8%D8%B1%D8%A7%D9%87%D9%8A%D9%85_%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D9%82%D8%A7%D8%AF%D8%B1_%D8%A7%D9%84%D9%85%D8%A7%D8%B2%D9%86%D9%89 "ابراهيم عبد القادر المازنى") كتاب نقدى عنوانه " الديوان ". 
[![](https://upload.wikimedia.org/wikipedia/arz/thumb/2/21/%D8%B9%D8%A8%D8%A7%D8%B3_%D8%A7%D9%84%D8%B9%D9%82%D8%A7%D8%AF.jpg/250px-%D8%B9%D8%A8%D8%A7%D8%B3_%D8%A7%D9%84%D8%B9%D9%82%D8%A7%D8%AF.jpg)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:%D8%B9%D8%A8%D8%A7%D8%B3_%D8%A7%D9%84%D8%B9%D9%82%D8%A7%D8%AF.jpg)
* * *
[عباس العقاد](https://arz.wikipedia.org/wiki/%D8%B9%D8%A8%D8%A7%D8%B3_%D8%A7%D9%84%D8%B9%D9%82%D8%A7%D8%AF "عباس العقاد")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/HSAktuell.svg/40px-HSAktuell.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:HSAktuell.svg) **فى الاخبار**
* * *
[![noframe](https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Igor_Grosu_November_2023.jpg/250px-Igor_Grosu_November_2023.jpg)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Igor_Grosu_November_2023.jpg "noframe")
  * زلزال بقوة 6.9 ضرب [مدينة سيبو](https://arz.wikipedia.org/wiki/%D9%85%D8%AF%D9%8A%D9%86%D9%87_%D8%B3%D9%8A%D8%A8%D9%88 "مدينه سيبو") ف [الفيليبين](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%81%D9%8A%D9%84%D9%8A%D8%A8%D9%8A%D9%86 "الفيليبين"). خللا اقل حاجه 69 شخص يموتو.
  * حزب العمل و التضامن الحاكم (زعيمه إيجور جروسو اللى فى الصوره) حافظ على اغلبيته ف انتخابات البرلمان فى [مولدوڤا](https://arz.wikipedia.org/wiki/%D9%85%D9%88%D9%84%D8%AF%D9%88%DA%A4%D8%A7 "مولدوڤا").
  * [بيتر موثاريكا](https://arz.wikipedia.org/wiki/%D8%A8%D9%8A%D8%AA%D8%B1_%D9%85%D9%88%D8%AB%D8%A7%D8%B1%D9%8A%D9%83%D8%A7 "بيتر موثاريكا") انتخب [رئيس](https://arz.wikipedia.org/w/index.php?title=%D8%B1%D8%A4%D8%B3%D8%A7_%D9%85%D8%A7%D9%84%D8%A7%D9%88%D9%89&action=edit&redlink=1 "رؤسا مالاوى \(الصفحه مالهاش وجود\)") جمهورية [مالاوى](https://arz.wikipedia.org/wiki/%D9%85%D8%A7%D9%84%D8%A7%D9%88%D9%89 "مالاوى").
  * اعصار راجاسا ضرب [تايوان](https://arz.wikipedia.org/wiki/%D8%AA%D8%A7%D9%8A%D9%88%D8%A7%D9%86 "تايوان") و [الفيليبين](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%81%D9%8A%D9%84%D9%8A%D8%A8%D9%8A%D9%86 "الفيليبين"). و عالقليله 25 شخص ماتو.
  * [السعوديه](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%85%D9%85%D9%84%D9%83%D9%87_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D9%87_%D8%A7%D9%84%D8%B3%D8%B9%D9%88%D8%AF%D9%8A%D9%87 "المملكه العربيه السعوديه") و [باكستان](https://arz.wikipedia.org/wiki/%D8%A8%D8%A7%D9%83%D8%B3%D8%AA%D8%A7%D9%86 "باكستان") مضو اتفاقيه دفاع مشترك.
  * [روبرت ريدفورد](https://arz.wikipedia.org/wiki/%D8%B1%D9%88%D8%A8%D8%B1%D8%AA_%D8%B1%D9%8A%D8%AF%D9%81%D9%88%D8%B1%D8%AF "روبرت ريدفورد"). الممثل و المخرج الامريكانى, مات و هو عنده 89 سنه.
  * فى التلفزيون, مسلسل The Studio كسب جايزة احسن كوميديا و مسلسل The Pitt كسب جايزة احسن دراما فى حفلة الـPrimetime Emmy Awards.
  * بعد مظاهرات كبيره, [سوشيلا كاركى](https://arz.wikipedia.org/wiki/%D8%B3%D9%88%D8%B4%D9%8A%D9%84%D8%A7_%D9%83%D8%A7%D8%B1%D9%83%D9%89 "سوشيلا كاركى") اتعينت رئيسه وزرا مؤقته فى نيبال بدل كى. پى. شارما اولى.
  * الرئيس [البرازيلى](https://arz.wikipedia.org/wiki/%D8%A8%D8%B1%D8%A7%D8%B2%D9%8A%D9%84 "برازيل") السابق, [جايير بولسونارو](https://arz.wikipedia.org/wiki/%D8%AC%D8%A7%D9%8A%D9%8A%D8%B1_%D8%A8%D9%88%D9%84%D8%B3%D9%88%D9%86%D8%A7%D8%B1%D9%88 "جايير بولسونارو"). اتحكم عليه بـ27 سنه سجن عشان كان متورط فى محاولة انقلاب.
  * رصد اندماج ثقبين اسودين بيثبت لاول مره القانون التانى للديناميكا الحراريه الخاصه بالثقوب السودا.


* * *
[احداث دلوقتى](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D8%AD%D8%AF%D8%A7%D8%AB_%D8%AF%D9%84%D9%88%D9%82%D8%AA%D9%89 "ويكيبيديا:احداث دلوقتى")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/HSWQuote.svg/40px-HSWQuote.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:HSWQuote.svg) **كلام بالمصرى**
الجاهل يعمل فى نفسه اللى مايعملهوش اعاديه فيه [من كتاب بدايع الزهور -ابن إياس](https://arz.wikipedia.org/wiki/%D8%A7%D8%A8%D9%86_%D8%A7%D9%8A%D8%A7%D8%B3 "ابن اياس")
  

[![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Flag_of_Egypt.svg/40px-Flag_of_Egypt.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Flag_of_Egypt.svg) **[شخصيات مصريه مشهوره](https://arz.wikipedia.org/wiki/%D8%B4%D8%AE%D8%B5%D9%8A%D8%A7%D8%AA_%D9%85%D8%B5%D8%B1%D9%8A%D9%87_%D9%85%D8%B4%D9%87%D9%88%D8%B1%D9%87 "شخصيات مصريه مشهوره")**
* * *
  * [رشدى اباظه](https://arz.wikipedia.org/wiki/%D8%B1%D8%B4%D8%AF%D9%89_%D8%A3%D8%A8%D8%A7%D8%B8%D9%87 "رشدى أباظه")
  * [عمرو عبد الحميد](https://arz.wikipedia.org/wiki/%D8%B9%D9%85%D8%B1%D9%88_%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D8%AD%D9%85%D9%8A%D8%AF "عمرو عبد الحميد")
  * [يحيى الفخرانى](https://arz.wikipedia.org/wiki/%D9%8A%D8%AD%D9%8A%D9%89_%D8%A7%D9%84%D9%81%D8%AE%D8%B1%D8%A7%D9%86%D9%89 "يحيى الفخرانى")
  * [عبد الرحمن الابنودى](https://arz.wikipedia.org/wiki/%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D8%B1%D8%AD%D9%85%D9%86_%D8%A7%D9%84%D8%A7%D8%A8%D9%86%D9%88%D8%AF%D9%89 "عبد الرحمن الابنودى")
  * [مصطفى محمود](https://arz.wikipedia.org/wiki/%D9%85%D8%B5%D8%B7%D9%81%D9%89_%D9%85%D8%AD%D9%85%D9%88%D8%AF "مصطفى محمود")
  * [ماريه القبطيه](https://arz.wikipedia.org/wiki/%D9%85%D8%A7%D8%B1%D9%8A%D9%87_%D8%A7%D9%84%D9%82%D8%A8%D8%B7%D9%8A%D9%87 "ماريه القبطيه")
  * [على الرجال](https://arz.wikipedia.org/w/index.php?title=%D8%B9%D9%84%D9%89_%D8%A7%D9%84%D8%B1%D8%AC%D8%A7%D9%84&action=edit&redlink=1 "على الرجال \(الصفحه مالهاش وجود\)")
  * [الن جريش](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%86_%D8%AC%D8%B1%D9%8A%D8%B4 "الن جريش")
  * [بولس فهمى](https://arz.wikipedia.org/wiki/%D8%A8%D9%88%D9%84%D8%B3_%D9%81%D9%87%D9%85%D9%89 "بولس فهمى")
  * [تحيه كاريوكا](https://arz.wikipedia.org/wiki/%D8%AA%D8%AD%D9%8A%D9%87_%D9%83%D8%A7%D8%B1%D9%8A%D9%88%D9%83%D8%A7 "تحيه كاريوكا")
  * [بمبه كشر](https://arz.wikipedia.org/wiki/%D8%A8%D9%85%D8%A8%D9%87_%D9%83%D8%B4%D8%B1 "بمبه كشر")
  * [ناجى اسعد](https://arz.wikipedia.org/wiki/%D9%86%D8%A7%D8%AC%D9%89_%D8%A7%D8%B3%D8%B9%D8%AF "ناجى اسعد")
  * [هيباتيا](https://arz.wikipedia.org/wiki/%D9%87%D9%8A%D8%A8%D8%A7%D8%AA%D9%8A%D8%A7 "هيباتيا")
  * [محمد عبد السلام فرج](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D9%85%D8%AF_%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D8%B3%D9%84%D8%A7%D9%85_%D9%81%D8%B1%D8%AC "محمد عبد السلام فرج")
  * [يوسف شاهين](https://arz.wikipedia.org/wiki/%D9%8A%D9%88%D8%B3%D9%81_%D8%B4%D8%A7%D9%87%D9%8A%D9%86 "يوسف شاهين")


[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/Isma%27il_Pasha.jpg/250px-Isma%27il_Pasha.jpg)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Isma%27il_Pasha.jpg)
[الخديوى اسماعيل](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%AE%D8%AF%D9%8A%D9%88%D9%89_%D8%A7%D8%B3%D9%85%D8%A7%D8%B9%D9%8A%D9%84 "الخديوى اسماعيل")
* * *
[المصريين](https://arz.wikipedia.org/wiki/%D9%85%D8%B5%D8%B1%D9%8A%D9%8A%D9%86 "مصريين") [اللغه المصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D9%87_%D8%A7%D9%84%D9%85%D8%B5%D8%B1%D9%8A%D9%87_%D8%A7%D9%84%D8%AD%D8%AF%D9%8A%D8%AB%D9%87 "اللغه المصريه الحديثه") [الليسته كامله](https://arz.wikipedia.org/wiki/%D8%B4%D8%AE%D8%B5%D9%8A%D8%A7%D8%AA_%D9%85%D8%B5%D8%B1%D9%8A%D9%87_%D9%85%D8%B4%D9%87%D9%88%D8%B1%D9%87 "شخصيات مصريه مشهوره")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Coat_of_arms_of_Egypt_%28Official%29.svg/20px-Coat_of_arms_of_Egypt_%28Official%29.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Coat_of_arms_of_Egypt_\(Official\).svg) **مصر**
* * *
**[مصر](https://arz.wikipedia.org/wiki/%D9%85%D8%B5%D8%B1 "مصر")** , دوله افريقية [اراضيها ف قارتين](https://arz.wikipedia.org/wiki/%D8%A8%D9%84%D8%A7%D8%AF_%D8%A7%D8%B1%D8%A7%D8%B6%D9%8A%D9%87%D8%A7_%D9%81_%D8%A7%D9%83%D8%AA%D8%B1_%D9%85%D9%86_%D9%82%D8%A7%D8%B1%D9%87_%D9%88%D8%A7%D8%AD%D8%AF%D9%87 "بلاد اراضيها ف اكتر من قاره واحده"), الغرب ف [شمال افريقيا](https://arz.wikipedia.org/wiki/%D8%B4%D9%85%D8%A7%D9%84_%D8%A7%D9%81%D8%B1%D9%8A%D9%82%D9%8A%D8%A7 "شمال افريقيا") و الشرق فغرب اسيا, اهلها بيتكلموا [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D9%87_%D8%A7%D9%84%D9%85%D8%B5%D8%B1%D9%8A%D9%87_%D8%A7%D9%84%D8%AD%D8%AF%D9%8A%D8%AB%D9%87 "اللغه المصريه الحديثه"), دينها الرسمي [الاسلام](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%A7%D8%B3%D9%84%D8%A7%D9%85 "الاسلام") (الإسم الرسمى للدولة الحالية هو **جمهورية مصر العربية** من سنة 1971. 
  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/EGY_orthographic.svg/250px-EGY_orthographic.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:EGY_orthographic.svg)
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/S_F-E-CAMERON_EGYPT_2005_APR_00361.JPG/250px-S_F-E-CAMERON_EGYPT_2005_APR_00361.JPG)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:S_F-E-CAMERON_EGYPT_2005_APR_00361.JPG)
[ابو سمبل ](https://arz.wikipedia.org/wiki/%D8%A7%D8%A8%D9%88_%D8%B3%D9%85%D8%A8%D9%84 "ابو سمبل")
* * *
[مصر](https://arz.wikipedia.org/wiki/%D9%85%D8%B5%D8%B1 "مصر") [نمر تليفونات مهمه](https://arz.wikipedia.org/wiki/%D9%86%D9%85%D8%B1_%D8%AA%D9%84%D9%8A%D9%81%D9%88%D9%86%D8%A7%D8%AA_%D9%85%D9%87%D9%85%D9%87_%D9%81%D9%89_%D9%85%D8%B5%D8%B1 "نمر تليفونات مهمه فى مصر") [الوزارات المصريه](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%88%D8%B2%D8%A7%D8%B1%D8%A7%D8%AA_%D8%A7%D9%84%D9%85%D8%B5%D8%B1%D9%8A%D9%87 "الوزارات المصريه") [سفارات مصر](https://arz.wikipedia.org/wiki/%D8%B3%D9%81%D8%A7%D8%B1%D8%A7%D8%AA_%D9%85%D8%B5%D8%B1_%D9%88%D8%B9%D9%86%D8%A7%D9%88%D9%86%D9%8A%D9%87%D8%A7 "سفارات مصر وعناونيها")
  * الاسعاف 123
  * بوليس النجدة 122
  * المطافئ 180
  * مديرية الامن 13
  * الكهرباء 121
  * الغاز 129
  * المياه 125
  * الصرف الصحي 175
  * شرطة السياحة 126
  * شرطة السكة الحديد 145


**محافظه مصريه**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Flag_of_Menoufia_Governorate.PNG/250px-Flag_of_Menoufia_Governorate.PNG)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Flag_of_Menoufia_Governorate.PNG) **المنوفيه** محافظه مصريه فى شمال مصر من ضمن محافضات الدلتا و عاصمتها شبين الكوم. 
* * *
[كمل قرايه](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D9%85%D9%86%D9%88%D9%81%D9%8A%D9%87 "محافظة المنوفيه")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Egypt_-_Administrative_Divisions_-_Nmbrs_-_colored.png/250px-Egypt_-_Administrative_Divisions_-_Nmbrs_-_colored.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Egypt_-_Administrative_Divisions_-_Nmbrs_-_colored.png)
1. [مرسى مطروح](https://arz.wikipedia.org/wiki/%D9%85%D8%B1%D8%B3%D9%89_%D9%85%D8%B7%D8%B1%D9%88%D8%AD "مرسى مطروح") 2. [محافظة اسكندريه](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D8%B3%D9%83%D9%86%D8%AF%D8%B1%D9%8A%D9%87 "محافظة اسكندريه") 3. [محافظة البحيره](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D8%A8%D8%AD%D9%8A%D8%B1%D9%87 "محافظة البحيره") 4. [محافظة كفر الشيخ](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D9%83%D9%81%D8%B1_%D8%A7%D9%84%D8%B4%D9%8A%D8%AE "محافظة كفر الشيخ") 5. [محافظة الدقهليه](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D8%AF%D9%82%D9%87%D9%84%D9%8A%D9%87 "محافظة الدقهليه") 6. [دمياط](https://arz.wikipedia.org/wiki/%D8%AF%D9%85%D9%8A%D8%A7%D8%B7 "دمياط") 7. [محافظة بورسعيد](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A8%D9%88%D8%B1%D8%B3%D8%B9%D9%8A%D8%AF "محافظة بورسعيد") 8. [محافظة شمال سينا](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%B4%D9%85%D8%A7%D9%84_%D8%B3%D9%8A%D9%86%D8%A7 "محافظة شمال سينا") 9. [محافظة الغربيه](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D8%BA%D8%B1%D8%A8%D9%8A%D9%87 "محافظة الغربيه") 10. [محافظة المنوفيه](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D9%85%D9%86%D9%88%D9%81%D9%8A%D9%87 "محافظة المنوفيه") 11. [محافظة القليوبيه](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D9%82%D9%84%D9%8A%D9%88%D8%A8%D9%8A%D9%87 "محافظة القليوبيه") 12. [محافظة الشرقيه](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D8%B4%D8%B1%D9%82%D9%8A%D9%87 "محافظة الشرقيه") 13. [محافظة الاسماعيليه](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D8%A7%D8%B3%D9%85%D8%A7%D8%B9%D9%8A%D9%84%D9%8A%D9%87 "محافظة الاسماعيليه") 14. [الجيزه](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%AC%D9%8A%D8%B2%D9%87 "الجيزه") 15. [الفيوم](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%81%D9%8A%D9%88%D9%85 "الفيوم") 16. [القاهره](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%82%D8%A7%D9%87%D8%B1%D9%87 "القاهره") 17. [محافظة السويس](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D8%B3%D9%88%D9%8A%D8%B3 "محافظة السويس") 18. [محافظة جنوب سينا](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%AC%D9%86%D9%88%D8%A8_%D8%B3%D9%8A%D9%86%D8%A7 "محافظة جنوب سينا") 19. [محافظة بنى سويف](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A8%D9%86%D9%89_%D8%B3%D9%88%D9%8A%D9%81 "محافظة بنى سويف") 20. [محافظة المنيا](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D9%85%D9%86%D9%8A%D8%A7 "محافظة المنيا") 21. [محافظة الوادى الجديد](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D9%88%D8%A7%D8%AF%D9%89_%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF "محافظة الوادى الجديد") 22. [محافظة اسيوط](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D8%B3%D9%8A%D9%88%D8%B7 "محافظة اسيوط") 23. [محافظة البحر الأحمر](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D8%A8%D8%AD%D8%B1_%D8%A7%D9%84%D8%A3%D8%AD%D9%85%D8%B1 "محافظة البحر الأحمر") 24. [محافظة سوهاج](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%B3%D9%88%D9%87%D8%A7%D8%AC "محافظة سوهاج") 25. [محافظة قنا](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D9%82%D9%86%D8%A7 "محافظة قنا") 26. [محافظة الاقصر](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D9%84%D8%A7%D9%82%D8%B5%D8%B1 "محافظة الاقصر") 27. [محافظة اسوان](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9_%D8%A7%D8%B3%D9%88%D8%A7%D9%86 "محافظة اسوان")
* * *
[محافظات مصر](https://arz.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A7%D8%AA_%D9%85%D8%B5%D8%B1 "محافظات مصر")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Google_Calendar_icon_%282015-2020%29.svg/40px-Google_Calendar_icon_%282015-2020%29.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Google_Calendar_icon_\(2015-2020\).svg) **الاجازات الرسميه فى مصر**
**[عيد الميلاد المجيد](https://arz.wikipedia.org/wiki/%D8%B9%D9%8A%D8%AF_%D8%A7%D9%84%D9%85%D9%8A%D9%84%D8%A7%D8%AF "عيد الميلاد")** : [7 يناير](https://arz.wikipedia.org/wiki/7_%D9%8A%D9%86%D8%A7%D9%8A%D8%B1 "7 يناير") ● **[عيد الشرطه](https://arz.wikipedia.org/wiki/%D8%B9%D9%8A%D8%AF_%D8%A7%D9%84%D8%B4%D8%B1%D8%B7%D9%87 "عيد الشرطه")** و **[عيد ثورة 25 يناير](https://arz.wikipedia.org/wiki/25_%D9%8A%D9%86%D8%A7%D9%8A%D8%B1 "25 يناير")** ● **[راس السنه الهجريه](https://arz.wikipedia.org/wiki/%D8%B1%D8%A7%D8%B3_%D8%A7%D9%84%D8%B3%D9%86%D9%87_%D8%A7%D9%84%D9%87%D8%AC%D8%B1%D9%8A%D9%87 "راس السنه الهجريه")** : 1 [المحرم](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%85%D8%AD%D8%B1%D9%85_\(%D8%B4%D9%87%D8%B1\) "المحرم \(شهر\)") [بالتقويم الهجرى](https://arz.wikipedia.org/wiki/%D8%AA%D9%82%D9%88%D9%8A%D9%85_%D9%87%D8%AC%D8%B1%D9%89 "تقويم هجرى") ● **[المولد النبوى](https://arz.wikipedia.org/wiki/%D9%85%D9%88%D9%84%D8%AF_%D8%A7%D9%84%D9%86%D8%A8%D9%89 "مولد النبى")** : 12 [ربيع الاول](https://arz.wikipedia.org/wiki/%D8%B1%D8%A8%D9%8A%D8%B9_%D8%A7%D9%84%D8%A7%D9%88%D9%84 "ربيع الاول") [بالتقويم الهجرى](https://arz.wikipedia.org/wiki/%D8%AA%D9%82%D9%88%D9%8A%D9%85_%D9%87%D8%AC%D8%B1%D9%89 "تقويم هجرى") ● **عيد تحرير[طابا](https://arz.wikipedia.org/wiki/%D8%B7%D8%A7%D8%A8%D8%A7 "طابا")**: [19 مارس](https://arz.wikipedia.org/wiki/19_%D9%85%D8%A7%D8%B1%D8%B3 "19 مارس") ● **[عيد تحرير سيناء](https://arz.wikipedia.org/wiki/%D8%B0%D9%83%D8%B1%D9%89_%D8%AA%D8%AD%D8%B1%D9%8A%D8%B1_%D8%B3%D9%8A%D9%86%D8%A7%D8%A1 "ذكرى تحرير سيناء")** : [25 ابريل](https://arz.wikipedia.org/wiki/25_%D8%A7%D8%A8%D8%B1%D9%8A%D9%84 "25 ابريل") ● **[عيد العمال](https://arz.wikipedia.org/wiki/%D8%B9%D9%8A%D8%AF_%D8%A7%D9%84%D8%B9%D9%85%D8%A7%D9%84 "عيد العمال")** : [1 مايو](https://arz.wikipedia.org/wiki/1_%D9%85%D8%A7%D9%8A%D9%88 "1 مايو") ● **[شم النسيم](https://arz.wikipedia.org/wiki/%D8%B4%D9%85_%D8%A7%D9%84%D9%86%D8%B3%D9%8A%D9%85 "شم النسيم")** : 1 [برموده](https://arz.wikipedia.org/wiki/%D8%A8%D8%B1%D9%85%D9%88%D8%AF%D9%87 "برموده")[بالتقويم القبطى](https://arz.wikipedia.org/wiki/%D8%AA%D9%82%D9%88%D9%8A%D9%85_%D9%82%D8%A8%D8%B7%D9%89 "تقويم قبطى") ● **[ثورة 23 يوليه](https://arz.wikipedia.org/wiki/%D8%AB%D9%88%D8%B1%D8%A9_23_%D9%8A%D9%88%D9%84%D9%8A%D9%87 "ثورة 23 يوليه")** : [23 يوليه](https://arz.wikipedia.org/wiki/23_%D9%8A%D9%88%D9%84%D9%8A%D9%87 "23 يوليه") ● **[عيد القوات المسلحه](https://arz.wikipedia.org/wiki/%D8%B9%D9%8A%D8%AF_%D8%A7%D9%84%D9%82%D9%88%D8%A7%D8%AA_%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%AD%D9%87 "عيد القوات المسلحه")** : [6 اكتوبر](https://arz.wikipedia.org/wiki/6_%D8%A7%D9%83%D8%AA%D9%88%D8%A8%D8%B1 "6 اكتوبر") ● **[عيد الفطر](https://arz.wikipedia.org/wiki/%D8%B9%D9%8A%D8%AF_%D8%A7%D9%84%D9%81%D8%B7%D8%B1 "عيد الفطر")** : 1-2-3 [شوال](https://arz.wikipedia.org/wiki/%D8%B4%D9%87%D8%B1_%D8%B4%D9%88%D8%A7%D9%84 "شهر شوال") [بالتقويم الهجرى](https://arz.wikipedia.org/wiki/%D8%AA%D9%82%D9%88%D9%8A%D9%85_%D9%87%D8%AC%D8%B1%D9%89 "تقويم هجرى") ● **[الوقوف بعرفه](https://arz.wikipedia.org/wiki/%D9%8A%D9%88%D9%85_%D8%B9%D8%B1%D9%81%D9%87 "يوم عرفه")** : 9 [ذو الحجه](https://arz.wikipedia.org/wiki/%D8%B0%D9%88_%D8%A7%D9%84%D8%AD%D8%AC%D9%87 "ذو الحجه") [بالتقويم الهجرى](https://arz.wikipedia.org/wiki/%D8%AA%D9%82%D9%88%D9%8A%D9%85_%D9%87%D8%AC%D8%B1%D9%89 "تقويم هجرى") ● **[عيد الاضحى](https://arz.wikipedia.org/wiki/%D8%B9%D9%8A%D8%AF_%D8%A7%D9%84%D8%A7%D8%B6%D8%AD%D9%89 "عيد الاضحى")** : 10-12-13 [ذو الحجه](https://arz.wikipedia.org/wiki/%D8%B0%D9%88_%D8%A7%D9%84%D8%AD%D8%AC%D9%87 "ذو الحجه") [بالتقويم الهجرى](https://arz.wikipedia.org/wiki/%D8%AA%D9%82%D9%88%D9%8A%D9%85_%D9%87%D8%AC%D8%B1%D9%89 "تقويم هجرى")
* * *
[كل المناسبات](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%A7%D8%AC%D8%A7%D8%B2%D8%A7%D8%AA_%D8%A7%D9%84%D8%B1%D8%B3%D9%85%D9%8A%D9%87_%D9%81%D9%89_%D9%85%D8%B5%D8%B1 "الاجازات الرسميه فى مصر")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/HSWPedia.svg/40px-HSWPedia.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:HSWPedia.svg) النسخه دى من ويكيبيديا مكتوبه [بالمصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D9%87_%D8%A7%D9%84%D9%85%D8%B5%D8%B1%D9%8A%D9%87_%D8%A7%D9%84%D8%AD%D8%AF%D9%8A%D8%AB%D9%87 "اللغه المصريه الحديثه") و فيها [1,629,143](https://arz.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A7%D8%AD%D8%B5%D8%A7%D8%A6%D9%8A%D8%A7%D8%AA "خاص:احصائيات") مقاله دلوقتى, فيه كتير من نسخ ويكيبيديا بلغات تانيه و النسخ الأكبر هى: 
**أكتر من 6,000,000 مقاله**
  * [English](https://en.wikipedia.org/wiki/)
  * [Cebuano](https://ceb.wikipedia.org/wiki/)


**أكتر من 1,000,000 مقاله**
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87)
  * [العربية](https://ar.wikipedia.org/wiki/)
  * [Deutsch](https://de.wikipedia.org/wiki/)
  * [Español](https://es.wikipedia.org/wiki/)
  * [Français](https://fr.wikipedia.org/wiki/)
  * [Italiano](https://it.wikipedia.org/wiki/)
  * [Nederlands](https://nl.wikipedia.org/wiki/)
  * [日本語](https://ja.wikipedia.org/wiki/)
  * [Polski](https://pl.wikipedia.org/wiki/)
  * [Português](https://pt.wikipedia.org/wiki/)
  * [Русский](https://ru.wikipedia.org/wiki/)
  * [Svenska](https://sv.wikipedia.org/wiki/)
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/)
  * [中文](https://zh.wikipedia.org/wiki/)


**أكتر من 250,000 مقاله**
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/)
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/)
  * [Български](https://bg.wikipedia.org/wiki/)
  * [Català](https://ca.wikipedia.org/wiki/)
  * [Čeština](https://cs.wikipedia.org/wiki/)
  * [Dansk](https://da.wikipedia.org/wiki/)
  * [Esperanto](https://eo.wikipedia.org/wiki/)
  * [Euskara](https://eu.wikipedia.org/wiki/)
  * [فارسی](https://fa.wikipedia.org/wiki/)
  * [עברית](https://he.wikipedia.org/wiki/)
  * [한국어](https://ko.wikipedia.org/wiki/)
  * [Magyar](https://hu.wikipedia.org/wiki/)
  * [Norsk Bokmål](https://no.wikipedia.org/wiki/)
  * [Română](https://ro.wikipedia.org/wiki/)
  * [Srpski](https://sr.wikipedia.org/wiki/)
  * [Srpskohrvatski](https://sh.wikipedia.org/wiki/)
  * [Suomi](https://fi.wikipedia.org/wiki/)
  * [Türkçe](https://tr.wikipedia.org/wiki/)
  * [Українська](https://uk.wikipedia.org/wiki/)


**أكتر من 50,000 مقاله**
  * [Bosanski](https://bs.wikipedia.org/wiki/)
  * [Eesti](https://et.wikipedia.org/wiki/)
  * [Ελληνικά](https://el.wikipedia.org/wiki/)
  * [English (simple form)](https://simple.wikipedia.org/wiki/)
  * [Galego](https://gl.wikipedia.org/wiki/)
  * [Hrvatski](https://hr.wikipedia.org/wiki/)
  * [Latviešu](https://lv.wikipedia.org/wiki/)
  * [Lietuvių](https://lt.wikipedia.org/wiki/)
  * [മലയാളം](https://ml.wikipedia.org/wiki/)
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/)
  * [Slovenčina](https://sk.wikipedia.org/wiki/)
  * [Slovenščina](https://sl.wikipedia.org/wiki/)
  * [ไทย](https://th.wikipedia.org/wiki/)


**[شوف ليسته بكل ويكيهات ويكيميديا](https://meta.wikimedia.org/wiki/List_of_Wikipedias "meta:List of Wikipedias")**
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Wikimedia-logo-circle.svg/40px-Wikimedia-logo-circle.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikimedia-logo-circle.svg) [ويكيبيديا](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7_%D9%85%D8%B5%D8%B1%D9%89 "ويكيبيديا مصرى") معاها مشاريع تانيه معاونه اسمها المشاريع الشقيقه بتستضيفها و بتديرها [مؤسسه ويكيميديا](https://arz.wikipedia.org/wiki/%D9%85%D8%A4%D8%B3%D8%B3%D8%A9_%D9%88%D9%8A%D9%83%D9%8A%D9%85%D9%8A%D8%AF%D9%8A%D8%A7 "مؤسسة ويكيميديا") و اللى هى:      [![Wikipedia](https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Wikipedia-logo-v2.svg/40px-Wikipedia-logo-v2.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikipedia-logo-v2.svg "Wikipedia")
[**ويكيبيديا**](https://en.wikipedia.org/wiki/en: "w:en:")  
الموسوعة الحرة      [![ويكاموس](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wiktionary-logo.svg "ويكاموس")
[**ويكاموس**](https://arz.wiktionary.org/wiki/en: "wikt:en:")  
القاموس و المرادفات      [![ويكيمصدر](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikisource-logo.svg "ويكيمصدر")
[**ويكى مصدر**](https://arz.wikisource.org/wiki/mul: "s:mul:")  
مكتبة بمحتوى مجاني      [![ويكي اقتباس](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikiquote-logo.svg "ويكي اقتباس")
[**ويكي اقتباس**](https://arz.wikiquote.org/wiki/en: "q:en:")  
مجموعة من الاقتباسات      [![ويكي كتب](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikibooks-logo.svg "ويكي كتب")
[**ويكي كتب**](https://arz.wikibooks.org/wiki/en: "b:en:")  
كتب مدرسية مجانية و أدلة      [![ويكي أخبار](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikinews-logo.svg "ويكي أخبار")
[**ويكي نيوز**](https://arz.wikinews.org/wiki/en: "n:en:")  
أخبار مجانية      [![ويكي الجامعات](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/40px-Wikiversity_logo_2017.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikiversity_logo_2017.svg "ويكي الجامعات")
[**ويكي الجامعات**](https://beta.wikiversity.org/wiki/ "betawikiversity:")  
مواد و أنشطة تعليمية مجانية      [![ويكي الرحلات](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikivoyage-Logo-v3-icon.svg "ويكي الرحلات")
[**ويكي الرحلات**](https://arz.wikivoyage.org/wiki/en: "voy:en:")  
دليل السفر المجاني على الإنترنت      [![ويكي أنواع](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikispecies-logo.svg "ويكي أنواع")
[**Wikispecies**](https://species.wikimedia.org/wiki/ "species:")  
دليل الأنواع      [![ويكي بيانات](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikidata-logo.svg "ويكي بيانات")
[**Wikidata**](https://www.wikidata.org/wiki/ "d:")  
قاعدة المعرفة المجانية      [![ويكي كومنز](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Commons-logo.svg "ويكي كومنز")
[**ويكي كومنز**](https://commons.wikimedia.org/wiki/ "c:")  
مستودع الوسائط المشتركة      [![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://arz.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Wikimedia_Community_Logo.svg "Meta-Wiki")
[**Meta-Wiki**](https://meta.wikimedia.org/wiki/ "m:")  
تنسيق مشروع ويكيميديا 
اتجابت من "[https://arz.wikipedia.org/w/index.php?title=الصفحه_الرئيسيه&oldid=12248946](https://arz.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&oldid=12248946)"
[تصانيف](https://arz.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%AA%D8%B5%D8%A7%D9%86%D9%8A%D9%81 "خاص:تصانيف"): 
  * [تاريخ قبطى](https://arz.wikipedia.org/wiki/%D8%AA%D8%B5%D9%86%D9%8A%D9%81:%D8%AA%D8%A7%D8%B1%D9%8A%D8%AE_%D9%82%D8%A8%D8%B7%D9%89 "تصنيف:تاريخ قبطى")
  * [ويكيبيديا](https://arz.wikipedia.org/wiki/%D8%AA%D8%B5%D9%86%D9%8A%D9%81:%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7 "تصنيف:ويكيبيديا")
  * [الصفحه الرئيسيه](https://arz.wikipedia.org/wiki/%D8%AA%D8%B5%D9%86%D9%8A%D9%81:%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "تصنيف:الصفحه الرئيسيه")


353 لغات
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "ل Main Page – الأفارية")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "ل Ихадоу адаҟьа – الأبخازية")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "ل Ôn Keue – الأتشينيزية")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "ل НэкӀубгъо шъхьаӀ – الأديغة")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "ل Tuisblad – الأفريقانية")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "ل Wikipedia:Houptsyte – الألمانية السويسرية")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "ل Тӧс бӱк – الألطائية الجنوبية")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ل ዋናው ገጽ – الأمهرية")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "ل Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "ل Portalada – الأراغونية")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "ل Heafodtramet – الإنجليزية القديمة")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "ل Uwu – أوبلو")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "ل मुख्य पृष्ठ – الأنجيكا")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "ل الصفحة الرئيسة – العربية")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ل ܦܐܬܐ ܪܝܫܝܬܐ – الآرامية")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "ل الصفحة اللولا – Moroccan Arabic")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "ل বেটুপাত – الأسامية")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "ل Portada – الأسترية")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "ل Otitikowin – الأتيكاميكو")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "ل БетӀераб гьумер – الأوارية")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "ل Xadola – Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "ل प्रधान पन्ना – الأوادية")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "ل Nayriri uñstawi – الأيمارا")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "ل Ana səhifə – الأذربيجانية")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "ل آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "ل Баш бит – الباشكيرية")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "ل Kaca Utama – البالينية")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "ل Wikipedia:Hoamseitn – Bavarian")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "ل Pėrms poslapis – Samogitian")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "ل Pogu ni Alaman – Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "ل Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "ل Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "ل Галоўная старонка – البيلاروسية")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "ل Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "ل Balé-balé – Betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "ل Начална страница – البلغارية")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "ل मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "ل Nambawan Pej – البيسلامية")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "ل Laman Tatambaian – Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "ل အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "ل Nyɛ fɔlɔ – البامبارا")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "ل প্রধান পাতা – البنغالية")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "ل གཙོ་ངོས། – التبتية")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "ل পয়লা পাতা – Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "ل Degemer – البريتونية")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "ل Početna strana – البوسنية")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "ل Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "ل Watangpola – البجينيزية")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "ل Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "ل Portada – الكتالانية")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "ل El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "ل Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "ل Коьрта агӀо – الشيشانية")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "ل Unang Panid – السيبيوانية")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "ل Fanhaluman – التشامورو")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "ل Main Page – الشوكتو")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ل ᎤᎵᎮᎵᏍᏗ – الشيروكي")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "ل Va'ohtama – الشايان")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "ل دەستپێک – السورانية الكردية")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "ل Pagina maestra – الكورسيكية")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ل ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – الكرى")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "ل Baş Saife – لغة تتار القرم")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "ل Hlavní strana – التشيكية")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "ل Przédnô starna – الكاشبايان")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "ل Главьна страница – سلافية كنسية")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "ل Тĕп страница – التشوفاشي")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "ل Hafan – الويلزية")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "ل Forside – الدانمركية")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "ل Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "ل Wikipedia:Hauptseite – الألمانية")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "ل A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "ل Apam këdït – الدنكا")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "ل Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "ل Głowny bok – صوربيا السفلى")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "ل Natad Tagayo – Central Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "ل मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "ل މައި ޞަފްޙާ – المالديفية")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "ل མ་ཤོག། – دزونكا")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "ل Axa do Ŋgɔ – الإيوي")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "ل Πύλη:Κύρια – اليونانية")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "ل PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "ل Main Page – الإنجليزية")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "ل Vikipedio:Ĉefpaĝo – الإسبرانتو")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "ل Wikipedia:Portada – الإسبانية")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "ل Vikipeedia:Esileht – الإستونية")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "ل Azala – الباسكية")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "ل Portá antigua – Extremaduran")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "ل صفحهٔ اصلی – الفارسية")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "ل Kratafa Tsitsir – الفانتي")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "ل Hello jaɓɓorgo – الفولانية")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "ل Wikipedia:Etusivu – الفنلندية")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "ل Wikipedia:Pääleht – Võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "ل Tabana levu – الفيجية")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "ل Forsíða – الفاروية")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "ل Wémá Nukɔntɔn – الفون")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "ل Wikipédia:Accueil principal – الفرنسية")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "ل Vouiquipèdia:Reçua principâla – Arpitan")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "ل Wikipedia:Hoodsid – الفريزينية الشمالية")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "ل Pagjine principâl – الفريلايان")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "ل Haadside – الفريزيان")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "ل Príomhleathanach – الأيرلندية")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "ل Baş yaprak – الغاغوز")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "ل 封面 – الغان الصينية")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "ل Paj Prensipal – Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "ل Prìomh-Dhuilleag – الغيلية الأسكتلندية")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "ل Portada – الجاليكية")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "ل گتˇ ولگ – Gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "ل Kuatia Ñepyrũha – الغوارانية")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "ل मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "ل Halaman Bungaliyo – الجورونتالو")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "ل 𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – القوطية")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "ل Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "ل મુખપૃષ્ઠ – الغوجاراتية")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "ل Ee'iyalaaya a'laülaasü – Wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "ل Pɛgezure – Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "ل Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "ل Ard-ghuillag – المنكية")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "ل Babban shafi – الهوسا")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "ل Thèu-Ya̍p – الهاكا الصينية")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "ل Ka papa kinohi – لغة هاواي")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "ل עמוד ראשי – العبرية")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "ل मुखपृष्ठ – الهندية")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "ل Pahila Panna – Fiji Hindi")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "ل Main Page – الهيري موتو")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "ل Glavna stranica – الكرواتية")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "ل Hłowna strona – الصوربية العليا")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "ل Paj Prensipal – الكريولية الهايتية")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "ل Kezdőlap – الهنغارية")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "ل Գլխավոր էջ – الأرمنية")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "ل Գլխաւոր Էջ – Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "ل Main Page – الهيريرو")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "ل Pagina principal – اللّغة الوسيطة")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "ل Lambar Keterubah – الإيبان")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "ل Halaman Utama – الإندونيسية")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "ل Principal págine – الإنترلينج")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "ل Ihu m̀bụ – الإيجبو")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "ل Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "ل Aullaġniisaaġvik – الإينبياك")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "ل Umuna a Panid – الإيلوكو")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "ل Керттера оагӀув – الإنجوشية")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "ل Frontispico – الإيدو")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "ل Forsíða – الأيسلندية")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "ل Pagina principale – الإيطالية")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ل ᐊᒥᖅ – الإينكتيتت")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "ل メインページ – اليابانية")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "ل Mien Piej – Jamaican Creole English")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "ل uikipedi'as:ralju – اللوجبان")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "ل Wikipédia:Pendhapa – الجاوية")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "ل მთავარი გვერდი – الجورجية")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "ل Bas bet – الكارا-كالباك")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "ل Asebter agejdan – القبيلية")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "ل НапэкӀуэцӀ нэхъыщхьэ – الكاباردايان")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "ل Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "ل A̱tsak Wat Wu – التايابية")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "ل Mukânda ya ngudi – الكونغو")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "ل Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "ل Main Page – الكيكيو")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "ل Main Page – كوانياما")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "ل Басты бет – الكازاخستانية")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "ل Saqqaa – الكالاليست")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ل ទំព័រដើម – الخميرية")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ل ಮುಖ್ಯ ಪುಟ – الكانادا")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "ل Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "ل 위키백과:대문 – الكورية")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "ل Пондӧтчан листбок – كومي-بيرماياك")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "ل Main Page – الكانوري")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "ل Баш бет – الكاراتشاي-بالكار")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "ل اَہَم صَفہٕ – الكشميرية")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "ل Wikipedia:Houpsigk – لغة الكولونيان")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "ل Destpêk – الكردية")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "ل Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "ل Медшӧр лист бок – الكومي")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "ل Folen dre – الكورنية")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "ل Башкы барак – القيرغيزية")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "ل Vicipaedia:Pagina prima – اللاتينية")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "ل La Primera Oja – اللادينو")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "ل Haaptsäit – اللكسمبورغية")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "ل Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "ل Кьилин ччин – الليزجية")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "ل Paje xef – Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "ل Olupapula Olusooka – الغاندا")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "ل Veurblaad – الليمبورغية")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "ل Pagina prinçipâ – الليغورية")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "ل Plata prinzipala – Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "ل Pagina principala – اللومبردية")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "ل Lokásá ya libosó – اللينجالا")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ل ໜ້າຫຼັກ – اللاوية")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "ل سرآسونٱ – اللرية الشمالية")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "ل Pagrindinis puslapis – الليتوانية")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "ل Suoku puslopa – Latgalian")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "ل Sākumlapa – اللاتفية")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "ل Tanèyan – المادريز")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "ل सम्मुख पन्ना – المايثيلي")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "ل Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "ل Пря лопа – الموكشا")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "ل Wikipedia:Fandraisana – الملغاشي")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "ل Main Page – المارشالية")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "ل Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "ل Hau Kāinga – الماورية")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "ل Laman Utamo – المينانجكاباو")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "ل Главна страница – المقدونية")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "ل പ്രധാന താൾ – المالايالامية")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "ل Нүүр хуудас – المنغولية")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ل ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – المانيبورية")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "ل မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "ل Soraogo – الموسي")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "ل मुखपृष्ठ – الماراثية")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "ل Тӹнг ӹлӹштӓш – Western Mari")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "ل Laman Utama – الماليزية")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "ل Il-Paġna prinċipali – المالطية")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "ل Main Page – الكريك")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "ل Biquipédia:Páigina percipal – الميرانديز")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ل ဗဟိုစာမျက်နှာ – البورمية")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "ل Прявтлопа – الأرزية")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "ل گت صفحه – المازندرانية")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "ل Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "ل Paggena prencepale – النابولية")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "ل Wikipedia:Hööftsiet – الألمانية السفلى")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "ل Vöärblad – السكسونية السفلى")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "ل मुख्य पृष्ठ – النيبالية")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "ل मू पौ – النوارية")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "ل Hambili Tarkerazu – الندونجا")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "ل Wikipedia:Olayama – النياس")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "ل Hoofdpagina – الهولندية")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "ل Hovudside – النرويجية نينورسك")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "ل Forside – النرويجية بوكمال")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "ل Chefi pagine – Novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ل ߓߏ߬ߟߏ߲߬ߘߊ – أنكو")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "ل Main Page – النديبيل الجنوبي")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "ل Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "ل Letlakala la pele – السوتو الشمالية")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "ل Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "ل Íiyisíí Naaltsoos – النافاجو")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "ل Tsamba Lalikulu – النيانجا")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "ل Acuèlh – الأوكسيتانية")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "ل Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "ل Fuula Dura – الأورومية")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ل ପ୍ରଧାନ ପୃଷ୍ଠା – الأورية")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "ل Сæйраг фарс – الأوسيتيك")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ل ਮੁੱਖ ਸਫ਼ਾ – البنجابية")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "ل Arapan ya Bolong – البانجاسينان")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "ل Pun Bulung – البامبانجا")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "ل Página Prinsipal – البابيامينتو")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "ل Accueul – Picard")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "ل Main Pej – البدجنية النيجيرية")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "ل Haaptblatt – Pennsylvania German")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "ل Wikipedia:Haubdsaid – Palatine German")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "ل पमुख पत्त Pamukha patta – البالية")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "ل Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "ل Wikipedia:Strona główna – البولندية")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "ل Intrada – Piedmontese")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "ل پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "ل Αρχικόν σελίδα – Pontic")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "ل لومړی مخ – البشتو")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "ل Wikipédia:Página principal – البرتغالية")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "ل sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "ل Qhapaq p'anqa – كيشوا")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ل အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "ل Wikipedia:Pagina principala – الرومانشية")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "ل Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "ل Urupapuro nyamukuru – الرندي")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "ل Pagina principală – الرومانية")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "ل Prota frãndzã – الأرومانيان")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "ل Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "ل Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "ل Заглавная страница – الروسية")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "ل Головна сторінка – Rusyn")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "ل Intangiriro – الكينيارواندا")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "ل मुख्यपृष्ठम् – السنسكريتية")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "ل Сүрүн сирэй – الساخيّة")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ل ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – السانتالية")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "ل Pàgina printzipale – السردينية")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "ل Pàggina principali – الصقلية")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "ل Main Page – الأسكتلندية")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "ل مُک صفحو – السندية")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "ل Portála:Ovdasiidu – سامي الشمالية")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "ل Gä nzönî – السانجو")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "ل Glavna stranica – صربية-كرواتية")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "ل Tasna Tamzwarut – تشلحيت")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ل ၼႃႈႁူဝ်ႁႅၵ်ႈ – الشان")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "ل මුල් පිටුව – السنهالية")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "ل Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "ل Hlavná stránka – السلوفاكية")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "ل پہلا پرت – Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "ل Glavna stran – السلوفانية")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "ل Itūlau Muamua – الساموائية")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "ل Ovdâsijđo – الإيناري سامي")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "ل Peji Rekutanga – الشونا")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "ل Bogga Hore – الصومالية")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "ل Faqja kryesore – الألبانية")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "ل Главна страна – الصربية")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "ل Fesipapira – السرانان تونجو")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "ل Likhasi Lelikhulu – السواتي")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "ل Leqephe la pele – السوتو الجنوبية")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "ل Haudsiede – Saterland Frisian")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "ل Tepas – السوندانية")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "ل Portal:Huvudsida – السويدية")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "ل Mwanzo – السواحلية")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ل ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "ل Przodniŏ zajta – السيليزية")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "ل saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "ل முதற் பக்கம் – التاميلية")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "ل T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ل ಮುಖ್ಯ ಪುಟ – Tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ل ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "ل మొదటి పేజీ – التيلوغوية")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "ل Pájina Mahuluk – التيتم")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "ل Саҳифаи аслӣ – الطاجيكية")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "ل หน้าหลัก – التايلاندية")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "ل መበገሲ ገጽ – التغرينية")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "ل አግዳ ገጽ – التيغرية")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "ل Baş Sahypa – التركمانية")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "ل Unang Pahina – التاغالوغية")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "ل Sərlovhə – Talysh")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "ل Tsebe ya konokono – التسوانية")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "ل Peesi tali fiefia – التونغية")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "ل Fran pes – التوك بيسين")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "ل Anasayfa – التركية")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "ل Ruwahan patas – لغة التاروكو")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "ل Tlukankulu – السونجا")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "ل Баш бит – التترية")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "ل Jani likulu – التامبوكا")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "ل Kratafa Titiriw – التوي")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "ل Fa’ari’ira’a – التاهيتية")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "ل Кол арын – التوفية")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "ل Кутскон бам – الأدمرت")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "ل باش بەت – الأويغورية")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "ل Головна сторінка – الأوكرانية")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "ل صفحۂ اول – الأوردية")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "ل Bosh Sahifa – الأوزبكية")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "ل Hayani – الفيندا")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "ل Wikipedia:Prinsipio – البندقية")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "ل Pälehtpol’ – Veps")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "ل Trang Chính – الفيتنامية")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "ل Voorblad – West Flemish")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "ل Cifapad – لغة الفولابوك")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "ل Mwaisse pådje – الولونية")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "ل Syahan nga Pakli – الواراي")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "ل Xët wu njëkk – الولوفية")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "ل 封面 – الوو الصينية")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "ل Нүр халх – الكالميك")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "ل Iphepha Elingundoqo – الخوسا")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "ل დუდხასჷლა – Mingrelian")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "ل הויפט זייט – اليديشية")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "ل Ojúewé Àkọ́kọ́ – اليوروبا")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "ل Yiebdaeuz – الزهيونج")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "ل Vòblad – Zeelandic")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ل ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – التمازيغية المغربية القياسية")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "ل Wikipedia:首页 – الصينية")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "ل 維基大典:卷首 – Literary Chinese")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "ل Thâu-ia̍h – مين-نان الصينية")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "ل 頭版 – الكَنْتُونية")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "ل Ikhasi Elikhulu – الزولو")


[عدل الوصلات](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "تعديل الروابط ما بين اللغات")
  * الصفحه دى اتعدلت اخر مره فى 21 اغسطس 2025,‏ 22:37.
  * النصوص متوفرة تحت [رخصة التشارك الإبداع العزو/المشاركة بالمثل](https://creativecommons.org/licenses/by-sa/4.0/); ممكن تطبيق شروط إضافية. بص على [شروط الاستخدام](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use) للتفاصيل.


  * [بوليسة الخصوصيه](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy/ar)
  * [عن ويكيبيديا](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%85%D8%B9%D9%84%D9%88%D9%85%D8%A7%D8%AA_%D8%B9%D9%86)
  * [تنازل عن مسئوليه](https://arz.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AA%D9%86%D8%A7%D8%B2%D9%84_%D8%B9%D9%86_%D9%85%D8%B3%D8%A6%D9%88%D9%84%D9%8A%D9%87_%D8%B9%D9%85%D9%88%D9%85%D9%89)
  * [القواعد السلوكية](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [مطورين](https://developer.wikimedia.org)
  * [احصائيات](https://stats.wikimedia.org/#/arz.wikipedia.org)
  * [بيان الكوكيز](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [نسخة المحمول](https://arz.m.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87&mobileaction=toggle_view_mobile)
  * [عدِّل إعدادت المعاينة](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87)


  * [![Wikimedia Foundation](https://arz.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://arz.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


تدوير
تدوير
الصفحه الرئيسيه
[](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87) [](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87) [](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87) [](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87) [](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87) [](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87) [](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87) [](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87)
353 لغات [ضيف موضوع ](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87)
[](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87?action=edit)
