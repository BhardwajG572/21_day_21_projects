[Məzmuna keç](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99#bodyContent)
Əsas menyu
Əsas menyu
yan panelə köçür gizlə
Naviqasiya 
  * [Ana səhifə](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifəni ziyarət edin \[z\]")
  * [Kənd meydanı](https://az.wikipedia.org/wiki/Vikipediya:K%C9%99nd_meydan%C4%B1 "Layihə haqqında, nələr edəbilərsiniz, axtardıqlarınızı harda tapmaq olar")
  * [İcma portalı](https://az.wikipedia.org/wiki/Vikipediya:%C4%B0cma_portal%C4%B1 "Gündəlik xəbərlər ilə əlaqəli məlumatlar")
  * [Son dəyişikliklər](https://az.wikipedia.org/wiki/X%C3%BCsusi:SonD%C9%99yi%C5%9Fiklikl%C9%99r "Vikidəki son dəyişikliklər siyahısı \[r\]")
  * [Təsadüfi məqalə](https://az.wikipedia.org/wiki/X%C3%BCsusi:T%C9%99sad%C3%BCfi "Təsadüfi məqaləyə keç \[x\]")
  * [Xüsusi səhifələr](https://az.wikipedia.org/wiki/X%C3%BCsusi:X%C3%BCsusiS%C9%99hif%C9%99l%C9%99r)


Layihələr 
  * [Seçilmiş məqalələr](https://az.wikipedia.org/wiki/Vikipediya:Se%C3%A7ilmi%C5%9F_m%C9%99qal%C9%99l%C9%99r)
  * [Seçilmiş siyahılar](https://az.wikipedia.org/wiki/Vikipediya:Se%C3%A7ilmi%C5%9F_siyah%C4%B1lar)
  * [Yaxşı məqalələr](https://az.wikipedia.org/wiki/Vikipediya:Yax%C5%9F%C4%B1_m%C9%99qal%C9%99l%C9%99r)
  * [Məqalə namizədləri](https://az.wikipedia.org/wiki/Vikipediya:M%C9%99qal%C9%99_namiz%C9%99dl%C9%99ri)
  * [Mövzulu ay](https://az.wikipedia.org/wiki/Vikipediya:M%C3%B6vzulu_ay)


Xüsusi 
  * [Bizimlə əlaqə](https://az.wikipedia.org/wiki/Vikipediya:Biziml%C9%99_%C9%99laq%C9%99)
  * [Kömək](https://az.wikipedia.org/wiki/K%C3%B6m%C9%99k:M%C3%BCnd%C9%99ricat "Yardım almaq üçün.")


[ ![](https://az.wikipedia.org/static/images/icons/wikipedia.png) ![Vikipediya](https://az.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-az.svg) ![](https://az.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-az.svg) ](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99)
[Axtar ](https://az.wikipedia.org/wiki/X%C3%BCsusi:Axtar "Vikipediyada axtar \[f\]")
Axtar
Görünüş
  * [İanə et](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=az.wikipedia.org&uselang=az)
  * [Hesab yarat](https://az.wikipedia.org/w/index.php?title=X%C3%BCsusi:HesabYarat&returnto=Ana+s%C9%99hif%C9%99 "Hesab yaratmaq və daxil olmaq üçün təşviq olunursunuz; Ancaq məcburi deyil")
  * [Daxil ol](https://az.wikipedia.org/w/index.php?title=X%C3%BCsusi:DaxilOl&returnto=Ana+s%C9%99hif%C9%99 "Daxil olmanız tövsiyə olunur, amma bu məcburi tələb deyil. \[o\]")


Şəxsi alətlər
  * [İanə et](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=az.wikipedia.org&uselang=az)
  * [Hesab yarat](https://az.wikipedia.org/w/index.php?title=X%C3%BCsusi:HesabYarat&returnto=Ana+s%C9%99hif%C9%99 "Hesab yaratmaq və daxil olmaq üçün təşviq olunursunuz; Ancaq məcburi deyil")
  * [Daxil ol](https://az.wikipedia.org/w/index.php?title=X%C3%BCsusi:DaxilOl&returnto=Ana+s%C9%99hif%C9%99 "Daxil olmanız tövsiyə olunur, amma bu məcburi tələb deyil. \[o\]")


# Ana səhifə
  * [Ana səhifə](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Məqalənin məzmununu göstər \[c\]")
  * [Müzakirə](https://az.wikipedia.org/wiki/M%C3%BCzakir%C9%99:Ana_s%C9%99hif%C9%99 "Səhifə barədə müzakirə \[t\]")


azərbaycanca
  * [Oxu](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99)
  * [Vikimətnə bax](https://az.wikipedia.org/w/index.php?title=Ana_s%C9%99hif%C9%99&action=edit "Bu səhifə dəyişikliklərdən mühafizə olunur. Amma siz onun mətninə baxa və mətnin surətini köçürə bilərsiniz. \[e\]")
  * [Tarixçəyə bax](https://az.wikipedia.org/w/index.php?title=Ana_s%C9%99hif%C9%99&action=history "Bu səhifənin keçmiş nüsxələri. \[h\]")


Alətlər
Alətlər
yan panelə köçür gizlə
Fəaliyyətlər 
  * [Oxu](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99)
  * [Vikimətnə bax](https://az.wikipedia.org/w/index.php?title=Ana_s%C9%99hif%C9%99&action=edit)
  * [Tarixçəyə bax](https://az.wikipedia.org/w/index.php?title=Ana_s%C9%99hif%C9%99&action=history)


Ümumi 
  * [Səhifəyə keçidlər](https://az.wikipedia.org/wiki/X%C3%BCsusi:S%C9%99hif%C9%99y%C9%99Ke%C3%A7idl%C9%99r/Ana_s%C9%99hif%C9%99 "Vikidə bu məqaləyə bağlantılar \[j\]")
  * [Əlaqəli redaktələr](https://az.wikipedia.org/wiki/X%C3%BCsusi:%C6%8Flaq%C9%99liD%C9%99yi%C5%9Fiklikl%C9%99r/Ana_s%C9%99hif%C9%99 "Bu məqaləyə aid başqa səhifələrdə yeni dəyişikliklər \[k\]")
  * [Fayl yüklə](https://az.wikipedia.org/wiki/Vikipediya:Y%C3%BCkl%C9%99m%C9%99_sehrbaz%C4%B1 "Yeni şəkil və ya multimedia faylı yüklə \[u\]")
  * [Daimi keçid](https://az.wikipedia.org/w/index.php?title=Ana_s%C9%99hif%C9%99&oldid=7990926 "Bu səhifənin bu versiyasına daimi keçid")
  * [Səhifə məlumatları](https://az.wikipedia.org/w/index.php?title=Ana_s%C9%99hif%C9%99&action=info "Bu səhifə haqqında ətraflı məlumat")
  * [Bu səhifəyə istinad et](https://az.wikipedia.org/w/index.php?title=X%C3%BCsusi:CiteThisPage&page=Ana_s%C9%99hif%C9%99&id=7990926&wpFormIdentifier=titleform "Bu səhifəyə necə istinad etmək barədə məlumat")
  * [Qısaldılmış URL əldə et](https://az.wikipedia.org/w/index.php?title=X%C3%BCsusi:UrlQ%C4%B1sald%C4%B1c%C4%B1s%C4%B1&url=https%3A%2F%2Faz.wikipedia.org%2Fwiki%2FAna_s%25C9%2599hif%25C9%2599)
  * [QR-kodu endir](https://az.wikipedia.org/w/index.php?title=X%C3%BCsusi:QrKodu&url=https%3A%2F%2Faz.wikipedia.org%2Fwiki%2FAna_s%25C9%2599hif%25C9%2599)


Çap et/ixrac 
  * [Kitab yarat](https://az.wikipedia.org/w/index.php?title=X%C3%BCsusi:Book&bookcmd=book_creator&referer=Ana+s%C9%99hif%C9%99)
  * [PDF kimi yüklə](https://az.wikipedia.org/w/index.php?title=X%C3%BCsusi:PdfOlaraqY%C3%BCkl%C9%99&page=Ana_s%C9%99hif%C9%99&action=show-download-screen)
  * [Çap versiyası](https://az.wikipedia.org/w/index.php?title=Ana_s%C9%99hif%C9%99&printable=yes "Səhifənin çap versiyası \[p\]")


Digər layihələrdə 
  * [Vikianbar](https://commons.wikimedia.org/wiki/Main_Page)
  * [Vikimedia Fondu](https://foundation.wikimedia.org/wiki/Home)
  * [MediaViki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Viki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Vikimedia Maarifləndirmə](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Çoxdilli Vikimənbə](https://wikisource.org/wiki/Main_Page)
  * [Vikinövlər](https://species.wikimedia.org/wiki/Main_Page)
  * [Vikikitab](https://az.wikibooks.org/wiki/Ana_s%C9%99hif%C9%99)
  * [Vikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Vikifunksiyalar](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Vikisitat](https://az.wikiquote.org/wiki/Ana_s%C9%99hif%C9%99)
  * [Vikimənbə](https://az.wikisource.org/wiki/Ana_s%C9%99hif%C9%99)
  * [Vikilüğət](https://az.wiktionary.org/wiki/Ana_s%C9%99hif%C9%99)
  * [Vikidata elementi](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Bağlanan məlumatların saxlanması elementinə keçid \[g\]")


Görünüş
yan panelə köçür gizlə
Vikipediya, azad ensiklopediya
[Hər kəsin](https://az.wikipedia.org/wiki/Vikipediya:Vikipediyan%C4%B1_kiml%C9%99r_yaz%C4%B1r%3F "Vikipediya:Vikipediyanı kimlər yazır?") redaktə edə biləcəyi azad [ensiklopediya](https://az.wikipedia.org/wiki/Ensiklopediya "Ensiklopediya") olan 
#  [Vikipediyaya](https://az.wikipedia.org/wiki/Vikipediya "Vikipediya") xoş gəlmisiniz!
[207.861 məqalə arasında axtar](https://az.wikipedia.org/wiki/X%C3%BCsusi:Axtar "Xüsusi:Axtar")
Hal-hazırda [Azərbaycanca](https://az.wikipedia.org/wiki/Az%C9%99rbaycan_dili "Azərbaycan dili") [Vikipediyada](https://az.wikipedia.org/wiki/Az%C9%99rbaycanca_Vikipediya "Azərbaycanca Vikipediya") [207.861](https://az.wikipedia.org/wiki/X%C3%BCsusi:Statistika "Xüsusi:Statistika") məqalə mövcuddur.
  * [Məqalə yarat](https://az.wikipedia.org/wiki/Vikipediya:M%C9%99qal%C9%99_sehrbaz%C4%B1 "Vikipediya:Məqalə sehrbazı")
  * [Mündəricat](https://az.wikipedia.org/wiki/K%C3%B6m%C9%99k:M%C3%BCnd%C9%99ricat "Kömək:Mündəricat")
  * [Kömək istə](https://az.wikipedia.org/wiki/Vikipediya:Yard%C4%B1m_masas%C4%B1 "Vikipediya:Yardım masası")
  * [Cəsur ol!](https://az.wikipedia.org/wiki/Vikipediya:C%C9%99sur_ol "Vikipediya:Cəsur ol")


[![Seçilmiş məqalələrə bax](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/HSUtvald.svg/40px-HSUtvald.svg.png)](https://az.wikipedia.org/wiki/Vikipediya:Se%C3%A7ilmi%C5%9F_m%C9%99qal%C9%99l%C9%99r "Seçilmiş məqalələrə bax")
Həftənin seçilmiş məqaləsi
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Japan_on_the_globe_%28de-facto%29_%28Japan_centered%29.svg/250px-Japan_on_the_globe_%28de-facto%29_%28Japan_centered%29.svg.png)](https://az.wikipedia.org/wiki/Fayl:Japan_on_the_globe_\(de-facto\)_\(Japan_centered\).svg) **[Yaponiya](https://az.wikipedia.org/wiki/Yaponiya "Yaponiya")** — [Şərqi Asiyada](https://az.wikipedia.org/wiki/%C5%9E%C9%99rqi_Asiya "Şərqi Asiya") yerləşən ada ölkəsi. Yaponiya [Sakit okeanda](https://az.wikipedia.org/wiki/Sakit_okean "Sakit okean"), [Yapon dənizinin](https://az.wikipedia.org/wiki/Yapon_d%C9%99nizi "Yapon dənizi"), [Şərqi Çin dənizinin](https://az.wikipedia.org/wiki/%C5%9E%C9%99rqi_%C3%87in_d%C9%99nizi "Şərqi Çin dənizi"), [Çinin](https://az.wikipedia.org/wiki/%C3%87in "Çin"), [Şimali Koreyanın](https://az.wikipedia.org/wiki/%C5%9Eimali_Koreya "Şimali Koreya"), [Cənubi Koreyanın](https://az.wikipedia.org/wiki/C%C9%99nubi_Koreya "Cənubi Koreya") və [Rusiyanın](https://az.wikipedia.org/wiki/Rusiya "Rusiya") şərqində yerləşir, şimalda [Oxot dənizinə](https://az.wikipedia.org/wiki/Oxot_d%C9%99nizi "Oxot dənizi"), cənubda [Şərqi Çin dənizi](https://az.wikipedia.org/wiki/%C5%9E%C9%99rqi_%C3%87in_d%C9%99nizi "Şərqi Çin dənizi") və [Tayvan](https://az.wikipedia.org/wiki/Tayvan "Tayvan") adasına qədər uzanır. "Yaponiya" adının _"günəş"_ mənası [kanci](https://az.wikipedia.org/wiki/Kanci "Kanci") ilə bağlıdır və Yaponiya tez-tez _"Gündoğan ölkə"_ adı ilə çağırılır. Yaponiya 14.125 adadan ibarət [stratovulkanik](https://az.wikipedia.org/wiki/Stratovulkan "Stratovulkan") [arxipelaqdır](https://az.wikipedia.org/wiki/Arxipelaq "Arxipelaq"). Yaponiyanın ən böyük dörd adası — [Honşu](https://az.wikipedia.org/wiki/Hon%C5%9Fu "Honşu"), [Hokkaydo](https://az.wikipedia.org/wiki/Hokkaydo_\(ada\) "Hokkaydo \(ada\)"), [Kyuşu](https://az.wikipedia.org/wiki/Kyu%C5%9Fu_\(ada\) "Kyuşu \(ada\)") və [Şikoku adası](https://az.wikipedia.org/wiki/%C5%9Eikoku_\(ada\) "Şikoku \(ada\)") ölkə ərazisinin təxminən 97 %-ni əhatə edir. ([**Davamı...**](https://az.wikipedia.org/wiki/Yaponiya "Yaponiya"))   
---  
([bax](https://az.wikipedia.org/wiki/Vikipediya:H%C9%99ft%C9%99nin_se%C3%A7ilmi%C5%9F_m%C9%99qal%C9%99si/39._H%C9%99ft%C9%99_2025 "Vikipediya:Həftənin seçilmiş məqaləsi/39. Həftə 2025") • [redaktə](https://az.wikipedia.org/wiki/X%C3%BCsusi:EditPage/Vikipediya:H%C9%99ft%C9%99nin_se%C3%A7ilmi%C5%9F_m%C9%99qal%C9%99si/39._H%C9%99ft%C9%99_2025 "Xüsusi:EditPage/Vikipediya:Həftənin seçilmiş məqaləsi/39. Həftə 2025") • [tarixçə](https://az.wikipedia.org/w/index.php?title=Vikipediya:H%C9%99ft%C9%99nin_se%C3%A7ilmi%C5%9F_m%C9%99qal%C9%99si/39._H%C9%99ft%C9%99_2025&action=history))
  * **[Arxiv](https://az.wikipedia.org/wiki/Vikipediya:H%C9%99ft%C9%99nin_se%C3%A7ilmi%C5%9F_m%C9%99qal%C9%99si/oktyabr_2025 "Vikipediya:Həftənin seçilmiş məqaləsi/oktyabr 2025")**
  * **[Digər seçilmiş məqalələr...](https://az.wikipedia.org/wiki/Vikipediya:Se%C3%A7ilmi%C5%9F_m%C9%99qal%C9%99l%C9%99r "Vikipediya:Seçilmiş məqalələr")**


[![Yaxşı məqalələrə bax](https://upload.wikimedia.org/wikipedia/commons/thumb/1/13/HS_VdQ.svg/40px-HS_VdQ.svg.png)](https://az.wikipedia.org/wiki/Vikipediya:Yax%C5%9F%C4%B1_m%C9%99qal%C9%99l%C9%99r "Yaxşı məqalələrə bax")
Həftənin yaxşı məqaləsi
**[Süleyman bəy Zülqədər](https://az.wikipedia.org/wiki/S%C3%BCleyman_b%C9%99y_Z%C3%BClq%C9%99d%C9%99r "Süleyman bəy Zülqədər")** (ö. 1454) — 1442-ci ildən vəfatına qədər [Anadolunun](https://az.wikipedia.org/wiki/Ki%C3%A7ik_Asiya "Kiçik Asiya") cənubunda yerləşən [Zülqədəroğulları bəyliyinin](https://az.wikipedia.org/wiki/Z%C3%BClq%C9%99d%C9%99ro%C4%9Fullar%C4%B1_b%C9%99yliyi "Zülqədəroğulları bəyliyi") altıncı hökmdarı. O, atası [Nasirəddin Məhəmməd bəyin](https://az.wikipedia.org/wiki/Nasir%C9%99ddin_M%C9%99h%C9%99mm%C9%99d_b%C9%99y_Z%C3%BClq%C9%99d%C9%99r "Nasirəddin Məhəmməd bəy Zülqədər") (hökmdarlığı: 1399–1442) dövründə [Kayseri](https://az.wikipedia.org/wiki/Kayseri "Kayseri") valisi kimi xidmət etmişdir. Süleyman bəyin hakimiyyəti nisbətən sakit keçmişdir. Onun hakimiyyəti dövründə əldə etdiyi ən böyük nailiyyəti öz qızlarının Zülqədəroğulları bəyliyinin aralarında bufer zona kimi rol oynadığı iki böyük gücün hökmdarları – Osmanlı sultanı [II Mehmed](https://az.wikipedia.org/wiki/II_Mehmed "II Mehmed") (hökmdarlığı: 1444–1446, 1451–1481) və [Məmlük sultanı](https://az.wikipedia.org/wiki/M%C9%99ml%C3%BCk_sultanlar%C4%B1n%C4%B1n_siyah%C4%B1s%C4%B1 "Məmlük sultanlarının siyahısı") [Seyfəddin Çaxmaq](https://az.wikipedia.org/wiki/Seyf%C9%99ddin_%C3%87axmaq "Seyfəddin Çaxmaq") (hökmdarlığı: 1438–1453) ilə siyasi evliliklərini təşkil etməsi olmuşdur. Hakimiyyətinin sonlarına yaxın Süleyman bəy [Ağqoyunluların](https://az.wikipedia.org/wiki/A%C4%9Fqoyunlular "Ağqoyunlular") daxili mübarizəsinə qarışmış, bu münaqişədən sonra [Bayandurlar sülaləsinin](https://az.wikipedia.org/wiki/Bayandurlar_s%C3%BClal%C9%99si "Bayandurlar sülaləsi") bəzi üzvləri onun himayəsinə sığınmışdır. 
([**Davamı...**](https://az.wikipedia.org/wiki/S%C3%BCleyman_b%C9%99y_Z%C3%BClq%C9%99d%C9%99r "Süleyman bəy Zülqədər")) 
([bax](https://az.wikipedia.org/wiki/Vikipediya:H%C9%99ft%C9%99nin_yax%C5%9F%C4%B1_m%C9%99qal%C9%99si/39._H%C9%99ft%C9%99_2025 "Vikipediya:Həftənin yaxşı məqaləsi/39. Həftə 2025") • [redaktə](https://az.wikipedia.org/wiki/X%C3%BCsusi:EditPage/Vikipediya:H%C9%99ft%C9%99nin_yax%C5%9F%C4%B1_m%C9%99qal%C9%99si/39._H%C9%99ft%C9%99_2025 "Xüsusi:EditPage/Vikipediya:Həftənin yaxşı məqaləsi/39. Həftə 2025") • [tarixçə](https://az.wikipedia.org/w/index.php?title=Vikipediya:H%C9%99ft%C9%99nin_yax%C5%9F%C4%B1_m%C9%99qal%C9%99si/39._H%C9%99ft%C9%99_2025&action=history))
  * **[Arxiv](https://az.wikipedia.org/wiki/Vikipediya:H%C9%99ft%C9%99nin_yax%C5%9F%C4%B1_m%C9%99qal%C9%99si/oktyabr_2025 "Vikipediya:Həftənin yaxşı məqaləsi/oktyabr 2025")**
  * **[Digər yaxşı məqalələr...](https://az.wikipedia.org/wiki/Vikipediya:Yax%C5%9F%C4%B1_m%C9%99qal%C9%99l%C9%99r "Vikipediya:Yaxşı məqalələr")**


[![Seçilmiş siyahılara bax](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/HS_Liste.svg/40px-HS_Liste.svg.png)](https://az.wikipedia.org/wiki/Vikipediya:Se%C3%A7ilmi%C5%9F_siyah%C4%B1lar "Seçilmiş siyahılara bax")
Həftənin seçilmiş siyahısı
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/Official_portrait_of_Keir_Starmer_crop_2.jpg/250px-Official_portrait_of_Keir_Starmer_crop_2.jpg)](https://az.wikipedia.org/wiki/Fayl:Official_portrait_of_Keir_Starmer_crop_2.jpg) **[Böyük Britaniyanın baş nazirlərinin siyahısı](https://az.wikipedia.org/wiki/B%C3%B6y%C3%BCk_Britaniyan%C4%B1n_ba%C5%9F_nazirl%C9%99rinin_siyah%C4%B1s%C4%B1 "Böyük Britaniyanın baş nazirlərinin siyahısı")** — [Böyük Britaniya və Şimali İrlandiya Birləşmiş Krallığının](https://az.wikipedia.org/wiki/Birl%C9%99%C5%9Fmi%C5%9F_Krall%C4%B1q "Birləşmiş Krallıq") [Baş naziri](https://az.wikipedia.org/wiki/Ba%C5%9F_nazir "Baş nazir"), nominal olaraq [dövlət başçısı](https://az.wikipedia.org/wiki/D%C3%B6vl%C9%99t_ba%C5%9F%C3%A7%C4%B1s%C4%B1 "Dövlət başçısı") [Britaniya monarxı](https://az.wikipedia.org/wiki/Britaniya_monarxlar%C4%B1n%C4%B1n_siyah%C4%B1s%C4%B1 "Britaniya monarxlarının siyahısı") tərəfindən təyin edilən hökumət başçısıdır və bir çox [icraedici](https://az.wikipedia.org/wiki/%C4%B0craedici_hakimiyy%C9%99t "İcraedici hakimiyyət") funksiyaları icra edir. [XVIII əsrdə](https://az.wikipedia.org/wiki/XVIII_%C9%99sr "XVIII əsr") meydana gələn Nazirlər kabinetindən ibarət olan hakimiyyətin başçısı "Baş nazir" (bəzən "Birinci nazir") adlanırdı; bu günə qədər də Baş nazir həmişə nazirliklərdən birinin yerini tutmuşdur (adətən xəzinənin birinci lordu). ([**Davamı...**](https://az.wikipedia.org/wiki/B%C3%B6y%C3%BCk_Britaniyan%C4%B1n_ba%C5%9F_nazirl%C9%99rinin_siyah%C4%B1s%C4%B1 "Böyük Britaniyanın baş nazirlərinin siyahısı"))   
---  
([bax](https://az.wikipedia.org/wiki/Vikipediya:H%C9%99ft%C9%99nin_se%C3%A7ilmi%C5%9F_siyah%C4%B1s%C4%B1/39._H%C9%99ft%C9%99_2025 "Vikipediya:Həftənin seçilmiş siyahısı/39. Həftə 2025") • [redaktə](https://az.wikipedia.org/wiki/X%C3%BCsusi:EditPage/Vikipediya:H%C9%99ft%C9%99nin_se%C3%A7ilmi%C5%9F_siyah%C4%B1s%C4%B1/39._H%C9%99ft%C9%99_2025 "Xüsusi:EditPage/Vikipediya:Həftənin seçilmiş siyahısı/39. Həftə 2025") • [tarixçə](https://az.wikipedia.org/w/index.php?title=Vikipediya:H%C9%99ft%C9%99nin_se%C3%A7ilmi%C5%9F_siyah%C4%B1s%C4%B1/39._H%C9%99ft%C9%99_2025&action=history))
  * **[Arxiv](https://az.wikipedia.org/wiki/Vikipediya:H%C9%99ft%C9%99nin_se%C3%A7ilmi%C5%9F_siyah%C4%B1s%C4%B1/oktyabr_2025 "Vikipediya:Həftənin seçilmiş siyahısı/oktyabr 2025")**
  * **[Digər seçilmiş siyahılar...](https://az.wikipedia.org/wiki/Vikipediya:Se%C3%A7ilmi%C5%9F_siyah%C4%B1lar "Vikipediya:Seçilmiş siyahılar")**


[![Günün seçilmiş şəkli](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/HSCommons.svg/40px-HSCommons.svg.png)](https://commons.wikimedia.org/wiki/Commons:Picture_of_the_day "Günün seçilmiş şəkli")
Günün seçilmiş şəkli
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Yellowstone_National_Park_%28WY%2C_USA%29%2C_Grand_Prismatic_Spring_--_2022_--_2519.jpg/330px-Yellowstone_National_Park_%28WY%2C_USA%29%2C_Grand_Prismatic_Spring_--_2022_--_2519.jpg)](https://az.wikipedia.org/wiki/Fayl:Yellowstone_National_Park_\(WY,_USA\),_Grand_Prismatic_Spring_--_2022_--_2519.jpg)  
---  
  

  * **[Arxiv](https://az.wikipedia.org/wiki/%C5%9Eablon:Ana_s%C9%99hif%C9%99/Se%C3%A7ilmi%C5%9F_%C5%9F%C9%99kil/Arxiv "Şablon:Ana səhifə/Seçilmiş şəkil/Arxiv")**


![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/PL_Wiki_Aktualnosci_ikona.svg/34px-PL_Wiki_Aktualnosci_ikona.svg.png)
Xəbərlər
[![Ceyn Qudoll 2010-cu ildə](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Jane_Goodall_2010_%28cropped%29.jpg/120px-Jane_Goodall_2010_%28cropped%29.jpg)](https://az.wikipedia.org/wiki/Fayl:Jane_Goodall_2010_\(cropped\).jpg "Ceyn Qudoll 2010-cu ildə")Ceyn Qudoll 2010-cu ildə
  * İngilis [zooloqu](https://az.wikipedia.org/wiki/Zoologiya "Zoologiya") və [primatoloqu](https://az.wikipedia.org/wiki/Primatalogiya "Primatalogiya") **[Ceyn Qudoll](https://az.wikipedia.org/wiki/Ceyn_Qudoll "Ceyn Qudoll")** _(şəkildə)_ 91 yaşında vəfat edib.
  * [ABŞ federal hökuməti](https://az.wikipedia.org/wiki/AB%C5%9E_federal_h%C3%B6kum%C9%99ti "ABŞ federal hökuməti") büdcə çatışmazlığı səbəbi ilə [**fəaliyyətini dayandırıb**](https://az.wikipedia.org/wiki/2025_Amerika_Birl%C9%99%C5%9Fmi%C5%9F_%C5%9Etatlar%C4%B1_federal_h%C3%B6kum%C9%99tinin_ba%C4%9Flanmas%C4%B1 "2025 Amerika Birləşmiş Ştatları federal hökumətinin bağlanması").
  * [Azərbaycanın](https://az.wikipedia.org/wiki/Az%C9%99rbaycan "Azərbaycan") ev sahibliyi etdiyi **[III MDB Oyunları](https://az.wikipedia.org/wiki/2025_MDB_Oyunlar%C4%B1 "2025 MDB Oyunları")** start götürüb.


**Aktual hadisələr:** [HƏMAS–İsrail müharibəsi](https://az.wikipedia.org/wiki/H%C6%8FMAS%E2%80%93%C4%B0srail_m%C3%BCharib%C9%99si "HƏMAS–İsrail müharibəsi") • [Rusiya–Ukrayna müharibəsi](https://az.wikipedia.org/wiki/Rusiya%E2%80%93Ukrayna_m%C3%BCharib%C9%99si_\(2022%E2%80%93hal-haz%C4%B1rda\) "Rusiya–Ukrayna müharibəsi \(2022–hal-hazırda\)") • [Sudanda vətəndaş müharibəsi](https://az.wikipedia.org/wiki/Sudanda_v%C9%99t%C9%99nda%C5%9F_m%C3%BCharib%C9%99si_\(2023%E2%80%93hal-haz%C4%B1rda\) "Sudanda vətəndaş müharibəsi \(2023–hal-hazırda\)")
**[Son ölümlər:](https://az.wikipedia.org/wiki/2025-ci_ild%C9%99_v%C9%99fat_ed%C9%99nl%C9%99rin_siyah%C4%B1s%C4%B1 "2025-ci ildə vəfat edənlərin siyahısı") **[Oleq Xanov](https://az.wikipedia.org/wiki/Oleq_Xanov "Oleq Xanov"), [Cabir İmanov](https://az.wikipedia.org/wiki/Cabir_%C4%B0manov "Cabir İmanov"), [Yavuz Bülənd Bakilər](https://az.wikipedia.org/wiki/Yavuz_B%C3%BCl%C9%99nd_Bakil%C9%99r "Yavuz Bülənd Bakilər"), [Klaudiya Kardinale](https://az.wikipedia.org/wiki/Klaudiya_Kardinale "Klaudiya Kardinale"), [Şəmistan Nəzirli](https://az.wikipedia.org/wiki/%C5%9E%C9%99mistan_N%C9%99zirli "Şəmistan Nəzirli"), [Robert Redford](https://az.wikipedia.org/wiki/Robert_Redford "Robert Redford")
([bax](https://az.wikipedia.org/wiki/%C5%9Eablon:X%C9%99b%C9%99rl%C9%99r "Şablon:Xəbərlər") • [redaktə](https://az.wikipedia.org/wiki/X%C3%BCsusi:EditPage/%C5%9Eablon:X%C9%99b%C9%99rl%C9%99r "Xüsusi:EditPage/Şablon:Xəbərlər") • [tarixçə](https://az.wikipedia.org/w/index.php?title=%C5%9Eablon:X%C9%99b%C9%99rl%C9%99r&action=history))
  * **[Arxiv](https://az.wikipedia.org/wiki/Vikipediya:Ana_s%C9%99hif%C9%99/X%C9%99b%C9%99rl%C9%99r/Arxiv/2025 "Vikipediya:Ana səhifə/Xəbərlər/Arxiv/2025")**
  * **[Məqalə təklif et](https://az.wikipedia.org/wiki/%C5%9Eablon_m%C3%BCzakir%C9%99si:X%C9%99b%C9%99rl%C9%99r "Şablon müzakirəsi:Xəbərlər")**


![Bilirsinizmi?](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/PL_Wiki_CzyWiesz_ikona.svg/34px-PL_Wiki_CzyWiesz_ikona.svg.png)
Bilirsinizmi?
[![Palicourea elata](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Psychotria_elata_-_FLOR_BESO.jpg/250px-Psychotria_elata_-_FLOR_BESO.jpg)](https://az.wikipedia.org/wiki/Fayl:Psychotria_elata_-_FLOR_BESO.jpg "Palicourea elata")Palicourea elata
  * "_**[Palicourea elata](https://az.wikipedia.org/wiki/Palicourea_elata "Palicourea elata")**_ " _(şəkildə)_ bitkisi özünün aydın formalı, [dodağa](https://az.wikipedia.org/wiki/Dodaq "Dodaq") bənzər qırmızı diş telləri ilə diqqəti cəlb etdiyi üçün əsasən "isti dodaqlar" və "sevgili öpüşü" adları ilə tanınır.
  * [Yuli Sezar](https://az.wikipedia.org/wiki/Yuli_Sezar "Yuli Sezar") ikinci arvadı [Pompeyadan](https://az.wikipedia.org/wiki/Pompeya_Sulla "Pompeya Sulla") **["Bona Dea" ritualları](https://az.wikipedia.org/wiki/Bona_Dea#Dekabr_ritual%C4%B1 "Bona Dea")** ilə bağlı qalmaqalda iştirak etdiyi üçün boşanmışdır.
  * [Rumıniya Sosialist Respublikasında](https://az.wikipedia.org/wiki/Rum%C4%B1niya_Sosialist_Respublikas%C4%B1 "Rumıniya Sosialist Respublikası") **[pravoslav ruhanilərin](https://az.wikipedia.org/wiki/Rum%C4%B1niya_Sosialist_Respublikas%C4%B1nda_Pravoslav_Kils%C9%99si "Rumıniya Sosialist Respublikasında Pravoslav Kilsəsi")** böyük əksəriyyəti məxfi polis orqanı olan "[Sekuritate](https://az.wikipedia.org/wiki/Sekuritate "Sekuritate")"nin əməkdaşı idi.
  * [Coğrafi kəşflər dövründə](https://az.wikipedia.org/wiki/Co%C4%9Frafi_k%C9%99%C5%9Ffl%C9%99r "Coğrafi kəşflər") [Roma](https://az.wikipedia.org/wiki/Q%C9%99dim_Roma "Qədim Roma") yazıçısı [Senekanın](https://az.wikipedia.org/wiki/Lusi_Anney_Seneka "Lusi Anney Seneka") I əsrdə ərsəyə gətirdiyi "_**[Medeya](https://az.wikipedia.org/wiki/Medeya_\(Seneka\) "Medeya \(Seneka\)")**_ " əsərində [Amerikanın](https://az.wikipedia.org/wiki/Amerika_\(qit%C9%99\) "Amerika \(qitə\)") kəşfini proqnozlaşdırdığına inanılırdı.
  * Tobu Zooparkında saxlanılmış [pinqvin](https://az.wikipedia.org/wiki/Pinqvinl%C9%99r "Pinqvinlər") **[Qreyp-kun](https://az.wikipedia.org/wiki/Qreyp-kun "Qreyp-kun")** 2017-ci ildə [anime](https://az.wikipedia.org/wiki/Anime "Anime") personajına "aşiq olmuşdur".


([bax](https://az.wikipedia.org/wiki/Vikipediya:Bilirsinizmi/39._H%C9%99ft%C9%99_2025 "Vikipediya:Bilirsinizmi/39. Həftə 2025") • [redaktə](https://az.wikipedia.org/wiki/X%C3%BCsusi:EditPage/Vikipediya:Bilirsinizmi/39._H%C9%99ft%C9%99_2025 "Xüsusi:EditPage/Vikipediya:Bilirsinizmi/39. Həftə 2025") • [tarixçə](https://az.wikipedia.org/w/index.php?title=Vikipediya:Bilirsinizmi/39._H%C9%99ft%C9%99_2025&action=history))
  * **[Arxiv](https://az.wikipedia.org/wiki/Vikipediya:Bilirsinizmi/oktyabr_2025 "Vikipediya:Bilirsinizmi/oktyabr 2025")**
  * **[Yeni məqalə yaz](https://az.wikipedia.org/wiki/K%C3%B6m%C9%99k:%C4%B0lk_m%C9%99qal%C9%99niz "Kömək:İlk məqaləniz")**
  * **[Məqalə namizəd göstər](https://az.wikipedia.org/wiki/Vikipediya:Bilirsinizmi_namiz%C9%99dl%C9%99ri "Vikipediya:Bilirsinizmi namizədləri")**


[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Datum02.svg/40px-Datum02.svg.png)](https://az.wikipedia.org/wiki/2_oktyabr "2 oktyabr")
Tarixdə bu gün
**[2 oktyabr](https://az.wikipedia.org/wiki/2_oktyabr "2 oktyabr")** : [Avropa Birliyi](https://az.wikipedia.org/wiki/Avropa_Birliyi "Avropa Birliyi") ölkələri arasında Amsterdam sazişi; [Qvineyada](https://az.wikipedia.org/wiki/Qvineya "Qvineya") müstəqillik günü. [![Avropa Birliyinin bayrağı](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/Flag_of_Europe.svg/120px-Flag_of_Europe.svg.png)](https://az.wikipedia.org/wiki/Fayl:Flag_of_Europe.svg "Avropa Birliyinin bayrağı")Avropa Birliyinin bayrağı
* [1187](https://az.wikipedia.org/wiki/1187 "1187") — Misir hökmdarı Səlahəddin [Qüdsü](https://az.wikipedia.org/wiki/Q%C3%BCds "Qüds") səlibçilərdən azad etmişdir. 
* [1552](https://az.wikipedia.org/wiki/1552 "1552") — [İvan Qroznı](https://az.wikipedia.org/wiki/%C4%B0van_Qrozn%C4%B1 "İvan Qroznı") [Kazanı](https://az.wikipedia.org/wiki/Kazan "Kazan") tutmuş və [Kazan xanlığı](https://az.wikipedia.org/wiki/Kazan_xanl%C4%B1%C4%9F%C4%B1 "Kazan xanlığı") Rusiyaya birləşdirilmişdir. 
* [1870](https://az.wikipedia.org/wiki/1870 "1870") — [Roma](https://az.wikipedia.org/wiki/Roma "Roma") vahid İtaliyanın paytaxtı olmuşdur. 
* [1936](https://az.wikipedia.org/wiki/1936 "1936") — [ABŞ](https://az.wikipedia.org/wiki/AB%C5%9E "ABŞ")-də yenidən [spirtli içki](https://az.wikipedia.org/wiki/Spirtli_i%C3%A7ki "Spirtli içki") istehsalına icazə verilmişdir. 
* [1936](https://az.wikipedia.org/wiki/1936 "1936") — [SSRİ](https://az.wikipedia.org/wiki/SSR%C4%B0 "SSRİ")-də maksimum həbs müddəti 10 ildən 25 ilə qaldırılmışdır. 
* [1975](https://az.wikipedia.org/wiki/1975 "1975") — ABŞ [Türkiyəyə](https://az.wikipedia.org/wiki/T%C3%BCrkiy%C9%99 "Türkiyə") qoyduğu silah embarqosunu yumşaltmışdır. 
* [1992](https://az.wikipedia.org/wiki/1992 "1992") — [Xocavənd rayonu](https://az.wikipedia.org/wiki/Xocav%C9%99nd_rayonu "Xocavənd rayonu") erməni silahlı birləşmələri tərəfindən işğal edilmişdir. 
* [1997](https://az.wikipedia.org/wiki/1997 "1997") — [Avropa Birliyi](https://az.wikipedia.org/wiki/Avropa_Birliyi "Avropa Birliyi") ölkələri arasında Amsterdam sazişi imzalanmışdır. 
Digər günlər: [1 oktyabr](https://az.wikipedia.org/wiki/1_oktyabr "1 oktyabr") – **[2 oktyabr](https://az.wikipedia.org/wiki/2_oktyabr "2 oktyabr")** – [3 oktyabr](https://az.wikipedia.org/wiki/3_oktyabr "3 oktyabr")
([bax](https://az.wikipedia.org/wiki/Vikipediya:Tarixd%C9%99_bu_g%C3%BCn/oktyabr_2 "Vikipediya:Tarixdə bu gün/oktyabr 2") • [redaktə](https://az.wikipedia.org/wiki/X%C3%BCsusi:EditPage/Vikipediya:Tarixd%C9%99_bu_g%C3%BCn/oktyabr_2 "Xüsusi:EditPage/Vikipediya:Tarixdə bu gün/oktyabr 2") • [tarixçə](https://az.wikipedia.org/w/index.php?title=Vikipediya:Tarixd%C9%99_bu_g%C3%BCn/oktyabr_2&action=history))
**[Arxiv](https://az.wikipedia.org/wiki/Vikipediya:Tarixd%C9%99_bu_g%C3%BCn/Oktyabr "Vikipediya:Tarixdə bu gün/Oktyabr")** – **[İlin digər günləri](https://az.wikipedia.org/wiki/%C4%B0lin_g%C3%BCnl%C9%99ri "İlin günləri")** – **[Haqqında](https://az.wikipedia.org/wiki/Vikipediya:Tarixd%C9%99_bu_g%C3%BCn "Vikipediya:Tarixdə bu gün")**
[![Kömək səhifələri](https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/HS_Emblem-question.png/40px-HS_Emblem-question.png)](https://az.wikipedia.org/wiki/Vikipediya:K%C3%B6m%C9%99k "Kömək səhifələri")
Kömək səhifələri
  * [Vikipediyaçılar](https://az.wikipedia.org/wiki/Kateqoriya:Vikipediya%C3%A7%C4%B1lar "Kateqoriya:Vikipediyaçılar")
  * [Beş əsas prinsip](https://az.wikipedia.org/wiki/Vikipediya:Be%C5%9F_%C9%99sas_prinsip "Vikipediya:Beş əsas prinsip")
  * [Qaralama dəftəri](https://az.wikipedia.org/wiki/Vikipediya:Qaralama_d%C9%99ft%C9%99ri "Vikipediya:Qaralama dəftəri")
  * [Şablonlar](https://az.wikipedia.org/wiki/Kateqoriya:Vikipediya_%C5%9Fablonlar%C4%B1 "Kateqoriya:Vikipediya şablonları")
  * [Yeni başlayanlar üçün təlimat](https://az.wikipedia.org/wiki/K%C3%B6m%C9%99k:%C4%B0lk_m%C9%99qal%C9%99niz "Kömək:İlk məqaləniz")
  * [Tez-tez soruşulan suallar](https://az.wikipedia.org/wiki/Vikipediya:Tez-tez_soru%C5%9Fulan_suallar "Vikipediya:Tez-tez soruşulan suallar")


[**Vikipediya**](https://az.wikipedia.org/wiki/Kateqoriya:Vikipediya "Kateqoriya:Vikipediya")
[![Vikimedia Fondu](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8b/Wikimedia-logo_black.svg/60px-Wikimedia-logo_black.svg.png)](https://wikimediafoundation.org/)
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Notification-icon-Wiktionary-logo.svg/48px-Notification-icon-Wiktionary-logo.svg.png)[**Vikilüğət** Lüğət](https://az.wiktionary.org/wiki/ "wikt:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Notification-icon-Wikiquote.svg/48px-Notification-icon-Wikiquote.svg.png)[**Vikisitat** Sitatlar](https://az.wikiquote.org/wiki/ "q:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/Notification-icon-Wikibooks-logo.svg/48px-Notification-icon-Wikibooks-logo.svg.png)[**Vikikitab** Azad dərsliklər və təlimat kitabları](https://az.wikibooks.org/wiki/ "b:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Notification-icon-Wikisource-logo.svg/48px-Notification-icon-Wikisource-logo.svg.png)[**Vikimənbə** Azad əsər kitabxanası](https://az.wikisource.org/wiki/ "s:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Notification-icon-Wikinews-logo.svg/48px-Notification-icon-Wikinews-logo.svg.png)[**Vikixəbər** Azad xəbər mənbəyi](https://az.wikinews.org/wiki/ "n:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Notification-icon-Wikiversity-logo.svg/48px-Notification-icon-Wikiversity-logo.svg.png)[**Vikiversitet** Tədris materialları](https://en.wikipedia.org/wiki/v: "en:v:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Notification-icon-Wikispecies-logo.svg/48px-Notification-icon-Wikispecies-logo.svg.png)[**Vikinövlər** Bioloji növlərin sistematikası](https://species.wikimedia.org/wiki/ "species:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/MediaWiki-2020-large-icon.svg/60px-MediaWiki-2020-large-icon.svg.png)[**Mediaviki** Viki proqram təminatının təkmilləşdirilməsi](https://www.mediawiki.org/wiki/ "mw:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Notification-icon-Wikidata-logo.svg/48px-Notification-icon-Wikidata-logo.svg.png)[**Vikidata** Ortaq verilənlər bazası](https://www.wikidata.org/wiki/ "d:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Notification-icon-Commons-logo.svg/48px-Notification-icon-Commons-logo.svg.png)[**Vikianbar** Ortaq media anbarı](https://commons.wikimedia.org/wiki/ "c:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Notification-icon-Wikivoyage-logo.svg/48px-Notification-icon-Wikivoyage-logo.svg.png)[**Vikisəyahət** Azad səyahət təlimatçası](https://az.wikivoyage.org/wiki/ "voy:")
  * ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Notification-icon-Meta-logo.svg/48px-Notification-icon-Meta-logo.svg.png)[**Meta-Viki** Vikimedia koordinasiya mərkəzi](https://meta.wikimedia.org/wiki/ "m:")


  

Mənbə — "[https://az.wikipedia.org/w/index.php?title=Ana_səhifə&oldid=7990926](https://az.wikipedia.org/w/index.php?title=Ana_s%C9%99hif%C9%99&oldid=7990926)"
49 dildə
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/ "abxaz")
  * [العربية](https://ar.wikipedia.org/wiki/ "ərəb")
  * [Авар](https://av.wikipedia.org/wiki/ "avar")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/ "South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/ "başqırd")
  * [Български](https://bg.wikipedia.org/wiki/ "bolqar")
  * [Bosanski](https://bs.wikipedia.org/wiki/ "bosniya")
  * [Нохчийн](https://ce.wikipedia.org/wiki/ "çeçen")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/ "krım türkcəsi")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/ "çuvaş")
  * [Dansk](https://da.wikipedia.org/wiki/ "danimarka")
  * [Deutsch](https://de.wikipedia.org/wiki/ "alman")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "yunan")
  * [English](https://en.wikipedia.org/wiki/ "ingilis")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "esperanto")
  * [Español](https://es.wikipedia.org/wiki/ "ispan")
  * [فارسی](https://fa.wikipedia.org/wiki/ "fars")
  * [Suomi](https://fi.wikipedia.org/wiki/ "fin")
  * [Français](https://fr.wikipedia.org/wiki/ "fransız")
  * [Gagauz](https://gag.wikipedia.org/wiki/ "qaqauz")
  * [עברית](https://he.wikipedia.org/wiki/ "ivrit")
  * [Magyar](https://hu.wikipedia.org/wiki/ "macar")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "indoneziya")
  * [İtaliano](https://it.wikipedia.org/wiki/ "italyan")
  * [ქართული](https://ka.wikipedia.org/wiki/ "gürcü")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/ "qaraqalpaq")
  * [Қазақша](https://kk.wikipedia.org/wiki/ "qazax")
  * [Кыргызча](https://ky.wikipedia.org/wiki/ "qırğız")
  * [Latina](https://la.wikipedia.org/wiki/ "latın")
  * [Македонски](https://mk.wikipedia.org/wiki/ "makedon")
  * [Монгол](https://mn.wikipedia.org/wiki/ "monqol")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "holland")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "nünorsk norveç")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "bokmal norveç")
  * [Polski](https://pl.wikipedia.org/wiki/ "polyak")
  * [Português](https://pt.wikipedia.org/wiki/ "portuqal")
  * [Română](https://ro.wikipedia.org/wiki/ "rumın")
  * [Русский](https://ru.wikipedia.org/wiki/ "rus")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Shqip](https://sq.wikipedia.org/wiki/ "alban")
  * [Svenska](https://sv.wikipedia.org/wiki/ "isveç")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/ "tacik")
  * [Türkmençe](https://tk.wikipedia.org/wiki/ "türkmən")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "türk")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/ "tatar")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/ "tuvinyan")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/ "uyğur")
  * [Українська](https://uk.wikipedia.org/wiki/ "ukrayna")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/ "özbək")


  * Bu səhifə sonuncu dəfə 22:41, 2 fevral 2025 tarixində redaktə edilib.
  * Mətn [Creative Commons Attribution-ShareAlike lisenziyası](https://creativecommons.org/licenses/by-sa/4.0/deed.az) altındadır, bəzi hallarda əlavə şərtlər tətbiq oluna bilər. Ətraflı məlumat üçün [istifadə şərtlərinə](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use) baxın.


  * [Gizlilik siyasəti](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Vikipediya haqqında](https://az.wikipedia.org/wiki/Vikipediya:Haqq%C4%B1nda)
  * [Məsuliyyətdən imtina](https://az.wikipedia.org/wiki/Vikipediya:M%C9%99suliyy%C9%99td%C9%99n_imtina)
  * [Davranış Kodeksi](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Tərtibatçılar](https://developer.wikimedia.org)
  * [Statistikalar](https://stats.wikimedia.org/#/az.wikipedia.org)
  * [Kuki məlumatı](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Mobil versiya](https://az.m.wikipedia.org/w/index.php?title=Ana_s%C9%99hif%C9%99&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://az.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://az.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Axtar
Axtar
Ana səhifə
[](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99) [](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99) [](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99) [](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99) [](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99) [](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99) [](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99) [](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99)
49 dildə [Mövzu əlavə et ](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99)
  *[ö.]: ölüm tarixi
