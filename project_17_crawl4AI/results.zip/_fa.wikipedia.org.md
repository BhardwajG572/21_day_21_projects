[پرش به محتوا](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C#bodyContent)
منوی اصلی
منوی اصلی
انتقال به نوار کناری نهفتن
بازدید محتوا 
  * [صفحهٔ اصلی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "مشاهدهٔ صفحهٔ اصلی \[alt-z\]")
  * [رویدادهای کنونی](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D8%B1%D9%88%DB%8C%D8%AF%D8%A7%D8%AF%D9%87%D8%A7%DB%8C_%DA%A9%D9%86%D9%88%D9%86%DB%8C "یافتن اطلاعات پس‌زمینه پیرامون رویدادهای کنونی")
  * [مقالهٔ تصادفی](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%AA%D8%B5%D8%A7%D8%AF%D9%81%DB%8C "آوردن یک صفحهٔ تصادفی \[alt-x\]")


همکاری 
  * [تغییرات اخیر](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%AA%D8%BA%DB%8C%DB%8C%D8%B1%D8%A7%D8%AA_%D8%A7%D8%AE%DB%8C%D8%B1 "فهرستی از تغییرات اخیر ویکی \[alt-r\]")
  * [ویکی‌نویس شوید!](https://fa.wikipedia.org/wiki/%D8%B1%D8%A7%D9%87%D9%86%D9%85%D8%A7:%D9%87%D9%85%DA%A9%D8%A7%D8%B1%DB%8C)
  * [راهنما](https://fa.wikipedia.org/wiki/%D8%B1%D8%A7%D9%87%D9%86%D9%85%D8%A7:%D9%81%D9%87%D8%B1%D8%B3%D8%AA "مکانی برای دریافتن")
  * [تماس با ویکی‌پدیا](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%AA%D9%85%D8%A7%D8%B3_%D8%A8%D8%A7_%D9%85%D8%A7)


[ ![](https://fa.wikipedia.org/static/images/icons/wikipedia.png) ![ویکی‌پدیا](https://fa.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-fa.svg) ![دانشنامهٔ آزاد](https://fa.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-fa.svg) ](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
[جستجو ](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%AC%D8%B3%D8%AA%D8%AC%D9%88 "جستجو در ویکی‌پدیا \[alt-f\]")
جستجو
ظاهر
ظاهر
انتقال به نوار کناری نهفتن
متن
  * کوچک
استاندارد
بزرگ

این صفحه همیشه از قلم در اندازهٔ کوچک استفاده می‌کند
عرض
  * استاندارد
پهن

این محتوا تا حدی که پنجرهٔ مرورگرتان اجازه می‌دهد عریض است
رنگ 
  * خودکار
روشن
تیره

این صفحه همیشه در حالت روشن است.
  * [کمک مالی](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=fa.wikipedia.org&uselang=fa)
  * [ساخت حساب](https://fa.wikipedia.org/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%D8%A7%DB%8C%D8%AC%D8%A7%D8%AF_%D8%AD%D8%B3%D8%A7%D8%A8_%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%DB%8C&returnto=%D8%B5%D9%81%D8%AD%D9%87%D9%94+%D8%A7%D8%B5%D9%84%DB%8C "از شما دعوت می‌شود که یک حساب ایجاد کنید و وارد شوید؛ هرچند که این کار اختیاری است.")
  * [ورود](https://fa.wikipedia.org/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%D9%88%D8%B1%D9%88%D8%AF_%D8%A8%D9%87_%D8%B3%D8%A7%D9%85%D8%A7%D9%86%D9%87&returnto=%D8%B5%D9%81%D8%AD%D9%87%D9%94+%D8%A7%D8%B5%D9%84%DB%8C "توصیه می‌شود که به سامانه وارد شوید، گرچه اجباری نیست \[alt-o\]")


ابزارهای شخصی
  * [کمک مالی](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=fa.wikipedia.org&uselang=fa)
  * [ساخت حساب](https://fa.wikipedia.org/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%D8%A7%DB%8C%D8%AC%D8%A7%D8%AF_%D8%AD%D8%B3%D8%A7%D8%A8_%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%DB%8C&returnto=%D8%B5%D9%81%D8%AD%D9%87%D9%94+%D8%A7%D8%B5%D9%84%DB%8C "از شما دعوت می‌شود که یک حساب ایجاد کنید و وارد شوید؛ هرچند که این کار اختیاری است.")
  * [ورود](https://fa.wikipedia.org/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%D9%88%D8%B1%D9%88%D8%AF_%D8%A8%D9%87_%D8%B3%D8%A7%D9%85%D8%A7%D9%86%D9%87&returnto=%D8%B5%D9%81%D8%AD%D9%87%D9%94+%D8%A7%D8%B5%D9%84%DB%8C "توصیه می‌شود که به سامانه وارد شوید، گرچه اجباری نیست \[alt-o\]")


# صفحهٔ اصلی
  * [صفحهٔ اصلی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "دیدن صفحهٔ محتویات \[alt-c\]")
  * [بحث](https://fa.wikipedia.org/wiki/%D8%A8%D8%AD%D8%AB:%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "گفتگو پیرامون محتوای صفحه \[alt-t\]")


فارسی
  * [خواندن](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
  * [نمایش مبدأ](https://fa.wikipedia.org/w/index.php?title=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&action=edit "این صفحه محافظت‌شده است.
می‌توانید متن مبدأ آن را ببینید \[alt-e\]")
  * [نمایش تاریخچه](https://fa.wikipedia.org/w/index.php?title=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&action=history "نسخه‌های پیشین این صفحه \[alt-h\]")


ابزارها
ابزارها
انتقال به نوار کناری نهفتن
کنش‌ها 
  * [خواندن](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
  * [نمایش مبدأ](https://fa.wikipedia.org/w/index.php?title=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&action=edit)
  * [نمایش تاریخچه](https://fa.wikipedia.org/w/index.php?title=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&action=history)


عمومی 
  * [پیوندها به این صفحه](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%BE%DB%8C%D9%88%D9%86%D8%AF_%D8%A8%D9%87_%D8%A7%DB%8C%D9%86_%D8%B5%D9%81%D8%AD%D9%87/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "فهرست همهٔ صفحه‌هایی که به این صفحه پیوند می‌دهند \[alt-j\]")
  * [تغییرات مرتبط](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%AA%D8%BA%DB%8C%DB%8C%D8%B1%D8%A7%D8%AA_%D9%85%D8%B1%D8%AA%D8%A8%D8%B7/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "تغییرات اخیر صفحه‌هایی که این صفحه به آن‌ها پیوند دارد \[alt-k\]")
  * [بارگذاری پرونده](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%A8%D8%A7%D8%B1%DA%AF%D8%B0%D8%A7%D8%B1%DB%8C "بارگذاری تصاویر و پرونده‌های دیگر \[alt-u\]")
  * [پیوند پایدار](https://fa.wikipedia.org/w/index.php?title=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&oldid=41777649 "پیوند پایدار به این نسخه از این صفحه")
  * [اطلاعات صفحه](https://fa.wikipedia.org/w/index.php?title=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&action=info "اطلاعات بیشتر دربارهٔ این صفحه")
  * [یادکرد این صفحه](https://fa.wikipedia.org/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%DB%8C%D8%A7%D8%AF%DA%A9%D8%B1%D8%AF&page=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&id=41777649&wpFormIdentifier=titleform "اطلاعات در خصوص چگونگی یادکرد این صفحه")
  * [دریافت نشانی کوتاه‌شده](https://fa.wikipedia.org/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:UrlShortener&url=https%3A%2F%2Ffa.wikipedia.org%2Fwiki%2F%25D8%25B5%25D9%2581%25D8%25AD%25D9%2587%25D9%2594_%25D8%25A7%25D8%25B5%25D9%2584%25DB%258C)
  * [بارگیری کیوآر کد](https://fa.wikipedia.org/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:QrCode&url=https%3A%2F%2Ffa.wikipedia.org%2Fwiki%2F%25D8%25B5%25D9%2581%25D8%25AD%25D9%2587%25D9%2594_%25D8%25A7%25D8%25B5%25D9%2584%25DB%258C)


نسخه‌برداری 
  * [بارگیری به‌صورت PDF](https://fa.wikipedia.org/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:DownloadAsPdf&page=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&action=show-download-screen)
  * [نسخهٔ قابل چاپ](https://fa.wikipedia.org/w/index.php?title=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&printable=yes "نسخهٔ قابل چاپ این صفحه \[alt-p\]")


در پروژه‌های دیگر 
  * [ویکی‌انبار](https://commons.wikimedia.org/wiki/Main_Page)
  * [بنیاد ویکی‌مدیا](https://foundation.wikimedia.org/wiki/Home)
  * [مدیاویکی](https://www.mediawiki.org/wiki/MediaWiki)
  * [فراویکی](https://meta.wikimedia.org/wiki/Main_Page)
  * [ویکی‌مدیا اوت‌ریچ](https://outreach.wikimedia.org/wiki/Main_Page)
  * [ویکی‌نبشته چندزبانی](https://wikisource.org/wiki/Main_Page)
  * [ویکی‌گونه](https://species.wikimedia.org/wiki/Main_Page)
  * [ویکی‌کتاب](https://fa.wikibooks.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
  * [ویکی‌داده](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [ویکی‌توابع](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [ویکی‌خبر](https://fa.wikinews.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
  * [ویکی‌گفتاورد](https://fa.wikiquote.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
  * [ویکی‌نبشته](https://fa.wikisource.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
  * [ویکی‌سفر](https://fa.wikivoyage.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
  * [ویکی‌واژه](https://fa.wiktionary.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%88%D8%A7%DA%98%D9%87:%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
  * [آیتم ویکی‌داده](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "پیوند به آیتم متصل‌شدۀ مخزن داده‌ها \[alt-g\]")


از ویکی‌پدیا، دانشنامهٔ آزاد
[![به ویکی‌پدیا خوش‌آمدید](https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/Welcome_to_Wikipedia_-_fa.svg/250px-Welcome_to_Wikipedia_-_fa.svg.png)](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%AE%D9%88%D8%B4_%D8%A2%D9%85%D8%AF%DB%8C%D8%AF "به ویکی‌پدیا خوش‌آمدید")
[دانشنامه‌ای آزاد](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%AF%D8%A7%D9%86%D8%B4%D9%86%D8%A7%D9%85%D9%87%D9%94_%D8%A2%D8%B2%D8%A7%D8%AF "ویکی‌پدیا:دانشنامهٔ آزاد") که همه می‌توانند آن را ویرایش کنند؛  
با [۱٬۰۵۷٬۷۰۴](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%A2%D9%85%D8%A7%D8%B1 "ویژه:آمار") مقاله به زبان [فارسی](https://fa.wikipedia.org/wiki/%D8%B2%D8%A8%D8%A7%D9%86_%D9%81%D8%A7%D8%B1%D8%B3%DB%8C "زبان فارسی")
  * [آشنایی با دانشنامه](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%A2%D8%B4%D9%86%D8%A7%DB%8C%DB%8C_%D8%A8%D8%A7_%D8%AF%D8%A7%D9%86%D8%B4%D9%86%D8%A7%D9%85%D9%87 "ویکی‌پدیا:آشنایی با دانشنامه")
  * [آشنایی با اصول ویرایش](https://fa.wikipedia.org/wiki/%D8%B1%D8%A7%D9%87%D9%86%D9%85%D8%A7:%D9%81%D9%87%D8%B1%D8%B3%D8%AA "راهنما:فهرست")
  * [کارهای قابل انجام](https://fa.wikipedia.org/wiki/%D8%B1%D8%A7%D9%87%D9%86%D9%85%D8%A7:%D9%87%D9%85%DA%A9%D8%A7%D8%B1%DB%8C "راهنما:همکاری")
  * [سیاست‌ها و رهنمودها](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%B3%DB%8C%D8%A7%D8%B3%D8%AA%E2%80%8C%D9%87%D8%A7_%D9%88_%D8%B1%D9%87%D9%86%D9%85%D9%88%D8%AF%D9%87%D8%A7 "ویکی‌پدیا:سیاست‌ها و رهنمودها")
  * [فهرست الفبایی مقاله‌ها](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D9%81%D9%87%D8%B1%D8%B3%D8%AA_%D8%B3%D8%B1%DB%8C%D8%B9 "ویکی‌پدیا:فهرست سریع")


![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Symbol_star_gold.svg/40px-Symbol_star_gold.svg.png) مقالهٔ برگزیده [ویرایش](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%88%DB%8C%D8%B1%D8%A7%DB%8C%D8%B4_%D8%B5%D9%81%D8%AD%D9%87/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D9%86%D9%88%D8%B4%D8%AA%D8%A7%D8%B1_%D9%BE%DB%8C%D8%B4%D9%86%D9%87%D8%A7%D8%AF%DB%8C/%DB%B2%DB%B0%DB%B2%DB%B5/%DB%B8%DB%B0 "ویژه:ویرایش صفحه/ویکی‌پدیا:نوشتار پیشنهادی/۲۰۲۵/۸۰")
[![سردر ساختمان مجلس شورای ملی](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/Majles_Shora_Melli_Entrance2.jpg/250px-Majles_Shora_Melli_Entrance2.jpg)](https://fa.wikipedia.org/wiki/%D9%BE%D8%B1%D9%88%D9%86%D8%AF%D9%87:Majles_Shora_Melli_Entrance2.jpg "سردر ساختمان مجلس شورای ملی")
سردر ساختمان مجلس شورای ملی
**[جنبش مشروطه](https://fa.wikipedia.org/wiki/%D8%AC%D9%86%D8%A8%D8%B4_%D9%85%D8%B4%D8%B1%D9%88%D8%B7%D9%87_%D8%A7%DB%8C%D8%B1%D8%A7%D9%86 "جنبش مشروطه ایران")** ، **جنبش مشروطه‌خواهی** یا **جنبش مشروطیت** مجموعه کوشش‌ها و رویدادهایی در نظر و عمل است که برای محدود شدن اختیارات [پادشاه](https://fa.wikipedia.org/wiki/%D9%BE%D8%A7%D8%AF%D8%B4%D8%A7%D9%87 "پادشاه") در نظام سلطنتی [ایران](https://fa.wikipedia.org/wiki/%D8%A7%DB%8C%D8%B1%D8%A7%D9%86 "ایران") و نهادینه‌سازی [حقوق اساسی](https://fa.wikipedia.org/wiki/%D8%AD%D9%82%D9%88%D9%82_%D8%A7%D8%B3%D8%A7%D8%B3%DB%8C "حقوق اساسی") مانند [آزادی فردی](https://fa.wikipedia.org/wiki/%D9%81%D8%B1%D8%AF%DA%AF%D8%B1%D8%A7%DB%8C%DB%8C "فردگرایی")، عدالت قضایی و [حاکمیت قانون](https://fa.wikipedia.org/wiki/%D8%AD%D8%A7%DA%A9%D9%85%DB%8C%D8%AA_%D9%82%D8%A7%D9%86%D9%88%D9%86 "حاکمیت قانون") آغاز شد و به دگرگونی [نظام سیاسی](https://fa.wikipedia.org/wiki/%D8%B3%DB%8C%D8%A7%D8%B3%D8%AA_%D8%AF%D8%B1_%D8%A7%DB%8C%D8%B1%D8%A7%D9%86 "سیاست در ایران") [ایران قاجاری](https://fa.wikipedia.org/wiki/%D8%A7%DB%8C%D8%B1%D8%A7%D9%86_%D9%82%D8%A7%D8%AC%D8%A7%D8%B1%DB%8C "ایران قاجاری") از [پادشاهی مطلقه](https://fa.wikipedia.org/wiki/%D9%BE%D8%A7%D8%AF%D8%B4%D8%A7%D9%87%DB%8C_%D9%85%D8%B7%D9%84%D9%82%D9%87 "پادشاهی مطلقه") به [پادشاهی مشروطه](https://fa.wikipedia.org/wiki/%D9%BE%D8%A7%D8%AF%D8%B4%D8%A7%D9%87%DB%8C_%D9%85%D8%B4%D8%B1%D9%88%D8%B7%D9%87 "پادشاهی مشروطه") منجر گردید. این جنبش از سال ۱۲۸۴ خورشیدی با وقوع اعتراضات منتهی به [انقلاب مشروطه](https://fa.wikipedia.org/wiki/%D8%A7%D9%86%D9%82%D9%84%D8%A7%D8%A8_%D9%85%D8%B4%D8%B1%D9%88%D8%B7%D9%87 "انقلاب مشروطه") آغاز شد و می‌توان شکست [استبداد صغیر](https://fa.wikipedia.org/wiki/%D8%A7%D8%B3%D8%AA%D8%A8%D8%AF%D8%A7%D8%AF_%D8%B5%D8%BA%DB%8C%D8%B1 "استبداد صغیر") و پایان حکومت [محمدعلی شاه](https://fa.wikipedia.org/wiki/%D9%85%D8%AD%D9%85%D8%AF%D8%B9%D9%84%DB%8C%E2%80%8C%D8%B4%D8%A7%D9%87 "محمدعلی‌شاه") در مرداد ۱۲۸۸ را (به سبب پایان حکمرانی آخرین پادشاه ایران در نظام حکومتی پادشاهی مطلقه) زمان پایان آن دانست. در سال‌های سلطنت [ناصرالدین شاه](https://fa.wikipedia.org/wiki/%D9%86%D8%A7%D8%B5%D8%B1%D8%A7%D9%84%D8%AF%DB%8C%D9%86%E2%80%8C%D8%B4%D8%A7%D9%87 "ناصرالدین‌شاه") برخی ایرانیان به‌واسطهٔ تحصیل یا تجارت در [اروپا](https://fa.wikipedia.org/wiki/%D8%A7%D8%B1%D9%88%D9%BE%D8%A7 "اروپا") و [عثمانی](https://fa.wikipedia.org/wiki/%D8%A7%D9%85%D9%BE%D8%B1%D8%A7%D8%AA%D9%88%D8%B1%DB%8C_%D8%B9%D8%AB%D9%85%D8%A7%D9%86%DB%8C "امپراتوری عثمانی")، با مظاهر پیشرفت در غرب آشنا شدند و تلاش کردند به نحوی حاکمان ایران را پذیرا به اصلاحات و مردم ایران را دگرگون و بیدار نمایند. نخستین جرقهٔ این جنبش در سطح سیاسی در ۲۱ آذر ۱۲۸۴ زده شد که [علاءالدوله](https://fa.wikipedia.org/wiki/%D8%A7%D8%AD%D9%85%D8%AF%D8%AE%D8%A7%D9%86_%D8%B9%D9%84%D8%A7%D8%A1%D8%A7%D9%84%D8%AF%D9%88%D9%84%D9%87 "احمدخان علاءالدوله")، حاکم [تهران](https://fa.wikipedia.org/wiki/%D8%AA%D9%87%D8%B1%D8%A7%D9%86 "تهران")، چند تن از تاجران خوشنام تهران را به خاطر افزایش قیمت قند، فلک کرد. در پی این جرقه، سلسله‌ای از اعتراض‌ها و بست‌نشینی‌ها به رهبری دو مجتهد سرشناس تهران، [سید محمد طباطبایی](https://fa.wikipedia.org/wiki/%D8%B3%DB%8C%D8%AF_%D9%85%D8%AD%D9%85%D8%AF_%D8%B7%D8%A8%D8%A7%D8%B7%D8%A8%D8%A7%DB%8C%DB%8C "سید محمد طباطبایی") و [سید عبدالله بهبهانی](https://fa.wikipedia.org/wiki/%D8%B3%DB%8C%D8%AF_%D8%B9%D8%A8%D8%AF%D8%A7%D9%84%D9%84%D9%87_%D8%A8%D9%87%D8%A8%D9%87%D8%A7%D9%86%DB%8C "سید عبدالله بهبهانی") شکل گرفت. مجموعه اعتراضات و دنباله آن، نظیر مهاجرت روحانیان به [قم](https://fa.wikipedia.org/wiki/%D9%82%D9%85 "قم") و بست‌نشینی اصناف در باغ [سفارت بریتانیا در تهران](https://fa.wikipedia.org/wiki/%D8%B3%D9%81%D8%A7%D8%B1%D8%AA_%D8%A8%D8%B1%DB%8C%D8%AA%D8%A7%D9%86%DB%8C%D8%A7_%D8%AF%D8%B1_%D8%AA%D9%87%D8%B1%D8%A7%D9%86 "سفارت بریتانیا در تهران") به نام انقلاب مشروطه نامیده می‌شود. دستاورد این انقلاب، امضای [فرمان مشروطیت](https://fa.wikipedia.org/wiki/%D9%81%D8%B1%D9%85%D8%A7%D9%86_%D9%85%D8%B4%D8%B1%D9%88%D8%B7%DB%8C%D8%AA "فرمان مشروطیت") به دست شاه وقت ایران، [مظفرالدین شاه](https://fa.wikipedia.org/wiki/%D9%85%D8%B8%D9%81%D8%B1%D8%A7%D9%84%D8%AF%DB%8C%D9%86%E2%80%8C%D8%B4%D8%A7%D9%87 "مظفرالدین‌شاه")، تشکیل [مجلس شورای ملی](https://fa.wikipedia.org/wiki/%D9%85%D8%AC%D9%84%D8%B3_%D8%B4%D9%88%D8%B1%D8%A7%DB%8C_%D9%85%D9%84%DB%8C "مجلس شورای ملی") و تدوین [قانون اساسی مشروطه](https://fa.wikipedia.org/wiki/%D9%82%D8%A7%D9%86%D9%88%D9%86_%D8%A7%D8%B3%D8%A7%D8%B3%DB%8C_%D9%85%D8%B4%D8%B1%D9%88%D8%B7%D9%87 "قانون اساسی مشروطه") بود. پیروزی انقلاب مشروطه، فضای آزادی ایجاد کرد که در آن روزنامه‌نگاران، واعظان مشروطه‌خواه، احزاب و انجمن‌ها نقدهای تندی به سنت‌های قدیمی، اصحاب قدرت و محمدعلی شاه — شاه جدید که با درگذشت پدرش به مقام شاهی رسیده بود — وارد می‌کردند. 
**[ادامه…](https://fa.wikipedia.org/wiki/%D8%AC%D9%86%D8%A8%D8%B4_%D9%85%D8%B4%D8%B1%D9%88%D8%B7%D9%87_%D8%A7%DB%8C%D8%B1%D8%A7%D9%86 "جنبش مشروطه ایران")**![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Symbol_star_gold.svg/20px-Symbol_star_gold.svg.png) **[مقاله‌های برگزیده](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D9%85%D9%82%D8%A7%D9%84%D9%87%E2%80%8C%D9%87%D8%A7%DB%8C_%D8%A8%D8%B1%DA%AF%D8%B2%DB%8C%D8%AF%D9%87 "ویکی‌پدیا:مقاله‌های برگزیده")** – **[مقالهٔ امروز](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D9%85%D9%82%D8%A7%D9%84%D9%87_%D9%BE%DB%8C%D8%B4%D9%86%D9%87%D8%A7%D8%AF%DB%8C_%D9%87%D9%81%D8%AA%D9%87 "ویکی‌پدیا:مقاله پیشنهادی هفته")**
![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/Help-browser_-_ar.svg/40px-Help-browser_-_ar.svg.png) آیا می‌دانستید که …؟ [ویرایش](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%88%DB%8C%D8%B1%D8%A7%DB%8C%D8%B4_%D8%B5%D9%81%D8%AD%D9%87/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%A2%DB%8C%D8%A7_%D9%85%DB%8C%E2%80%8C%D8%AF%D8%A7%D9%86%D8%B3%D8%AA%DB%8C%D8%AF_%DA%A9%D9%87...%D8%9F/%DB%B2%DB%B0%DB%B2%DB%B5/%D9%87%D9%81%D8%AA%D9%87_%DB%B4%DB%B0 "ویژه:ویرایش صفحه/ویکی‌پدیا:آیا می‌دانستید که...؟/۲۰۲۵/هفته ۴۰")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Daghighi-Tusi.jpg/120px-Daghighi-Tusi.jpg)](https://fa.wikipedia.org/wiki/%D9%BE%D8%B1%D9%88%D9%86%D8%AF%D9%87:Daghighi-Tusi.jpg)
  * … **[دقیقی](https://fa.wikipedia.org/wiki/%D8%AF%D9%82%DB%8C%D9%82%DB%8C "دقیقی")** آغاز کننده سرایش [شاهنامه](https://fa.wikipedia.org/wiki/%D8%B4%D8%A7%D9%87%D9%86%D8%A7%D9%85%D9%87 "شاهنامه") و از معدود شاعران [ادبیات فارسی](https://fa.wikipedia.org/wiki/%D8%A7%D8%AF%D8%A8%DB%8C%D8%A7%D8%AA_%D9%81%D8%A7%D8%B1%D8%B3%DB%8C "ادبیات فارسی") است که آئین [مزدیسنا](https://fa.wikipedia.org/wiki/%D9%85%D8%B2%D8%AF%DB%8C%D8%B3%D9%86%D8%A7 "مزدیسنا") داشته است؟ _(در تصویر)_
  * … **[قلعه دختر](https://fa.wikipedia.org/wiki/%D9%82%D9%84%D8%B9%D9%87_%D8%AF%D8%AE%D8%AA%D8%B1 "قلعه دختر")** به قلعه‌های دست‌نیافتنی‌ای می‌گفتند که تصرف آنها مشکل بوده است و در چندین شهر ایران آثاری از آنها برجای مانده است. همچنین گاه در مقابل آنها قلعه دیگری به نام **[قلعه پسر](https://fa.wikipedia.org/wiki/%D9%82%D9%84%D8%B9%D9%87_%D9%BE%D8%B3%D8%B1 "قلعه پسر")** ساخته می‌شد؟
  * … در جریان محاکمهٔ **[پزشک احمدی](https://fa.wikipedia.org/wiki/%D8%A7%D8%AD%D9%85%D8%AF_%D8%A7%D8%AD%D9%85%D8%AF%DB%8C_\(%D9%BE%D8%B2%D8%B4%DA%A9\) "احمد احمدی \(پزشک\)")** در سال ۱۳۲۰، [احمد کسروی](https://fa.wikipedia.org/wiki/%D8%A7%D8%AD%D9%85%D8%AF_%DA%A9%D8%B3%D8%B1%D9%88%DB%8C "احمد کسروی") با این عنوان که او «واسطه افزار جرم» بوده نه عامل آن، وکیل مدافع وی بود؟
  * … **[ام‌تی‌وی](https://fa.wikipedia.org/wiki/%D8%A7%D9%85%E2%80%8C%D8%AA%DB%8C%E2%80%8C%D9%88%DB%8C "ام‌تی‌وی")** نخستین شبکه تلویزیونی جهان بود که به‌طور شبانه‌روزی [موسیقی](https://fa.wikipedia.org/wiki/%D9%85%D9%88%D8%B3%DB%8C%D9%82%DB%8C "موسیقی") پخش می‌کرد؟
  * … **[بهاءالدین ولد](https://fa.wikipedia.org/wiki/%D8%A8%D9%87%D8%A7%D8%A1%D8%A7%D9%84%D8%AF%DB%8C%D9%86_%D9%88%D9%84%D8%AF "بهاءالدین ولد")** نام پدر و **[بهاء ولد](https://fa.wikipedia.org/wiki/%D8%A8%D9%87%D8%A7%D8%A1_%D9%88%D9%84%D8%AF "بهاء ولد")** نام پسر [مولوی](https://fa.wikipedia.org/wiki/%D9%85%D9%88%D9%84%D9%88%DB%8C "مولوی") بوده است؟
  * … **[برج گنبد کاووس](https://fa.wikipedia.org/wiki/%D8%A8%D8%B1%D8%AC_%DA%AF%D9%86%D8%A8%D8%AF_%D9%82%D8%A7%D8%A8%D9%88%D8%B3 "برج گنبد قابوس")** بلندترین بنای آجری دنیا است و بیش از هزارسال قدمت دارد؟
  * … **[یوناتان نتانیاهو](https://fa.wikipedia.org/wiki/%DB%8C%D9%88%D9%86%D8%A7%D8%AA%D8%A7%D9%86_%D9%86%D8%AA%D8%A7%D9%86%DB%8C%D8%A7%D9%87%D9%88 "یوناتان نتانیاهو")** برادر بزرگ‌تر [بنیامین نتانیاهو](https://fa.wikipedia.org/wiki/%D8%A8%D9%86%DB%8C%D8%A7%D9%85%DB%8C%D9%86_%D9%86%D8%AA%D8%A7%D9%86%DB%8C%D8%A7%D9%87%D9%88 "بنیامین نتانیاهو") نخست‌وزیر [اسرائیل](https://fa.wikipedia.org/wiki/%D8%A7%D8%B3%D8%B1%D8%A7%D8%A6%DB%8C%D9%84 "اسرائیل") در جریان عملیات آزادسازی مسافران هواپیمای فرانسوی در ۴ ژوئیه ۱۹۷۶ در فرودگاه انتبه کشته شد؟


![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Symbol_question_fa.svg/20px-Symbol_question_fa.svg.png) **[بیشتر…](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%A2%DB%8C%D8%A7_%D9%85%DB%8C%E2%80%8C%D8%AF%D8%A7%D9%86%D8%B3%D8%AA%DB%8C%D8%AF_%DA%A9%D9%87...%D8%9F/%D9%87%D9%81%D8%AA%D9%87%E2%80%8C%D9%87%D8%A7%DB%8C_%DB%B2%DB%B0%DB%B2%DB%B5_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "ویکی‌پدیا:آیا می‌دانستید که...؟/هفته‌های ۲۰۲۵ \(میلادی\)")** – **[پیشنهاد یک مقاله](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%A2%DB%8C%D8%A7_%D9%85%DB%8C%E2%80%8C%D8%AF%D8%A7%D9%86%D8%B3%D8%AA%DB%8C%D8%AF_%DA%A9%D9%87...%D8%9F/%D9%BE%DB%8C%D8%B4%E2%80%8C%D9%86%D9%88%DB%8C%D8%B3 "ویکی‌پدیا:آیا می‌دانستید که...؟/پیش‌نویس")**
![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/W-circle.svg/40px-W-circle.svg.png) دربارهٔ ویکی‌پدیا [ویرایش](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%88%DB%8C%D8%B1%D8%A7%DB%8C%D8%B4_%D8%B5%D9%81%D8%AD%D9%87/%D8%A7%D9%84%DA%AF%D9%88:%D8%AF%D8%B1%D8%A8%D8%A7%D8%B1%D9%87_%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7 "ویژه:ویرایش صفحه/الگو:درباره ویکی‌پدیا")
**[ویکی‌پدیا](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7 "ویکی‌پدیا")** [دانشنامه‌ای](https://fa.wikipedia.org/wiki/%D8%AF%D8%A7%D9%86%D8%B4%D9%86%D8%A7%D9%85%D9%87 "دانشنامه") [اینترنتی](https://fa.wikipedia.org/wiki/%D9%88%D8%A8 "وب") با بیش از ۳۲۹ زبان با [محتوای آزاد](https://fa.wikipedia.org/wiki/%D9%85%D8%AD%D8%AA%D9%88%D8%A7%DB%8C_%D8%A2%D8%B2%D8%A7%D8%AF "محتوای آزاد") است که با همکاری افراد داوطلب نوشته می‌شود و هر کس که به اینترنت دسترسی داشته باشد می‌تواند مقاله‌های آن را ویرایش کند. هدف _ویکی‌پدیا_ آفرینش و انتشار جهانی یک دانشنامهٔ [آزاد](https://fa.wikipedia.org/wiki/%D9%85%D8%AD%D8%AA%D9%88%D8%A7%DB%8C_%D8%A2%D8%B2%D8%A7%D8%AF "محتوای آزاد") به تمامی زبان‌های زندهٔ دنیاست. با رشد روزافزون این دانشنامه گردانندگان آن در [بنیاد ویکی‌مدیا](https://fa.wikipedia.org/wiki/%D8%A8%D9%86%DB%8C%D8%A7%D8%AF_%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%85%D8%AF%DB%8C%D8%A7 "بنیاد ویکی‌مدیا") چندین پروژهٔ مشابه دیگر همچون [ویکی‌واژه](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%88%D8%A7%DA%98%D9%87 "ویکی‌واژه")، [ویکی‌کتاب](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%DA%A9%D8%AA%D8%A7%D8%A8 "ویکی‌کتاب")، [ویکی‌گفتاورد](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%DA%AF%D9%81%D8%AA%D8%A7%D9%88%D8%B1%D8%AF "ویکی‌گفتاورد")، [ویکی‌خبر](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D8%AE%D8%A8%D8%B1 "ویکی‌خبر")، [ویکی‌دانشگاه](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87 "ویکی‌دانشگاه")، [ویکی‌سفر](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D8%B3%D9%81%D8%B1 "ویکی‌سفر")، [ویکی‌داده](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D8%AF%D8%A7%D8%AF%D9%87 "ویکی‌داده") و [ویکی‌گونه](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%DA%AF%D9%88%D9%86%D9%87 "ویکی‌گونه") را پدیدآوردند. 
**[ویکی‌پدیای فارسی](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7%DB%8C_%D9%81%D8%A7%D8%B1%D8%B3%DB%8C "ویکی‌پدیای فارسی")** دو سال پس از شروع پروژهٔ ویکی‌پدیای انگلیسی، در ۲۸ آذر ۱۳۸۲ (۱۹ دسامبر ۲۰۰۳) فعالیت خود را آغاز کرد و اکنون در ردهٔ **نوزدهم** ویکی‌پدیاها قرار دارد و بزرگترین [دانشنامهٔ فارسی](https://fa.wikipedia.org/wiki/%D9%81%D9%87%D8%B1%D8%B3%D8%AA_%D8%AF%D8%A7%D9%86%D8%B4%D9%86%D8%A7%D9%85%D9%87%E2%80%8C%D9%87%D8%A7%DB%8C_%D9%81%D8%A7%D8%B1%D8%B3%DB%8C "فهرست دانشنامه‌های فارسی") محسوب می‌شود. ویکی‌پدیای فارسی هم اکنون ([۱۰ مهر](https://fa.wikipedia.org/wiki/%DB%B1%DB%B0_%D9%85%D9%87%D8%B1 "۱۰ مهر") [۱۴۰۴](https://fa.wikipedia.org/wiki/%DB%B1%DB%B4%DB%B0%DB%B4_\(%D8%AE%D9%88%D8%B1%D8%B4%DB%8C%D8%AF%DB%8C\) "۱۴۰۴ \(خورشیدی\)") [خورشیدی](https://fa.wikipedia.org/wiki/%DA%AF%D8%A7%D9%87%E2%80%8C%D8%B4%D9%85%D8%A7%D8%B1%DB%8C_%D9%87%D8%AC%D8%B1%DB%8C_%D8%AE%D9%88%D8%B1%D8%B4%DB%8C%D8%AF%DB%8C "گاه‌شماری هجری خورشیدی")) **۱٬۰۵۷٬۷۰۴** نوشتار دارد. 
**[ادامه…](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%A2%D8%B4%D9%86%D8%A7%DB%8C%DB%8C_%D8%A8%D8%A7_%D8%AF%D8%A7%D9%86%D8%B4%D9%86%D8%A7%D9%85%D9%87 "ویکی‌پدیا:آشنایی با دانشنامه")** **[ویکی‌پدیا، بدون نیاز به اینترنت](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%AF%D8%A7%D9%86%D9%84%D9%88%D8%AF_%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7 "ویکی‌پدیا:دانلود ویکی‌پدیا")**
![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Ambox_globe.svg/40px-Ambox_globe.svg.png) از میان خبرها [ویرایش](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%88%DB%8C%D8%B1%D8%A7%DB%8C%D8%B4_%D8%B5%D9%81%D8%AD%D9%87/%D8%A7%D9%84%DA%AF%D9%88:%D8%A7%D8%B2_%D9%85%DB%8C%D8%A7%D9%86_%D8%AE%D8%A8%D8%B1%D9%87%D8%A7/%D9%BE%DB%8C%D8%B4%E2%80%8C%D9%86%D9%88%DB%8C%D8%B3 "ویژه:ویرایش صفحه/الگو:از میان خبرها/پیش‌نویس")
[![پیتر موتاریکا](https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Arthur_Peter_Mutharika_2014_%28cropped%29.jpg/250px-Arthur_Peter_Mutharika_2014_%28cropped%29.jpg)](https://fa.wikipedia.org/wiki/%D9%BE%D8%B1%D9%88%D9%86%D8%AF%D9%87:Arthur_Peter_Mutharika_2014_\(cropped\).jpg "پیتر موتاریکا")
پیتر موتاریکا
  * [پیتر موتاریکا](https://fa.wikipedia.org/wiki/%D9%BE%DB%8C%D8%AA%D8%B1_%D9%85%D9%88%D8%AA%D8%A7%D8%B1%DB%8C%DA%A9%D8%A7 "پیتر موتاریکا") (_در تصویر_) به‌عنوان رئیس‌جمهور مالاوی **[انتخاب شد](https://fa.wikipedia.org/wiki/%D8%A7%D9%86%D8%AA%D8%AE%D8%A7%D8%A8%D8%A7%D8%AA_%D8%B3%D8%B1%D8%A7%D8%B3%D8%B1%DB%8C_%D9%85%D8%A7%D9%84%D8%A7%D9%88%DB%8C_\(%DB%B2%DB%B0%DB%B2%DB%B5\) "انتخابات سراسری مالاوی \(۲۰۲۵\)")**.
  * **[تیفون راگاسا](https://fa.wikipedia.org/wiki/%D8%AA%DB%8C%D9%81%D9%88%D9%86_%D8%B1%D8%A7%DA%AF%D8%A7%D8%B3%D8%A7 "تیفون راگاسا")** در تایوان و فیلیپین دست کم ۲۸ کشته برجای گذاشت.
  * عربستان سعودی و پاکستان توافقنامه‌ای برای دفاع از یکدیگر در برابر حملات **[امضا کردند](https://fa.wikipedia.org/wiki/%D8%AA%D9%88%D8%A7%D9%81%D9%82%E2%80%8C%D9%86%D8%A7%D9%85%D9%87_%D8%B1%D8%A7%D9%87%D8%A8%D8%B1%D8%AF%DB%8C_%D8%AF%D9%81%D8%A7%D8%B9_%D9%85%D8%AA%D9%82%D8%A7%D8%A8%D9%84 "توافق‌نامه راهبردی دفاع متقابل")**.
  * **[رابرت ردفورد](https://fa.wikipedia.org/wiki/%D8%B1%D8%A7%D8%A8%D8%B1%D8%AA_%D8%B1%D8%AF%D9%81%D9%88%D8%B1%D8%AF "رابرت ردفورد")** بازیگر و فیلم‌ساز آمریکایی، در ۸۹ سالگی درگذشت.
  * در عرصهٔ تلویزیون، _[استودیو](https://fa.wikipedia.org/wiki/%D8%A7%D8%B3%D8%AA%D9%88%D8%AF%DB%8C%D9%88_\(%D9%85%D8%AC%D9%85%D9%88%D8%B9%D9%87_%D8%AA%D9%84%D9%88%DB%8C%D8%B2%DB%8C%D9%88%D9%86%DB%8C\) "استودیو \(مجموعه تلویزیونی\)")_ جایزه بهترین مجموعهٔ کمدی و _[پیت](https://fa.wikipedia.org/wiki/%D9%BE%DB%8C%D8%AA_\(%D9%85%D8%AC%D9%85%D9%88%D8%B9%D9%87_%D8%AA%D9%84%D9%88%D8%B2%DB%8C%D9%88%D9%86%DB%8C\) "پیت \(مجموعه تلوزیونی\)")_ جایزه بهترین مجموعهٔ درام را در **[جوایز امی ساعات پربیننده](https://fa.wikipedia.org/wiki/%D9%87%D9%81%D8%AA%D8%A7%D8%AF_%D9%88_%D9%87%D9%81%D8%AA%D9%85%DB%8C%D9%86_%D8%AC%D9%88%D8%A7%DB%8C%D8%B2_%D8%A7%D9%85%DB%8C_%D8%B3%D8%A7%D8%B9%D8%A7%D8%AA_%D9%BE%D8%B1%D8%A8%DB%8C%D9%86%D9%86%D8%AF%D9%87 "هفتاد و هفتمین جوایز امی ساعات پربیننده")** برنده شدند.


  * **[رویدادهای کنونی](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D8%B1%D9%88%DB%8C%D8%AF%D8%A7%D8%AF%D9%87%D8%A7%DB%8C_%DA%A9%D9%86%D9%88%D9%86%DB%8C "درگاه:رویدادهای کنونی")** : 
    * [جنگ غزه](https://fa.wikipedia.org/wiki/%D8%AC%D9%86%DA%AF_%D8%BA%D8%B2%D9%87 "جنگ غزه") ([نسل‌کشی](https://fa.wikipedia.org/wiki/%D9%86%D8%B3%D9%84%E2%80%8C%DA%A9%D8%B4%DB%8C_%D8%BA%D8%B2%D9%87 "نسل‌کشی غزه"))
    * [حملهٔ روسیه به اوکراین](https://fa.wikipedia.org/wiki/%D8%AD%D9%85%D9%84%D9%87_%D8%B1%D9%88%D8%B3%DB%8C%D9%87_%D8%A8%D9%87_%D8%A7%D9%88%DA%A9%D8%B1%D8%A7%DB%8C%D9%86 "حمله روسیه به اوکراین")
    * [جنگ داخلی سودان](https://fa.wikipedia.org/wiki/%D8%AC%D9%86%DA%AF_%D8%AF%D8%A7%D8%AE%D9%84%DB%8C_%D8%B3%D9%88%D8%AF%D8%A7%D9%86_\(%DB%B2%DB%B0%DB%B2%DB%B3%E2%80%93%D8%A7%DA%A9%D9%86%D9%88%D9%86\) "جنگ داخلی سودان \(۲۰۲۳–اکنون\)")
  * **[مرگ‌های اخیر](https://fa.wikipedia.org/wiki/%D9%85%D8%B1%DA%AF%E2%80%8C%D9%87%D8%A7_%D8%AF%D8%B1_%DB%B2%DB%B0%DB%B2%DB%B5 "مرگ‌ها در ۲۰۲۵")** : 
    * [راسل ام. نلسن](https://fa.wikipedia.org/wiki/%D8%B1%D8%A7%D8%B3%D9%84_%D8%A7%D9%85._%D9%86%D9%84%D8%B3%D9%86 "راسل ام. نلسن")
    * [مینگیس کمبل](https://fa.wikipedia.org/wiki/%D9%85%DB%8C%D9%86%DA%AF%DB%8C%D8%B3_%DA%A9%D9%85%D8%A8%D9%84 "مینگیس کمبل")
    * [تیگران کئوسایان](https://fa.wikipedia.org/wiki/%D8%AA%DB%8C%DA%AF%D8%B1%D8%A7%D9%86_%DA%A9%D8%A6%D9%88%D8%B3%D8%A7%DB%8C%D8%A7%D9%86 "تیگران کئوسایان")
    * [آساتا شاکور](https://fa.wikipedia.org/wiki/%D8%A2%D8%B3%D8%A7%D8%AA%D8%A7_%D8%B4%D8%A7%DA%A9%D9%88%D8%B1 "آساتا شاکور")
    * [سمیه رشیدی](https://fa.wikipedia.org/wiki/%D8%B3%D9%85%DB%8C%D9%87_%D8%B1%D8%B4%DB%8C%D8%AF%DB%8C "سمیه رشیدی")
    * [جرج اسموت](https://fa.wikipedia.org/wiki/%D8%AC%D8%B1%D8%AC_%D8%A7%D8%B3%D9%85%D9%88%D8%AA "جرج اسموت")


[به‌روزرسانی از پیش‌نویس کاربران](https://fa.wikipedia.org/w/index.php?title=%D8%A7%D9%84%DA%AF%D9%88:%D8%A7%D8%B2_%D9%85%DB%8C%D8%A7%D9%86_%D8%AE%D8%A8%D8%B1%D9%87%D8%A7/%D9%BE%DB%8C%D8%B4%E2%80%8C%D9%86%D9%88%DB%8C%D8%B3&withJS=MediaWiki:%D8%A7%D9%84%DA%AF%D9%88:%D8%A7%D8%B2_%D9%85%DB%8C%D8%A7%D9%86_%D8%AE%D8%A8%D8%B1%D9%87%D8%A7/%D9%BE%DB%8C%D8%B4%E2%80%8C%D9%86%D9%88%DB%8C%D8%B3.js)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Nuvola_apps_date-fa.png/40px-Nuvola_apps_date-fa.png) یادبودها [ویرایش](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%88%DB%8C%D8%B1%D8%A7%DB%8C%D8%B4_%D8%B5%D9%81%D8%AD%D9%87/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%DB%8C%D8%A7%D8%AF%D8%A8%D9%88%D8%AF%D9%87%D8%A7%DB%8C_%D8%A8%D8%B1%DA%AF%D8%B2%DB%8C%D8%AF%D9%87/%DB%B2_%D8%A7%DA%A9%D8%AA%D8%A8%D8%B1 "ویژه:ویرایش صفحه/ویکی‌پدیا:یادبودهای برگزیده/۲ اکتبر")
**امروز** : پنجشنبه، [۲ اکتبر](https://fa.wikipedia.org/wiki/%DB%B2_%D8%A7%DA%A9%D8%AA%D8%A8%D8%B1 "۲ اکتبر") [۲۰۲۵](https://fa.wikipedia.org/wiki/%DB%B2%DB%B0%DB%B2%DB%B5_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۲۰۲۵ \(میلادی\)") [میلادی](https://fa.wikipedia.org/wiki/%D8%AA%D9%82%D9%88%DB%8C%D9%85_%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C "تقویم میلادی") برابر [۱۰ مهر](https://fa.wikipedia.org/wiki/%DB%B1%DB%B0_%D9%85%D9%87%D8%B1 "۱۰ مهر") [۱۴۰۴](https://fa.wikipedia.org/wiki/%DB%B1%DB%B4%DB%B0%DB%B4_\(%D8%AE%D9%88%D8%B1%D8%B4%DB%8C%D8%AF%DB%8C\) "۱۴۰۴ \(خورشیدی\)") [هجری خورشیدی](https://fa.wikipedia.org/wiki/%DA%AF%D8%A7%D9%87%E2%80%8C%D8%B4%D9%85%D8%A7%D8%B1%DB%8C_%D9%87%D8%AC%D8%B1%DB%8C_%D8%AE%D9%88%D8%B1%D8%B4%DB%8C%D8%AF%DB%8C "گاه‌شماری هجری خورشیدی") و [۹ ربیع‌الثانی](https://fa.wikipedia.org/wiki/%DB%B9_%D8%B1%D8%A8%DB%8C%D8%B9%E2%80%8C%D8%A7%D9%84%D8%AB%D8%A7%D9%86%DB%8C "۹ ربیع‌الثانی") [۱۴۴۷](https://fa.wikipedia.org/wiki/%DB%B1%DB%B4%DB%B4%DB%B7_\(%D9%82%D9%85%D8%B1%DB%8C\) "۱۴۴۷ \(قمری\)") [هجری قمری](https://fa.wikipedia.org/wiki/%DA%AF%D8%A7%D9%87%E2%80%8C%D8%B4%D9%85%D8%A7%D8%B1%DB%8C_%D9%87%D8%AC%D8%B1%DB%8C_%D9%82%D9%85%D8%B1%DB%8C_%D9%82%D8%B1%D8%A7%D8%B1%D8%AF%D8%A7%D8%AF%DB%8C "گاه‌شماری هجری قمری قراردادی") ([UTC](https://fa.wikipedia.org/wiki/%D8%B3%D8%A7%D8%B9%D8%AA_%D9%87%D9%85%D8%A7%D9%87%D9%86%DA%AF_%D8%AC%D9%87%D8%A7%D9%86%DB%8C "ساعت هماهنگ جهانی")) 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Portrait_Gandhi.jpg/120px-Portrait_Gandhi.jpg)](https://fa.wikipedia.org/wiki/%D9%BE%D8%B1%D9%88%D9%86%D8%AF%D9%87:Portrait_Gandhi.jpg)
روز جهانی نفی‌خشونت، در [هندوستان](https://fa.wikipedia.org/wiki/%D9%87%D9%86%D8%AF%D9%88%D8%B3%D8%AA%D8%A7%D9%86 "هندوستان"): روز گاندی جایانتی، در [گینه](https://fa.wikipedia.org/wiki/%DA%AF%DB%8C%D9%86%D9%87 "گینه"): روز استقلال  

رویدادها

  * [۱۳۶۰](https://fa.wikipedia.org/wiki/%DB%B1%DB%B3%DB%B6%DB%B0_\(%D8%AE%D9%88%D8%B1%D8%B4%DB%8C%D8%AF%DB%8C\) "۱۳۶۰ \(خورشیدی\)") - برگزاری **[سومین دوره انتخابات ریاست جمهوری ایران](https://fa.wikipedia.org/wiki/%D8%A7%D9%86%D8%AA%D8%AE%D8%A7%D8%A8%D8%A7%D8%AA_%D8%B1%DB%8C%D8%A7%D8%B3%D8%AA%E2%80%8C%D8%AC%D9%85%D9%87%D9%88%D8%B1%DB%8C_%D8%A7%DB%8C%D8%B1%D8%A7%D9%86_\(%D9%85%D9%87%D8%B1_%DB%B1%DB%B3%DB%B6%DB%B0\) "انتخابات ریاست‌جمهوری ایران \(مهر ۱۳۶۰\)")** و پیروزی [سید علی خامنه‌ای](https://fa.wikipedia.org/wiki/%D8%B3%DB%8C%D8%AF_%D8%B9%D9%84%DB%8C_%D8%AE%D8%A7%D9%85%D9%86%D9%87%E2%80%8C%D8%A7%DB%8C "سید علی خامنه‌ای") در آن
  * [۱۸۳۵](https://fa.wikipedia.org/wiki/%DB%B1%DB%B8%DB%B3%DB%B5_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۸۳۵ \(میلادی\)") - در پی اعلام استقلال استان تجاس از [مکزیک](https://fa.wikipedia.org/wiki/%D9%85%DA%A9%D8%B2%DB%8C%DA%A9 "مکزیک") نبردی مسلحانه میان **[جمهوری تگزاس](https://fa.wikipedia.org/wiki/%D8%AC%D9%85%D9%87%D9%88%D8%B1%DB%8C_%D8%AA%DA%AF%D8%B2%D8%A7%D8%B3 "جمهوری تگزاس")** و [مکزیک](https://fa.wikipedia.org/wiki/%D9%85%DA%A9%D8%B2%DB%8C%DA%A9 "مکزیک") درگرفت که به انقلاب تگزاس یا جنگ استقلال تگزاس شهرت یافت.
  * [۱۹۲۸](https://fa.wikipedia.org/wiki/%DB%B1%DB%B9%DB%B2%DB%B8_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۹۲۸ \(میلادی\)") - [خوزه ماریا اسکریوا](https://fa.wikipedia.org/wiki/%D8%AE%D9%88%D8%B2%D9%87_%D9%85%D8%A7%D8%B1%DB%8C%D8%A7_%D8%A7%D8%B3%DA%A9%D8%B1%DB%8C%D9%88%D8%A7 "خوزه ماریا اسکریوا")، کشیش [کاتولیک](https://fa.wikipedia.org/wiki/%DA%A9%D8%A7%D8%AA%D9%88%D9%84%DB%8C%DA%A9 "کاتولیک") [اسپانیایی](https://fa.wikipedia.org/wiki/%D8%A7%D8%B3%D9%BE%D8%A7%D9%86%DB%8C%D8%A7 "اسپانیا")، سازمان محافظه‌کار کاتولیک **[اپوس دئی](https://fa.wikipedia.org/wiki/%D8%A7%D9%BE%D9%88%D8%B3_%D8%AF%D8%A6%DB%8C "اپوس دئی")** را بنیان‌گذاشت.
  * [۱۹۳۷](https://fa.wikipedia.org/wiki/%DB%B1%DB%B9%DB%B3%DB%B7_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۹۳۷ \(میلادی\)") - **[رافائل تروخیو](https://fa.wikipedia.org/wiki/%D8%B1%D8%A7%D9%81%D8%A7%D8%A6%D9%84_%D8%AA%D8%B1%D9%88%D8%AE%DB%8C%D9%88 "رافائل تروخیو")** حاکم نظامی [جمهوری دومینیکن](https://fa.wikipedia.org/wiki/%D8%AC%D9%85%D9%87%D9%88%D8%B1%DB%8C_%D8%AF%D9%88%D9%85%DB%8C%D9%86%DB%8C%DA%A9%D9%86 "جمهوری دومینیکن")، فرمان کشتار حدود ۲۰ هزار نفر از ساکنان [هائیتی‌تبار](https://fa.wikipedia.org/wiki/%D9%87%D8%A7%D8%A6%DB%8C%D8%AA%DB%8C "هائیتی") در جمهوری دومینیکن را صادر کرد.



زادروزها

  * [۱۴۵۲](https://fa.wikipedia.org/wiki/%DB%B1%DB%B4%DB%B5%DB%B2_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۴۵۲ \(میلادی\)") - زادروز **[ریچارد سوم](https://fa.wikipedia.org/wiki/%D8%B1%DB%8C%DA%86%D8%A7%D8%B1%D8%AF_%D8%B3%D9%88%D9%85_\(%D8%A7%D9%86%DA%AF%D9%84%D8%B3%D8%AA%D8%A7%D9%86\) "ریچارد سوم \(انگلستان\)")** [پادشاه](https://fa.wikipedia.org/wiki/%D9%BE%D8%A7%D8%AF%D8%B4%D8%A7%D9%87 "پادشاه") [انگلستان](https://fa.wikipedia.org/wiki/%D8%A7%D9%86%DA%AF%D9%84%D8%B3%D8%AA%D8%A7%D9%86 "انگلستان").
  * [۱۴۵۳](https://fa.wikipedia.org/wiki/%DB%B1%DB%B4%DB%B5%DB%B3_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۴۵۳ \(میلادی\)") - زادروز **[هیرونیموس بوش](https://fa.wikipedia.org/wiki/%D9%87%DB%8C%D8%B1%D9%88%D9%86%DB%8C%D9%85%D9%88%D8%B3_%D8%A8%D9%88%D8%B4 "هیرونیموس بوش")** [نقاش](https://fa.wikipedia.org/wiki/%D9%86%D9%82%D8%A7%D8%B4 "نقاش") [هلندی](https://fa.wikipedia.org/wiki/%D9%87%D9%84%D9%86%D8%AF "هلند")
  * [۱۸۴۷](https://fa.wikipedia.org/wiki/%DB%B1%DB%B8%DB%B4%DB%B7_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۸۴۷ \(میلادی\)") - زادروز **[پاول فون هیندنبورگ](https://fa.wikipedia.org/wiki/%D9%BE%D8%A7%D9%88%D9%84_%D9%81%D9%88%D9%86_%D9%87%DB%8C%D9%86%D8%AF%D9%86%D8%A8%D9%88%D8%B1%DA%AF "پاول فون هیندنبورگ")** دومین [رئیس‌جمهور](https://fa.wikipedia.org/wiki/%D8%B1%D8%A6%DB%8C%D8%B3%E2%80%8C%D8%AC%D9%85%D9%87%D9%88%D8%B1 "رئیس‌جمهور") [آلمان](https://fa.wikipedia.org/wiki/%D8%A2%D9%84%D9%85%D8%A7%D9%86 "آلمان")
  * [۱۸۵۲](https://fa.wikipedia.org/wiki/%DB%B1%DB%B8%DB%B5%DB%B2_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۸۵۲ \(میلادی\)") - زادروز **[ویلیام رمزی](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%D9%84%DB%8C%D8%A7%D9%85_%D8%B1%D9%85%D8%B2%DB%8C "ویلیام رمزی")** [شیمیدان](https://fa.wikipedia.org/wiki/%D8%B4%DB%8C%D9%85%DB%8C%D8%AF%D8%A7%D9%86 "شیمیدان") [اسکاتلندی](https://fa.wikipedia.org/wiki/%D8%A7%D8%B3%DA%A9%D8%A7%D8%AA%D9%84%D9%86%D8%AF%DB%8C "اسکاتلندی")، برندهٔ [جایزه نوبل شیمی](https://fa.wikipedia.org/wiki/%D8%AC%D8%A7%DB%8C%D8%B2%D9%87_%D9%86%D9%88%D8%A8%D9%84_%D8%B4%DB%8C%D9%85%DB%8C "جایزه نوبل شیمی") سال ۱۹۰۴، کاشف گازهای [نئون](https://fa.wikipedia.org/wiki/%D9%86%D8%A6%D9%88%D9%86 "نئون")، [آرگون](https://fa.wikipedia.org/wiki/%D8%A2%D8%B1%DA%AF%D9%88%D9%86 "آرگون")، [زنون](https://fa.wikipedia.org/wiki/%D8%B2%D9%86%D9%88%D9%86 "زنون")، [هلیوم](https://fa.wikipedia.org/wiki/%D9%87%D9%84%DB%8C%D9%88%D9%85 "هلیوم") و [کریپتون](https://fa.wikipedia.org/wiki/%DA%A9%D8%B1%DB%8C%D9%BE%D8%AA%D9%88%D9%86 "کریپتون")
  * [۱۸۶۹](https://fa.wikipedia.org/wiki/%DB%B1%DB%B8%DB%B6%DB%B9_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۸۶۹ \(میلادی\)") - زادروز **[ماهاتما گاندی](https://fa.wikipedia.org/wiki/%D9%85%D8%A7%D9%87%D8%A7%D8%AA%D9%85%D8%A7_%DA%AF%D8%A7%D9%86%D8%AF%DB%8C "ماهاتما گاندی")** _(در تصویر)_ ، رهبر [جنبش استقلال هند](https://fa.wikipedia.org/wiki/%D8%AC%D9%86%D8%A8%D8%B4_%D8%A7%D8%B3%D8%AA%D9%82%D9%84%D8%A7%D9%84_%D9%87%D9%86%D8%AF "جنبش استقلال هند") از [استعمار](https://fa.wikipedia.org/wiki/%D8%A7%D8%B3%D8%AA%D8%B9%D9%85%D8%A7%D8%B1 "استعمار") [امپراتوری بریتانیا](https://fa.wikipedia.org/wiki/%D8%A7%D9%85%D9%BE%D8%B1%D8%A7%D8%AA%D9%88%D8%B1%DB%8C_%D8%A8%D8%B1%DB%8C%D8%AA%D8%A7%D9%86%DB%8C%D8%A7 "امپراتوری بریتانیا")
  * [۱۹۰۴](https://fa.wikipedia.org/wiki/%DB%B1%DB%B9%DB%B0%DB%B4_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۹۰۴ \(میلادی\)") - زادروز **[گراهام گرین](https://fa.wikipedia.org/wiki/%DA%AF%D8%B1%D8%A7%D9%87%D8%A7%D9%85_%DA%AF%D8%B1%DB%8C%D9%86 "گراهام گرین")** رمان‌نویس، [نمایشنامه‌نویس](https://fa.wikipedia.org/wiki/%D9%86%D9%85%D8%A7%DB%8C%D8%B4%D9%86%D8%A7%D9%85%D9%87%E2%80%8C%D9%86%D9%88%DB%8C%D8%B3 "نمایشنامه‌نویس")، منتقد ادبی و سینمایی و [نویسندهٔ](https://fa.wikipedia.org/wiki/%D9%86%D9%88%DB%8C%D8%B3%D9%86%D8%AF%D9%87 "نویسنده") پرکار داستان‌های کوتاه [انگلیسی](https://fa.wikipedia.org/wiki/%D8%A7%D9%86%DA%AF%D9%84%D8%B3%D8%AA%D8%A7%D9%86 "انگلستان")



درگذشت‌ها

  * [۱۸۵۳](https://fa.wikipedia.org/wiki/%DB%B1%DB%B8%DB%B5%DB%B3_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۸۵۳ \(میلادی\)") - درگذشت **[فرانسوا آراگو](https://fa.wikipedia.org/wiki/%D9%81%D8%B1%D8%A7%D9%86%D8%B3%D9%88%D8%A7_%D8%A2%D8%B1%D8%A7%DA%AF%D9%88 "فرانسوا آراگو")** [ریاضیدان](https://fa.wikipedia.org/wiki/%D8%B1%DB%8C%D8%A7%D8%B6%DB%8C%D8%AF%D8%A7%D9%86 "ریاضیدان")، [فیزیکدان](https://fa.wikipedia.org/wiki/%D9%81%DB%8C%D8%B2%DB%8C%DA%A9%D8%AF%D8%A7%D9%86 "فیزیکدان")، [اخترشناس](https://fa.wikipedia.org/wiki/%D8%A7%D8%AE%D8%AA%D8%B1%D8%B4%D9%86%D8%A7%D8%B3 "اخترشناس") و [سیاست‌مدار](https://fa.wikipedia.org/wiki/%D8%B3%DB%8C%D8%A7%D8%B3%D8%AA%E2%80%8C%D9%85%D8%AF%D8%A7%D8%B1 "سیاست‌مدار") [فرانسوی](https://fa.wikipedia.org/wiki/%D9%81%D8%B1%D8%A7%D9%86%D8%B3%D9%87 "فرانسه")
  * [۱۹۲۰](https://fa.wikipedia.org/wiki/%DB%B1%DB%B9%DB%B2%DB%B0_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۹۲۰ \(میلادی\)") - درگذشت **[ماکس بروخ](https://fa.wikipedia.org/wiki/%D9%85%D8%A7%DA%A9%D8%B3_%D8%A8%D8%B1%D9%88%D8%AE "ماکس بروخ")** [آهنگساز](https://fa.wikipedia.org/wiki/%D8%A2%D9%87%D9%86%DA%AF%D8%B3%D8%A7%D8%B2 "آهنگساز") [آلمانی](https://fa.wikipedia.org/wiki/%D8%A2%D9%84%D9%85%D8%A7%D9%86 "آلمان")
  * [۱۹۲۷](https://fa.wikipedia.org/wiki/%DB%B1%DB%B9%DB%B2%DB%B7_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۹۲۷ \(میلادی\)") - درگذشت **[سوانت آرنیوس](https://fa.wikipedia.org/wiki/%D8%B3%D9%88%D8%A7%D9%86%D8%AA_%D8%A2%D8%B1%D9%86%DB%8C%D9%88%D8%B3 "سوانت آرنیوس")** [شیمیدان](https://fa.wikipedia.org/wiki/%D8%B4%DB%8C%D9%85%DB%8C%D8%AF%D8%A7%D9%86 "شیمیدان") [سوئدی](https://fa.wikipedia.org/wiki/%D8%B3%D9%88%D8%A6%D8%AF "سوئد")، برندهٔ [جایزه نوبل شیمی](https://fa.wikipedia.org/wiki/%D8%AC%D8%A7%DB%8C%D8%B2%D9%87_%D9%86%D9%88%D8%A8%D9%84_%D8%B4%DB%8C%D9%85%DB%8C "جایزه نوبل شیمی") ۱۹۰۳
  * [۱۹۶۸](https://fa.wikipedia.org/wiki/%DB%B1%DB%B9%DB%B6%DB%B8_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۹۶۸ \(میلادی\)") - درگذشت **[مارسل دوشان](https://fa.wikipedia.org/wiki/%D9%85%D8%A7%D8%B1%D8%B3%D9%84_%D8%AF%D9%88%D8%B4%D8%A7%D9%86 "مارسل دوشان")** [نقاش](https://fa.wikipedia.org/wiki/%D9%86%D9%82%D8%A7%D8%B4 "نقاش") و [مجسمه‌ساز](https://fa.wikipedia.org/wiki/%D9%85%D8%AC%D8%B3%D9%85%D9%87%E2%80%8C%D8%B3%D8%A7%D8%B2 "مجسمه‌ساز") [فرانسوی](https://fa.wikipedia.org/wiki/%D9%81%D8%B1%D8%A7%D9%86%D8%B3%D9%87 "فرانسه")
  * [۱۹۷۳](https://fa.wikipedia.org/wiki/%DB%B1%DB%B9%DB%B7%DB%B3_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۹۷۳ \(میلادی\)") - درگذشت **[پاوو نورمی](https://fa.wikipedia.org/wiki/%D9%BE%D8%A7%D9%88%D9%88_%D9%86%D9%88%D8%B1%D9%85%DB%8C "پاوو نورمی")** دونده اهل کشور [فنلاند](https://fa.wikipedia.org/wiki/%D9%81%D9%86%D9%84%D8%A7%D9%86%D8%AF "فنلاند")
  * [۱۹۸۵](https://fa.wikipedia.org/wiki/%DB%B1%DB%B9%DB%B8%DB%B5_\(%D9%85%DB%8C%D9%84%D8%A7%D8%AF%DB%8C\) "۱۹۸۵ \(میلادی\)") - درگذشت **[راک هادسن](https://fa.wikipedia.org/wiki/%D8%B1%D8%A7%DA%A9_%D9%87%D8%A7%D8%AF%D8%B3%D9%86 "راک هادسن")** [بازیگر](https://fa.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B2%DB%8C%DA%AF%D8%B1 "بازیگر")[آمریکایی](https://fa.wikipedia.org/wiki/%D8%A2%D9%85%D8%B1%DB%8C%DA%A9%D8%A7%DB%8C%DB%8C%E2%80%8C%D9%87%D8%A7 "آمریکایی‌ها")


[→ روز قبل](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%DB%8C%D8%A7%D8%AF%D8%A8%D9%88%D8%AF%D9%87%D8%A7%DB%8C_%D8%A8%D8%B1%DA%AF%D8%B2%DB%8C%D8%AF%D9%87/%DB%B1_%D8%A7%DA%A9%D8%AA%D8%A8%D8%B1 "ویکی‌پدیا:یادبودهای برگزیده/۱ اکتبر") – [روز بعد ←](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%DB%8C%D8%A7%D8%AF%D8%A8%D9%88%D8%AF%D9%87%D8%A7%DB%8C_%D8%A8%D8%B1%DA%AF%D8%B2%DB%8C%D8%AF%D9%87/%DB%B3_%D8%A7%DA%A9%D8%AA%D8%A8%D8%B1 "ویکی‌پدیا:یادبودهای برگزیده/۳ اکتبر")  
**[یادبودهای اکتبر](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%DB%8C%D8%A7%D8%AF%D8%A8%D9%88%D8%AF%D9%87%D8%A7%DB%8C_%D8%A8%D8%B1%DA%AF%D8%B2%DB%8C%D8%AF%D9%87/%D8%A7%DA%A9%D8%AA%D8%A8%D8%B1 "ویکی‌پدیا:یادبودهای برگزیده/اکتبر")** – **[یادبودهای بیشتر…](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%DB%8C%D8%A7%D8%AF%D8%A8%D9%88%D8%AF%D9%87%D8%A7%DB%8C_%D8%A8%D8%B1%DA%AF%D8%B2%DB%8C%D8%AF%D9%87 "ویکی‌پدیا:یادبودهای برگزیده")**
![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Symbol_star_blue.svg/40px-Symbol_star_blue.svg.png) نگارهٔ برگزیدهٔ امروز [ویرایش](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%88%DB%8C%D8%B1%D8%A7%DB%8C%D8%B4_%D8%B5%D9%81%D8%AD%D9%87/%D8%A7%D9%84%DA%AF%D9%88:%D9%86%D8%B1_%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%AA_%D8%B4%D8%AF%D9%87/2025-10-02 "ویژه:ویرایش صفحه/الگو:نر محافظت شده/2025-10-02")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Everest_kalapatthar_crop.jpg/960px-Everest_kalapatthar_crop.jpg)](https://fa.wikipedia.org/wiki/%D9%BE%D8%B1%D9%88%D9%86%D8%AF%D9%87:Everest_kalapatthar_crop.jpg) **[اورست](https://fa.wikipedia.org/wiki/%DA%A9%D9%88%D9%87_%D8%A7%D9%88%D8%B1%D8%B3%D8%AA "کوه اورست")** بلندترین کوه و بلندترین نقطهٔ کرهٔ [زمین](https://fa.wikipedia.org/wiki/%D8%B2%D9%85%DB%8C%D9%86 "زمین") است. ارتفاع قلهٔ آن از سطح دریا برابر با ۸۸۴۸٫۸۶ متر (حدوداً ۲۹٬۰۱۵ پا) است. قلهٔ اورست جزو رشته‌کوه [هیمالیا](https://fa.wikipedia.org/wiki/%D9%87%DB%8C%D9%85%D8%A7%D9%84%DB%8C%D8%A7 "هیمالیا") است و در کشور [نپال](https://fa.wikipedia.org/wiki/%D9%86%D9%BE%D8%A7%D9%84 "نپال") قرار دارد.
![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Cscr-featured.svg/20px-Cscr-featured.svg.png) **[بایگانی اکتبر ۲۰۲۵](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D9%86%DA%AF%D8%A7%D8%B1%D9%87_%D8%B1%D9%88%D8%B2/%D8%A7%DA%A9%D8%AA%D8%A8%D8%B1_%DB%B2%DB%B0%DB%B2%DB%B5 "ویکی‌پدیا:نگاره روز/اکتبر ۲۰۲۵")** – **[نگاره‌های برگزیدهٔ بیشتر](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D9%86%DA%AF%D8%A7%D8%B1%D9%87%E2%80%8C%D9%87%D8%A7%DB%8C_%D8%A8%D8%B1%DA%AF%D8%B2%DB%8C%D8%AF%D9%87 "ویکی‌پدیا:نگاره‌های برگزیده")**
![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Text-x-generic.svg/40px-Text-x-generic.svg.png) درون‌مایه [ویرایش](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%88%DB%8C%D8%B1%D8%A7%DB%8C%D8%B4_%D8%B5%D9%81%D8%AD%D9%87/%D8%A7%D9%84%DA%AF%D9%88:%D9%85%D8%AD%D8%AA%D9%88%D8%A7 "ویژه:ویرایش صفحه/الگو:محتوا")
  * **[دانش](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D8%AF%D8%A7%D9%86%D8%B4 "درگاه:دانش")** **[طبیعی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B9%D9%84%D9%88%D9%85_%D8%B7%D8%A8%DB%8C%D8%B9%DB%8C "رده:علوم طبیعی")** و **[صوری](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B9%D9%84%D9%88%D9%85_%D8%B5%D9%88%D8%B1%DB%8C "رده:علوم صوری")**
    * [اخترشناسی](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D8%A7%D8%AE%D8%AA%D8%B1%D8%B4%D9%86%D8%A7%D8%B3%DB%8C "درگاه:اخترشناسی")
    * [زیست‌شناسی](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D8%B2%DB%8C%D8%B3%D8%AA%E2%80%8C%D8%B4%D9%86%D8%A7%D8%B3%DB%8C "درگاه:زیست‌شناسی")
    * [شیمی](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D8%B4%DB%8C%D9%85%DB%8C "درگاه:شیمی")
    * [زمین‌شناسی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B9%D9%84%D9%88%D9%85_%D8%B2%D9%85%DB%8C%D9%86 "رده:علوم زمین")
    * [فیزیک](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D9%81%DB%8C%D8%B2%DB%8C%DA%A9 "درگاه:فیزیک")
    * [آمار](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%A2%D9%85%D8%A7%D8%B1 "رده:آمار")
    * [احتمالات](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%A7%D8%AD%D8%AA%D9%85%D8%A7%D9%84%D8%A7%D8%AA "رده:احتمالات")
    * [ریاضیات](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D8%B1%DB%8C%D8%A7%D8%B6%DB%8C%D8%A7%D8%AA "درگاه:ریاضیات")
    * [سامانه‌ها](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B3%D8%A7%D9%85%D8%A7%D9%86%D9%87%E2%80%8C%D9%87%D8%A7 "رده:سامانه‌ها")
    * [علوم رایانه](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B9%D9%84%D9%88%D9%85_%D8%B1%D8%A7%DB%8C%D8%A7%D9%86%D9%87 "رده:علوم رایانه")
    * [منطق](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%85%D9%86%D8%B7%D9%82 "رده:منطق")
  * **[دانش اجتماعی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B9%D9%84%D9%88%D9%85_%D8%A7%D8%AC%D8%AA%D9%85%D8%A7%D8%B9%DB%8C "رده:علوم اجتماعی")** و **[انسانی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B9%D9%84%D9%88%D9%85_%D8%A7%D9%86%D8%B3%D8%A7%D9%86%DB%8C "رده:علوم انسانی")**
    * [آموزش](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%A2%D9%85%D9%88%D8%B2%D8%B4 "رده:آموزش")
    * [ادبیات](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%A7%D8%AF%D8%A8%DB%8C%D8%A7%D8%AA "رده:ادبیات")
    * [اقتصاد](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF "رده:اقتصاد")
    * [انسان‌شناسی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%A7%D9%86%D8%B3%D8%A7%D9%86%E2%80%8C%D8%B4%D9%86%D8%A7%D8%B3%DB%8C "رده:انسان‌شناسی")
    * [باستان‌شناسی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%A8%D8%A7%D8%B3%D8%AA%D8%A7%D9%86%E2%80%8C%D8%B4%D9%86%D8%A7%D8%B3%DB%8C "رده:باستان‌شناسی")
    * [تاریخ](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D8%AA%D8%A7%D8%B1%DB%8C%D8%AE "درگاه:تاریخ")
    * [جامعه‌شناسی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%AC%D8%A7%D9%85%D8%B9%D9%87%E2%80%8C%D8%B4%D9%86%D8%A7%D8%B3%DB%8C "رده:جامعه‌شناسی")
    * [جغرافیا](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D8%AC%D8%BA%D8%B1%D8%A7%D9%81%DB%8C%D8%A7 "درگاه:جغرافیا")
    * [روان‌شناسی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B1%D9%88%D8%A7%D9%86%E2%80%8C%D8%B4%D9%86%D8%A7%D8%B3%DB%8C "رده:روان‌شناسی")
    * [زبان‌شناسی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B2%D8%A8%D8%A7%D9%86%E2%80%8C%D8%B4%D9%86%D8%A7%D8%B3%DB%8C "رده:زبان‌شناسی")
    * [ارتباطات](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B9%D9%84%D9%88%D9%85_%D8%A7%D8%B1%D8%AA%D8%A8%D8%A7%D8%B7%D8%A7%D8%AA "رده:علوم ارتباطات")
    * [علوم سیاسی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B9%D9%84%D9%88%D9%85_%D8%B3%DB%8C%D8%A7%D8%B3%DB%8C "رده:علوم سیاسی")
    * [فلسفه](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%81%D9%84%D8%B3%D9%81%D9%87 "رده:فلسفه")
  * **[دانش کاربردی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B9%D9%84%D9%88%D9%85_%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%D8%AF%DB%8C "رده:علوم کاربردی")**
    * [پزشکی](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D9%BE%D8%B2%D8%B4%DA%A9%DB%8C "درگاه:پزشکی")
    * [حقوق](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%AD%D9%82%D9%88%D9%82 "رده:حقوق")
    * [رایانه](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B1%D8%A7%DB%8C%D8%A7%D9%86%D9%87 "رده:رایانه")
    * [بهداشت](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B9%D9%84%D9%85_%D8%A8%D9%87%D8%AF%D8%A7%D8%B4%D8%AA "رده:علم بهداشت")
    * [فناوری اطلاعات](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C_%D8%A7%D8%B7%D9%84%D8%A7%D8%B9%D8%A7%D8%AA "رده:فناوری اطلاعات")
    * [فناوری](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C "درگاه:فناوری")
    * [کسب و کار](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%DA%A9%D8%B3%D8%A8_%D9%88_%DA%A9%D8%A7%D8%B1 "رده:کسب و کار")
    * [کشاورزی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%DA%A9%D8%B4%D8%A7%D9%88%D8%B1%D8%B2%DB%8C "رده:کشاورزی")
    * [مدیریت](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%85%D8%AF%DB%8C%D8%B1%DB%8C%D8%AA "رده:مدیریت")
    * [مهندسی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%85%D9%87%D9%86%D8%AF%D8%B3%DB%8C "رده:مهندسی")
  * **[فرهنگ](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%81%D8%B1%D9%87%D9%86%DA%AF "رده:فرهنگ")** و **[هنر](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D9%87%D9%86%D8%B1 "درگاه:هنر")**
    * [بزرگان و مشاهیر](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D8%B2%D9%86%D8%AF%DA%AF%DB%8C%E2%80%8C%D9%86%D8%A7%D9%85%D9%87 "درگاه:زندگی‌نامه")
    * [رسانه‌](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B1%D8%B3%D8%A7%D9%86%D9%87_%DA%AF%D8%B1%D9%88%D9%87%DB%8C "رده:رسانه گروهی")
    * [سرگرمی‌‌](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B3%D8%B1%DA%AF%D8%B1%D9%85%DB%8C%E2%80%8C%D9%87%D8%A7 "رده:سرگرمی‌ها")
    * [هنرهای نمایشی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%87%D9%86%D8%B1%D9%87%D8%A7%DB%8C_%D9%86%D9%85%D8%A7%DB%8C%D8%B4%DB%8C "رده:هنرهای نمایشی")
    * [هنرهای تجسمی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%87%D9%86%D8%B1%D9%87%D8%A7%DB%8C_%D8%AA%D8%AC%D8%B3%D9%85%DB%8C "رده:هنرهای تجسمی")
    * [سینما](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D8%B3%DB%8C%D9%86%D9%85%D8%A7 "رده:سینما")
    * [موسیقی](https://fa.wikipedia.org/wiki/%D8%AF%D8%B1%DA%AF%D8%A7%D9%87:%D9%85%D9%88%D8%B3%DB%8C%D9%82%DB%8C "درگاه:موسیقی")
    * [معماری](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%85%D8%B9%D9%85%D8%A7%D8%B1%DB%8C "رده:معماری")
    * [نقاشی](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%86%D9%82%D8%A7%D8%B4%DB%8C "رده:نقاشی")
    * [ورزش](https://fa.wikipedia.org/wiki/%D8%B1%D8%AF%D9%87:%D9%88%D8%B1%D8%B2%D8%B4 "رده:ورزش")


![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/40px-Wikimedia-logo.svg.png) پروژه‌های خواهر ویکی‌پدیا [ویرایش](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%88%DB%8C%D8%B1%D8%A7%DB%8C%D8%B4_%D8%B5%D9%81%D8%AD%D9%87/%D8%A7%D9%84%DA%AF%D9%88:%D9%BE%D8%B1%D9%88%DA%98%D9%87%E2%80%8C%D9%87%D8%A7%DB%8C_%D8%AE%D9%88%D8%A7%D9%87%D8%B1_%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7 "ویژه:ویرایش صفحه/الگو:پروژه‌های خواهر ویکی‌پدیا")
ویکی‌پدیا توسط ویرایشگران داوطلب نوشته شده و از سوی سازمان ناسودبر [بنیاد ویکی‌مدیا](https://fa.wikipedia.org/wiki/%D8%A8%D9%86%DB%8C%D8%A7%D8%AF_%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%85%D8%AF%DB%8C%D8%A7 "بنیاد ویکی‌مدیا") میزبانی می‌شود که خود میزبان چندین [پروژهٔ](https://wikimediafoundation.org/our-work/wikimedia-projects/ "foundationsite:our-work/wikimedia-projects/") داوطلبانهٔ دیگر نیز هست: 
  * [![لوگوی ویکی‌انبار](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/ "ویکی‌انبار")
[ویکی‌انبار](https://commons.wikimedia.org/wiki/ "c:")  
انبار رسانه‌های آزاد
  * [![لوگوی مدیاویکی](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/ "مدیاویکی")
[مدیاویکی](https://www.mediawiki.org/wiki/ "mw:")  
توسعهٔ نرم‌افزار ویکی
  * [![لوگوی فراویکی](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/ "فراویکی")
[فراویکی](https://meta.wikimedia.org/wiki/ "m:")  
هماهنگی پروژهٔ ویکی‌مدیا
  * [![لوگوی ویکی‌کتاب](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://fa.wikibooks.org/wiki/ "ویکی‌کتاب")
[ویکی‌کتاب](https://fa.wikibooks.org/wiki/ "b:")  
کتاب‌های درسی و راهنماهای آزاد
  * [![لوگوی ویکی‌داده](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "ویکی‌داده")
[ویکی‌داده](https://www.wikidata.org/wiki/ "d:")  
پایگاه دادهٔ آزاد
  * [![لوگوی ویکی‌خبر](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://fa.wikinews.org/wiki/ "ویکی‌خبر")
[ویکی‌خبر](https://fa.wikinews.org/wiki/ "n:")  
اخبار با محتوای آزاد
  * [![لوگوی ویکی‌گفتاورد](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://fa.wikiquote.org/wiki/ "ویکی‌گفتاورد")
[ویکی‌گفتاورد](https://fa.wikiquote.org/wiki/ "q:")  
مجموعه‌ای از نقل قول‌ها
  * [![لوگوی ویکی‌نبشته](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://fa.wikisource.org/wiki/ "ویکی‌نبشته")
[ویکی‌نبشته](https://fa.wikisource.org/wiki/ "s:")  
کتابخانه‌ای با محتوای آزاد
  * [![لوگوی ویکی‌گونه](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/ "ویکی‌گونه")
[ویکی‌گونه](https://species.wikimedia.org/wiki/ "species:")  
فهرست گونه‌ها
  * [![لوگوی ویکی‌دانشگاه](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/60px-Wikiversity_logo_2017.svg.png)](https://en.wikipedia.org/wiki/v: "ویکی‌دانشگاه")
[ویکی‌دانشگاه](https://en.wikipedia.org/wiki/v: "en:v:")  
ابزارهای آموزشی آزاد
  * [![لوگوی ویکی‌سفر](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://fa.wikivoyage.org/wiki/ "ویکی‌سفر")
[ویکی‌سفر](https://fa.wikivoyage.org/wiki/ "voy:")  
راهنمای آزاد سفر
  * [![لوگوی ویکی‌واژه](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://fa.wiktionary.org/wiki/ "ویکی‌واژه")[![لوگوی ویکی‌واژه](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/60px-Wiktionary-logo.svg.png)](https://fa.wiktionary.org/wiki/ "ویکی‌واژه")
[ویکی‌واژه](https://fa.wiktionary.org/wiki/ "wikt:")  
فرهنگ واژگان


![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Wikipedia%27s_W.svg/40px-Wikipedia%27s_W.svg.png) زبان‌های ویکی‌پدیا [ویرایش](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%88%DB%8C%D8%B1%D8%A7%DB%8C%D8%B4_%D8%B5%D9%81%D8%AD%D9%87/%D8%A7%D9%84%DA%AF%D9%88:%D8%B2%D8%A8%D8%A7%D9%86%E2%80%8C%D9%87%D8%A7%DB%8C_%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7 "ویژه:ویرایش صفحه/الگو:زبان‌های ویکی‌پدیا")
ویکی‌پدیای فارسی در سال ۱۳۸۲ بنیان‌گذاری شده و هم‌اکنون [۱٬۰۵۷٬۷۰۴](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%A2%D9%85%D8%A7%D8%B1 "ویژه:آمار") نوشتار دارد. ویکی‌پدیا به زبان‌های بسیاری وجود دارد؛ برخی از بزرگ‌ترین آن‌ها در زیر فهرست شده‌اند. 
۱٬۰۰۰٬۰۰۰+ نوشتار
  * [English](https://en.wikipedia.org/wiki/ "en:")
  * [Deutsch](https://de.wikipedia.org/wiki/ "de:")
  * [Français](https://fr.wikipedia.org/wiki/ "fr:")
  * [Svenska](https://sv.wikipedia.org/wiki/ "sv:")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "nl:")
  * [Русский](https://ru.wikipedia.org/wiki/ "ru:")
  * [Español](https://es.wikipedia.org/wiki/ "es:")
  * [Italiano](https://it.wikipedia.org/wiki/ "it:")
  * [Polski](https://pl.wikipedia.org/wiki/ "pl:")
  * [مصرى](https://arz.wikipedia.org/wiki/ "arz:")
  * [中文](https://zh.wikipedia.org/wiki/ "zh:")
  * [日本語](https://ja.wikipedia.org/wiki/ "ja:")
  * [Українська](https://uk.wikipedia.org/wiki/ "uk:")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vi:")
  * [العربية](https://ar.wikipedia.org/wiki/ "ar:")
  * [Português](https://pt.wikipedia.org/wiki/ "pt:")
  * فارسی


۲۵۰٬۰۰۰+ نوشتار
  * [Català](https://ca.wikipedia.org/wiki/ "ca:")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "id:")
  * [한국어](https://ko.wikipedia.org/wiki/ "ko:")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "sr:")
  * [Norsk](https://no.wikipedia.org/wiki/ "no:")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "tr:")
  * [Нохчийн](https://ce.wikipedia.org/wiki/ "ce:")
  * [Suomi](https://fi.wikipedia.org/wiki/ "fi:")
  * [Čeština](https://cs.wikipedia.org/wiki/ "cs:")
  * [Magyar](https://hu.wikipedia.org/wiki/ "hu:")
  * [Română](https://ro.wikipedia.org/wiki/ "ro:")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/ "tt:")
  * [Euskara](https://eu.wikipedia.org/wiki/ "eu:")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "sh:")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/ "zh-min-nan:")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "ms:")
  * [עברית](https://he.wikipedia.org/wiki/ "he:")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "eo:")
  * [Հայերեն](https://hy.wikipedia.org/wiki/ "hy:")
  * [Dansk](https://da.wikipedia.org/wiki/ "da:")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/ "uz:")
  * [Български](https://bg.wikipedia.org/wiki/ "bg:")
  * [Cymraeg](https://cy.wikipedia.org/wiki/ "cy:")
  * [Simple English](https://simple.wikipedia.org/wiki/ "simple:")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "el:")
  * [Беларуская](https://be.wikipedia.org/wiki/ "be:")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "sk:")
  * [Eesti](https://et.wikipedia.org/wiki/ "et:")


۵۰٬۰۰۰+ نوشتار
  * [تۆرکجه](https://azb.wikipedia.org/wiki/ "azb:")
  * [Қазақша](https://kk.wikipedia.org/wiki/ "kk:")
  * [اردو](https://ur.wikipedia.org/wiki/ "ur:")
  * [Minangkabau](https://min.wikipedia.org/wiki/ "min:")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "hr:")
  * [Galego](https://gl.wikipedia.org/wiki/ "gl:")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "lt:")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/ "az:")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "sl:")
  * [Ქართული](https://ka.wikipedia.org/wiki/ "ka:")
  * [Ladin](https://lld.wikipedia.org/wiki/ "lld:")
  * [தமிழ்](https://ta.wikipedia.org/wiki/ "ta:")
  * [ไทย](https://th.wikipedia.org/wiki/ "th:")
  * [বাংলা](https://bn.wikipedia.org/wiki/ "bn:")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "nn:")
  * [हिन्दी](https://hi.wikipedia.org/wiki/ "hi:")
  * [Македонски](https://mk.wikipedia.org/wiki/ "mk:")
  * [粵語](https://zh-yue.wikipedia.org/wiki/ "zh-yue:")
  * [Latina](https://la.wikipedia.org/wiki/ "la:")
  * [Latviešu](https://lv.wikipedia.org/wiki/ "lv:")
  * [Asturianu](https://ast.wikipedia.org/wiki/ "ast:")
  * [Afrikaans](https://af.wikipedia.org/wiki/ "af:")
  * [తెలుగు](https://te.wikipedia.org/wiki/ "te:")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/ "tg:")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/ "my:")
  * [Shqip](https://sq.wikipedia.org/wiki/ "sq:")
  * [Kiswahili](https://sw.wikipedia.org/wiki/ "sw:")
  * [Malagasy](https://mg.wikipedia.org/wiki/ "mg:")
  * [मराठी](https://mr.wikipedia.org/wiki/ "mr:")
  * [Bosanski](https://bs.wikipedia.org/wiki/ "bs:")
  * [Kurdî](https://ku.wikipedia.org/wiki/ "ku:")
  * [Occitan](https://oc.wikipedia.org/wiki/ "oc:")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/ "be-tarask:")
  * [Brezhoneg](https://br.wikipedia.org/wiki/ "br:")
  * [മലയാളം](https://ml.wikipedia.org/wiki/ "ml:")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/ "nds:")
  * [Lombard](https://lmo.wikipedia.org/wiki/ "lmo:")
  * [کوردی](https://ckb.wikipedia.org/wiki/ "ckb:")
  * [Кыргызча](https://ky.wikipedia.org/wiki/ "ky:")
  * [Jawa](https://jv.wikipedia.org/wiki/ "jv:")
  * [پنجابی](https://pnb.wikipedia.org/wiki/ "pnb:")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/ "new:")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/ "ht:")
  * [Piemontèis](https://pms.wikipedia.org/wiki/ "pms:")
  * [Hausa](https://ha.wikipedia.org/wiki/ "ha:")
  * [Vèneto](https://vec.wikipedia.org/wiki/ "vec:")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/ "lb:")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/ "mzn:")
  * [Башҡортса](https://ba.wikipedia.org/wiki/ "ba:")
  * [Gaeilge](https://ga.wikipedia.org/wiki/ "ga:")
  * [Sunda](https://su.wikipedia.org/wiki/ "su:")
  * [Íslenska](https://is.wikipedia.org/wiki/ "is:")
  * [Ido](https://io.wikipedia.org/wiki/ "io:")
  * [Ślůnski](https://szl.wikipedia.org/wiki/ "szl:")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/ "pa:")
  * [Frysk](https://fy.wikipedia.org/wiki/ "fy:")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/ "cv:")
  * [Aragonés](https://an.wikipedia.org/wiki/ "an:")


[فهرست کامل ویکی‌پدیاها](https://meta.wikimedia.org/wiki/List_of_Wikipedias/fa "meta:List of Wikipedias/fa")
برگرفته از «[https://fa.wikipedia.org/w/index.php?title=صفحهٔ_اصلی&oldid=41777649](https://fa.wikipedia.org/w/index.php?title=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&oldid=41777649)»
۴۶ زبان
  * [العربية](https://ar.wikipedia.org/wiki/ "عربی")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/ "آرامی")
  * [مصرى](https://arz.wikipedia.org/wiki/ "عربی مصری")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/ "ترکی آذربایجانی")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/ "South Azerbaijani")
  * [کوردی](https://ckb.wikipedia.org/wiki/ "کردی مرکزی")
  * [Čeština](https://cs.wikipedia.org/wiki/ "چکی")
  * [Deutsch](https://de.wikipedia.org/wiki/ "آلمانی")
  * [Zazaki](https://diq.wikipedia.org/wiki/ "Dimli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/ "دیوهی")
  * [English](https://en.wikipedia.org/wiki/ "انگلیسی")
  * [Español](https://es.wikipedia.org/wiki/ "اسپانیایی")
  * [Suomi](https://fi.wikipedia.org/wiki/ "فنلاندی")
  * [Français](https://fr.wikipedia.org/wiki/ "فرانسوی")
  * [گیلکی](https://glk.wikipedia.org/wiki/ "گیلکی")
  * [Hausa](https://ha.wikipedia.org/wiki/ "هوسایی")
  * [עברית](https://he.wikipedia.org/wiki/ "عبری")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "کروات")
  * [Հայերեն](https://hy.wikipedia.org/wiki/ "ارمنی")
  * [Italiano](https://it.wikipedia.org/wiki/ "ایتالیایی")
  * [日本語](https://ja.wikipedia.org/wiki/ "ژاپنی")
  * [한국어](https://ko.wikipedia.org/wiki/ "کره‌ای")
  * [کٲشُر](https://ks.wikipedia.org/wiki/ "کشمیری")
  * [Kurdî](https://ku.wikipedia.org/wiki/ "کردی")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/ "مازندرانی")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "هلندی")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "نروژی بوک‌مُل")
  * [Ирон](https://os.wikipedia.org/wiki/ "آسی")
  * [Polski](https://pl.wikipedia.org/wiki/ "لهستانی")
  * [پنجابی](https://pnb.wikipedia.org/wiki/ "پنجابی")
  * [پښتو](https://ps.wikipedia.org/wiki/ "پشتو")
  * [Português](https://pt.wikipedia.org/wiki/ "پرتغالی")
  * [Română](https://ro.wikipedia.org/wiki/ "رومانیایی")
  * [Русский](https://ru.wikipedia.org/wiki/ "روسی")
  * [سنڌي](https://sd.wikipedia.org/wiki/ "سندی")
  * [Simple English](https://simple.wikipedia.org/wiki/ "انگلیسی ساده")
  * [Svenska](https://sv.wikipedia.org/wiki/ "سوئدی")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/ "تاجیکی")
  * [Türkmençe](https://tk.wikipedia.org/wiki/ "ترکمنی")
  * [Tolışi](https://tly.wikipedia.org/wiki/ "Talysh")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "ترکی استانبولی")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/ "اویغوری")
  * [اردو](https://ur.wikipedia.org/wiki/ "اردو")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/ "ازبکی")
  * [ייִדיש](https://yi.wikipedia.org/wiki/ "یدی")
  * [中文](https://zh.wikipedia.org/wiki/ "چینی")


  * این صفحه آخرین‌بار در ۱۳ مهٔ ۲۰۲۵ ساعت ۲۰:۲۳ ویرایش شده است.
  * همهٔ نوشته‌ها تحت [مجوز Creative Commons Attribution/Share-Alike](https://creativecommons.org/licenses/by-sa/4.0/deed.en) در دسترس است؛ برای جزئیات بیشتر [شرایط استفاده](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use) را بخوانید.  
ویکی‌پدیا® علامتی تجاری متعلق به سازمان غیرانتفاعی [بنیاد ویکی‌مدیا](https://www.wikimediafoundation.org/) است.  



  * [سیاست حفظ حریم خصوصی](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [دربارهٔ ویکی‌پدیا](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%AF%D8%B1%D8%A8%D8%A7%D8%B1%D9%87)
  * [تکذیب‌نامه‌ها](https://fa.wikipedia.org/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%BE%D8%AF%DB%8C%D8%A7:%D8%AA%DA%A9%D8%B0%DB%8C%D8%A8%E2%80%8C%D9%86%D8%A7%D9%85%D9%87%D9%94_%D8%B9%D9%85%D9%88%D9%85%DB%8C)
  * [آیین‌نامه رفتاری](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [توسعه‌دهندگان](https://www.mediawiki.org/wiki/How_to_contribute/fa?uselang=fa)
  * [آمار](https://stats.wikimedia.org/#/fa.wikipedia.org)
  * [بیانیهٔ کوکی](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [نمای موبایل](https://fa.wikipedia.org/w/index.php?title=%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C&mobileaction=toggle_view_mobile)
  * [ویرایش تنظیمات پیش‌نمایش](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)


  * [![Wikimedia Foundation](https://fa.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://fa.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


جستجو
جستجو
صفحهٔ اصلی
[](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C) [](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C) [](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C) [](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C) [](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C) [](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C) [](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C) [](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
۴۶ زبان [افزودن مبحث ](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
[](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C?action=edit)
