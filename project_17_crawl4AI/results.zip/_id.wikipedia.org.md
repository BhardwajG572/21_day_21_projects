[Lompat ke isi](https://id.wikipedia.org/wiki/Halaman_Utama#bodyContent)
Menu utama
Menu utama
pindah ke bilah sisi sembunyikan
Navigasi 
  * [Halaman Utama](https://id.wikipedia.org/wiki/Halaman_Utama "Kunjungi Halaman Utama \[z\]")
  * [Daftar isi](https://id.wikipedia.org/wiki/Wikipedia:Isi)
  * [Perubahan terbaru](https://id.wikipedia.org/wiki/Istimewa:Perubahan_terbaru "Daftar perubahan terbaru dalam wiki. \[r\]")
  * [Artikel pilihan](https://id.wikipedia.org/wiki/Wikipedia:Artikel_pilihan/Topik)
  * [Peristiwa terkini](https://id.wikipedia.org/wiki/Portal:Peristiwa_terkini "Temukan informasi tentang peristiwa terkini")
  * [Halaman baru](https://id.wikipedia.org/wiki/Istimewa:Halaman_baru)
  * [Halaman sembarang](https://id.wikipedia.org/wiki/Istimewa:Halaman_sembarang "Tampilkan sembarang halaman \[x\]")
  * [Halaman istimewa](https://id.wikipedia.org/wiki/Istimewa:Halaman_istimewa)


Komunitas 
  * [Warung Kopi](https://id.wikipedia.org/wiki/Wikipedia:Warung_Kopi)
  * [Portal komunitas](https://id.wikipedia.org/wiki/Portal:Komunitas "Tentang proyek, apa yang dapat Anda lakukan, di mana untuk mencari sesuatu")
  * [Bantuan](https://id.wikipedia.org/wiki/Bantuan:Isi "Tempat mencari bantuan.")


Wikipedia 
  * [Tentang Wikipedia](https://id.wikipedia.org/wiki/Wikipedia:Perihal)
  * [Pancapilar](https://id.wikipedia.org/wiki/Wikipedia:Pancapilar)
  * [Kebijakan](https://id.wikipedia.org/wiki/Wikipedia:Kebijakan_dan_pedoman)
  * [Hubungi kami](https://id.wikipedia.org/wiki/Wikipedia:Hubungi_kami)
  * [Bak pasir](https://id.wikipedia.org/wiki/Wikipedia:Bak_pasir)


Bagikan 
[ ![](https://id.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://id.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![Ensiklopedia Bebas](https://id.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-id.svg) ](https://id.wikipedia.org/wiki/Halaman_Utama)
[Pencarian ](https://id.wikipedia.org/wiki/Istimewa:Pencarian "Cari di Wikipedia \[f\]")
Cari
Tampilan
  * [Menyumbang](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=id.wikipedia.org&uselang=id)
  * [Buat akun baru](https://id.wikipedia.org/w/index.php?title=Istimewa:Buat_akun&returnto=Halaman+Utama "Anda dianjurkan untuk membuat akun dan masuk log; meskipun, hal itu tidak diwajibkan")
  * [Masuk log](https://id.wikipedia.org/w/index.php?title=Istimewa:Masuk_log&returnto=Halaman+Utama "Anda disarankan untuk masuk log, meskipun hal itu tidak diwajibkan. \[o\]")


Perkakas pribadi
  * [Menyumbang](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=id.wikipedia.org&uselang=id)
  * [Buat akun baru](https://id.wikipedia.org/w/index.php?title=Istimewa:Buat_akun&returnto=Halaman+Utama "Anda dianjurkan untuk membuat akun dan masuk log; meskipun, hal itu tidak diwajibkan")
  * [Masuk log](https://id.wikipedia.org/w/index.php?title=Istimewa:Masuk_log&returnto=Halaman+Utama "Anda disarankan untuk masuk log, meskipun hal itu tidak diwajibkan. \[o\]")


# Halaman Utama
  * [Utama](https://id.wikipedia.org/wiki/Halaman_Utama "Lihat halaman isi \[c\]")
  * [Pembicaraan](https://id.wikipedia.org/wiki/Pembicaraan:Halaman_Utama "Pembicaraan halaman isi \[t\]")


Bahasa Indonesia
  * [Baca](https://id.wikipedia.org/wiki/Halaman_Utama)
  * [Lihat sumber](https://id.wikipedia.org/w/index.php?title=Halaman_Utama&action=edit "Halaman ini dilindungi. Anda hanya dapat melihat sumbernya. \[e\]")
  * [Lihat riwayat](https://id.wikipedia.org/w/index.php?title=Halaman_Utama&action=history "Revisi sebelumnya dari halaman ini. \[h\]")


Perkakas
Perkakas
pindah ke bilah sisi sembunyikan
Tindakan 
  * [Baca](https://id.wikipedia.org/wiki/Halaman_Utama)
  * [Lihat sumber](https://id.wikipedia.org/w/index.php?title=Halaman_Utama&action=edit)
  * [Lihat riwayat](https://id.wikipedia.org/w/index.php?title=Halaman_Utama&action=history)


Umum 
  * [Pranala balik](https://id.wikipedia.org/wiki/Istimewa:Pranala_balik/Halaman_Utama "Daftar semua halaman wiki yang memiliki pranala ke halaman ini \[j\]")
  * [Perubahan terkait](https://id.wikipedia.org/wiki/Istimewa:Perubahan_terkait/Halaman_Utama "Perubahan terbaru halaman-halaman yang memiliki pranala ke halaman ini \[k\]")
  * [Pranala permanen](https://id.wikipedia.org/w/index.php?title=Halaman_Utama&oldid=26846860 "Pranala permanen untuk revisi halaman ini")
  * [Informasi halaman](https://id.wikipedia.org/w/index.php?title=Halaman_Utama&action=info "Informasi lanjut tentang halaman ini")
  * [Kutip halaman ini](https://id.wikipedia.org/w/index.php?title=Istimewa:Kutip&page=Halaman_Utama&id=26846860&wpFormIdentifier=titleform "Informasi tentang bagaimana mengutip halaman ini")
  * [Lihat URL pendek](https://id.wikipedia.org/w/index.php?title=Istimewa:UrlShortener&url=https%3A%2F%2Fid.wikipedia.org%2Fwiki%2FHalaman_Utama)
  * [Unduh kode QR](https://id.wikipedia.org/w/index.php?title=Istimewa:QrCode&url=https%3A%2F%2Fid.wikipedia.org%2Fwiki%2FHalaman_Utama)


Cetak/ekspor 
  * [Buat buku](https://id.wikipedia.org/w/index.php?title=Istimewa:Buku&bookcmd=book_creator&referer=Halaman+Utama)
  * [Unduh versi PDF](https://id.wikipedia.org/w/index.php?title=Istimewa:DownloadAsPdf&page=Halaman_Utama&action=show-download-screen)
  * [Versi cetak](https://id.wikipedia.org/w/index.php?title=Halaman_Utama&printable=yes "Versi cetak halaman ini \[p\]")


Dalam proyek lain 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Wikisumber multibahasa](https://wikisource.org/wiki/Main_Page)
  * [Wikispesies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikibuku](https://id.wikibooks.org/wiki/Halaman_Utama)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifungsi](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikikutip](https://id.wikiquote.org/wiki/Halaman_Utama)
  * [Wikisumber](https://id.wikisource.org/wiki/Halaman_Utama)
  * [Wikiwisata](https://id.wikivoyage.org/wiki/Halaman_Utama)
  * [Wikikamus](https://id.wiktionary.org/wiki/Wikikamus:Halaman_Utama)
  * [Butir di Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Pranala untuk menghubungkan butir pada ruang penyimpanan data \[g\]")


Tampilan
pindah ke bilah sisi sembunyikan
Dari Wikipedia bahasa Indonesia, ensiklopedia bebas
Selamat datang di [Wikipedia](https://id.wikipedia.org/wiki/Wikipedia "Wikipedia"),
sebuah [ensiklopedia](https://id.wikipedia.org/wiki/Ensiklopedia "Ensiklopedia") [bebas](https://id.wikipedia.org/wiki/Isi_bebas "Isi bebas") yang [bisa disunting oleh siapa saja](https://id.wikipedia.org/wiki/Wikipedia:Pengantar "Wikipedia:Pengantar").
**[745.877 artikel](https://id.wikipedia.org/wiki/Istimewa:Statistik "Istimewa:Statistik")** dalam **[bahasa Indonesia](https://id.wikipedia.org/wiki/Bahasa_Indonesia "Bahasa Indonesia")**.
  * [Biografi](https://id.wikipedia.org/wiki/Portal:Biografi "Portal:Biografi")
  * [Geografi](https://id.wikipedia.org/wiki/Portal:Geografi "Portal:Geografi")
  * [Ilmu](https://id.wikipedia.org/wiki/Portal:Ilmu "Portal:Ilmu")
  * [Sejarah](https://id.wikipedia.org/wiki/Portal:Sejarah "Portal:Sejarah")
  * [Kimia](https://id.wikipedia.org/wiki/Portal:Kimia "Portal:Kimia")
  * [Teknologi](https://id.wikipedia.org/wiki/Portal:Teknologi "Portal:Teknologi")
  * [Komunitas](https://id.wikipedia.org/wiki/Portal:Komunitas "Portal:Komunitas")
  * [Seni](https://id.wikipedia.org/wiki/Portal:Seni "Portal:Seni")
  * **[Semua portal](https://id.wikipedia.org/wiki/Portal:Daftar_portal "Portal:Daftar portal")**


## 
![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/HSUtvald.svg/40px-HSUtvald.svg.png)
Artikel pilihan
_**[Penumpasan Pengkhianatan G30S/PKI](https://id.wikipedia.org/wiki/Penumpasan_Pengkhianatan_G30S/PKI "Penumpasan Pengkhianatan G30S/PKI")**_ adalah judul [film](https://id.wikipedia.org/wiki/Film "Film") [dokudrama](https://id.wikipedia.org/wiki/Dokudrama "Dokudrama") [propaganda](https://id.wikipedia.org/wiki/Film_propaganda "Film propaganda") [Indonesia](https://id.wikipedia.org/wiki/Indonesia "Indonesia") tahun [1984](https://id.wikipedia.org/wiki/1984 "1984"). Film ini [disutradarai](https://id.wikipedia.org/wiki/Sutradara "Sutradara") dan ditulis oleh [Arifin C Noer](https://id.wikipedia.org/wiki/Arifin_C_Noer "Arifin C Noer"), diproduseri oleh [G. Dwipayana](https://id.wikipedia.org/wiki/Gufran_Dwipayana "Gufran Dwipayana"), dan dibintangi [Amoroso Katamsi](https://id.wikipedia.org/wiki/Amoroso_Katamsi "Amoroso Katamsi"), [Umar Kayam](https://id.wikipedia.org/wiki/Umar_Kayam "Umar Kayam"), dan [Syubah Asa](https://id.wikipedia.org/wiki/Syubah_Asa "Syubah Asa"). Diproduksi selama dua tahun dengan anggaran sebesar [Rp](https://id.wikipedia.org/wiki/Rp "Rp"). 800 juta kala itu, film ini disponsori oleh pemerintahan [Orde Baru](https://id.wikipedia.org/wiki/Orde_Baru "Orde Baru") [Soeharto](https://id.wikipedia.org/wiki/Soeharto "Soeharto"). Film ini dibuat berdasarkan pada versi resmi menurut pemerintah kala itu dari peristiwa "[Gerakan 30 September](https://id.wikipedia.org/wiki/Gerakan_30_September "Gerakan 30 September")" atau "G30S" (peristiwa percobaan [kudeta](https://id.wikipedia.org/wiki/Kudeta "Kudeta") pada tahun 1965) yang ditulis oleh [Nugroho Notosusanto](https://id.wikipedia.org/wiki/Nugroho_Notosusanto "Nugroho Notosusanto") dan [Ismail Saleh](https://id.wikipedia.org/wiki/Ismail_Saleh "Ismail Saleh"), yang menggambarkan peristiwa kudeta ini didalangi oleh [Partai Komunis Indonesia](https://id.wikipedia.org/wiki/Partai_Komunis_Indonesia "Partai Komunis Indonesia") atau PKI. **([Selengkapnya...](https://id.wikipedia.org/wiki/Penumpasan_Pengkhianatan_G_30_S_PKI "Penumpasan Pengkhianatan G 30 S PKI"))**
Artikel pilihan sebelumnya: [Gertie the Dinosaur](https://id.wikipedia.org/wiki/Gertie_the_Dinosaur "Gertie the Dinosaur") – [Undang-Undang Nürnberg](https://id.wikipedia.org/wiki/Undang-Undang_N%C3%BCrnberg "Undang-Undang Nürnberg") – [Departures](https://id.wikipedia.org/wiki/Departures "Departures")
[Arsip](https://id.wikipedia.org/wiki/Wikipedia:Artikel_pilihan/2025 "Wikipedia:Artikel pilihan/2025") – [Artikel pilihan lainnya](https://id.wikipedia.org/wiki/Wikipedia:Artikel_pilihan "Wikipedia:Artikel pilihan") (**[Daftar](https://id.wikipedia.org/wiki/Wikipedia:Artikel_pilihan/Topik "Wikipedia:Artikel pilihan/Topik")** — **[Sembarang](https://id.wikipedia.org/wiki/Istimewa:Sembarang_di_kategori/Semua_artikel_pilihan "Istimewa:Sembarang di kategori/Semua artikel pilihan")**) 
## 
![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/PL_Wiki_Aktualnosci_ikona.svg/38px-PL_Wiki_Aktualnosci_ikona.svg.png)
Peristiwa terkini
[![Marc Márquez pada 2025](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Marc_M%C3%A1rquez_at_Estrella_Galicia_stand_during_2025_Dutch_TT.jpg/120px-Marc_M%C3%A1rquez_at_Estrella_Galicia_stand_during_2025_Dutch_TT.jpg)](https://id.wikipedia.org/wiki/Berkas:Marc_M%C3%A1rquez_at_Estrella_Galicia_stand_during_2025_Dutch_TT.jpg "Marc Márquez pada 2025")
Marc Márquez
  * [Pemerintah Federal Amerika Serikat](https://id.wikipedia.org/wiki/Pemerintah_Federal_Amerika_Serikat "Pemerintah Federal Amerika Serikat") **[ditutup](https://id.wikipedia.org/w/index.php?title=Penutupan_pemerintahan_federal_Amerika_Serikat_2025&action=edit&redlink=1 "Penutupan pemerintahan federal Amerika Serikat 2025 \(halaman belum tersedia\)")** karena ketiadaan tindakan dari [Kongres](https://id.wikipedia.org/wiki/Kongres_Amerika_Serikat "Kongres Amerika Serikat") dalam mengesahkan undang-undang alokasi anggaran [tahun fiskal 2026](https://id.wikipedia.org/w/index.php?title=Anggaran_federal_Amerika_Serikat_2025&action=edit&redlink=1 "Anggaran federal Amerika Serikat 2025 \(halaman belum tersedia\)").
  * **[Gempa bumi](https://id.wikipedia.org/wiki/Gempa_bumi_Cebu_2025 "Gempa bumi Cebu 2025")** dengan magnitudo 6,9 melanda [Cebu](https://id.wikipedia.org/wiki/Provinsi_Cebu "Provinsi Cebu"), [Filipina](https://id.wikipedia.org/wiki/Filipina "Filipina"), menewaskan 70 orang.
  * **[Unjuk rasa](https://id.wikipedia.org/wiki/Unjuk_rasa_Madagaskar_2025 "Unjuk rasa Madagaskar 2025")** di [Madagaskar](https://id.wikipedia.org/wiki/Madagaskar "Madagaskar") menewaskan 22 orang.
  * [Partai Aksi dan Solidaritas](https://id.wikipedia.org/wiki/Partai_Aksi_dan_Solidaritas "Partai Aksi dan Solidaritas") yang dipimpin [Igor Grosu](https://id.wikipedia.org/wiki/Igor_Grosu "Igor Grosu") memenangkan mayoritas kursi dalam **[pemilihan parlemen Moldova](https://id.wikipedia.org/w/index.php?title=Pemilihan_umum_Parlemen_Moldova_2025&action=edit&redlink=1 "Pemilihan umum Parlemen Moldova 2025 \(halaman belum tersedia\)")**.
  * Dalam [olahraga otomotif](https://id.wikipedia.org/wiki/Olahraga_otomotif "Olahraga otomotif"), [Marc Márquez](https://id.wikipedia.org/wiki/Marc_M%C3%A1rquez "Marc Márquez") _(gambar)_ menjuarai **[Kejuaraan Dunia FIM MotoGP 2025](https://id.wikipedia.org/wiki/MotoGP_musim_2025 "MotoGP musim 2025")**.


**[Sedang berlangsung](https://id.wikipedia.org/wiki/Portal:Peristiwa_terkini "Portal:Peristiwa terkini")** :      [Perang Sudan](https://id.wikipedia.org/wiki/Perang_Saudara_Sudan_\(2023%E2%80%93sekarang\) "Perang Saudara Sudan \(2023–sekarang\)")      [Perang Gaza](https://id.wikipedia.org/wiki/Perang_Israel%E2%80%93Hamas "Perang Israel–Hamas") ([genosida](https://id.wikipedia.org/wiki/Genosida_Gaza "Genosida Gaza"))     [Invasi Ukraina oleh Rusia](https://id.wikipedia.org/wiki/Invasi_Ukraina_oleh_Rusia "Invasi Ukraina oleh Rusia")
**[Kematian terkini](https://id.wikipedia.org/wiki/Wikipedia:Laporan_basis_data/Kematian_terkini "Wikipedia:Laporan basis data/Kematian terkini")** :      [Ngogesa Sitepu](https://id.wikipedia.org/wiki/Ngogesa_Sitepu "Ngogesa Sitepu")     [Claudia Cardinale](https://id.wikipedia.org/wiki/Claudia_Cardinale "Claudia Cardinale")     [Abdul Aziz bin Abdullah Alu Syaikh](https://id.wikipedia.org/wiki/Abdul_Aziz_bin_Abdullah_Alu_Syaikh "Abdul Aziz bin Abdullah Alu Syaikh")     [David Kroyanker](https://id.wikipedia.org/wiki/David_Kroyanker "David Kroyanker")     [Stanislav Lakoba](https://id.wikipedia.org/wiki/Stanislav_Lakoba "Stanislav Lakoba")     [Fumio Ueda](https://id.wikipedia.org/wiki/Fumio_Ueda "Fumio Ueda")
  * **[Peristiwa terkini lainnya...](https://id.wikipedia.org/wiki/Portal:Peristiwa_terkini "Portal:Peristiwa terkini")**


## 
![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/PL_Wiki_CzyWiesz_ikona.svg/38px-PL_Wiki_CzyWiesz_ikona.svg.png)
Tahukah Anda
[![{{{title}}}](https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Cameron_R_Hume.jpg/120px-Cameron_R_Hume.jpg)](https://id.wikipedia.org/wiki/Berkas:Cameron_R_Hume.jpg "Cameron R. Hume")  
[Cameron R. Hume](https://id.wikipedia.org/wiki/Cameron_R._Hume "Cameron R. Hume")
  * "... bahwa **[Cameron R. Hume](https://id.wikipedia.org/wiki/Cameron_R._Hume "Cameron R. Hume")** , Duta Besar Amerika Serikat untuk Indonesia masa jabatan 2007–2010, diangkat menjadi penasihat [Sinar Mas Group](https://id.wikipedia.org/wiki/Sinar_Mas_Group "Sinar Mas Group") beberapa bulan setelah jabatannya berakhir?"
  * "... bahwa **[mikrobiologi pangan](https://id.wikipedia.org/wiki/Mikrobiologi_pangan "Mikrobiologi pangan")** menelaah [mikroorganisme](https://id.wikipedia.org/wiki/Mikroorganisme "Mikroorganisme") yang mendiami, membuat, hingga yang merusak [makanan](https://id.wikipedia.org/wiki/Makanan "Makanan")?"
  * "... bahwa segala bentuk [desain](https://id.wikipedia.org/wiki/Desain "Desain") yang meminimalisasi dampak destruktif terhadap [lingkungan](https://id.wikipedia.org/wiki/Lingkungan "Lingkungan") dengan mengintegrasikan diri dengan proses terkait makhluk hidup disebut sebagai **[desain ekologis](https://id.wikipedia.org/wiki/Desain_ekologis "Desain ekologis")**?"
  * "... bahwa fenomena begitu cepatnya rekonstruksi dan perkembangan ekonomi [Jerman Barat](https://id.wikipedia.org/wiki/Jerman_Barat "Jerman Barat") dan [Austria](https://id.wikipedia.org/wiki/Austria "Austria") setelah [Perang Dunia II](https://id.wikipedia.org/wiki/Perang_Dunia_II "Perang Dunia II") disebut sebagai _**[Wirtschaftswunder](https://id.wikipedia.org/wiki/Wirtschaftswunder "Wirtschaftswunder")**_ yang berarti 'keajaiban ekonomi'?"


[Arsip](https://id.wikipedia.org/wiki/Wikipedia:Tahukah_Anda "Wikipedia:Tahukah Anda") · [Memulai artikel baru](https://id.wikipedia.org/wiki/Wikipedia:Artikel_pertama_Anda "Wikipedia:Artikel pertama Anda")
## 
![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/HSSamarbetecolor.svg/40px-HSSamarbetecolor.svg.png)
Tantangan kolaborasi
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/OOjs_UI_icon_heart-progressive.svg/20px-OOjs_UI_icon_heart-progressive.svg.png)](https://id.wikipedia.org/wiki/Berkas:OOjs_UI_icon_heart-progressive.svg) **Kolaborasi artikel baru**
Wikipedia membutuhkan artikel-artikel berikut. Mari bersama-sama merintisnya pada **Oktober 2025.** 

Tantangan kolaborasi

  * [People's Choice Awards ke-32](https://id.wikipedia.org/w/index.php?title=People%27s_Choice_Awards_ke-32&action=edit&redlink=1 "People's Choice Awards ke-32 \(halaman belum tersedia\)") ([en](https://en.wikipedia.org/wiki/32nd_People%27s_Choice_Awards "en:32nd People's Choice Awards"))
  * [Tara, Oblast Omsk](https://id.wikipedia.org/w/index.php?title=Tara,_Oblast_Omsk&action=edit&redlink=1 "Tara, Oblast Omsk \(halaman belum tersedia\)") ([en](https://en.wikipedia.org/wiki/Tara,_Omsk_Oblast "en:Tara, Omsk Oblast"))
  * [Kegubernuran Saratov](https://id.wikipedia.org/w/index.php?title=Kegubernuran_Saratov&action=edit&redlink=1 "Kegubernuran Saratov \(halaman belum tersedia\)") ([en](https://en.wikipedia.org/wiki/Saratov_Governorate "en:Saratov Governorate"))
  * [Costume Designers Guild Award untuk Keunggulan dalam Film Sci-Fi/Fantasi](https://id.wikipedia.org/w/index.php?title=Costume_Designers_Guild_Award_untuk_Keunggulan_dalam_Film_Sci-Fi/Fantasi&action=edit&redlink=1 "Costume Designers Guild Award untuk Keunggulan dalam Film Sci-Fi/Fantasi \(halaman belum tersedia\)") ([en](https://en.wikipedia.org/wiki/Costume_Designers_Guild_Award_for_Excellence_in_Sci-Fi/Fantasy_Film "en:Costume Designers Guild Award for Excellence in Sci-Fi/Fantasy Film"))
  * [Manga memasak](https://id.wikipedia.org/w/index.php?title=Manga_memasak&action=edit&redlink=1 "Manga memasak \(halaman belum tersedia\)") ([en](https://en.wikipedia.org/wiki/Cooking_manga "en:Cooking manga"))
  * [Teen Choice Awards 2006](https://id.wikipedia.org/w/index.php?title=Teen_Choice_Awards_2006&action=edit&redlink=1 "Teen Choice Awards 2006 \(halaman belum tersedia\)") ([en](https://en.wikipedia.org/wiki/2006_Teen_Choice_Awards "en:2006 Teen Choice Awards"))
  * [Arleta, Los Angeles](https://id.wikipedia.org/w/index.php?title=Arleta,_Los_Angeles&action=edit&redlink=1 "Arleta, Los Angeles \(halaman belum tersedia\)") ([en](https://en.wikipedia.org/wiki/Arleta,_Los_Angeles "en:Arleta, Los Angeles"))
  * [Penembakan Beit Hanoun 2006](https://id.wikipedia.org/w/index.php?title=Penembakan_Beit_Hanoun_2006&action=edit&redlink=1 "Penembakan Beit Hanoun 2006 \(halaman belum tersedia\)") ([en](https://en.wikipedia.org/wiki/2006_shelling_of_Beit_Hanoun "en:2006 shelling of Beit Hanoun"))
  * [Kegubernuran Nizhny Novgorod](https://id.wikipedia.org/w/index.php?title=Kegubernuran_Nizhny_Novgorod&action=edit&redlink=1 "Kegubernuran Nizhny Novgorod \(halaman belum tersedia\)") ([en](https://en.wikipedia.org/wiki/Nizhny_Novgorod_Governorate "en:Nizhny Novgorod Governorate"))
  * [Bolshoy Irgiz](https://id.wikipedia.org/w/index.php?title=Bolshoy_Irgiz&action=edit&redlink=1 "Bolshoy Irgiz \(halaman belum tersedia\)") ([en](https://en.wikipedia.org/wiki/Bolshoy_Irgiz "en:Bolshoy Irgiz"))



Hasil kolaborasi terbaru

  * [Guslitsa](https://id.wikipedia.org/wiki/Guslitsa "Guslitsa") ([en](https://en.wikipedia.org/wiki/Guslitsa "en:Guslitsa"))
  * [Kegubernuran Perm](https://id.wikipedia.org/wiki/Kegubernuran_Perm "Kegubernuran Perm") ([en](https://en.wikipedia.org/wiki/Perm_Governorate "en:Perm Governorate"))
  * [Suku Kazak Nekrasov](https://id.wikipedia.org/wiki/Suku_Kazak_Nekrasov "Suku Kazak Nekrasov") ([en](https://en.wikipedia.org/wiki/Nekrasov_Cossacks "en:Nekrasov Cossacks"))
  * [American Cinema Editors Award untuk Penyuntingan Film Terbaik – Komedi atau Musikal](https://id.wikipedia.org/wiki/American_Cinema_Editors_Award_untuk_Penyuntingan_Film_Terbaik_%E2%80%93_Komedi_atau_Musikal "American Cinema Editors Award untuk Penyuntingan Film Terbaik – Komedi atau Musikal") ([en](https://en.wikipedia.org/wiki/American_Cinema_Editors_Award_for_Best_Edited_Feature_Film_%E2%80%93_Comedy_or_Musical "en:American Cinema Editors Award for Best Edited Feature Film – Comedy or Musical"))
  * [Popovtsi](https://id.wikipedia.org/wiki/Popovtsi "Popovtsi") ([en](https://en.wikipedia.org/wiki/Popovtsy "en:Popovtsy"))


**[Panduan menerjemahkan artikel](https://id.wikipedia.org/wiki/Wikipedia:Panduan_dalam_menerjemahkan_artikel "Wikipedia:Panduan dalam menerjemahkan artikel")** · **[Arsip halaman yang telah dibuat](https://id.wikipedia.org/wiki/Wikipedia:Modul_partisipasi/Halaman_yang_telah_dibuat "Wikipedia:Modul partisipasi/Halaman yang telah dibuat")**
## 
![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/PL_Wiki_Kalendarium_ikona.svg/38px-PL_Wiki_Kalendarium_ikona.svg.png)
Hari ini dalam sejarah
**[2 Oktober](https://id.wikipedia.org/wiki/2_Oktober "2 Oktober")** : **[Hari Anti Kekerasan Sedunia](https://id.wikipedia.org/wiki/Hari_Anti_Kekerasan_Sedunia "Hari Anti Kekerasan Sedunia")** ; **[Gandhi Jayanti](https://id.wikipedia.org/wiki/Gandhi_Jayanti "Gandhi Jayanti")** di India 
[![{{{title}}}](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Batik_Indonesia.jpg/120px-Batik_Indonesia.jpg)](https://id.wikipedia.org/wiki/Berkas:Batik_Indonesia.jpg "Batik")  
[Batik](https://id.wikipedia.org/wiki/Batik "Batik")
  * **[1187](https://id.wikipedia.org/wiki/1187 "1187")** - [Pengepungan Yerusalem](https://id.wikipedia.org/wiki/Pengepungan_Yerusalem_\(1187\) "Pengepungan Yerusalem \(1187\)"): [Salahuddin Ayyubi](https://id.wikipedia.org/wiki/Salahuddin_Ayyubi "Salahuddin Ayyubi") merebut [Yerusalem](https://id.wikipedia.org/wiki/Yerusalem "Yerusalem").
  * **[1935](https://id.wikipedia.org/wiki/1935 "1935")** - [Italia](https://id.wikipedia.org/wiki/Italia "Italia") menginvasi Abisinia ([Ethiopia](https://id.wikipedia.org/wiki/Ethiopia "Ethiopia")).
  * **[1941](https://id.wikipedia.org/wiki/1941 "1941")** - [Perang Dunia II](https://id.wikipedia.org/wiki/Perang_Dunia_II "Perang Dunia II"): Dimulainya [Pertempuran Moskwa](https://id.wikipedia.org/wiki/Pertempuran_Moskwa "Pertempuran Moskwa").
  * **[1958](https://id.wikipedia.org/wiki/1958 "1958")** - [Guinea](https://id.wikipedia.org/wiki/Guinea "Guinea") merdeka dari [Prancis](https://id.wikipedia.org/wiki/Prancis "Prancis").
  * **[1990](https://id.wikipedia.org/wiki/1990 "1990")** - Sebuah [Boeing 737](https://id.wikipedia.org/wiki/Boeing_737 "Boeing 737")-247 milik maskapai penerbangan Tiongkok dibajak dan menabrak dua pesawat lainnya ketika mendarat di [Guangzhou](https://id.wikipedia.org/wiki/Guangzhou "Guangzhou"), menewaskan 132 orang.
  * **[2009](https://id.wikipedia.org/wiki/2009 "2009")** - [UNESCO](https://id.wikipedia.org/wiki/UNESCO "UNESCO") menetapkan [batik](https://id.wikipedia.org/wiki/Batik "Batik") sebagai warisan budaya manusia untuk dunia dari [Indonesia](https://id.wikipedia.org/wiki/Indonesia "Indonesia").


Tanggal lain: [1 Oktober](https://id.wikipedia.org/wiki/1_Oktober "1 Oktober") – **[2 Oktober](https://id.wikipedia.org/wiki/2_Oktober "2 Oktober")** – [3 Oktober](https://id.wikipedia.org/wiki/3_Oktober "3 Oktober")
**[Kirim via surel](https://lists.wikimedia.org/postorius/lists/daily-article-l.lists.wikimedia.org/ "mail:daily-article-l")** – **[Daftar tanggal](https://id.wikipedia.org/wiki/Wikipedia:Kalender_peristiwa "Wikipedia:Kalender peristiwa")** – **[Ulang tahun](https://id.wikipedia.org/wiki/Wikipedia:Laporan_basis_data/Ulang_tahun_hari_ini "Wikipedia:Laporan basis data/Ulang tahun hari ini")**
Hari ini tanggal 2 Oktober 2025 ([UTC](https://id.wikipedia.org/wiki/Coordinated_Universal_Time "Coordinated Universal Time")) – [Muat ulang](https://id.wikipedia.org/w/index.php?title=Halaman_Utama&action=purge)
## 
![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/PL_Wiki_InM_ikona.svg/38px-PL_Wiki_InM_ikona.svg.png)
Gambar pilihan
[![Sebuah desa kecil di tengah sawah di Banaue, Filipina.](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/Batad_houses.jpg/250px-Batad_houses.jpg)](https://id.wikipedia.org/wiki/Berkas:Batad_houses.jpg "Sebuah desa kecil di tengah sawah di Banaue, Filipina.")
Sebuah desa kecil di tengah sawah di [Banaue](https://id.wikipedia.org/wiki/Banaue,_Ifugao "Banaue, Ifugao"), [Filipina](https://id.wikipedia.org/wiki/Filipina "Filipina").  
_(ukuran asli: 2.992 × 3.992 piksel, 16,08 MB)_
[Arsip Gambar Pilihan](https://id.wikipedia.org/wiki/Wikipedia:Gambar_pilihan/2025 "Wikipedia:Gambar pilihan/2025")  
« [Minyak zaitun, salah satu bahan penting dalam masakan Timur Tengah.](https://id.wikipedia.org/wiki/Berkas:Egyptian_Olives.jpg "Berkas:Egyptian Olives.jpg")
Oleh: Vinnie Cartabiano  
Lisensi: [CC BY 2.0](https://id.wikipedia.org/wiki/Lisensi_Creative_Commons "Lisensi Creative Commons")  

[Lainnya](https://id.wikipedia.org/wiki/Wikipedia:Gambar_pilihan "Wikipedia:Gambar pilihan")
## 
![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Wikimedia-logo-circle.svg/40px-Wikimedia-logo-circle.svg.png)
Proyek Wikimedia lain
**Wikipedia bahasa Indonesia** , ensiklopedia bebas dalam bahasa Indonesia, disediakan secara gratis oleh [Wikimedia Foundation](https://id.wikipedia.org/wiki/Wikimedia_Foundation "Wikimedia Foundation"), sebuah organisasi nirlaba. Selain dalam bahasa Indonesia, Wikipedia tersedia dalam beberapa bahasa lain yang dipertuturkan di Indonesia: [Aceh](https://ace.wikipedia.org/wiki/ "ace:"), [Bali](https://ban.wikipedia.org/wiki/ "ban:"), [Banjar](https://bjn.wikipedia.org/wiki/ "bjn:"), [Banyumas](https://map-bms.wikipedia.org/wiki/ "map-bms:"), [Batak Toba](https://bbc.wikipedia.org/wiki/ "bbc:"), [Betawi](https://bew.wikipedia.org/wiki/ "bew:"), [Bugis](https://bug.wikipedia.org/wiki/ "bug:"), [Gorontalo](https://gor.wikipedia.org/wiki/ "gor:"), [Iban](https://iba.wikipedia.org/wiki/ "iba:"), [Jawa](https://jv.wikipedia.org/wiki/ "jv:"), [Komering](https://kge.wikipedia.org/wiki/ "kge:"), [Madura](https://mad.wikipedia.org/wiki/ "mad:"), [Batak Mandailing](https://btm.wikipedia.org/wiki/ "btm:"), [Melayu](https://ms.wikipedia.org/wiki/ "ms:"), [Minangkabau](https://min.wikipedia.org/wiki/ "min:"), [Nias](https://nia.wikipedia.org/wiki/ "nia:"), [Sunda](https://su.wikipedia.org/wiki/ "su:"), dan [Tetun](https://tet.wikipedia.org/wiki/ "tet:")
Wikimedia Foundation juga mengoperasikan sejumlah [proyek multibahasa](https://meta.wikimedia.org/wiki/Wikipedia "m:Wikipedia") lain: 
[![Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/Halaman_Utama "Wikimedia Commons") |  **[Commons](https://commons.wikimedia.org/wiki/Halaman_Utama "c:Halaman Utama")**  
Repositori media bebas  |  |  [![Wikikamus](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://id.wiktionary.org/wiki/ "Wikikamus") |  **[Wikikamus](https://id.wiktionary.org/wiki/ "wikt:")**  
Kamus multibahasa bebas  |  |  [![Wikisumber](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://id.wikisource.org/wiki/ "Wikisumber") |  **[Wikisumber](https://id.wikisource.org/wiki/ "s:")**  
Naskah sumber bebas  |  |  [![Wikibooks](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://id.wikibooks.org/wiki/ "Wikibooks") |  **[Wikibuku](https://id.wikibooks.org/wiki/ "b:")**  
Sumber buku bebas   
---|---|---|---|---|---|---|---|---|---|---  
[![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/Wikidata:Halaman_Utama "Wikidata") |  **[Wikidata](https://en.wikipedia.org/wiki/Wikidata:Halaman_Utama "w:Wikidata:Halaman Utama")**  
Basis data terbuka  |  |  [![Wikikutip](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://id.wikiquote.org/wiki/ "Wikikutip") |  **[Wikikutip](https://id.wikiquote.org/wiki/ "q:")**  
Koleksi kutipan  |  |  [![Wikispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/Halaman_Utama "Wikispecies") |  **[Wikispesies](https://species.wikimedia.org/wiki/Halaman_Utama "species:Halaman Utama")**  
Direktori spesies  |  |  [![Wikiversity](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/40px-Wikiversity_logo_2017.svg.png)](https://en.wikiversity.org/wiki/ "Wikiversity") |  **[Wikiversitas](https://en.wikiversity.org/wiki/ "wikiversity:")**  
Materi belajar   
[![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://en.wikivoyage.org/wiki/ "Wikivoyage") |  **[Wikiwisata](https://id.wikivoyage.org/wiki/ "voy:")**  
Panduan perjalanan wisata  |  |  [![Wikiberita](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://en.wikinews.org/wiki/ "Wikiberita") |  **[Wikiberita](https://en.wikinews.org/wiki/ "wikinews:")**  
Sumber berita bebas  |  |  [![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/20px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/Main_Page/id "Meta-Wiki") |  **[Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page/id "m:Main Page/id")**  
Koordinasi proyek Wikimedia  |  |  [![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/MediaWiki/id "MediaWiki") |  **[MediaWiki](https://www.mediawiki.org/wiki/MediaWiki/id "mw:MediaWiki/id")**  
Perangkat lunak MediaWiki   
[![logo Inkubator](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Incubator-logo.svg/40px-Incubator-logo.svg.png)](https://incubator.wikimedia.org/wiki/ "logo Inkubator") |  **[Inkubator](https://incubator.wikimedia.org/wiki/ "incubator:")**  
Situs untuk mempersiapkan proyek baru  |  |  [![logo Wikimania](https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Wikimania.svg/40px-Wikimania.svg.png)](https://wikimania.wikimedia.org/wiki/ "logo Wikimania") |  **[Wikimania](https://wikimania.wikimedia.org/wiki/ "wmania:")**  
Konferensi internasional tahunan  |  |  [![Wikimedia Foundation](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/40px-Wikimedia-logo.svg.png)](https://foundation.wikimedia.org/wiki/ "Wikimedia Foundation") |  **[Wikimedia Foundation](https://foundation.wikimedia.org/wiki/ "wmf:")**  
Organisasi yang menaungi proyek-proyek di atas |  |  [![Wikimedia Indonesia](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Wikimedia_Indonesia.svg/40px-Wikimedia_Indonesia.svg.png)](https://foundation.wikimedia.org/wiki/ "Wikimedia Indonesia") |  **[Wikimedia Indonesia](https://id.wikimedia.org/wiki/ "wmid:")**  
Afiliasi Wikimedia Foundation di Indonesia   
[Wikipedia tidak menjamin keabsahan isi artikel](https://id.wikipedia.org/wiki/Wikipedia:Penyangkalan_umum "Wikipedia:Penyangkalan umum").
[Wikimedia Foundation](https://id.wikipedia.org/wiki/Wikimedia_Foundation "Wikimedia Foundation") tidak bertanggung jawab atas isi Wikipedia. Setiap penulis bertanggung jawab atas suntingannya masing-masing.
[![Hubungi kami](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7b/Crystal_128_mail.png/40px-Crystal_128_mail.png)](https://id.wikipedia.org/wiki/Wikipedia:Hubungi_kami "Wikipedia:Hubungi kami") _[Butuh bantuan? Hubungi kami!](https://id.wikipedia.org/wiki/Wikipedia:Hubungi_kami "Wikipedia:Hubungi kami")_
Diperoleh dari "[https://id.wikipedia.org/w/index.php?title=Halaman_Utama&oldid=26846860](https://id.wikipedia.org/w/index.php?title=Halaman_Utama&oldid=26846860)"
Kategori tersembunyi: 
  * [Halaman Utama](https://id.wikipedia.org/wiki/Kategori:Halaman_Utama "Kategori:Halaman Utama")


353 bahasa
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – Afar")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – Abkhaz")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – Aceh")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – Adygei")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – Afrikaans")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – Jerman \(Swiss\)")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – Altai Selatan")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – Amharik")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – Aragon")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – Inggris Kuno")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – Obolo")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – Angika")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – Arab")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – Aram")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – Arab Maroko")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – Arab Mesir")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – Assam")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – Asturia")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – Atikamekw")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – Avar")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – Awadhi")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – Aymara")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – Azerbaijani")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – Bashkir")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Bali")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – Bavaria")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – Samogitian")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusia")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – Betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница – Bulgaria")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – Bislama")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – Bambara")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – Bengali")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – Tibet")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – Breton")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – Bosnia")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – Bugis")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – Katalan")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – Chechen")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – Cebuano")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – Chamorro")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – Koktaw")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – Cherokee")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – Cheyenne")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – Kurdi Sorani")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – Korsika")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – Kree")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – Tatar Krimea")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana – Ceko")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – Kashubia")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – Bahasa Gereja Slavonia")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – Chuvash")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – Welsh")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside – Dansk")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – Jerman")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – Dinka")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – Sorbia Hilir")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – Central Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – Divehi")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – Dzongkha")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – Ewe")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – Yunani")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – Inggris")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – Esperanto")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – Spanyol")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht – Estonia")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala – Basque")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – Extremaduran")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – Persia")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – Fanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – Fula")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – Suomi")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – Võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – Fiji")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – Faroe")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – Fon")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal – Prancis")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – Arpitan")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – Frisia Utara")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – Friuli")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – Frisia Barat")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – Irlandia")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – Gagauz")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – Gan")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – Gaelik Skotlandia")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – Galisia")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – Gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – Guarani")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – Gorontalo")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – Gotik")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – Gujarat")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – Wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – Manx")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – Hausa")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – Hakka Chinese")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – Hawaii")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – Ibrani")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – Hindi")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – Hindi Fiji")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – Hiri Motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – Kroasia")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – Sorbia Hulu")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Kreol Haiti")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – Hungaria")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ – Armenia")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – Herero")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – Interlingua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – Iban")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – Interlingue")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – Igbo")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – Inupiak")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – Iloko")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – Ingushetia")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – Ido")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – Islandia")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – Italia")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – Inuktitut")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – Jepang")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – Jamaican Creole English")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – Lojban")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – Jawa")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – Georgia")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – Kara-Kalpak")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – Kabyle")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – Kabardi")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – Tyap")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – Kongo")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – Kikuyu")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – Kuanyama")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – Kazakh")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – Kalaallisut")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – Khmer")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – Kannada")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – Korea")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – Komi-Permyak")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – Kanuri")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – Karachai Balkar")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – Kashmir")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – Dialek Kolsch")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – Kurdi")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – Komi")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – Kornish")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – Kirgiz")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima – Latin")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – Ladino")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – Luksemburg")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – Lezghia")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – Ganda")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – Limburgia")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – Liguria")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – Lombard")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – Lingala")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – Lao")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – Luri Utara")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – Lituania")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – Latgalian")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – Latvia")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – Madura")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – Maithili")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – Moksha")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – Malagasi")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – Marshall")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – Maori")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – Minangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – Makedonia")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – Malayalam")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – Mongolia")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – Manipuri")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – Mossi")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – Marathi")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – Western Mari")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – Melayu")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – Malta")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – Bahasa Muskogee")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – Miranda")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – Burma")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – Eryza")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – Mazanderani")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – Neapolitan")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – Jerman Rendah")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – Low Saxon")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – Nepali")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – Newari")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – Ndonga")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – Nias")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina – Belanda")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – Nynorsk Norwegia")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – Bokmål Norwegia")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – Novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – N’Ko")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – Ndebele Selatan")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – Sotho Utara")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – Navajo")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – Nyanja")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – Ositania")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – Oromo")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – Oriya")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – Ossetia")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – Punjabi")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – Pangasina")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – Pampanga")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – Papiamento")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – Picard")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – Pidgin Nigeria")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – Jerman Pennsylvania")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – Palatine German")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – Pali")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – Polski")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – Piedmontese")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – Pontic")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – Pashto")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – Portugis")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – Quechua")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – Reto-Roman")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – Rundi")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – Rumania")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – Aromania")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – Rusia")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – Rusyn")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – Kinyarwanda")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – Sanskerta")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – Sakha")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – Santali")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – Sardinia")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – Sisilia")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – Skotlandia")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – Sindhi")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – Sami Utara")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – Sango")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – Serbo-Kroasia")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – Tachelhit")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – Shan")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – Sinhala")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – Slovak")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – Slovenia")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – Samoa")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – Inari Sami")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – Shona")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – Somalia")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – Albania")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – Serbia")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – Sranan Tongo")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – Swati")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – Sotho Selatan")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – Saterland Frisian")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – Sunda")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – Swedia")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – Swahili")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – Silesia")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – Tamil")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – Tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – Telugu")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – Tetun")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – Tajik")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – Thai")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – Tigrinya")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – Tigre")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – Turkmen")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – Tagalog")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – Talysh")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – Tswana")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – Tonga")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – Tok Pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – Turki")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – Taroko")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – Tsonga")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – Tatar")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – Tumbuka")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – Twi")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – Tahiti")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – Tuvinia")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – Udmurt")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – Uyghur")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – Ukraina")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – Urdu")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – Uzbek")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – Venda")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – Venesia")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – Veps")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – Vietnam")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – West Flemish")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – Volapuk")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – Walloon")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – Warai")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – Wolof")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – Wu Tionghoa")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – Kalmuk")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – Xhosa")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – Mingrelian")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – Yiddish")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – Yoruba")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – Zhuang")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – Zeelandic")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – Tamazight Maroko Standar")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 – Tionghoa")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – Literary Chinese")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – Minnan")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – Kanton")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – Zulu")


[Sunting pranala](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Sunting pranala interwiki")
  * Halaman ini terakhir diubah pada 27 Januari 2025, pukul 05.55.
  * Teks tersedia di bawah [Lisensi Atribusi-BerbagiSerupa Creative Commons](https://creativecommons.org/licenses/by-sa/4.0/deed.en); ketentuan tambahan mungkin berlaku. Lihat [Ketentuan Penggunaan](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use) untuk rincian lebih lanjut.


  * [Kebijakan privasi](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Tentang Wikipedia](https://id.wikipedia.org/wiki/Wikipedia:Tentang)
  * [Penyangkalan](https://id.wikipedia.org/wiki/Wikipedia:Penyangkalan_umum)
  * [Kode Etik](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Pengembang](https://developer.wikimedia.org)
  * [Statistik](https://stats.wikimedia.org/#/id.wikipedia.org)
  * [Pernyataan kuki](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Tampilan seluler](https://id.m.wikipedia.org/w/index.php?title=Halaman_Utama&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://id.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://id.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Pencarian
Cari
Halaman Utama
[](https://id.wikipedia.org/wiki/Halaman_Utama) [](https://id.wikipedia.org/wiki/Halaman_Utama) [](https://id.wikipedia.org/wiki/Halaman_Utama) [](https://id.wikipedia.org/wiki/Halaman_Utama) [](https://id.wikipedia.org/wiki/Halaman_Utama) [](https://id.wikipedia.org/wiki/Halaman_Utama) [](https://id.wikipedia.org/wiki/Halaman_Utama) [](https://id.wikipedia.org/wiki/Halaman_Utama)
353 bahasa [Bagian baru ](https://id.wikipedia.org/wiki/Halaman_Utama)
