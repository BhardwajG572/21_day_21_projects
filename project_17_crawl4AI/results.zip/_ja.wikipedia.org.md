[コンテンツにスキップ](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8#bodyContent)
メインメニュー
メインメニュー
サイドバーに移動 非表示
案内 
  * [メインページ](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページに移動する \[alt-z\]")
  * [コミュニティ・ポータル](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%B3%E3%83%9F%E3%83%A5%E3%83%8B%E3%83%86%E3%82%A3%E3%83%BB%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "このプロジェクトについて、できること、情報を入手する場所")
  * [最近の出来事](https://ja.wikipedia.org/wiki/Portal:%E6%9C%80%E8%BF%91%E3%81%AE%E5%87%BA%E6%9D%A5%E4%BA%8B "最近の出来事の背景を知る")
  * [新しいページ](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E6%96%B0%E3%81%97%E3%81%84%E3%83%9A%E3%83%BC%E3%82%B8 "最近新規に作成されたページの一覧")
  * [最近の更新](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E6%9C%80%E8%BF%91%E3%81%AE%E6%9B%B4%E6%96%B0 "このウィキにおける最近の更新の一覧 \[alt-r\]")
  * [おまかせ表示](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E3%81%8A%E3%81%BE%E3%81%8B%E3%81%9B%E8%A1%A8%E7%A4%BA "無作為に選択されたページを読み込む \[alt-x\]")
  * [練習用ページ](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%B5%E3%83%B3%E3%83%89%E3%83%9C%E3%83%83%E3%82%AF%E3%82%B9 "練習用のページ")
  * [アップロード (ウィキメディア・コモンズ)](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=ja "画像やメディアファイルをウィキメディア・コモンズにアップロード")
  * [特別ページ](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E7%89%B9%E5%88%A5%E3%83%9A%E3%83%BC%E3%82%B8%E4%B8%80%E8%A6%A7)


ヘルプ 
  * [ヘルプ](https://ja.wikipedia.org/wiki/Help:%E7%9B%AE%E6%AC%A1 "情報を得る場所")
  * [利用案内](https://ja.wikipedia.org/wiki/Wikipedia:%E5%88%A9%E7%94%A8%E6%A1%88%E5%86%85)
  * [井戸端](https://ja.wikipedia.org/wiki/Wikipedia:%E4%BA%95%E6%88%B8%E7%AB%AF "プロジェクトについての意見交換")
  * [お知らせ](https://ja.wikipedia.org/wiki/Wikipedia:%E3%81%8A%E7%9F%A5%E3%82%89%E3%81%9B "プロジェクトについてのお知らせ")
  * [バグの報告](https://ja.wikipedia.org/wiki/Wikipedia:%E3%83%90%E3%82%B0%E3%81%AE%E5%A0%B1%E5%91%8A "ウィキペディア・ソフトウェアのバグ報告")
  * [ウィキペディアに関するお問い合わせ](https://ja.wikipedia.org/wiki/Wikipedia:%E9%80%A3%E7%B5%A1%E5%85%88 "ウィキペディアやウィキメディア財団に関する連絡先")


[ ![](https://ja.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://ja.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-ja.svg) ![](https://ja.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-ja.svg) ](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
[検索 ](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E6%A4%9C%E7%B4%A2 "Wikipedia内を検索 \[alt-f\]")
検索
表示
表示
サイドバーに移動 非表示
テキスト
  * 小
標準
大

このページは常に小さいフォントサイズを使用します
幅
  * 標準
広め

コンテンツはブラウザウインドウに対して、できるだけ広くします。
色 (ベータ)
  * 自動
ライト
ダーク

このページは常にライトモードです。
  * [寄付](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ja.wikipedia.org&uselang=ja)
  * [アカウント作成](https://ja.wikipedia.org/w/index.php?title=%E7%89%B9%E5%88%A5:%E3%82%A2%E3%82%AB%E3%82%A6%E3%83%B3%E3%83%88%E4%BD%9C%E6%88%90&returnto=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "アカウントを作成してログインすることをお勧めしますが、必須ではありません")
  * [ログイン](https://ja.wikipedia.org/w/index.php?title=%E7%89%B9%E5%88%A5:%E3%83%AD%E3%82%B0%E3%82%A4%E3%83%B3&returnto=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "ログインすることを推奨します。ただし、必須ではありません。 \[alt-o\]")


個人用ツール
  * [寄付](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ja.wikipedia.org&uselang=ja)
  * [アカウント作成](https://ja.wikipedia.org/w/index.php?title=%E7%89%B9%E5%88%A5:%E3%82%A2%E3%82%AB%E3%82%A6%E3%83%B3%E3%83%88%E4%BD%9C%E6%88%90&returnto=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "アカウントを作成してログインすることをお勧めしますが、必須ではありません")
  * [ログイン](https://ja.wikipedia.org/w/index.php?title=%E7%89%B9%E5%88%A5:%E3%83%AD%E3%82%B0%E3%82%A4%E3%83%B3&returnto=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "ログインすることを推奨します。ただし、必須ではありません。 \[alt-o\]")


# メインページ
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Edit_Protection.svg/30px-Edit_Protection.svg.png)](https://ja.wikipedia.org/wiki/Wikipedia:%E4%BF%9D%E8%AD%B7%E3%81%AE%E6%96%B9%E9%87%9D)
  * [メインページ](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "コンテンツページを表示 \[alt-c\]")
  * [ノート](https://ja.wikipedia.org/wiki/%E3%83%8E%E3%83%BC%E3%83%88:%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "コンテンツページについての議論 \[alt-t\]")


日本語
  * [閲覧](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
  * [ソースを閲覧](https://ja.wikipedia.org/w/index.php?title=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&action=edit "このページは保護されています。
ページのソースを閲覧できます。 \[alt-e\]")
  * [履歴を表示](https://ja.wikipedia.org/w/index.php?title=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&action=history "このページの過去の版 \[alt-h\]")


ツール
ツール
サイドバーに移動 非表示
操作 
  * [閲覧](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
  * [ソースを閲覧](https://ja.wikipedia.org/w/index.php?title=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&action=edit)
  * [履歴を表示](https://ja.wikipedia.org/w/index.php?title=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&action=history)


全般 
  * [リンク元](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E3%83%AA%E3%83%B3%E3%82%AF%E5%85%83/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "ここにリンクしている全ウィキページの一覧 \[alt-j\]")
  * [関連ページの更新状況](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E9%96%A2%E9%80%A3%E3%83%9A%E3%83%BC%E3%82%B8%E3%81%AE%E6%9B%B4%E6%96%B0%E7%8A%B6%E6%B3%81/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "このページからリンクしているページの最近の更新 \[alt-k\]")
  * [ファイルをアップロード](https://ja.wikipedia.org/wiki/Wikipedia:%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB%E3%81%AE%E3%82%A2%E3%83%83%E3%83%97%E3%83%AD%E3%83%BC%E3%83%89 "ファイルをアップロードする \[alt-u\]")
  * [この版への固定リンク](https://ja.wikipedia.org/w/index.php?title=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&oldid=93774786 "このページのこの版への固定リンク")
  * [ページ情報](https://ja.wikipedia.org/w/index.php?title=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&action=info "このページについての詳細情報")
  * [このページを引用](https://ja.wikipedia.org/w/index.php?title=%E7%89%B9%E5%88%A5:%E3%81%93%E3%81%AE%E3%83%9A%E3%83%BC%E3%82%B8%E3%82%92%E5%BC%95%E7%94%A8&page=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&id=93774786&wpFormIdentifier=titleform "このページの引用方法")
  * [短縮URLを取得する](https://ja.wikipedia.org/w/index.php?title=%E7%89%B9%E5%88%A5:UrlShortener&url=https%3A%2F%2Fja.wikipedia.org%2Fwiki%2F%25E3%2583%25A1%25E3%2582%25A4%25E3%2583%25B3%25E3%2583%259A%25E3%2583%25BC%25E3%2582%25B8)
  * [QRコードをダウンロード](https://ja.wikipedia.org/w/index.php?title=%E7%89%B9%E5%88%A5:QrCode&url=https%3A%2F%2Fja.wikipedia.org%2Fwiki%2F%25E3%2583%25A1%25E3%2582%25A4%25E3%2583%25B3%25E3%2583%259A%25E3%2583%25BC%25E3%2582%25B8)


印刷/書き出し 
  * [ブックの新規作成](https://ja.wikipedia.org/w/index.php?title=%E7%89%B9%E5%88%A5:%E3%83%96%E3%83%83%E3%82%AF&bookcmd=book_creator&referer=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
  * [PDF 形式でダウンロード](https://ja.wikipedia.org/w/index.php?title=%E7%89%B9%E5%88%A5:DownloadAsPdf&page=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&action=show-download-screen)
  * [印刷用バージョン](https://ja.wikipedia.org/w/index.php?title=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&printable=yes "このページの印刷用ページ \[alt-p\]")


他のプロジェクト 
  * [コモンズ](https://commons.wikimedia.org/wiki/Main_Page)
  * [ウィキメディア財団](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [メタウィキ](https://meta.wikimedia.org/wiki/Main_Page)
  * [ウィキメディア・アウトリーチ](https://outreach.wikimedia.org/wiki/Main_Page)
  * [多言語ウィキソース](https://wikisource.org/wiki/Main_Page)
  * [ウィキスピーシーズ](https://species.wikimedia.org/wiki/Main_Page)
  * [ウィキブックス](https://ja.wikibooks.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
  * [ウィキデータ](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [ウィキファンクションズ](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [ウィキニュース](https://ja.wikinews.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
  * [ウィキクォート](https://ja.wikiquote.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
  * [ウィキソース](https://ja.wikisource.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
  * [ウィキバーシティ](https://ja.wikiversity.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
  * [ウィキボヤージュ](https://ja.wikivoyage.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
  * [ウィクショナリー](https://ja.wiktionary.org/wiki/Wiktionary:%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
  * [ウィキデータ項目](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "関連付けられたデータリポジトリ項目へのリンク \[alt-g\]")


出典: フリー百科事典『ウィキペディア（Wikipedia）』
[ウィキペディア](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%9A%E3%83%87%E3%82%A3%E3%82%A2%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6 "Wikipedia:ウィキペディアについて")へようこそ
ウィキペディアは[誰でも編集できる](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%9A%E3%83%87%E3%82%A3%E3%82%A2%E3%81%B8%E3%82%88%E3%81%86%E3%81%93%E3%81%9D "Wikipedia:ウィキペディアへようこそ")[フリー](https://ja.wikipedia.org/wiki/%E3%82%AA%E3%83%BC%E3%83%97%E3%83%B3%E3%82%B3%E3%83%B3%E3%83%86%E3%83%B3%E3%83%88 "オープンコンテント")[百科事典](https://ja.wikipedia.org/wiki/%E7%99%BE%E7%A7%91%E4%BA%8B%E5%85%B8 "百科事典")です
**[1,475,069](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E7%B5%B1%E8%A8%88 "特別:統計")** 本の[記事](https://ja.wikipedia.org/wiki/Help:%E8%A8%98%E4%BA%8B%E3%81%A8%E3%81%AF%E4%BD%95%E3%81%8B "Help:記事とは何か")をあなたと
[Help for Non-Japanese Speakers](https://ja.wikipedia.org/wiki/Wikipedia:Help_for_Non-Japanese_Speakers "Wikipedia:Help for Non-Japanese Speakers")
##  [![""](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/HSutvald2.svg/40px-HSutvald2.svg.png)](https://ja.wikipedia.org/wiki/Wikipedia:%E7%A7%80%E9%80%B8%E3%81%AA%E8%A8%98%E4%BA%8B "Wikipedia:秀逸な記事")選り抜き記事
[![フィンランドのロヴァニエミのオーロラ](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Rovaniemi_-_Aurora_Borealis.jpg/120px-Rovaniemi_-_Aurora_Borealis.jpg)](https://ja.wikipedia.org/wiki/%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB:Rovaniemi_-_Aurora_Borealis.jpg "フィンランドのロヴァニエミのオーロラ")[フィンランド](https://ja.wikipedia.org/wiki/%E3%83%95%E3%82%A3%E3%83%B3%E3%83%A9%E3%83%B3%E3%83%89 "フィンランド")の[ロヴァニエミ](https://ja.wikipedia.org/wiki/%E3%83%AD%E3%83%B4%E3%82%A1%E3%83%8B%E3%82%A8%E3%83%9F "ロヴァニエミ")のオーロラ
**[オーロラ](https://ja.wikipedia.org/wiki/%E3%82%AA%E3%83%BC%E3%83%AD%E3%83%A9 "オーロラ")** は、[天体](https://ja.wikipedia.org/wiki/%E5%A4%A9%E4%BD%93 "天体")の[極域](https://ja.wikipedia.org/wiki/%E6%A5%B5%E5%9F%9F "極域")近辺に見られる[大気](https://ja.wikipedia.org/wiki/%E5%A4%A7%E6%B0%97 "大気")の発光現象である。**極光** または観測される極域により、[北極](https://ja.wikipedia.org/wiki/%E5%8C%97%E6%A5%B5 "北極")寄りなら**北極光** 、[南極](https://ja.wikipedia.org/wiki/%E5%8D%97%E6%A5%B5 "南極")寄りなら**南極光** ともいう。以下本項では特に断らないかぎり、[地球](https://ja.wikipedia.org/wiki/%E5%9C%B0%E7%90%83 "地球")のオーロラについて述べる。 
[女神](https://ja.wikipedia.org/wiki/%E5%A5%B3%E7%A5%9E "女神")の名に由来するオーロラは古代から[古文書](https://ja.wikipedia.org/wiki/%E5%8F%A4%E6%96%87%E6%9B%B8 "古文書")や[伝承](https://ja.wikipedia.org/wiki/%E4%BC%9D%E6%89%BF "伝承")に残されており、[日本](https://ja.wikipedia.org/wiki/%E6%97%A5%E6%9C%AC "日本")でも観測されている。近代に入ってからは[両極](https://ja.wikipedia.org/wiki/%E4%B8%A1%E6%A5%B5 "両極")の探検家がその存在を広く知らしめた。オーロラの研究は[電磁気学](https://ja.wikipedia.org/wiki/%E9%9B%BB%E7%A3%81%E6%B0%97%E5%AD%A6 "電磁気学")の発展とともに進歩した。発生原理は、[太陽風](https://ja.wikipedia.org/wiki/%E5%A4%AA%E9%99%BD%E9%A2%A8 "太陽風")の[プラズマ](https://ja.wikipedia.org/wiki/%E3%83%97%E3%83%A9%E3%82%BA%E3%83%9E "プラズマ")が地球の[磁力線](https://ja.wikipedia.org/wiki/%E7%A3%81%E5%8A%9B%E7%B7%9A "磁力線")に沿って高速で降下して[地球の大気](https://ja.wikipedia.org/wiki/%E5%9C%B0%E7%90%83%E3%81%AE%E5%A4%A7%E6%B0%97 "地球の大気")に含まれる[酸素](https://ja.wikipedia.org/wiki/%E9%85%B8%E7%B4%A0 "酸素")や[窒素](https://ja.wikipedia.org/wiki/%E7%AA%92%E7%B4%A0 "窒素")の[原子](https://ja.wikipedia.org/wiki/%E5%8E%9F%E5%AD%90 "原子")を励起することによって発光すると考えられているが、その詳細にはいまだ不明な点が多い…… 
  * [秀逸な記事](https://ja.wikipedia.org/wiki/Wikipedia:%E7%A7%80%E9%80%B8%E3%81%AA%E8%A8%98%E4%BA%8B "Wikipedia:秀逸な記事")
  * [おまかせ表示](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E3%82%AB%E3%83%86%E3%82%B4%E3%83%AA%E5%86%85%E3%81%8A%E3%81%BE%E3%81%8B%E3%81%9B%E8%A1%A8%E7%A4%BA/%E7%A7%80%E9%80%B8%E3%81%AA%E8%A8%98%E4%BA%8B "特別:カテゴリ内おまかせ表示/秀逸な記事")
  * [つまみ読み](https://ja.wikipedia.org/wiki/Wikipedia:%E7%A7%80%E9%80%B8%E3%83%94%E3%83%83%E3%82%AF%E3%82%A2%E3%83%83%E3%83%97 "Wikipedia:秀逸ピックアップ")
  * [選考](https://ja.wikipedia.org/wiki/Wikipedia:%E7%A7%80%E9%80%B8%E3%81%AA%E8%A8%98%E4%BA%8B%E3%81%AE%E9%81%B8%E8%80%83 "Wikipedia:秀逸な記事の選考")


* * *
  * **[パウル・ルートヴィヒ・ハンス・アントン・フォン・ベネッケンドルフ・ウント・フォン・ヒンデンブルク](https://ja.wikipedia.org/wiki/%E3%83%91%E3%82%A6%E3%83%AB%E3%83%BB%E3%83%95%E3%82%A9%E3%83%B3%E3%83%BB%E3%83%92%E3%83%B3%E3%83%87%E3%83%B3%E3%83%96%E3%83%AB%E3%82%AF "パウル・フォン・ヒンデンブルク")** （[1847年](https://ja.wikipedia.org/wiki/1847%E5%B9%B4 "1847年")[10月2日](https://ja.wikipedia.org/wiki/10%E6%9C%882%E6%97%A5 "10月2日") - [1934年](https://ja.wikipedia.org/wiki/1934%E5%B9%B4 "1934年")[8月2日](https://ja.wikipedia.org/wiki/8%E6%9C%882%E6%97%A5 "8月2日")）は[ドイツ](https://ja.wikipedia.org/wiki/%E3%83%89%E3%82%A4%E3%83%84 "ドイツ")の[軍人](https://ja.wikipedia.org/wiki/%E8%BB%8D%E4%BA%BA "軍人")、[政治家](https://ja.wikipedia.org/wiki/%E6%94%BF%E6%B2%BB%E5%AE%B6 "政治家")。[ドイツ国](https://ja.wikipedia.org/wiki/%E3%83%89%E3%82%A4%E3%83%84%E5%9B%BD "ドイツ国")（[ヴァイマル共和政](https://ja.wikipedia.org/wiki/%E3%83%B4%E3%82%A1%E3%82%A4%E3%83%9E%E3%83%AB%E5%85%B1%E5%92%8C%E6%94%BF "ヴァイマル共和政")）第2代[大統領](https://ja.wikipedia.org/wiki/%E3%83%89%E3%82%A4%E3%83%84%E5%9B%BD%E5%A4%A7%E7%B5%B1%E9%A0%98 "ドイツ国大統領")（在任：[1925年](https://ja.wikipedia.org/wiki/1925%E5%B9%B4 "1925年") - [1934年](https://ja.wikipedia.org/wiki/1934%E5%B9%B4 "1934年")）……
  * **[ドイツのための選択肢](https://ja.wikipedia.org/wiki/%E3%83%89%E3%82%A4%E3%83%84%E3%81%AE%E3%81%9F%E3%82%81%E3%81%AE%E9%81%B8%E6%8A%9E%E8%82%A2 "ドイツのための選択肢")** （略称：**AfD** ）は、[ドイツ](https://ja.wikipedia.org/wiki/%E3%83%89%E3%82%A4%E3%83%84 "ドイツ")の[政党](https://ja.wikipedia.org/wiki/%E3%83%89%E3%82%A4%E3%83%84%E3%81%AE%E6%94%BF%E5%85%9A "ドイツの政党")。2013年、ギリシャ経済危機を契機に反EUを掲げて結党され、ドイツのEU離脱を最大の目標として掲げている。EU加盟国で議論となっている[移民](https://ja.wikipedia.org/wiki/%E7%A7%BB%E6%B0%91 "移民")問題についても……
  * **[ジャーマンフラッツへの攻撃](https://ja.wikipedia.org/wiki/%E3%82%B8%E3%83%A3%E3%83%BC%E3%83%9E%E3%83%B3%E3%83%95%E3%83%A9%E3%83%83%E3%83%84%E3%81%B8%E3%81%AE%E6%94%BB%E6%92%83 "ジャーマンフラッツへの攻撃")** は、[アメリカ独立戦争](https://ja.wikipedia.org/wiki/%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E7%8B%AC%E7%AB%8B%E6%88%A6%E4%BA%89 "アメリカ独立戦争")中の[1778年](https://ja.wikipedia.org/wiki/1778%E5%B9%B4 "1778年")[9月17日](https://ja.wikipedia.org/wiki/9%E6%9C%8817%E6%97%A5 "9月17日")、[イギリス軍](https://ja.wikipedia.org/wiki/%E3%82%A4%E3%82%AE%E3%83%AA%E3%82%B9%E8%BB%8D "イギリス軍")を支持する[ロイヤリスト](https://ja.wikipedia.org/wiki/%E3%83%AD%E3%82%A4%E3%83%A4%E3%83%AA%E3%82%B9%E3%83%88 "ロイヤリスト")と[イロコイ連邦](https://ja.wikipedia.org/wiki/%E3%82%A4%E3%83%AD%E3%82%B3%E3%82%A4%E9%80%A3%E9%82%A6 "イロコイ連邦")[インディアン](https://ja.wikipedia.org/wiki/%E3%82%A4%E3%83%B3%E3%83%87%E3%82%A3%E3%82%A2%E3%83%B3 "インディアン")の混成部隊が[ジャーマンフラッツ](https://ja.wikipedia.org/w/index.php?title=%E3%82%B8%E3%83%A3%E3%83%BC%E3%83%9E%E3%83%B3%E3%83%95%E3%83%A9%E3%83%83%E3%83%84_\(%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%A8%E3%83%BC%E3%82%AF%E5%B7%9E\)&action=edit&redlink=1 "ジャーマンフラッツ \(ニューヨーク州\) \(存在しないページ\)")前線開拓地（現在の[ニューヨーク州](https://ja.wikipedia.org/wiki/%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%A8%E3%83%BC%E3%82%AF%E5%B7%9E "ニューヨーク州")[ハーキマー](https://ja.wikipedia.org/w/index.php?title=%E3%83%8F%E3%83%BC%E3%82%AD%E3%83%9E%E3%83%BC_\(%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%A8%E3%83%BC%E3%82%AF%E5%B7%9E\)&action=edit&redlink=1 "ハーキマー \(ニューヨーク州\) \(存在しないページ\)")も含む）を……


  * [良質な記事](https://ja.wikipedia.org/wiki/Wikipedia:%E8%89%AF%E8%B3%AA%E3%81%AA%E8%A8%98%E4%BA%8B "Wikipedia:良質な記事")
  * [おまかせ表示](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E3%82%AB%E3%83%86%E3%82%B4%E3%83%AA%E5%86%85%E3%81%8A%E3%81%BE%E3%81%8B%E3%81%9B%E8%A1%A8%E7%A4%BA/%E8%89%AF%E8%B3%AA%E3%81%AA%E8%A8%98%E4%BA%8B "特別:カテゴリ内おまかせ表示/良質な記事")
  * [つまみ読み](https://ja.wikipedia.org/wiki/Wikipedia:%E8%89%AF%E8%B3%AA%E3%83%94%E3%83%83%E3%82%AF%E3%82%A2%E3%83%83%E3%83%97 "Wikipedia:良質ピックアップ")
  * [選考](https://ja.wikipedia.org/wiki/Wikipedia:%E8%89%AF%E8%B3%AA%E3%81%AA%E8%A8%98%E4%BA%8B/%E8%89%AF%E8%B3%AA%E3%81%AA%E8%A8%98%E4%BA%8B%E3%81%AE%E9%81%B8%E8%80%83 "Wikipedia:良質な記事/良質な記事の選考")


##  [![""](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/HSVissteduatt.svg/40px-HSVissteduatt.svg.png)](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E6%96%B0%E3%81%97%E3%81%84%E3%83%9A%E3%83%BC%E3%82%B8 "特別:新しいページ")新しい記事
  * **[岩屋大塚古墳](https://ja.wikipedia.org/wiki/%E5%B2%A9%E5%B1%8B%E5%A4%A7%E5%A1%9A%E5%8F%A4%E5%A2%B3 "岩屋大塚古墳")** は、[奈良県](https://ja.wikipedia.org/wiki/%E5%A5%88%E8%89%AF%E7%9C%8C "奈良県")[天理市](https://ja.wikipedia.org/wiki/%E5%A4%A9%E7%90%86%E5%B8%82 "天理市")岩屋町にある[古墳](https://ja.wikipedia.org/wiki/%E5%8F%A4%E5%A2%B3 "古墳")。形状は[前方後円墳](https://ja.wikipedia.org/wiki/%E5%89%8D%E6%96%B9%E5%BE%8C%E5%86%86%E5%A2%B3 "前方後円墳")。石上・豊田古墳群を構成する古墳の1つ。史跡指定はされていない。[奈良盆地](https://ja.wikipedia.org/wiki/%E5%A5%88%E8%89%AF%E7%9B%86%E5%9C%B0 "奈良盆地")東縁、高瀬川上流の岩屋谷の中央部に築造された古墳である。墳丘は開墾等によって大きく改変されているほか、[名阪国道](https://ja.wikipedia.org/wiki/%E5%90%8D%E9%98%AA%E5%9B%BD%E9%81%93 "名阪国道")建設の際に南半が失われている。……
  * **[ブックガイド](https://ja.wikipedia.org/wiki/%E3%83%96%E3%83%83%E3%82%AF%E3%82%AC%E3%82%A4%E3%83%89 "ブックガイド")** は、[書籍](https://ja.wikipedia.org/wiki/%E6%9B%B8%E7%B1%8D "書籍")の案内を目的とした文章やこれをまとめた[出版物](https://ja.wikipedia.org/wiki/%E5%87%BA%E7%89%88%E7%89%A9 "出版物")。[書評](https://ja.wikipedia.org/wiki/%E6%9B%B8%E8%A9%95 "書評")や[目録](https://ja.wikipedia.org/wiki/%E7%9B%AE%E9%8C%B2 "目録")の要素を備えたものもあり、日本においては「本の本」ともいわれ、[読書](https://ja.wikipedia.org/wiki/%E8%AA%AD%E6%9B%B8 "読書")の対象とする書籍の選定材料に使われるほか、[図書館](https://ja.wikipedia.org/wiki/%E5%9B%B3%E6%9B%B8%E9%A4%A8 "図書館")の[レファレンスサービス](https://ja.wikipedia.org/wiki/%E3%83%AC%E3%83%95%E3%82%A1%E3%83%AC%E3%83%B3%E3%82%B9%E3%82%B5%E3%83%BC%E3%83%93%E3%82%B9 "レファレンスサービス")にも利用されることがある。ブックガイドの需要が顕在化したのは[19世紀](https://ja.wikipedia.org/wiki/19%E4%B8%96%E7%B4%80 "19世紀")後半とされ、……
  * **[豊田トンド山古墳](https://ja.wikipedia.org/wiki/%E8%B1%8A%E7%94%B0%E3%83%88%E3%83%B3%E3%83%89%E5%B1%B1%E5%8F%A4%E5%A2%B3 "豊田トンド山古墳")** は、[奈良県](https://ja.wikipedia.org/wiki/%E5%A5%88%E8%89%AF%E7%9C%8C "奈良県")[天理市](https://ja.wikipedia.org/wiki/%E5%A4%A9%E7%90%86%E5%B8%82 "天理市")豊田町にある[古墳](https://ja.wikipedia.org/wiki/%E5%8F%A4%E5%A2%B3 "古墳")。形状は[円墳](https://ja.wikipedia.org/wiki/%E5%86%86%E5%A2%B3 "円墳")。石上・豊田古墳群を構成する古墳の1つ。史跡指定はされていない。[奈良盆地](https://ja.wikipedia.org/wiki/%E5%A5%88%E8%89%AF%E7%9B%86%E5%9C%B0 "奈良盆地")東縁、通称豊田山を最高所とする丘陵頂上部南斜面（標高約114.5メートル）に山寄せで築造された大型円墳である。丘陵上では本古墳を含む……
  * **[インターフレックス作戦](https://ja.wikipedia.org/wiki/%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%95%E3%83%AC%E3%83%83%E3%82%AF%E3%82%B9%E4%BD%9C%E6%88%A6 "インターフレックス作戦")** は、[イギリス](https://ja.wikipedia.org/wiki/%E3%82%A4%E3%82%AE%E3%83%AA%E3%82%B9 "イギリス")主導による[ウクライナ軍](https://ja.wikipedia.org/wiki/%E3%82%A6%E3%82%AF%E3%83%A9%E3%82%A4%E3%83%8A%E8%BB%8D "ウクライナ軍")の訓練支援を目的とした作戦。[2015年](https://ja.wikipedia.org/wiki/2015%E5%B9%B4 "2015年")から実施されていた[オービタル作戦](https://ja.wikipedia.org/w/index.php?title=%E3%82%AA%E3%83%BC%E3%83%93%E3%82%BF%E3%83%AB%E4%BD%9C%E6%88%A6&action=edit&redlink=1 "オービタル作戦 \(存在しないページ\)")が、[2022年](https://ja.wikipedia.org/wiki/2022%E5%B9%B4 "2022年")2月の[ロシアのウクライナ侵攻](https://ja.wikipedia.org/wiki/%E3%83%AD%E3%82%B7%E3%82%A2%E3%81%AE%E3%82%A6%E3%82%AF%E3%83%A9%E3%82%A4%E3%83%8A%E4%BE%B5%E6%94%BB "ロシアのウクライナ侵攻")により中止されたことに伴い、後継の作戦として7月から開始され、[2026年](https://ja.wikipedia.org/wiki/2026%E5%B9%B4 "2026年")末までの継続が予定されている。……


  * [投票・推薦](https://ja.wikipedia.org/wiki/Wikipedia:%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8%E6%96%B0%E7%9D%80%E6%8A%95%E7%A5%A8%E6%89%80#%E6%96%B0%E3%81%97%E3%81%84%E8%A8%98%E4%BA%8B%E6%8A%95%E7%A5%A8%E6%89%80 "Wikipedia:メインページ新着投票所")
    * [月間新記事](https://ja.wikipedia.org/wiki/Wikipedia:%E6%9C%88%E9%96%93%E6%96%B0%E8%A8%98%E4%BA%8B%E8%B3%9E "Wikipedia:月間新記事賞")


##  [![""](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/HSBild.svg/40px-HSBild.svg.png)](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E6%96%B0%E7%9D%80%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB "特別:新着ファイル")新しい画像
[![飛鳥III](https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/AsukaIII_at_takamatsu_port.jpg/250px-AsukaIII_at_takamatsu_port.jpg)](https://ja.wikipedia.org/wiki/%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB:AsukaIII_at_takamatsu_port.jpg "飛鳥III")
[飛鳥III](https://ja.wikipedia.org/wiki/%E9%A3%9B%E9%B3%A5III "飛鳥III")
[![塩屋湾のウンガミで行われる御願バーリー（沖縄県大宜味村）](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Dragon_boat_race_held_during_Ungami_of_Shioya_Bay_202509_05.jpg/250px-Dragon_boat_race_held_during_Ungami_of_Shioya_Bay_202509_05.jpg)](https://ja.wikipedia.org/wiki/%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB:Dragon_boat_race_held_during_Ungami_of_Shioya_Bay_202509_05.jpg "塩屋湾のウンガミで行われる御願バーリー（沖縄県大宜味村）")
塩屋湾の[ウンガミ](https://ja.wikipedia.org/wiki/%E6%B5%B7%E7%A5%9E%E7%A5%AD "海神祭")で行われる[御願バーリー](https://ja.wikipedia.org/wiki/%E7%88%AC%E7%AB%9C "爬竜")（[沖縄県](https://ja.wikipedia.org/wiki/%E6%B2%96%E7%B8%84%E7%9C%8C "沖縄県")[大宜味村](https://ja.wikipedia.org/wiki/%E5%A4%A7%E5%AE%9C%E5%91%B3%E6%9D%91 "大宜味村")）
  * [新しい画像](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E6%96%B0%E7%9D%80%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB "特別:新着ファイル")
  * [投票・推薦](https://ja.wikipedia.org/wiki/Wikipedia:%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8%E6%96%B0%E7%9D%80%E6%8A%95%E7%A5%A8%E6%89%80#%E6%96%B0%E3%81%97%E3%81%84%E7%94%BB%E5%83%8F%E6%8A%95%E7%A5%A8%E6%89%80 "Wikipedia:メインページ新着投票所")
    * [今月の一枚](https://ja.wikipedia.org/wiki/Wikipedia:%E6%9C%88%E9%96%93%E6%96%B0%E8%A8%98%E4%BA%8B%E8%B3%9E "Wikipedia:月間新記事賞")


##  [![""](https://upload.wikimedia.org/wikipedia/commons/thumb/1/13/HS_VdQ.svg/40px-HS_VdQ.svg.png)](https://ja.wikipedia.org/wiki/Wikipedia:%E6%9C%80%E8%BF%91%E5%A4%A7%E5%B9%85%E5%8A%A0%E7%AD%86%E3%81%95%E3%82%8C%E3%81%9F%E8%A8%98%E4%BA%8B "Wikipedia:最近大幅加筆された記事")強化記事
  * **[松岡藩](https://ja.wikipedia.org/wiki/%E8%B6%8A%E5%89%8D%E6%9D%BE%E5%B2%A1%E8%97%A9 "越前松岡藩")** は、[越前国](https://ja.wikipedia.org/wiki/%E8%B6%8A%E5%89%8D%E5%9B%BD "越前国")に[正保](https://ja.wikipedia.org/wiki/%E6%AD%A3%E4%BF%9D "正保")2年（[1645年](https://ja.wikipedia.org/wiki/1645%E5%B9%B4 "1645年")）から[享保](https://ja.wikipedia.org/wiki/%E4%BA%AB%E4%BF%9D "享保")6年（[1721年](https://ja.wikipedia.org/wiki/1721%E5%B9%B4 "1721年")）まで存在した、[福井藩](https://ja.wikipedia.org/wiki/%E7%A6%8F%E4%BA%95%E8%97%A9 "福井藩")の[支藩](https://ja.wikipedia.org/wiki/%E6%94%AF%E8%97%A9 "支藩")。石高は5万石。第3代福井藩主[松平忠昌](https://ja.wikipedia.org/wiki/%E6%9D%BE%E5%B9%B3%E5%BF%A0%E6%98%8C "松平忠昌")の庶子・[松平昌勝](https://ja.wikipedia.org/wiki/%E6%9D%BE%E5%B9%B3%E6%98%8C%E5%8B%9D "松平昌勝")が、父の死後に松岡の地を分知され成立した藩であり、後に昌勝の子・[昌平](https://ja.wikipedia.org/wiki/%E6%9D%BE%E5%B9%B3%E6%98%8C%E5%B9%B3 "松平昌平")が福井藩主に就任したことに伴い廃藩となった。……
  * **[アケイティーズ](https://ja.wikipedia.org/wiki/%E3%82%A2%E3%82%B1%E3%82%A4%E3%83%86%E3%82%A3%E3%83%BC%E3%82%BA_\(%E9%A7%86%E9%80%90%E8%89%A6%E3%83%BB2%E4%BB%A3\) "アケイティーズ \(駆逐艦・2代\)")** とは、[イギリス海軍](https://ja.wikipedia.org/wiki/%E3%82%A4%E3%82%AE%E3%83%AA%E3%82%B9%E6%B5%B7%E8%BB%8D "イギリス海軍")の[駆逐艦](https://ja.wikipedia.org/wiki/%E9%A7%86%E9%80%90%E8%89%A6 "駆逐艦")。[A級駆逐艦](https://ja.wikipedia.org/wiki/A%E7%B4%9A%E9%A7%86%E9%80%90%E8%89%A6_\(2%E4%BB%A3\) "A級駆逐艦 \(2代\)")。艦名は、[ギリシア神話](https://ja.wikipedia.org/wiki/%E3%82%AE%E3%83%AA%E3%82%B7%E3%82%A2%E7%A5%9E%E8%A9%B1 "ギリシア神話")・[ローマ神話](https://ja.wikipedia.org/wiki/%E3%83%AD%E3%83%BC%E3%83%9E%E7%A5%9E%E8%A9%B1 "ローマ神話")において英雄[アイネイアース](https://ja.wikipedia.org/wiki/%E3%82%A2%E3%82%A4%E3%83%8D%E3%82%A4%E3%82%A2%E3%83%BC%E3%82%B9 "アイネイアース")の忠実な部下とされる[アカーテース](https://ja.wikipedia.org/wiki/%E3%82%A2%E3%82%AB%E3%83%BC%E3%83%86%E3%83%BC%E3%82%B9 "アカーテース")に由来する。[バレンツ海海戦](https://ja.wikipedia.org/wiki/%E3%83%90%E3%83%AC%E3%83%B3%E3%83%84%E6%B5%B7%E6%B5%B7%E6%88%A6 "バレンツ海海戦")で[ドイツ海軍](https://ja.wikipedia.org/wiki/%E3%83%89%E3%82%A4%E3%83%84%E6%B5%B7%E8%BB%8D_\(%E5%9B%BD%E9%98%B2%E8%BB%8D\) "ドイツ海軍 \(国防軍\)")の攻撃によって大破、撃沈された。……
  * **[ヒルデスハイム](https://ja.wikipedia.org/wiki/%E3%83%92%E3%83%AB%E3%83%87%E3%82%B9%E3%83%8F%E3%82%A4%E3%83%A0 "ヒルデスハイム")** は、[ドイツ連邦共和国](https://ja.wikipedia.org/wiki/%E3%83%89%E3%82%A4%E3%83%84%E9%80%A3%E9%82%A6%E5%85%B1%E5%92%8C%E5%9B%BD "ドイツ連邦共和国")[ニーダーザクセン州](https://ja.wikipedia.org/wiki/%E3%83%8B%E3%83%BC%E3%83%80%E3%83%BC%E3%82%B6%E3%82%AF%E3%82%BB%E3%83%B3%E5%B7%9E "ニーダーザクセン州")[ヒルデスハイム郡](https://ja.wikipedia.org/wiki/%E3%83%92%E3%83%AB%E3%83%87%E3%82%B9%E3%83%8F%E3%82%A4%E3%83%A0%E9%83%A1 "ヒルデスハイム郡")の市。ヒルデスハイム司教区の[司教座](https://ja.wikipedia.org/wiki/%E5%8F%B8%E6%95%99%E5%BA%A7 "司教座")都市である。[ヒルデスハイムの聖マリア大聖堂と聖ミカエル聖堂](https://ja.wikipedia.org/wiki/%E3%83%92%E3%83%AB%E3%83%87%E3%82%B9%E3%83%8F%E3%82%A4%E3%83%A0%E3%81%AE%E8%81%96%E3%83%9E%E3%83%AA%E3%82%A2%E5%A4%A7%E8%81%96%E5%A0%82%E3%81%A8%E8%81%96%E3%83%9F%E3%82%AB%E3%82%A8%E3%83%AB%E8%81%96%E5%A0%82 "ヒルデスハイムの聖マリア大聖堂と聖ミカエル聖堂")は、[ロマネスク](https://ja.wikipedia.org/wiki/%E3%83%AD%E3%83%9E%E3%83%8D%E3%82%B9%E3%82%AF%E5%BB%BA%E7%AF%89 "ロマネスク建築")初期の最も重要な建築の1つであり、[1985年](https://ja.wikipedia.org/wiki/1985%E5%B9%B4 "1985年")に[世界遺産](https://ja.wikipedia.org/wiki/%E4%B8%96%E7%95%8C%E9%81%BA%E7%94%A3 "世界遺産")に登録されている。……


  * [強化記事](https://ja.wikipedia.org/wiki/Wikipedia:%E6%9C%80%E8%BF%91%E5%A4%A7%E5%B9%85%E5%8A%A0%E7%AD%86%E3%81%95%E3%82%8C%E3%81%9F%E8%A8%98%E4%BA%8B/2025%E5%B9%B4 "Wikipedia:最近大幅加筆された記事/2025年")
  * [投票・推薦](https://ja.wikipedia.org/wiki/Wikipedia:%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8%E5%BC%B7%E5%8C%96%E8%A8%98%E4%BA%8B%E6%8A%95%E7%A5%A8%E6%89%80/%E9%A0%85%E7%9B%AE%E5%80%99%E8%A3%9C "Wikipedia:メインページ強化記事投票所/項目候補")
    * [月間強化記事](https://ja.wikipedia.org/wiki/Wikipedia:%E6%9C%88%E9%96%93%E5%BC%B7%E5%8C%96%E8%A8%98%E4%BA%8B%E8%B3%9E "Wikipedia:月間強化記事賞")


##  [![""](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/HSPolitic.svg/40px-HSPolitic.svg.png)](https://ja.wikipedia.org/wiki/Wikipedia:%E7%A7%80%E9%80%B8%E3%81%AA%E7%94%BB%E5%83%8F "Wikipedia:秀逸な画像")[今日の一枚](https://ja.wikipedia.org/wiki/Wikipedia:%E4%BB%8A%E6%97%A5%E3%81%AE%E4%B8%80%E6%9E%9A "Wikipedia:今日の一枚")
[![芦ノ湖上に浮かぶ箱根神社の平和鳥居と富士山、元箱根にて](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/LakeAshi_and_MtFuji_Hakone.JPG/330px-LakeAshi_and_MtFuji_Hakone.JPG)](https://ja.wikipedia.org/wiki/%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB:LakeAshi_and_MtFuji_Hakone.JPG "芦ノ湖上に浮かぶ箱根神社の平和鳥居と富士山、元箱根にて")  
[芦ノ湖](https://ja.wikipedia.org/wiki/%E8%8A%A6%E3%83%8E%E6%B9%96 "芦ノ湖")上に浮かぶ[箱根神社](https://ja.wikipedia.org/wiki/%E7%AE%B1%E6%A0%B9%E7%A5%9E%E7%A4%BE "箱根神社")の平和鳥居と[富士山](https://ja.wikipedia.org/wiki/%E5%AF%8C%E5%A3%AB%E5%B1%B1 "富士山")、[元箱根](https://ja.wikipedia.org/wiki/%E5%85%83%E7%AE%B1%E6%A0%B9 "元箱根")にて
  * [秀逸な画像](https://ja.wikipedia.org/wiki/Wikipedia:%E7%A7%80%E9%80%B8%E3%81%AA%E7%94%BB%E5%83%8F "Wikipedia:秀逸な画像")
  * [投票・推薦](https://ja.wikipedia.org/wiki/Wikipedia:%E7%A7%80%E9%80%B8%E3%81%AA%E7%94%BB%E5%83%8F%E3%81%AE%E6%8E%A8%E8%96%A6 "Wikipedia:秀逸な画像の推薦")


##  [![""](https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/HSDagensdatum.svg/40px-HSDagensdatum.svg.png)](https://ja.wikipedia.org/wiki/Wikipedia:%E4%BB%8A%E6%97%A5%E3%81%AF%E4%BD%95%E3%81%AE%E6%97%A5_10%E6%9C%88 "Wikipedia:今日は何の日 10月")[今日は何の日](https://ja.wikipedia.org/wiki/Wikipedia:%E4%BB%8A%E6%97%A5%E3%81%AF%E4%BD%95%E3%81%AE%E6%97%A5_10%E6%9C%88 "Wikipedia:今日は何の日 10月") [10月2日](https://ja.wikipedia.org/wiki/10%E6%9C%882%E6%97%A5 "10月2日")
  * [国際非暴力デー](https://ja.wikipedia.org/wiki/%E5%9B%BD%E9%9A%9B%E9%9D%9E%E6%9A%B4%E5%8A%9B%E3%83%87%E3%83%BC "国際非暴力デー")
  * [サラーフッディーン](https://ja.wikipedia.org/wiki/%E3%82%B5%E3%83%A9%E3%83%BC%E3%83%95%E3%83%83%E3%83%87%E3%82%A3%E3%83%BC%E3%83%B3 "サラーフッディーン")が[エルサレム王国](https://ja.wikipedia.org/wiki/%E3%82%A8%E3%83%AB%E3%82%B5%E3%83%AC%E3%83%A0%E7%8E%8B%E5%9B%BD "エルサレム王国")より[エルサレム](https://ja.wikipedia.org/wiki/%E3%82%A8%E3%83%AB%E3%82%B5%E3%83%AC%E3%83%A0 "エルサレム")を奪取（[1187年](https://ja.wikipedia.org/wiki/1187%E5%B9%B4 "1187年")）
  * [ゴンザレスの戦い](https://ja.wikipedia.org/wiki/%E3%82%B4%E3%83%B3%E3%82%B6%E3%83%AC%E3%82%B9%E3%81%AE%E6%88%A6%E3%81%84 "ゴンザレスの戦い")により[テキサス革命](https://ja.wikipedia.org/wiki/%E3%83%86%E3%82%AD%E3%82%B5%E3%82%B9%E9%9D%A9%E5%91%BD "テキサス革命")が始まる（[1835年](https://ja.wikipedia.org/wiki/1835%E5%B9%B4 "1835年")）
  * [チャールズ・ダーウィン](https://ja.wikipedia.org/wiki/%E3%83%81%E3%83%A3%E3%83%BC%E3%83%AB%E3%82%BA%E3%83%BB%E3%83%80%E3%83%BC%E3%82%A6%E3%82%A3%E3%83%B3 "チャールズ・ダーウィン")が[ビーグル号](https://ja.wikipedia.org/wiki/%E3%83%93%E3%83%BC%E3%82%B0%E3%83%AB_\(%E5%B8%86%E8%88%B9\) "ビーグル \(帆船\)")による5年間の世界一周航海から帰国（[1836年](https://ja.wikipedia.org/wiki/1836%E5%B9%B4 "1836年")）
  * [琿春事件](https://ja.wikipedia.org/wiki/%E9%96%93%E5%B3%B6%E4%BA%8B%E4%BB%B6 "間島事件")（[1920年](https://ja.wikipedia.org/wiki/1920%E5%B9%B4 "1920年")）
  * 日本が[ロンドン海軍軍縮条約](https://ja.wikipedia.org/wiki/%E3%83%AD%E3%83%B3%E3%83%89%E3%83%B3%E6%B5%B7%E8%BB%8D%E8%BB%8D%E7%B8%AE%E6%9D%A1%E7%B4%84 "ロンドン海軍軍縮条約")を[批准](https://ja.wikipedia.org/wiki/%E6%89%B9%E5%87%86 "批准")（[1930年](https://ja.wikipedia.org/wiki/1930%E5%B9%B4 "1930年")）
  * [リットン報告書](https://ja.wikipedia.org/wiki/%E3%83%AA%E3%83%83%E3%83%88%E3%83%B3%E5%A0%B1%E5%91%8A%E6%9B%B8 "リットン報告書")発表（[1932年](https://ja.wikipedia.org/wiki/1932%E5%B9%B4 "1932年")）
  * [第二次世界大戦](https://ja.wikipedia.org/wiki/%E7%AC%AC%E4%BA%8C%E6%AC%A1%E4%B8%96%E7%95%8C%E5%A4%A7%E6%88%A6 "第二次世界大戦")：「在学徴集延期臨時特例」公布。文科系学生の徴兵猶予を全面停止。（[学徒出陣](https://ja.wikipedia.org/wiki/%E5%AD%A6%E5%BE%92%E5%87%BA%E9%99%A3 "学徒出陣")）（[1943年](https://ja.wikipedia.org/wiki/1943%E5%B9%B4 "1943年")）
  * 第二次世界大戦：[ポーランド国内軍](https://ja.wikipedia.org/wiki/%E5%9B%BD%E5%86%85%E8%BB%8D_\(%E3%83%9D%E3%83%BC%E3%83%A9%E3%83%B3%E3%83%89\) "国内軍 \(ポーランド\)")が[ドイツ国防軍](https://ja.wikipedia.org/wiki/%E3%83%89%E3%82%A4%E3%83%84%E5%9B%BD%E9%98%B2%E8%BB%8D "ドイツ国防軍")に降伏し、[ワルシャワ蜂起](https://ja.wikipedia.org/wiki/%E3%83%AF%E3%83%AB%E3%82%B7%E3%83%A3%E3%83%AF%E8%9C%82%E8%B5%B7 "ワルシャワ蜂起")が終結（[1944年](https://ja.wikipedia.org/wiki/1944%E5%B9%B4 "1944年")）
  * [ギニア](https://ja.wikipedia.org/wiki/%E3%82%AE%E3%83%8B%E3%82%A2 "ギニア")が[フランス](https://ja.wikipedia.org/wiki/%E3%83%95%E3%83%A9%E3%83%B3%E3%82%B9 "フランス")から独立（[1958年](https://ja.wikipedia.org/wiki/1958%E5%B9%B4 "1958年")）
  * [東京](https://ja.wikipedia.org/wiki/%E6%9D%B1%E4%BA%AC%E8%A8%BC%E5%88%B8%E5%8F%96%E5%BC%95%E6%89%80 "東京証券取引所")・[大阪](https://ja.wikipedia.org/wiki/%E5%A4%A7%E9%98%AA%E8%A8%BC%E5%88%B8%E5%8F%96%E5%BC%95%E6%89%80 "大阪証券取引所")・[名古屋](https://ja.wikipedia.org/wiki/%E5%90%8D%E5%8F%A4%E5%B1%8B%E8%A8%BC%E5%88%B8%E5%8F%96%E5%BC%95%E6%89%80 "名古屋証券取引所")の各[証券取引所](https://ja.wikipedia.org/wiki/%E8%A8%BC%E5%88%B8%E5%8F%96%E5%BC%95%E6%89%80 "証券取引所")が[株式市場](https://ja.wikipedia.org/wiki/%E6%A0%AA%E5%BC%8F%E5%B8%82%E5%A0%B4 "株式市場")第2部を開設（[1961年](https://ja.wikipedia.org/wiki/1961%E5%B9%B4 "1961年")）
  * [サーグッド・マーシャル](https://ja.wikipedia.org/wiki/%E3%82%B5%E3%83%BC%E3%82%B0%E3%83%83%E3%83%89%E3%83%BB%E3%83%9E%E3%83%BC%E3%82%B7%E3%83%A3%E3%83%AB "サーグッド・マーシャル")が[アフリカ系アメリカ人](https://ja.wikipedia.org/wiki/%E3%82%A2%E3%83%95%E3%83%AA%E3%82%AB%E7%B3%BB%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E4%BA%BA "アフリカ系アメリカ人")として初めて[米連邦最高裁](https://ja.wikipedia.org/wiki/%E5%90%88%E8%A1%86%E5%9B%BD%E6%9C%80%E9%AB%98%E8%A3%81%E5%88%A4%E6%89%80 "合衆国最高裁判所")判事に就任（[1967年](https://ja.wikipedia.org/wiki/1967%E5%B9%B4 "1967年")）
  * [廈門航空機ハイジャック事件](https://ja.wikipedia.org/wiki/%E5%BB%88%E9%96%80%E8%88%AA%E7%A9%BA%E6%A9%9F%E3%83%8F%E3%82%A4%E3%82%B8%E3%83%A3%E3%83%83%E3%82%AF%E4%BA%8B%E4%BB%B6 "廈門航空機ハイジャック事件")（[1990年](https://ja.wikipedia.org/wiki/1990%E5%B9%B4 "1990年")）
  * [アムステルダム条約](https://ja.wikipedia.org/wiki/%E3%82%A2%E3%83%A0%E3%82%B9%E3%83%86%E3%83%AB%E3%83%80%E3%83%A0%E6%9D%A1%E7%B4%84 "アムステルダム条約")調印（[1997年](https://ja.wikipedia.org/wiki/1997%E5%B9%B4 "1997年")）


##  [![""](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/PL_Wiki_Aktualnosci_ikona.svg/38px-PL_Wiki_Aktualnosci_ikona.svg.png)](https://ja.wikipedia.org/wiki/Wikipedia:%E5%AD%A3%E7%AF%80%E3%81%AE%E8%A9%B1%E9%A1%8C "Wikipedia:季節の話題")風物詩
[![ドングリ](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b0/Quercus_crispula_2002-10-11.jpg/250px-Quercus_crispula_2002-10-11.jpg)](https://ja.wikipedia.org/wiki/%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB:Quercus_crispula_2002-10-11.jpg "ドングリ")
  * [秋](https://ja.wikipedia.org/wiki/%E7%A7%8B "秋")
  * [キンモクセイ](https://ja.wikipedia.org/wiki/%E3%82%AD%E3%83%B3%E3%83%A2%E3%82%AF%E3%82%BB%E3%82%A4 "キンモクセイ")
  * [ブドウ](https://ja.wikipedia.org/wiki/%E3%83%96%E3%83%89%E3%82%A6 "ブドウ")
  * [梨](https://ja.wikipedia.org/wiki/%E6%A2%A8 "梨")
  * [月見](https://ja.wikipedia.org/wiki/%E6%9C%88%E8%A6%8B "月見")
  * [ススキ](https://ja.wikipedia.org/wiki/%E3%82%B9%E3%82%B9%E3%82%AD "ススキ")
  * [ドングリ](https://ja.wikipedia.org/wiki/%E3%83%89%E3%83%B3%E3%82%B0%E3%83%AA "ドングリ")
  * [トンボ](https://ja.wikipedia.org/wiki/%E3%83%88%E3%83%B3%E3%83%9C "トンボ")
  * [サンマ](https://ja.wikipedia.org/wiki/%E3%82%B5%E3%83%B3%E3%83%9E "サンマ")
  * [サツマイモ](https://ja.wikipedia.org/wiki/%E3%82%B5%E3%83%84%E3%83%9E%E3%82%A4%E3%83%A2 "サツマイモ")
  * [初冠雪](https://ja.wikipedia.org/wiki/%E5%88%9D%E5%86%A0%E9%9B%AA "初冠雪")
  * [あけび](https://ja.wikipedia.org/wiki/%E3%81%82%E3%81%91%E3%81%B3 "あけび")
  * [いちじく](https://ja.wikipedia.org/wiki/%E3%81%84%E3%81%A1%E3%81%98%E3%81%8F "いちじく")


  * [画像の投票・推薦](https://ja.wikipedia.org/wiki/Wikipedia:%E5%AD%A3%E7%AF%80%E3%81%AE%E7%94%BB%E5%83%8F%E6%8A%95%E7%A5%A8%E6%89%80 "Wikipedia:季節の画像投票所")
  * [話題](https://ja.wikipedia.org/wiki/Wikipedia:%E5%AD%A3%E7%AF%80%E3%81%AE%E8%A9%B1%E9%A1%8C "Wikipedia:季節の話題")


##  [![""](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/HSSamarbete.svg/40px-HSSamarbete.svg.png)](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Wikipedia:ウィキポータル")[ポータル](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB#%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Wikipedia:ウィキポータル")
  * [人文科学](https://ja.wikipedia.org/wiki/Category:%E4%BA%BA%E6%96%87%E7%A7%91%E5%AD%A6%E3%81%AE%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Category:人文科学のポータル")
  * [歴史](https://ja.wikipedia.org/wiki/Category:%E6%AD%B4%E5%8F%B2%E3%81%AE%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Category:歴史のポータル")
  * [地理](https://ja.wikipedia.org/wiki/Category:%E5%9C%B0%E7%90%86%E3%81%AE%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Category:地理のポータル")
  * [社会科学](https://ja.wikipedia.org/wiki/Category:%E7%A4%BE%E4%BC%9A%E7%A7%91%E5%AD%A6%E3%81%AE%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Category:社会科学のポータル")
  * [自然科学](https://ja.wikipedia.org/wiki/Category:%E8%87%AA%E7%84%B6%E7%A7%91%E5%AD%A6%E3%81%AE%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Category:自然科学のポータル")
  * [技術産業](https://ja.wikipedia.org/wiki/Category:%E6%8A%80%E8%A1%93%E3%81%A8%E7%94%A3%E6%A5%AD%E3%81%AE%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Category:技術と産業のポータル")
  * [文化と芸術](https://ja.wikipedia.org/wiki/Category:%E6%96%87%E5%8C%96%E3%81%A8%E8%8A%B8%E8%A1%93%E3%81%AE%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Category:文化と芸術のポータル")
  * [娯楽とスポーツ](https://ja.wikipedia.org/wiki/Category:%E5%A8%AF%E6%A5%BD%E3%81%A8%E3%82%B9%E3%83%9D%E3%83%BC%E3%83%84%E3%81%AE%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Category:娯楽とスポーツのポータル")


[ポータルとは](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Wikipedia:ウィキポータル")
[ウィキポータル](https://ja.wikipedia.org/wiki/Category:%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%9D%E3%83%BC%E3%82%BF%E3%83%AB "Category:ウィキポータル")
##  [![""](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/W-circle.svg/40px-W-circle.svg.png)](https://ja.wikipedia.org/wiki/Help:%E7%9B%AE%E6%AC%A1 "Help:目次")インフォメーション
  * [ガイド](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%AC%E3%82%A4%E3%83%89%E3%83%96%E3%83%83%E3%82%AF "Wikipedia:ガイドブック")
  * [利用案内](https://ja.wikipedia.org/wiki/Wikipedia:%E5%88%A9%E7%94%A8%E6%A1%88%E5%86%85 "Wikipedia:利用案内")
  * [方針](https://ja.wikipedia.org/wiki/Wikipedia:%E6%96%B9%E9%87%9D%E3%81%A8%E3%82%AC%E3%82%A4%E3%83%89%E3%83%A9%E3%82%A4%E3%83%B3 "Wikipedia:方針とガイドライン")
  * [カテゴリ](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%AB%E3%83%86%E3%82%B4%E3%83%AA "Wikipedia:カテゴリ")
  * [索引](https://ja.wikipedia.org/wiki/Wikipedia:%E7%B4%A2%E5%BC%95 "Wikipedia:索引")
  * [連絡先](https://ja.wikipedia.org/wiki/Wikipedia:%E9%80%A3%E7%B5%A1%E5%85%88 "Wikipedia:連絡先")


##  [![""](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/HSWPedia.svg/40px-HSWPedia.svg.png)](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%A1%E3%83%87%E3%82%A3%E3%82%A2%E3%83%BB%E3%83%97%E3%83%AD%E3%82%B8%E3%82%A7%E3%82%AF%E3%83%88 "Wikipedia:ウィキメディア・プロジェクト")ウィキメディアプロジェクト
  * [コモンズを探検する](https://commons.wikimedia.org/wiki/Commons:%E7%A7%80%E9%80%B8%E3%81%AA%E7%94%BB%E5%83%8F "commons:Commons:秀逸な画像")
  * [今月のおすすめ](https://ja.wikipedia.org/wiki/Wikipedia:%E6%9C%88%E9%96%93%E6%96%B0%E8%A8%98%E4%BA%8B%E8%B3%9E "Wikipedia:月間新記事賞")


ウィキペディアは[非営利団体](https://ja.wikipedia.org/wiki/%E9%9D%9E%E5%96%B6%E5%88%A9%E5%9B%A3%E4%BD%93 "非営利団体")である[ウィキメディア財団](https://ja.wikipedia.org/wiki/%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%A1%E3%83%87%E3%82%A3%E3%82%A2%E8%B2%A1%E5%9B%A3 "ウィキメディア財団")によって運営されています。並びに以下の[姉妹プロジェクト](https://wikimediafoundation.org/our-work/wikimedia-projects/ "foundationsite:our-work/wikimedia-projects/")も運営しています。 
[![コモンズ](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/ "コモンズ")
**[コモンズ](https://commons.wikimedia.org/)**  
ファイルの集積
[![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/ "MediaWiki")
**[MediaWiki](https://mediawiki.org/)**   
ウィキソフトウェアの開発
[![メタウィキ](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/ "メタウィキ")
**[メタウィキ](https://meta.wikimedia.org/)**  
全プロジェクトの議論
[![ウィキブックス](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://ja.wikibooks.org/wiki/ "ウィキブックス")
**[ウィキブックス](https://ja.wikibooks.org/)**  
教科書や解説書
[![ウィキデータ](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "ウィキデータ")
**[ウィキデータ](https://www.wikidata.org/)**  
フリー知識ベース
[![ウィキニュース](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://ja.wikinews.org/wiki/ "ウィキニュース")
**[ウィキニュース](https://ja.wikinews.org/)**  
自由なニュース
[![ウィキクォート](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://ja.wikiquote.org/wiki/ "ウィキクォート")
**[ウィキクォート](https://ja.wikiquote.org/)**  
引用句集
[![ウィキソース](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://ja.wikisource.org/wiki/ "ウィキソース")
**[ウィキソース](https://ja.wikisource.org/)**  
著作権フリー文書
[![ウィキスピーシーズ](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/ "ウィキスピーシーズ")
**[ウィキスピーシーズ](https://species.wikimedia.org/)**  
生物種のディレクトリ
[![ウィキバーシティ](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/60px-Wikiversity-logo.svg.png)](https://ja.wikiversity.org/wiki/ "ウィキバーシティ")
**[ウィキバーシティ](https://ja.wikiversity.org/)**  
学習支援
[![ウィキボヤージュ](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://en.wikivoyage.org/wiki/ja: "ウィキボヤージュ")
**[ウィキボヤージュ](https://ja.wikivoyage.org/)**   
フリー旅行ガイド
[![ウィクショナリー](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://ja.wiktionary.org/wiki/ "ウィクショナリー")
**[ウィクショナリー](https://ja.wiktionary.org/)**  
多機能辞典
ウィキペディアは日本語をはじめ約300の言語で執筆されています。全ての言語版については[ウィキペディアの一覧](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%9A%E3%83%87%E3%82%A3%E3%82%A2%E3%81%AE%E4%B8%80%E8%A6%A7 "Wikipedia:ウィキペディアの一覧")や[全言語版の統計](https://ja.wikipedia.org/wiki/Wikipedia:%E5%85%A8%E8%A8%80%E8%AA%9E%E7%89%88%E3%81%AE%E7%B5%B1%E8%A8%88 "Wikipedia:全言語版の統計")をご覧ください。以下は特に規模の大きな言語版です。 
  * [English](https://en.wikipedia.org/wiki/ "en:")
  * [Deutsch](https://de.wikipedia.org/wiki/ "de:")
  * [svenska](https://sv.wikipedia.org/wiki/ "sv:")
  * [français](https://fr.wikipedia.org/wiki/ "fr:")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "nl:")
  * [русский](https://ru.wikipedia.org/wiki/ "ru:")
  * [español](https://es.wikipedia.org/wiki/ "es:")
  * [italiano](https://it.wikipedia.org/wiki/ "it:")
  * [polski](https://pl.wikipedia.org/wiki/ "pl:")
  * [中文](https://zh.wikipedia.org/wiki/ "zh:")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vi:")
  * [українська](https://uk.wikipedia.org/wiki/ "uk:")
  * [العربية](https://ar.wikipedia.org/wiki/ "ar:")
  * [português](https://pt.wikipedia.org/wiki/ "pt:")
  * [فارسی](https://fa.wikipedia.org/wiki/ "fa:")
  * [català](https://ca.wikipedia.org/wiki/ "ca:")
  * [српски / srpski](https://sr.wikipedia.org/wiki/ "sr:")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "id:")
  * [한국어](https://ko.wikipedia.org/wiki/ "ko:")
  * [norsk](https://no.wikipedia.org/wiki/ "no:")
  * [suomi](https://fi.wikipedia.org/wiki/ "fi:")
  * [čeština](https://cs.wikipedia.org/wiki/ "cs:")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "tr:")
  * [magyar](https://hu.wikipedia.org/wiki/ "hu:")
  * [srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "sh:")


ウィキペディアの運営は皆様の寄付によって成り立っています。**[ご理解・ご協力](https://donate.wikimedia.org/wiki/Special:FundraiserRedirector "donate:Special:FundraiserRedirector")** 賜りますようよろしくお願い申し上げます。 
「[https://ja.wikipedia.org/w/index.php?title=メインページ&oldid=93774786](https://ja.wikipedia.org/w/index.php?title=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&oldid=93774786)」から取得
50 個の言語版
  * [العربية](https://ar.wikipedia.org/wiki/ "アラビア語")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/ "アゼルバイジャン語")
  * [Български](https://bg.wikipedia.org/wiki/ "ブルガリア語")
  * [Català](https://ca.wikipedia.org/wiki/ "カタロニア語")
  * [Čeština](https://cs.wikipedia.org/wiki/ "チェコ語")
  * [Dansk](https://da.wikipedia.org/wiki/ "デンマーク語")
  * [Deutsch](https://de.wikipedia.org/wiki/ "ドイツ語")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "ギリシャ語")
  * [English](https://en.wikipedia.org/wiki/ "英語")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "エスペラント語")
  * [Español](https://es.wikipedia.org/wiki/ "スペイン語")
  * [Eesti](https://et.wikipedia.org/wiki/ "エストニア語")
  * [Euskara](https://eu.wikipedia.org/wiki/ "バスク語")
  * [فارسی](https://fa.wikipedia.org/wiki/ "ペルシア語")
  * [Suomi](https://fi.wikipedia.org/wiki/ "フィンランド語")
  * [Français](https://fr.wikipedia.org/wiki/ "フランス語")
  * [Galego](https://gl.wikipedia.org/wiki/ "ガリシア語")
  * [עברית](https://he.wikipedia.org/wiki/ "ヘブライ語")
  * [हिन्दी](https://hi.wikipedia.org/wiki/ "ヒンディー語")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "クロアチア語")
  * [Magyar](https://hu.wikipedia.org/wiki/ "ハンガリー語")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "インドネシア語")
  * [Italiano](https://it.wikipedia.org/wiki/ "イタリア語")
  * [ქართული](https://ka.wikipedia.org/wiki/ "ジョージア語")
  * [Қазақша](https://kk.wikipedia.org/wiki/ "カザフ語")
  * [한국어](https://ko.wikipedia.org/wiki/ "韓国語")
  * [Latina](https://la.wikipedia.org/wiki/ "ラテン語")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "リトアニア語")
  * [Македонски](https://mk.wikipedia.org/wiki/ "マケドニア語")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "マレー語")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/ "ネワール語")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "オランダ語")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "ノルウェー語\(ニーノシュク\)")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "ノルウェー語\(ブークモール\)")
  * [Polski](https://pl.wikipedia.org/wiki/ "ポーランド語")
  * [Português](https://pt.wikipedia.org/wiki/ "ポルトガル語")
  * [Română](https://ro.wikipedia.org/wiki/ "ルーマニア語")
  * [Русский](https://ru.wikipedia.org/wiki/ "ロシア語")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "セルボ・クロアチア語")
  * [Simple English](https://simple.wikipedia.org/wiki/ "シンプル英語")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "スロバキア語")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "スロベニア語")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "セルビア語")
  * [Svenska](https://sv.wikipedia.org/wiki/ "スウェーデン語")
  * [ไทย](https://th.wikipedia.org/wiki/ "タイ語")
  * [Tagalog](https://tl.wikipedia.org/wiki/ "タガログ語")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "トルコ語")
  * [Українська](https://uk.wikipedia.org/wiki/ "ウクライナ語")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "ベトナム語")
  * [中文](https://zh.wikipedia.org/wiki/ "中国語")


  * 最終更新 2023年2月8日 (水) 15:04 （日時は[個人設定](https://ja.wikipedia.org/wiki/%E7%89%B9%E5%88%A5:%E5%80%8B%E4%BA%BA%E8%A8%AD%E5%AE%9A#mw-prefsection-rendering "特別:個人設定")で未設定ならば[UTC](https://ja.wikipedia.org/wiki/%E5%8D%94%E5%AE%9A%E4%B8%96%E7%95%8C%E6%99%82 "協定世界時")）。
  * テキストは[クリエイティブ・コモンズ 表示-継承ライセンス](https://creativecommons.org/licenses/by-sa/4.0/deed.ja)のもとで利用できます。追加の条件が適用される場合があります。詳細については[利用規約](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use)を参照してください。


  * [プライバシー・ポリシー](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy/ja)
  * [ウィキペディアについて](https://ja.wikipedia.org/wiki/Wikipedia:%E3%82%A6%E3%82%A3%E3%82%AD%E3%83%9A%E3%83%87%E3%82%A3%E3%82%A2%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6)
  * [免責事項](https://ja.wikipedia.org/wiki/Wikipedia:%E5%85%8D%E8%B2%AC%E4%BA%8B%E9%A0%85)
  * [行動規範](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [開発者](https://developer.wikimedia.org)
  * [統計](https://stats.wikimedia.org/#/ja.wikipedia.org)
  * [Cookieに関する声明](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [モバイルビュー](https://ja.wikipedia.org/w/index.php?title=%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8&mobileaction=toggle_view_mobile)
  * [プレビュー設定を編集する](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)


  * [![Wikimedia Foundation](https://ja.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://ja.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


検索
検索
メインページ
[](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8) [](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8) [](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8) [](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8) [](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8) [](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8) [](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8) [](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
50 個の言語版 [話題を追加 ](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8)
