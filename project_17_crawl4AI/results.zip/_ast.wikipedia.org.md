[Saltar al conteníu](https://ast.wikipedia.org/wiki/Portada#bodyContent)
Menú principal
Menú principal
mover a la barra llateral despintar
Navegación 
  * [Portada](https://ast.wikipedia.org/wiki/Portada "Visita la portada \[alt-z\]")
  * [Portal de la comunidá](https://ast.wikipedia.org/wiki/Wikipedia:Portal_de_la_comunid%C3%A1 "Tocante al proyeutu, lo qué pues facer, ú s'alcuentren les coses")
  * [Cambeos recién](https://ast.wikipedia.org/wiki/Especial:CambeosRecientes "La llista de cambios recientes de la wiki. \[alt-r\]")
  * [Páxina al debalu](https://ast.wikipedia.org/wiki/Especial:Aleatoria "Carga una páxina al debalu \[alt-x\]")
  * [Páxines especiales](https://ast.wikipedia.org/wiki/Especial:P%C3%A1ginasEspeciales)
  * [Ayuda](https://www.mediawiki.org/wiki/Special:MyLanguage/Help:Contents "El llugar pa deprender")


[ ![](https://ast.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://ast.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![La Enciclopedia Llibre](https://ast.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-ast.svg) ](https://ast.wikipedia.org/wiki/Portada)
[Buscar ](https://ast.wikipedia.org/wiki/Especial:Gueta "Busca en Wikipedia \[alt-f\]")
Guetar
Apariencia
Apariencia
mover a la barra llateral despintar
Testu
  * Pequeñu
Estándar
Grande

Esta páxina usa siempre'l tamañu de fonte pequeñu
Anchor
  * Estándar
Wide

El conteníu ye lo más ampliu posible pa la ventana del navegador.
  * [Donativos](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ast.wikipedia.org&uselang=ast)
  * [Crear una cuenta](https://ast.wikipedia.org/w/index.php?title=Especial:Crear_una_cuenta&returnto=Portada "Encamentámoste que crees una cuenta y qu'anicies sesión; sicasí, nun ye obligatorio")
  * [Entrar](https://ast.wikipedia.org/w/index.php?title=Especial:Entrar&returnto=Portada "T'encamentamos que t'identifiques, anque nun ye obligatorio \[alt-o\]")


Ferramientes personales
  * [Donativos](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ast.wikipedia.org&uselang=ast)
  * [Crear una cuenta](https://ast.wikipedia.org/w/index.php?title=Especial:Crear_una_cuenta&returnto=Portada "Encamentámoste que crees una cuenta y qu'anicies sesión; sicasí, nun ye obligatorio")
  * [Entrar](https://ast.wikipedia.org/w/index.php?title=Especial:Entrar&returnto=Portada "T'encamentamos que t'identifiques, anque nun ye obligatorio \[alt-o\]")


# Portada
  * [Portada](https://ast.wikipedia.org/wiki/Portada "Ver la páxina de conteníu \[alt-c\]")
  * [Alderique](https://ast.wikipedia.org/wiki/Alderique:Portada "Alderique tocante al conteníu de la páxina \[alt-t\]")


asturianu
  * [Lleer](https://ast.wikipedia.org/wiki/Portada)
  * [Ver fonte](https://ast.wikipedia.org/w/index.php?title=Portada&action=edit "Esta páxina ta protexida.
Pues ver el so códigu fonte. \[alt-e\]")
  * [Ver historial](https://ast.wikipedia.org/w/index.php?title=Portada&action=history "Versiones antigües d'esta páxina \[alt-h\]")


Ferramientes
Ferramientes
mover a la barra llateral despintar
Aiciones 
  * [Lleer](https://ast.wikipedia.org/wiki/Portada)
  * [Ver fonte](https://ast.wikipedia.org/w/index.php?title=Portada&action=edit)
  * [Ver historial](https://ast.wikipedia.org/w/index.php?title=Portada&action=history)


Xeneral 
  * [Lo qu'enllaza equí](https://ast.wikipedia.org/wiki/Especial:LoQueEnlazaAqu%C3%AD/Portada "Llista de toles páxines wiki qu'enllacien equí \[alt-j\]")
  * [Cambios rellacionaos](https://ast.wikipedia.org/wiki/Especial:CambiosEnEnlazadas/Portada "Cambios recientes nes páxines enllazaes dende esta \[alt-k\]")
  * [Xubir ficheru](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=ast "Xubir ficheros \[alt-u\]")
  * [Enllaz permanente](https://ast.wikipedia.org/w/index.php?title=Portada&oldid=4396297 "Enllaz permanente a esta revisión de la páxina")
  * [Información de la páxina](https://ast.wikipedia.org/w/index.php?title=Portada&action=info "Más información sobro esta páxina")
  * [Citar esta páxina](https://ast.wikipedia.org/w/index.php?title=Especial:CiteThisPage&page=Portada&id=4396297&wpFormIdentifier=titleform "Información tocante a cómo citar esta páxina")
  * [Llograr la URL encurtiada](https://ast.wikipedia.org/w/index.php?title=Especial:UrlShortener&url=https%3A%2F%2Fast.wikipedia.org%2Fwiki%2FPortada)
  * [Xenerar códigu QR](https://ast.wikipedia.org/w/index.php?title=Especial:QrCode&url=https%3A%2F%2Fast.wikipedia.org%2Fwiki%2FPortada)


Imprentar/esportar 
  * [Crear un llibru](https://ast.wikipedia.org/w/index.php?title=Especial:Book&bookcmd=book_creator&referer=Portada)
  * [Descargar como PDF](https://ast.wikipedia.org/w/index.php?title=Especial:DownloadAsPdf&page=Portada&action=show-download-screen)
  * [Versión pa imprentar](https://ast.wikipedia.org/w/index.php?title=Portada&printable=yes "Versión imprentable d'esta páxina \[alt-p\]")


N'otros proyeutos 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikiespecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikillibros](https://ast.wikibooks.org/wiki/Portada)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikicites](https://ast.wikiquote.org/wiki/Portada)
  * [Wikcionariu](https://ast.wiktionary.org/wiki/Portada)
  * [Elementu de Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Enllaz al elementu del depósitu de datos coneutáu \[alt-g\]")


De Wikipedia
[![](https://upload.wikimedia.org/wikipedia/commons/4/46/Wbar_blue.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Wbar_blue.jpg)
[miércoles 1 d'ochobre](https://ast.wikipedia.org/wiki/1_d%27ochobre "1 d'ochobre")
**[2025](https://ast.wikipedia.org/wiki/2025 "2025")**
[Afáyate](https://ast.wikipedia.org/wiki/Wikipedia:Bienven%C3%ADos "Wikipedia:Bienveníos") na [Wikipedia](https://ast.wikipedia.org/wiki/Wikipedia "Wikipedia"), la enciclopedia llibre en 300 llingües. Equí tamos trabayando pa facela n'[asturianu](https://ast.wikipedia.org/wiki/Asturianu "Asturianu"). Nesta versión yá tenemos [**137 603**](https://ast.wikipedia.org/wiki/Especial:Estad%C3%ADstiques "Especial:Estadístiques") artículos**. Si quies collaborar pues entamar prauticando na[páxina de pruebes](https://ast.wikipedia.org/wiki/Wikipedia:P%C3%A1xina_de_pruebes "Wikipedia:Páxina de pruebes") y deprender a editar na [páxina d'ayuda](https://ast.wikipedia.org/wiki/Wikipedia:Ayuda "Wikipedia:Ayuda") :).  
** [anovar](https://ast.wikipedia.org/w/index.php?title=Portada&action=purge)
_If you don't speak Asturian, you can visit our**[Embassy](https://ast.wikipedia.org/wiki/Wikipedia:Embaxada "Wikipedia:Embaxada")**._   

  

[Archivu](https://ast.wikipedia.org/wiki/Wikipedia:Llist%C3%A1u_d%27art%C3%ADculos_d%27actualid%C3%A1_na_portada "Wikipedia:Llistáu d'artículos d'actualidá na portada")  

[![](https://upload.wikimedia.org/wikipedia/commons/e/e9/Wbar_green3.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Wbar_green3.jpg)
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5b/Xuan_Bello_-_Poesia_Urumea_bazterrean_4_%287286101378%29.jpg/250px-Xuan_Bello_-_Poesia_Urumea_bazterrean_4_%287286101378%29.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Xuan_Bello_-_Poesia_Urumea_bazterrean_4_\(7286101378\).jpg)Xuan Bello recitando en Donostia.
**Xuan Bello** ([Paniceiros](https://ast.wikipedia.org/wiki/Paniceiros "Paniceiros"), [1965](https://ast.wikipedia.org/wiki/1965 "1965"); [Uviéu](https://ast.wikipedia.org/wiki/Uvi%C3%A9u "Uviéu") – [2025](https://ast.wikipedia.org/wiki/2025 "2025")) foi ún de los escritores más destacaos de la lliteratura contemporánea en [llingua asturiana](https://ast.wikipedia.org/wiki/Llingua_asturiana "Llingua asturiana"). Autor de poemarios como _El llibru vieyu_ , _El llibru nuevu_ o _Les islles inciertes_ , y de prosa como _Hestoria Universal de Paniceiros_ , _La memoria del mundu_ o _Meditaciones nel desiertu_ , cultivó una obra fonda, reflexiva y de gran prestixu. Amás de poeta y narrador, foi traductor d'autores como Pessoa, Cunqueiro o Castelao, periodista y activista cultural. 
Recibió tamién distinciones como'l [Premiu Teodoro Cuesta](https://ast.wikipedia.org/wiki/Premiu_Teodoro_Cuesta "Premiu Teodoro Cuesta"), el [Premiu de la Crítica RPA](https://ast.wikipedia.org/wiki/Premiu_de_la_Cr%C3%ADtica_RPA "Premiu de la Crítica RPA") y el [Premiu Nacional de Lliteratura Asturiana](https://ast.wikipedia.org/wiki/Premiu_Nacional_de_Lliteratura_Asturiana "Premiu Nacional de Lliteratura Asturiana") na so primer edición ([2017](https://ast.wikipedia.org/wiki/2017 "2017")), polos sos méritos na dignificación y proyección de la [lliteratura n'asturianu](https://ast.wikipedia.org/wiki/Lliteratura_n%27asturianu "Lliteratura n'asturianu"). 
_**[Lleer más](https://ast.wikipedia.org/wiki/Xuan_Bello "Xuan Bello")**_
  

  

[![](https://upload.wikimedia.org/wikipedia/commons/e/e8/Wbar_pink.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Wbar_pink.jpg)
**Un día como güei...**
**[1 d'ochobre](https://ast.wikipedia.org/wiki/1_d%27ochobre "1 d'ochobre")** : 
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Youngest_parader_in_New_York_City_suffragist_parade_LCCN97500068_%28cropped%29.jpg/120px-Youngest_parader_in_New_York_City_suffragist_parade_LCCN97500068_%28cropped%29.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Youngest_parader_in_New_York_City_suffragist_parade_LCCN97500068_\(cropped\).jpg)
  * [1823](https://ast.wikipedia.org/wiki/1823 "1823"): [España](https://ast.wikipedia.org/wiki/Espa%C3%B1a "España"): [Fernandu VII](https://ast.wikipedia.org/wiki/Fernandu_VII_d%27Espa%C3%B1a "Fernandu VII d'España") restablez la [inquisición](https://ast.wikipedia.org/wiki/Inquisici%C3%B3n "Inquisición").
  * **[1931](https://ast.wikipedia.org/wiki/1931 "1931")** : La [Segunda República Española](https://ast.wikipedia.org/wiki/Segunda_Rep%C3%BAblica_Espa%C3%B1ola "Segunda República Española") reconoz el [sufraxu universal](https://ast.wikipedia.org/wiki/Sufraxu_universal "Sufraxu universal") concediendo'l **[derechu al votu a les muyeres](https://ast.wikipedia.org/wiki/Sufraxu_femen%C3%ADn "Sufraxu femenín")**.
  * [1949](https://ast.wikipedia.org/wiki/1949 "1949"): Proclamación por [Mao Zedong](https://ast.wikipedia.org/wiki/Mao_Zedong "Mao Zedong") de la [República Popular China](https://ast.wikipedia.org/wiki/Rep%C3%BAblica_Popular_China "República Popular China").
  * [1994](https://ast.wikipedia.org/wiki/1994 "1994"): [Paláu](https://ast.wikipedia.org/wiki/Pal%C3%A1u "Paláu") llogra la [independencia](https://ast.wikipedia.org/wiki/Independencia "Independencia").


  
  

  

**Persones finaes de recién**
  * ([29 de setiembre](https://ast.wikipedia.org/wiki/29_de_setiembre "29 de setiembre")) [Adriana Aizemberg](https://ast.wikipedia.org/wiki/Adriana_Aizemberg "Adriana Aizemberg"), actriz arxentina (86 años)
  * ([28 de setiembre](https://ast.wikipedia.org/wiki/28_de_setiembre "28 de setiembre")) [Javier García](https://ast.wikipedia.org/wiki/Javier_Garc%C3%ADa "Javier García"), xugador de balonmano asturianu (1947-2025) (78 años)
  * ([23 de setiembre](https://ast.wikipedia.org/wiki/23_de_setiembre "23 de setiembre")) [Claudia Cardinale](https://ast.wikipedia.org/wiki/Claudia_Cardinale "Claudia Cardinale"), actriz italiana (1938-2025) (87 años)
  * ([19 de setiembre](https://ast.wikipedia.org/wiki/19_de_setiembre "19 de setiembre")) [Miguel Morales Barretto](https://ast.wikipedia.org/wiki/Miguel_Morales_Barretto "Miguel Morales Barretto"), músicu filipín (1950-2025) (75 años)
  * ([19 de setiembre](https://ast.wikipedia.org/wiki/19_de_setiembre "19 de setiembre")) [Julieta Norma Fierro Gossman](https://ast.wikipedia.org/wiki/Julieta_Norma_Fierro_Gossman "Julieta Norma Fierro Gossman"), atrofísica mexicana (1948-2025) (77 años)
  * ([16 de setiembre](https://ast.wikipedia.org/wiki/16_de_setiembre "16 de setiembre")) [Robert Redford](https://ast.wikipedia.org/wiki/Robert_Redford "Robert Redford"), actor y direutor de cine d'Estaos Xuníos (1936-2025) (89 años)
  * ([14 de setiembre](https://ast.wikipedia.org/wiki/14_de_setiembre "14 de setiembre")) [Pat Crowley](https://ast.wikipedia.org/wiki/Pat_Crowley "Pat Crowley"), actriz estauxunidense (1933-2025) (91 años)
  * ([14 de setiembre](https://ast.wikipedia.org/wiki/14_de_setiembre "14 de setiembre")) [Jaime Rodríguez](https://ast.wikipedia.org/wiki/Jaime_Rodr%C3%ADguez "Jaime Rodríguez"), futbolista salvadorianu (1959-2025) (66 años)


Fin de llista xenerada automáticamente dende Wikidata.
[![](https://upload.wikimedia.org/wikipedia/commons/7/75/Wbar_purple.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Wbar_purple.jpg)
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Nuvola_apps_kate.png/40px-Nuvola_apps_kate.png)](https://ast.wikipedia.org/wiki/Ficheru:Nuvola_apps_kate.png)
  
  

[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Presa_de_decissions.png/40px-Presa_de_decissions.png)](https://ast.wikipedia.org/wiki/Ficheru:Presa_de_decissions.png) [Entra nel **Portal de la Comunidá**](https://ast.wikipedia.org/wiki/Wikipedia:Portal_de_la_comunid%C3%A1 "Wikipedia:Portal de la comunidá")  
  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Nuvola_apps_kteatime.png/40px-Nuvola_apps_kteatime.png)](https://ast.wikipedia.org/wiki/Ficheru:Nuvola_apps_kteatime.png) [Ve al **chigre** pa esclariar duldes y facer propuestes](https://ast.wikipedia.org/wiki/Wikipedia:Chigre "Wikipedia:Chigre")  
  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/52/Nuvola_apps_edu_miscellaneous.png/40px-Nuvola_apps_edu_miscellaneous.png)](https://ast.wikipedia.org/wiki/Ficheru:Nuvola_apps_edu_miscellaneous.png) [Plantega equí les **duldes gramaticales y léxiques**](https://ast.wikipedia.org/wiki/Wikipedia:Chigre/Ortograf%C3%ADa "Wikipedia:Chigre/Ortografía") y [consulta'l DALLA](https://diccionariu.alladixital.org)   
  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Nuvola_apps_filetypes.png/40px-Nuvola_apps_filetypes.png)](https://ast.wikipedia.org/wiki/Ficheru:Nuvola_apps_filetypes.png) [**Manual** básicu pa facer el to primer artículu](https://ast.wikipedia.org/wiki/Ayuda:C%C3%B3mo_pues_collaborar "Ayuda:Cómo pues collaborar")  
  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/Nuvola_apps_khexedit.png/40px-Nuvola_apps_khexedit.png)](https://ast.wikipedia.org/wiki/Ficheru:Nuvola_apps_khexedit.png) [Llista d'artículos que toles Wikipedies habríen de tener](https://ast.wikipedia.org/wiki/Wikipedia:Llista_d%27art%C3%ADculos_que_toles_Wikipedies_habr%C3%ADen_de_tener "Wikipedia:Llista d'artículos que toles Wikipedies habríen de tener")   
  

  

[![](https://upload.wikimedia.org/wikipedia/commons/e/e8/Wbar_pink.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Wbar_pink.jpg)
[Archivu](https://ast.wikipedia.org/wiki/Wikipedia:Imaxe_destacada "Wikipedia:Imaxe destacada")  

[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/Trial_by_Jury_-_Chaos_in_the_Courtroom.png/250px-Trial_by_Jury_-_Chaos_in_the_Courtroom.png)](https://ast.wikipedia.org/wiki/Ficheru:Trial_by_Jury_-_Chaos_in_the_Courtroom.png)  
---  
Grabáu de la ópera cómica _Trial_ por **[Jury de Gilbert y Sullivan](https://ast.wikipedia.org/w/index.php?title=Jury_de_Gilbert_y_Sullivan&action=edit&redlink=1 "Jury de Gilbert y Sullivan \(la páxina nun esiste\)")**. 
  

  

[![](https://upload.wikimedia.org/wikipedia/commons/c/ce/Wbar_yellow.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Wbar_yellow.jpg)
[![Gatu](https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Bastet-E_2533-Egypte_louvre_058.jpg/60px-Bastet-E_2533-Egypte_louvre_058.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Bastet-E_2533-Egypte_louvre_058.jpg "Gatu")
  * ... nel **[Antiguu Exiptu](https://ast.wikipedia.org/wiki/Antiguu_Exiptu "Antiguu Exiptu")** , los [gatos](https://ast.wikipedia.org/wiki/Gatu "Gatu") gociaben d'una consideranza especial y yeren representaos n'[obres d'arte](https://ast.wikipedia.org/wiki/Obres_d%27arte "Obres d'arte")?
  * ... dalgunos [organismos](https://ast.wikipedia.org/wiki/Ser_vivu "Ser vivu") se reproducen ensin sexu? L'**[ameba](https://ast.wikipedia.org/w/index.php?title=Ameba&action=edit&redlink=1 "Ameba \(la páxina nun esiste\)")** , por exemplu, dixébrase en dos.
  * ... la mesma **[nicotina](https://ast.wikipedia.org/wiki/Nicotina "Nicotina")** qu'hai nos [cigarros](https://ast.wikipedia.org/wiki/Cigarru "Cigarru") ye un [velenu](https://ast.wikipedia.org/wiki/Velenu "Velenu") tan potente que lu empleguen en bien d'[insecticides](https://ast.wikipedia.org/wiki/Insecticida "Insecticida")?


  

  

  

[![](https://upload.wikimedia.org/wikipedia/commons/9/90/Wbar_green2.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Wbar_green2.jpg)
[Toles categoríes](https://ast.wikipedia.org/wiki/Especial:Categor%C3%ADas "Especial:Categorías")
####  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Nuvola_apps_kalzium.png/40px-Nuvola_apps_kalzium.png)](https://ast.wikipedia.org/wiki/Ficheru:Nuvola_apps_kalzium.png) [Ciencies naturales](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Ciencies_naturales "Categoría:Ciencies naturales")      [Astronomía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Astronom%C3%ADa "Categoría:Astronomía") - [Bioloxía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Biolox%C3%ADa "Categoría:Bioloxía") - [Física](https://ast.wikipedia.org/wiki/Categor%C3%ADa:F%C3%ADsica "Categoría:Física") - [Xeoloxía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Xeolox%C3%ADa "Categoría:Xeoloxía") - [Matemátiques](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Matem%C3%A1tiques "Categoría:Matemátiques") - [Química](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Qu%C3%ADmica "Categoría:Química")
####  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Nuvola_apps_kdmconfig.png/40px-Nuvola_apps_kdmconfig.png)](https://ast.wikipedia.org/wiki/Ficheru:Nuvola_apps_kdmconfig.png) [Ciencies humanes](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Ciencies_humanes "Categoría:Ciencies humanes") y [ciencies sociales](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Ciencies_sociales "Categoría:Ciencies sociales")      [Antropoloxía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Antropolox%C3%ADa "Categoría:Antropoloxía") - [Derechu](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Derechu "Categoría:Derechu") - [Economía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Econom%C3%ADa "Categoría:Economía") - [Educación](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Educaci%C3%B3n "Categoría:Educación") - [Filosofía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Filosof%C3%ADa "Categoría:Filosofía") - [Xeografía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Xeograf%C3%ADa "Categoría:Xeografía") - [Historia](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Historia "Categoría:Historia") - [Llingüística](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Lling%C3%BC%C3%ADstica "Categoría:Llingüística") - [Política](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Pol%C3%ADtica "Categoría:Política") - [Sicoloxía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Sicolox%C3%ADa "Categoría:Sicoloxía") - [Socioloxía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Sociolox%C3%ADa "Categoría:Socioloxía") - [Toponimia](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Toponimia "Categoría:Toponimia")
####  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Crystal_Clear_app_Login_Manager.svg/40px-Crystal_Clear_app_Login_Manager.svg.png)](https://ast.wikipedia.org/wiki/Ficheru:Crystal_Clear_app_Login_Manager.svg) [Biografíes](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Biograf%C3%ADes "Categoría:Biografíes")      [Actores y actrices](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Actores_y_actrices "Categoría:Actores y actrices") - [Científicos y científiques](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Cient%C3%ADficos_y_cient%C3%ADfiques "Categoría:Científicos y científiques") - [Deportistes](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Deportistes "Categoría:Deportistes") - [Escritores](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Escritores "Categoría:Escritores") - [Historiadores](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Historiadores "Categoría:Historiadores") - [Informáticos ya informátiques](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Inform%C3%A1ticos_ya_inform%C3%A1tiques "Categoría:Informáticos ya informátiques") - [Músicos y músiques](https://ast.wikipedia.org/wiki/Categor%C3%ADa:M%C3%BAsicos_y_m%C3%BAsiques "Categoría:Músicos y músiques") - [Políticos y polítiques](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Pol%C3%ADticos_y_pol%C3%ADtiques "Categoría:Políticos y polítiques") - [Relixosos y relixoses](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Relixosos_y_relixoses "Categoría:Relixosos y relixoses")
####  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Nuvola_apps_display.png/40px-Nuvola_apps_display.png)](https://ast.wikipedia.org/wiki/Ficheru:Nuvola_apps_display.png) [Ciencies aplicaes](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Ciencies_aplicaes "Categoría:Ciencies aplicaes") y [Teunoloxía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Teunolox%C3%ADa "Categoría:Teunoloxía")      [Agricultura](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Agricultura "Categoría:Agricultura") - [Ciencies de la salú](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Ciencies_de_la_sal%C3%BA "Categoría:Ciencies de la salú") - [Comunicaciones](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Comunicaciones "Categoría:Comunicaciones") – [Informática](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Inform%C3%A1tica "Categoría:Informática") - [Inxeniería](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Inxenier%C3%ADa "Categoría:Inxeniería")
####  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Nuvola_apps_bookcase.svg/40px-Nuvola_apps_bookcase.svg.png)](https://ast.wikipedia.org/wiki/Ficheru:Nuvola_apps_bookcase.svg) [Artes](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Artes "Categoría:Artes") y [Cultura](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Cultura "Categoría:Cultura")      [Arquiteutura](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Arquiteutura "Categoría:Arquiteutura") - [Artesanía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Artesan%C3%ADa "Categoría:Artesanía") -[Relixón](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Relix%C3%B3n "Categoría:Relixón") - [Artes gráfiques](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Artes_gr%C3%A1fiques "Categoría:Artes gráfiques") - [Cine](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Cine "Categoría:Cine") - [Danza](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Danza "Categoría:Danza") - [Escultura](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Escultura "Categoría:Escultura") - [Fotografía](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Fotograf%C3%ADa "Categoría:Fotografía") - [Cómic](https://ast.wikipedia.org/wiki/Categor%C3%ADa:C%C3%B3mic "Categoría:Cómic") - [Lliteratura](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Lliteratura "Categoría:Lliteratura") - [Música](https://ast.wikipedia.org/wiki/Categor%C3%ADa:M%C3%BAsica "Categoría:Música") - [Pintura](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Pintura "Categoría:Pintura")
####  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/13/Nuvola_filesystems_folder_home.png/40px-Nuvola_filesystems_folder_home.png)](https://ast.wikipedia.org/wiki/Ficheru:Nuvola_filesystems_folder_home.png) [Sociedá](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Socied%C3%A1 "Categoría:Sociedá")      [Espectáculos](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Espect%C3%A1culos "Categoría:Espectáculos") - [Deportes](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Deportes "Categoría:Deportes") - [Fuelga](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Fuelga "Categoría:Fuelga") - [Xuegos](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Xuegos "Categoría:Xuegos")
  

[![](https://upload.wikimedia.org/wikipedia/commons/8/82/Wbar_white.jpg)](https://ast.wikipedia.org/wiki/Ficheru:Wbar_white.jpg)
[![Wikipedia](https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/125px-Wikipedia-logo.png)](https://ast.wikipedia.org/wiki/Ficheru:Wikipedia-logo.png "Wikipedia")Wikipedia
**Wikipedies n'otres llingües**
  

_**Con más de 5.000.000 artículos**_  
[Inglés](https://en.wikipedia.org/wiki/ "en:") · [Cebuanu](https://ceb.wikipedia.org/wiki/ "ceb:")   

_**Con más de 2.500.000 artículos**_  
[Suecu](https://sv.wikipedia.org/wiki/ "sv:")   

_**Con más de 1.000.000 artículos**_  
[Alemán](https://de.wikipedia.org/wiki/ "de:") · [Chinu](https://zh.wikipedia.org/wiki/ "zh:") · [Español](https://es.wikipedia.org/wiki/ "es:") · [Francés](https://fr.wikipedia.org/wiki/ "fr:") · [Italianu](https://it.wikipedia.org/wiki/ "it:") · [Neerlandés](https://nl.wikipedia.org/wiki/ "nl:") · [Portugués](https://pt.wikipedia.org/wiki/ "pt:") · [Polacu](https://pl.wikipedia.org/wiki/ "pl:") · [Rusu](https://ru.wikipedia.org/wiki/ "ru:") · [Samaranu](https://war.wikipedia.org/wiki/ "war:")· [Vietnamita](https://vi.wikipedia.org/wiki/ "vi:") · [Xaponés](https://ja.wikipedia.org/wiki/ "ja:")   

_**Con más de 500.000 artículos**_  
[Árabe](https://ar.wikipedia.org/wiki/ "ar:") · [Catalán](https://ca.wikipedia.org/wiki/ "ca:") · [Persa](https://fa.wikipedia.org/wiki/ "fa:") · [Ucraín](https://uk.wikipedia.org/wiki/ "uk:")   

_**Con más de 250.000 artículos**_  
[Checu](https://cs.wikipedia.org/wiki/ "cs:") · [Coreanu](https://ko.wikipedia.org/wiki/ "ko:") · [Eusquera](https://eu.wikipedia.org/wiki/ "eu:") · [Finés](https://fi.wikipedia.org/wiki/ "fi:") · [Húngaru](https://hu.wikipedia.org/wiki/ "hu:") · [Indonesiu](https://id.wikipedia.org/wiki/ "id:") · [Malayu](https://ms.wikipedia.org/wiki/ "ms:") · [Noruegu](https://no.wikipedia.org/wiki/ "no:") · [Rumanu](https://ro.wikipedia.org/wiki/ "ro:") · [Serbiu](https://sr.wikipedia.org/wiki/ "sr:") · [Serbocroata](https://sh.wikipedia.org/wiki/ "sh:") · [Turcu](https://tr.wikipedia.org/wiki/ "tr:")   

_**Con más de 100.000 artículos**_  
[Armeniu](https://hy.wikipedia.org/wiki/ "hy:") · Asturianu · [Azerbaixanu](https://az.wikipedia.org/wiki/ "az:") · [Bielorrusu](https://be.wikipedia.org/wiki/ "be:") · [Búlgaru](https://bg.wikipedia.org/wiki/ "bg:") · [Chechenu](https://ce.wikipedia.org/wiki/ "ce:") · [Croata](https://hr.wikipedia.org/wiki/ "hr:") · [Danés](https://da.wikipedia.org/wiki/ "da:") · [Eslovacu](https://sk.wikipedia.org/wiki/ "sk:") · [Eslovenu](https://sl.wikipedia.org/wiki/ "sl:") · [Esperantu](https://eo.wikipedia.org/wiki/ "eo:") · [Estoniu](https://et.wikipedia.org/wiki/ "et:") · [Gallegu](https://gl.wikipedia.org/wiki/ "gl:") · [Griegu](https://el.wikipedia.org/wiki/ "el:") · [Hebréu](https://he.wikipedia.org/wiki/ "he:") · [Hindi](https://hi.wikipedia.org/wiki/ "hi:") · [Inglés simple](https://simple.wikipedia.org/wiki/ "simple:") · [Kazaquistanín](https://kk.wikipedia.org/wiki/ "kk:") · [Lituanu](https://lt.wikipedia.org/wiki/ "lt:") · [Llatín](https://la.wikipedia.org/wiki/ "la:") · [Min nan](https://zh-min-nan.wikipedia.org/wiki/ "zh-min-nan:") · [Minangkabau](https://min.wikipedia.org/wiki/ "min:") · [Nynorsk](https://nn.wikipedia.org/wiki/ "nn:") · [Tailandés](https://th.wikipedia.org/wiki/ "th:") · [Tamil](https://ta.wikipedia.org/wiki/ "ta:") · [Urdú](https://ur.wikipedia.org/wiki/ "ur:") · [Uzbequistanín](https://uz.wikipedia.org/wiki/ "uz:") · [Volapük](https://vo.wikipedia.org/wiki/ "vo:") · [Xeorxanu](https://ka.wikipedia.org/wiki/ "ka:")   

_**Con más de 50.000 artículos**_  
[Afrikaans](https://af.wikipedia.org/wiki/ "af:") · [Albanés](https://sq.wikipedia.org/wiki/ "sq:") · [Azerbaixanu del sur](https://azb.wikipedia.org/wiki/ "azb:") · [Bengalín](https://bn.wikipedia.org/wiki/ "bn:") · [Bielorrusu clásicu](https://be-tarask.wikipedia.org/wiki/ "be-x-old:") · [Bosniu](https://bs.wikipedia.org/wiki/ "bs:") · [Bretón](https://br.wikipedia.org/wiki/ "br:") · [Cantonés](https://zh-yue.wikipedia.org/wiki/ "zh-yue:") · [Chechenu](https://ce.wikipedia.org/wiki/ "ce:") · [Galés](https://cy.wikipedia.org/wiki/ "cy:") · [Haitianu](https://ht.wikipedia.org/wiki/ "ht:") · [Kirguís](https://ky.wikipedia.org/wiki/ "ky:") · [Letón](https://lv.wikipedia.org/wiki/ "lv:") · [Luxemburgués](https://lb.wikipedia.org/wiki/ "lb:") · [Macedoniu](https://mk.wikipedia.org/wiki/ "mk:") · [Malayalam](https://ml.wikipedia.org/wiki/ "ml:") · [Malgaxe](https://mg.wikipedia.org/wiki/ "mg:") · [Marathi](https://mr.wikipedia.org/wiki/ "mr:") · [Nepal Bhasa](https://new.wikipedia.org/wiki/ "new:") · [Occitanu](https://oc.wikipedia.org/wiki/ "oc:") · [Piamontés](https://pms.wikipedia.org/wiki/ "pms:") · [Tagalu‬](https://tl.wikipedia.org/wiki/ "tl:") · [Tártaru](https://tt.wikipedia.org/wiki/ "tt:") · [Taxiquistanín](https://tg.wikipedia.org/wiki/ "tg:") · [Telugu](https://te.wikipedia.org/wiki/ "te:") · [Xavanés](https://jv.wikipedia.org/wiki/ "jv:")
  

**[Ver la llista completa de Wikipedies](https://ast.wikipedia.org/wiki/Llista_de_Wikipedies "Llista de Wikipedies")**   

  
  
**Proyeutos hermanos n'asturianu:**  

Wikipedia ye ún de los proyeutos Wikimedia, de conteníu llibre y alministráu téunicamente pola [Fundación Wikimedia](https://ast.wikipedia.org/wiki/Fundaci%C3%B3n_Wikimedia "Fundación Wikimedia"), una organización d'Estaos Xuníos ensin ánimu d'arriquecimientu.   
---  
[35x50px||link=wikt:](https://ast.wikipedia.org/w/index.php?title=Imagen:Wiktionary-logo.svg&action=edit&redlink=1 "Imagen:Wiktionary-logo.svg \(la páxina nun esiste\)") |  [**Wikcionariu**](https://ast.wiktionary.org/wiki/ "wikt:")  
Diccionariu llibre con sinónimos  |  [35x50px||link=b:](https://ast.wikipedia.org/w/index.php?title=Imagen:Wikibooks-logo.svg&action=edit&redlink=1 "Imagen:Wikibooks-logo.svg \(la páxina nun esiste\)") |  [**Wikillibros**](https://ast.wikibooks.org/wiki/ "b:")  
Llibros de testu y manuales  |  [35x50px||link=q:](https://ast.wikipedia.org/w/index.php?title=Imagen:Wikiquote-logo.svg&action=edit&redlink=1 "Imagen:Wikiquote-logo.svg \(la páxina nun esiste\)") |  [**Wikiquote**](https://ast.wikiquote.org/wiki/ "q:")  
Esbilla de cites   
[35x50px||link=s:Main Page/Asturianu](https://ast.wikipedia.org/w/index.php?title=Imagen:Wikisource-logo.svg&action=edit&redlink=1 "Imagen:Wikisource-logo.svg \(la páxina nun esiste\)") |  [**Wikisource**](https://wikisource.org/wiki/Main_Page/Asturianu)  
Esbilla de documentos nel dominiu públicu  |  [35x50px||link=wikispecies:Páxina principal](https://ast.wikipedia.org/w/index.php?title=Imagen:Wikispecies-logo.svg&action=edit&redlink=1 "Imagen:Wikispecies-logo.svg \(la páxina nun esiste\)") |  [**Wikispecies**](https://species.wikimedia.org/wiki/P%C3%A1xina_principal "wikispecies:Páxina principal")  
Llistáu d'especies  |  [45x50px||link=n:](https://ast.wikipedia.org/w/index.php?title=Imagen:Wikinews-logo.svg&action=edit&redlink=1 "Imagen:Wikinews-logo.svg \(la páxina nun esiste\)") |  [**Wikinoticies**](https://www.wikinews.org/)  
Noticies llibres   
[35x50px||link=commons:Entamu](https://ast.wikipedia.org/w/index.php?title=Imagen:Commons-logo.svg&action=edit&redlink=1 "Imagen:Commons-logo.svg \(la páxina nun esiste\)") |  [**Commons**](https://commons.wikimedia.org/wiki/Entamu "commons:Entamu")  
Imáxenes y multimedia de llicencia llibre  |  [35x50px||link=m:Portada/ast](https://ast.wikipedia.org/w/index.php?title=Imagen:Wikimedia_Community_Logo.svg&action=edit&redlink=1 "Imagen:Wikimedia Community Logo.svg \(la páxina nun esiste\)") |  [**Meta-Wiki**](https://meta.wikimedia.org/wiki/Portada/ast "m:Portada/ast")  
Coordinación de proyeutos  |  [35x50px||link=v:](https://ast.wikipedia.org/w/index.php?title=Imagen:Wikiversity-logo.svg&action=edit&redlink=1 "Imagen:Wikiversity-logo.svg \(la páxina nun esiste\)") |  [**Wikiversidá**](https://en.wikiversity.org/wiki/Wikiversity:Main_Page)  
Comunidá de deprendizaxe llibre   
[31px||link=voy:Portada](https://ast.wikipedia.org/w/index.php?title=Imagen:Wikivoyage-Logo-v3-icon.svg&action=edit&redlink=1 "Imagen:Wikivoyage-Logo-v3-icon.svg \(la páxina nun esiste\)") |  [**Wikiviaxes**](https://www.wikivoyage.org/)  
Guía de viaxes  |  [47px||link=d:Wikidata:Portada](https://ast.wikipedia.org/w/index.php?title=Imagen:Wikidata-logo.svg&action=edit&redlink=1 "Imagen:Wikidata-logo.svg \(la páxina nun esiste\)") |  [**Wikidata**](https://www.wikidata.org/)  
Base de conocimientu llibre  |  [35px||link=mw:MediaWiki/ast](https://ast.wikipedia.org/w/index.php?title=Imagen:MediaWiki-2020-icon.svg&action=edit&redlink=1 "Imagen:MediaWiki-2020-icon.svg \(la páxina nun esiste\)") |  [**MediaWiki**](https://www.mediawiki.org/wiki/MediaWiki/ast)  
Desenvolvimientu de software llibre   
  

  

Sacáu de «[https://ast.wikipedia.org/w/index.php?title=Portada&oldid=4396297](https://ast.wikipedia.org/w/index.php?title=Portada&oldid=4396297)»
[Categoríes](https://ast.wikipedia.org/wiki/Especial:Categor%C3%ADas "Especial:Categorías"): 
  * [Wikipedia:Llistes basaes en Wikidata](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Wikipedia:Llistes_basaes_en_Wikidata "Categoría:Wikipedia:Llistes basaes en Wikidata")
  * [Principal](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Principal "Categoría:Principal")


Categoría anubrida: 
  * [Wikipedia:Páxines con plantíes nel espaciu de nomes incorreutu](https://ast.wikipedia.org/wiki/Categor%C3%ADa:Wikipedia:P%C3%A1xines_con_plant%C3%ADes_nel_espaciu_de_nomes_incorreutu "Categoría:Wikipedia:Páxines con plantíes nel espaciu de nomes incorreutu")


76 llingües
  * [Aragonés](https://an.wikipedia.org/wiki/ "aragonés")
  * [العربية](https://ar.wikipedia.org/wiki/ "árabe")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/ "azerbaixanu")
  * [Беларуская](https://be.wikipedia.org/wiki/ "bielorrusu")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/ "Belarusian \(Taraškievica orthography\)")
  * [Български](https://bg.wikipedia.org/wiki/ "búlgaru")
  * [Brezhoneg](https://br.wikipedia.org/wiki/ "bretón")
  * [Bosanski](https://bs.wikipedia.org/wiki/ "bosniu")
  * [Català](https://ca.wikipedia.org/wiki/ "catalán")
  * [Нохчийн](https://ce.wikipedia.org/wiki/ "chechenu")
  * [Cebuano](https://ceb.wikipedia.org/wiki/ "cebuanu")
  * [Čeština](https://cs.wikipedia.org/wiki/ "checu")
  * [Cymraeg](https://cy.wikipedia.org/wiki/ "galés")
  * [Dansk](https://da.wikipedia.org/wiki/ "danés")
  * [Deutsch](https://de.wikipedia.org/wiki/ "alemán")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "griegu")
  * [English](https://en.wikipedia.org/wiki/ "inglés")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "esperanto")
  * [Español](https://es.wikipedia.org/wiki/ "español")
  * [Eesti](https://et.wikipedia.org/wiki/ "estoniu")
  * [Euskara](https://eu.wikipedia.org/wiki/ "vascu")
  * [Estremeñu](https://ext.wikipedia.org/wiki/ "estremeñu")
  * [فارسی](https://fa.wikipedia.org/wiki/ "persa")
  * [Suomi](https://fi.wikipedia.org/wiki/ "finlandés")
  * [Français](https://fr.wikipedia.org/wiki/ "francés")
  * [Galego](https://gl.wikipedia.org/wiki/ "gallegu")
  * [עברית](https://he.wikipedia.org/wiki/ "hebréu")
  * [हिन्दी](https://hi.wikipedia.org/wiki/ "hindi")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "croata")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/ "haitianu")
  * [Magyar](https://hu.wikipedia.org/wiki/ "húngaru")
  * [Հայերեն](https://hy.wikipedia.org/wiki/ "armeniu")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "indonesiu")
  * [Italiano](https://it.wikipedia.org/wiki/ "italianu")
  * [日本語](https://ja.wikipedia.org/wiki/ "xaponés")
  * [ქართული](https://ka.wikipedia.org/wiki/ "xeorxanu")
  * [Қазақша](https://kk.wikipedia.org/wiki/ "kazaquistanín")
  * [한국어](https://ko.wikipedia.org/wiki/ "coreanu")
  * [Latina](https://la.wikipedia.org/wiki/ "llatín")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "lituanu")
  * [Latviešu](https://lv.wikipedia.org/wiki/ "letón")
  * [Malagasy](https://mg.wikipedia.org/wiki/ "malgaxe")
  * [Minangkabau](https://min.wikipedia.org/wiki/ "minangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/ "macedoniu")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "malayu")
  * [Mirandés](https://mwl.wikipedia.org/wiki/ "mirandés")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/ "newari")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "neerlandés")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "noruegu Nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "noruegu Bokmål")
  * [Occitan](https://oc.wikipedia.org/wiki/ "occitanu")
  * [Polski](https://pl.wikipedia.org/wiki/ "polacu")
  * [Piemontèis](https://pms.wikipedia.org/wiki/ "piamontés")
  * [Português](https://pt.wikipedia.org/wiki/ "portugués")
  * [Română](https://ro.wikipedia.org/wiki/ "rumanu")
  * [Русский](https://ru.wikipedia.org/wiki/ "rusu")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "serbo-croata")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "eslovacu")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "eslovenu")
  * [Shqip](https://sq.wikipedia.org/wiki/ "albanu")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "serbiu")
  * [Svenska](https://sv.wikipedia.org/wiki/ "suecu")
  * [தமிழ்](https://ta.wikipedia.org/wiki/ "tamil")
  * [తెలుగు](https://te.wikipedia.org/wiki/ "telugu")
  * [ไทย](https://th.wikipedia.org/wiki/ "tailandés")
  * [Tagalog](https://tl.wikipedia.org/wiki/ "tagalog")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "turcu")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/ "tártaru")
  * [Українська](https://uk.wikipedia.org/wiki/ "ucraín")
  * [اردو](https://ur.wikipedia.org/wiki/ "urdu")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/ "uzbequistanín")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vietnamín")
  * [Volapük](https://vo.wikipedia.org/wiki/ "volapük")
  * [Winaray](https://war.wikipedia.org/wiki/ "waray")
  * [中文](https://zh.wikipedia.org/wiki/ "chinu")


  * La última edición d'esta páxina foi'l 31 xnt 2025 a les 09:54.
  * El testu ta disponible baxo la [Llicencia Creative Commons Reconocimientu/CompartirIgual 4.0](https://creativecommons.org/licenses/by-sa/4.0/deed.es); puen aplicase términos adicionales. Llei [les condiciones d'usu](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use) pa más detalles.


  * [Política d'intimidá](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Tocante a Wikipedia](https://ast.wikipedia.org/wiki/Wikipedia:Tocante_a)
  * [Avisu llegal](https://ast.wikipedia.org/wiki/Wikipedia:Avisu_xeneral)
  * [Códigu de conducta](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Desendolcadores](https://developer.wikimedia.org)
  * [Estadístiques](https://stats.wikimedia.org/#/ast.wikipedia.org)
  * [Declaración de cookies](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Vista pa móvil](https://ast.m.wikipedia.org/w/index.php?title=Portada&mobileaction=toggle_view_mobile)
  * [Activar vistes previes](https://ast.wikipedia.org/wiki/Portada)


  * [![Wikimedia Foundation](https://ast.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://ast.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Buscar
Guetar
Portada
[](https://ast.wikipedia.org/wiki/Portada) [](https://ast.wikipedia.org/wiki/Portada) [](https://ast.wikipedia.org/wiki/Portada) [](https://ast.wikipedia.org/wiki/Portada) [](https://ast.wikipedia.org/wiki/Portada) [](https://ast.wikipedia.org/wiki/Portada) [](https://ast.wikipedia.org/wiki/Portada) [](https://ast.wikipedia.org/wiki/Portada)
76 llingües [Amestar seición ](https://ast.wikipedia.org/wiki/Portada)
