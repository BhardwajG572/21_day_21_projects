[Zum Inhalt springen](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#bodyContent)
Hauptmenü
Hauptmenü
In die Seitenleiste verschieben Verbergen
Navigation 
  * [Hauptseite](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Hauptseite besuchen \[z\]")
  * [Themenportale](https://de.wikipedia.org/wiki/Portal:Wikipedia_nach_Themen)
  * [Zufälliger Artikel](https://de.wikipedia.org/wiki/Spezial:Zuf%C3%A4llige_Seite "Zufällige Seite aufrufen \[x\]")
  * [Spezialseiten](https://de.wikipedia.org/wiki/Spezial:Spezialseiten)


Mitmachen 
  * [Artikel verbessern](https://de.wikipedia.org/wiki/Wikipedia:Beteiligen)
  * [Neuen Artikel anlegen](https://de.wikipedia.org/wiki/Hilfe:Neuen_Artikel_anlegen)
  * [Autorenportal](https://de.wikipedia.org/wiki/Wikipedia:Autorenportal "Info-Zentrum über Beteiligungsmöglichkeiten")
  * [Hilfe](https://de.wikipedia.org/wiki/Hilfe:%C3%9Cbersicht "Übersicht über Hilfeseiten")
  * [Letzte Änderungen](https://de.wikipedia.org/wiki/Spezial:Letzte_%C3%84nderungen "Liste der letzten Änderungen in Wikipedia \[r\]")
  * [Kontakt](https://de.wikipedia.org/wiki/Wikipedia:Kontakt "Kontaktmöglichkeiten")


[ ![](https://de.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://de.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![Die freie Enzyklopädie](https://de.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-de.svg) ](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite)
[Suche ](https://de.wikipedia.org/wiki/Spezial:Suche "Durchsuche die Wikipedia \[f\]")
Suchen
Erscheinungsbild
  * [Jetzt spenden](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=de.wikipedia.org&uselang=de)
  * [Benutzerkonto erstellen](https://de.wikipedia.org/w/index.php?title=Spezial:Benutzerkonto_anlegen&returnto=Wikipedia%3AHauptseite "Wir ermutigen dich dazu, ein Benutzerkonto zu erstellen und dich anzumelden. Es ist jedoch nicht zwingend erforderlich.")
  * [Anmelden](https://de.wikipedia.org/w/index.php?title=Spezial:Anmelden&returnto=Wikipedia%3AHauptseite "Anmelden ist zwar keine Pflicht, wird aber gerne gesehen. \[o\]")


Meine Werkzeuge
  * [Jetzt spenden](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=de.wikipedia.org&uselang=de)
  * [Benutzerkonto erstellen](https://de.wikipedia.org/w/index.php?title=Spezial:Benutzerkonto_anlegen&returnto=Wikipedia%3AHauptseite "Wir ermutigen dich dazu, ein Benutzerkonto zu erstellen und dich anzumelden. Es ist jedoch nicht zwingend erforderlich.")
  * [Anmelden](https://de.wikipedia.org/w/index.php?title=Spezial:Anmelden&returnto=Wikipedia%3AHauptseite "Anmelden ist zwar keine Pflicht, wird aber gerne gesehen. \[o\]")


#  Wikipedia:Hauptseite
  * [Hauptseite](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Portalseite anzeigen \[c\]")
  * [Diskussion](https://de.wikipedia.org/wiki/Wikipedia_Diskussion:Hauptseite "Diskussion zum Seiteninhalt \[t\]")


Deutsch
  * [Lesen](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite)
  * [Quelltext anzeigen](https://de.wikipedia.org/w/index.php?title=Wikipedia:Hauptseite&action=edit "Diese Seite ist geschützt. Ihr Quelltext kann dennoch angesehen und kopiert werden. \[e\]")
  * [Versionsgeschichte](https://de.wikipedia.org/w/index.php?title=Wikipedia:Hauptseite&action=history "Frühere Versionen dieser Seite listen \[h\]")


Werkzeuge
Werkzeuge
In die Seitenleiste verschieben Verbergen
Aktionen 
  * [Lesen](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite)
  * [Quelltext anzeigen](https://de.wikipedia.org/w/index.php?title=Wikipedia:Hauptseite&action=edit)
  * [Versionsgeschichte](https://de.wikipedia.org/w/index.php?title=Wikipedia:Hauptseite&action=history)


Allgemein 
  * [Links auf diese Seite](https://de.wikipedia.org/wiki/Spezial:Linkliste/Wikipedia:Hauptseite "Liste aller Seiten, die hierher verlinken \[j\]")
  * [Änderungen an verlinkten Seiten](https://de.wikipedia.org/wiki/Spezial:%C3%84nderungen_an_verlinkten_Seiten/Wikipedia:Hauptseite "Letzte Änderungen an Seiten, die von hier verlinkt sind \[k\]")
  * [Permanenter Link](https://de.wikipedia.org/w/index.php?title=Wikipedia:Hauptseite&oldid=247114458 "Dauerhafter Link zu dieser Seitenversion")
  * [Seiten­­informationen](https://de.wikipedia.org/w/index.php?title=Wikipedia:Hauptseite&action=info "Weitere Informationen über diese Seite")
  * [Kurzlink](https://de.wikipedia.org/w/index.php?title=Spezial:URL-K%C3%BCrzung&url=https%3A%2F%2Fde.wikipedia.org%2Fwiki%2FWikipedia%3AHauptseite)
  * [QR-Code herunterladen](https://de.wikipedia.org/w/index.php?title=Spezial:QrCode&url=https%3A%2F%2Fde.wikipedia.org%2Fwiki%2FWikipedia%3AHauptseite)


Drucken/​exportieren 
  * [Als PDF herunterladen](https://de.wikipedia.org/w/index.php?title=Spezial:DownloadAsPdf&page=Wikipedia%3AHauptseite&action=show-download-screen)
  * [Druckversion](https://de.wikipedia.org/w/index.php?title=Wikipedia:Hauptseite&printable=yes "Druckansicht dieser Seite \[p\]")


In anderen Projekten 
  * [Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Mehrsprachige Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikibooks](https://de.wikibooks.org/wiki/Hauptseite)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikinews](https://de.wikinews.org/wiki/Hauptseite)
  * [Wikiquote](https://de.wikiquote.org/wiki/Hauptseite)
  * [Wikisource](https://de.wikisource.org/wiki/Hauptseite)
  * [Wikiversity](https://de.wikiversity.org/wiki/Hauptseite)
  * [Wikivoyage](https://de.wikivoyage.org/wiki/Hauptseite)
  * [Wiktionary](https://de.wiktionary.org/wiki/Wiktionary:Hauptseite)
  * [Wikidata-Datenobjekt](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Link zum verbundenen Objekt im Datenrepositorium \[g\]")


Erscheinungsbild
In die Seitenleiste verschieben Verbergen
aus Wikipedia, der freien Enzyklopädie
  1. [Artikel des Tages](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#artikel)
  2. [Was geschah am …?](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#ereignisse)
  3. [In den Nachrichten](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#nachrichten)
  4. [Verstorben](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#verstorbene)
  5. [Schon gewusst?](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#wissenswertes)
  6. [Schwesterprojekte](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#schwesterprojekte)


##  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Jump-to-top_icon.svg/20px-Jump-to-top_icon.svg.png)](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#top "Nach oben")Willkommen bei Wikipedia
[Wikipedia](https://de.wikipedia.org/wiki/Wikipedia:%C3%9Cber_Wikipedia "Wikipedia:Über Wikipedia") ist ein Projekt zum Aufbau einer [Enzyklopädie](https://de.wikipedia.org/wiki/Enzyklop%C3%A4die "Enzyklopädie") aus [freien Inhalten](https://de.wikipedia.org/wiki/Freie_Inhalte "Freie Inhalte"), zu denen [du sehr gern beitragen kannst](https://de.wikipedia.org/wiki/Wikipedia:Starthilfe "Wikipedia:Starthilfe"). Seit März 2001 sind [3.055.771](https://de.wikipedia.org/wiki/Spezial:Statistik "Spezial:Statistik") Artikel in deutscher Sprache entstanden.
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/P_countries-vector.svg/40px-P_countries-vector.svg.png)](https://de.wikipedia.org/wiki/Portal:Geographie "Portal Geographie") [Geographie](https://de.wikipedia.org/wiki/Portal:Geographie "Portal:Geographie")
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/P_history.svg/40px-P_history.svg.png)](https://de.wikipedia.org/wiki/Portal:Geschichte "Portal Geschichte") [Geschichte](https://de.wikipedia.org/wiki/Portal:Geschichte "Portal:Geschichte")
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Social_sciences.svg/40px-Social_sciences.svg.png)](https://de.wikipedia.org/wiki/Portal:Gesellschaft "Portal Gesellschaft") [Gesellschaft](https://de.wikipedia.org/wiki/Portal:Gesellschaft "Portal:Gesellschaft")
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/P_culture.svg/40px-P_culture.svg.png)](https://de.wikipedia.org/wiki/Portal:Kunst_und_Kultur "Portal Kunst und Kultur") [Kunst und Kultur](https://de.wikipedia.org/wiki/Portal:Kunst_und_Kultur "Portal:Kunst und Kultur")
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/P_religion_world.svg/40px-P_religion_world.svg.png)](https://de.wikipedia.org/wiki/Portal:Religion "Portal Religion") [Religion](https://de.wikipedia.org/wiki/Portal:Religion "Portal:Religion")
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/P_sport.svg/40px-P_sport.svg.png)](https://de.wikipedia.org/wiki/Portal:Sport "Portal Sport") [Sport](https://de.wikipedia.org/wiki/Portal:Sport "Portal:Sport")
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/P_train.svg/40px-P_train.svg.png)](https://de.wikipedia.org/wiki/Portal:Technik "Portal Technik") [Technik](https://de.wikipedia.org/wiki/Portal:Technik "Portal:Technik")
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/P_parthenon.svg/40px-P_parthenon.svg.png)](https://de.wikipedia.org/wiki/Portal:Wissenschaft "Portal Wissenschaft") [Wissenschaft](https://de.wikipedia.org/wiki/Portal:Wissenschaft "Portal:Wissenschaft")


  * [Artikel nach Themen](https://de.wikipedia.org/wiki/Portal:Wikipedia_nach_Themen "Portal:Wikipedia nach Themen")
  * [Artikel nach Kategorien](https://de.wikipedia.org/wiki/Kategorie:!Hauptkategorie "Kategorie:!Hauptkategorie")
  * [Gesprochene Wikipedia](https://de.wikipedia.org/wiki/Portal:Gesprochene_Wikipedia "Portal:Gesprochene Wikipedia")
  * [Archiv der Hauptseite](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite/Archiv "Wikipedia:Hauptseite/Archiv")


  * **[Mitmachen](https://de.wikipedia.org/wiki/Wikipedia:Autorenportal "Wikipedia:Autorenportal")**
  * [Mentorenprogramm](https://de.wikipedia.org/wiki/Wikipedia:Mentorenprogramm "Wikipedia:Mentorenprogramm")
  * [Kontakt](https://de.wikipedia.org/wiki/Spezial:Meine_Sprache/Wikipedia:Kontakt "Spezial:Meine Sprache/Wikipedia:Kontakt")
  * [Presse](https://de.wikipedia.org/wiki/Wikipedia:Presse "Wikipedia:Presse")
  * [Statistik](https://de.wikipedia.org/wiki/Wikipedia:Statistik "Wikipedia:Statistik")
  * [Sprachversionen](https://de.wikipedia.org/wiki/Wikipedia:Sprachen "Wikipedia:Sprachen")


##  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Jump-to-top_icon.svg/20px-Jump-to-top_icon.svg.png)](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#top "Nach oben")Wikipedia aktuell
Für die Publikumspreise des [43. Schreib­wettbewerbs](https://de.wikipedia.org/wiki/Wikipedia:Schreibwettbewerb#Nominierte_Artikel "Wikipedia:Schreibwettbewerb") und des [24. Miniaturenwettbewerbs](https://de.wikipedia.org/wiki/Wikipedia:Miniaturenwettbewerb#Nominierte_Artikel "Wikipedia:Miniaturenwettbewerb") können ab sofort die Stimmen abgegeben werden.
##  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Jump-to-top_icon.svg/20px-Jump-to-top_icon.svg.png)](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#top "Nach oben")Artikel des Tages
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/da/Landappbw_567179_1822_Gesch%C3%A4ftshaus_Schnauffer_Calw%2C_Lederstr._39.jpg/120px-Landappbw_567179_1822_Gesch%C3%A4ftshaus_Schnauffer_Calw%2C_Lederstr._39.jpg)](https://de.wikipedia.org/wiki/Datei:Landappbw_567179_1822_Gesch%C3%A4ftshaus_Schnauffer_Calw,_Lederstr._39.jpg "Haus Schnaufer: Von Johann Jakob Schill \(1628–1704\), Kompagnie-Mitgründer und Bürgermeister, 1694 errichtetes Fachwerkhaus")
Die **[Calwer Zeughandlungskompagnie](https://de.wikipedia.org/wiki/Calwer_Zeughandlungskompagnie "Calwer Zeughandlungskompagnie")** war ein im Verlagssystem organisiertes Unternehmen der Zeug-Produktion und des Zeug-Handels. Sie wurde 1650 in Calw gegründet und 1797 aufgelöst. Die Teilhaber dieses Unternehmens kamen aus 14 vielfach miteinander verwandten Familien. Zeitweise waren bis zu 1000 Zeugmachermeister durch das Verlagssystem vom Unternehmen abhängig; rund 2000 Spinnerinnen kamen hinzu. Die Zeugmacher lebten in einem Gebiet, das von Heimsheim im Norden, Schönaich im Osten, Horb im Süden bis Bösingen im Westen reichte. Über den Fernhandel gelangte das Calwer Zeug nach Frankreich, in die Schweiz, die Territorien auf der italienischen Halbinsel, Ober- und Niederösterreich, Tirol, Böhmen, Ungarn, Schlesien und Polen sowie in die Erzbistümer Trier, Köln oder Mainz und weitere Gebiete des Heiligen Römischen Reichs Deutscher Nation. Im Herzogtum Württemberg war die Kompagnie das erste und größte Verlagsunternehmen und der größte Exporteur; sie entwickelte sich zu einer der größten gewerblichen Organisationen auf dem europäischen Kontinent. – _[Zum Artikel …](https://de.wikipedia.org/wiki/Calwer_Zeughandlungskompagnie "Calwer Zeughandlungskompagnie")_
  * [Archiv](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite/Artikel_des_Tages/Chronologie_2025 "Wikipedia:Hauptseite/Artikel des Tages/Chronologie 2025")
  * Weitere [exzellente](https://de.wikipedia.org/wiki/Wikipedia:Exzellente_Artikel "Wikipedia:Exzellente Artikel") und [lesenswerte](https://de.wikipedia.org/wiki/Wikipedia:Lesenswerte_Artikel "Wikipedia:Lesenswerte Artikel") Artikel sowie [informative](https://de.wikipedia.org/wiki/Wikipedia:Informative_Listen_und_Portale "Wikipedia:Informative Listen und Portale") Listen
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Feed-icon.svg/20px-Feed-icon.svg.png)](https://de.wikipedia.org/w/api.php?action=featuredfeed&feed=featured&feedformat=atom "RSS-Feed") [RSS-Feed](https://de.wikipedia.org/w/api.php?action=featuredfeed&feed=featured&feedformat=atom)


##  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Jump-to-top_icon.svg/20px-Jump-to-top_icon.svg.png)](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#top "Nach oben")Was geschah am 2. Oktober?
  * [1800](https://de.wikipedia.org/wiki/1800 "1800") – In Virginia kommt der Sklave [Nat Turner](https://de.wikipedia.org/wiki/Nat_Turner "Nat Turner") zur Welt, der 1831 einen Auf­stand anführen wird.
  * [1850](https://de.wikipedia.org/wiki/1850 "1850") – In Wien stirbt mit [Josef Madersperger](https://de.wikipedia.org/wiki/Josef_Madersperger "Josef Madersperger") einer der Erfin­der der [Nähmaschine](https://de.wikipedia.org/wiki/N%C3%A4hmaschine "Nähmaschine").
  * [![Josephine Baker](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Josephinebaker.jpg/120px-Josephinebaker.jpg)](https://de.wikipedia.org/wiki/Datei:Josephinebaker.jpg "Josephine Baker")
[1925](https://de.wikipedia.org/wiki/1925 "1925") – [Josephine Baker](https://de.wikipedia.org/wiki/Josephine_Baker "Josephine Baker") (Bild) feiert die viel­beachtete Premiere ihrer _Revue Nègre_ am [Théâtre des Champs-Élysées](https://de.wikipedia.org/wiki/Th%C3%A9%C3%A2tre_des_Champs-%C3%89lys%C3%A9es "Théâtre des Champs-Élysées") in Paris.
  * [1940](https://de.wikipedia.org/wiki/1940 "1940") – Die [deutschen Besatzer](https://de.wikipedia.org/wiki/Deutsche_Besetzung_Polens_1939%E2%80%931945 "Deutsche Besetzung Polens 1939–1945") ordnen den Umzug aller etwa 400.000 in Warschau lebenden Juden in das [Ghetto der Stadt](https://de.wikipedia.org/wiki/Warschauer_Ghetto "Warschauer Ghetto") an.
  * [1950](https://de.wikipedia.org/wiki/1950 "1950") – In sieben US-amerikanischen Zeitungen erscheint erst­mals der Comic-Strip _[Peanuts](https://de.wikipedia.org/wiki/Die_Peanuts "Die Peanuts")_ von [Charles M. Schulz](https://de.wikipedia.org/wiki/Charles_M._Schulz "Charles M. Schulz").


  * [Weitere Ereignisse](https://de.wikipedia.org/wiki/2._Oktober "2. Oktober")
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Feed-icon.svg/20px-Feed-icon.svg.png)](https://de.wikipedia.org/w/api.php?action=featuredfeed&feed=onthisday&feedformat=atom "RSS-Feed") [RSS-Feed](https://de.wikipedia.org/w/api.php?action=featuredfeed&feed=onthisday&feedformat=atom)


##  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Jump-to-top_icon.svg/20px-Jump-to-top_icon.svg.png)](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#top "Nach oben")In den Nachrichten
  * [Krieg in der Ukraine](https://de.wikipedia.org/wiki/Chronik_des_russischen_%C3%9Cberfalls_auf_die_Ukraine_ab_2025#1._Oktober "Chronik des russischen Überfalls auf die Ukraine ab 2025")
  * [Krieg in Nahost](https://de.wikipedia.org/wiki/Chronik_des_Kriegs_in_Nahost_seit_2023#28._September "Chronik des Kriegs in Nahost seit 2023")
  * [Right Livelihood Award](https://de.wikipedia.org/wiki/Liste_der_Tr%C3%A4ger_des_Right_Livelihood_Award#2025 "Liste der Träger des Right Livelihood Award")
  * [Ulrike Guérot](https://de.wikipedia.org/wiki/Ulrike_Gu%C3%A9rot#idn "Ulrike Guérot")
  * [Jom Kippur](https://de.wikipedia.org/wiki/Jom_Kippur "Jom Kippur")


* * *
[![Joseph Kabila \(2016\)](https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Joseph_Kabila_April_2016.jpg/120px-Joseph_Kabila_April_2016.jpg)](https://de.wikipedia.org/wiki/Datei:Joseph_Kabila_April_2016.jpg "Joseph Kabila \(2016\)")
  * [Joseph Kabila](https://de.wikipedia.org/wiki/Joseph_Kabila#Nach_dem_Ende_der_Pr%C3%A4sidentschaft "Joseph Kabila") (Bild), der ehemalige Präsident der [Demokrati­schen Republik Kongo](https://de.wikipedia.org/wiki/Demokratische_Republik_Kongo "Demokratische Republik Kongo"), ist in Abwesen­heit wegen Hoch­verrats und Kriegs­verbrechen zum Tode verurteilt worden.
  * Wegen [Spionage in einem besonders schweren Fall](https://de.wikipedia.org/wiki/Geheimdienstliche_Agentent%C3%A4tigkeit "Geheimdienstliche Agententätigkeit") ist ein ehemaliger Mit­arbeiter des AfD-Bundes­tags­abge­ordneten [Maximilian Krah](https://de.wikipedia.org/wiki/Maximilian_Krah#Verurteilung_eines_Mitarbeiters_wegen_Spionage_f%C3%BCr_China "Maximilian Krah") zu einer mehr­jährigen Frei­heits­strafe ver­urteilt worden.
  * Bei der [Parlaments­wahl in der Republik Moldau](https://de.wikipedia.org/wiki/Parlamentswahl_in_der_Republik_Moldau_2025 "Parlamentswahl in der Republik Moldau 2025") hat die pro­europä­ische [Partidul Acțiune și Solidaritate](https://de.wikipedia.org/wiki/Partidul_Ac%C8%9Biune_%C8%99i_Solidaritate "Partidul Acțiune și Solidaritate") die absolute Mehr­heit der Sitze im [Parla­ment](https://de.wikipedia.org/wiki/Parlament_der_Republik_Moldau "Parlament der Republik Moldau") erhalten.


[Weitere aktuelle Ereignisse](https://de.wikipedia.org/wiki/Oktober_2025 "Oktober 2025")
##  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Jump-to-top_icon.svg/20px-Jump-to-top_icon.svg.png)](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#top "Nach oben")Kürzlich Verstorbene
  * [José Antonio Álvarez Sánchez](https://de.wikipedia.org/wiki/Jos%C3%A9_Antonio_%C3%81lvarez_S%C3%A1nchez "José Antonio Álvarez Sánchez") (50), spanischer Weihbischof († 1. Oktober)
  * [Jane Goodall](https://de.wikipedia.org/wiki/Jane_Goodall "Jane Goodall") (91), britische Verhaltensforscherin († 1. Oktober)
  * [Renato Casaro](https://de.wikipedia.org/wiki/Renato_Casaro "Renato Casaro") (89), italienischer Plakatkünstler († 30. September)
  * [Nathi Mthethwa](https://de.wikipedia.org/wiki/Nathi_Mthethwa "Nathi Mthethwa") (58), südafrikanischer Politiker und Diplomat († 29./30. September)
  * [Friedl Weiss](https://de.wikipedia.org/wiki/Friedl_Weiss "Friedl Weiss") (78), österreichischer Rechtswissenschaftler († 15. September)


[Weitere kürzlich Verstorbene](https://de.wikipedia.org/wiki/Nekrolog_2025 "Nekrolog 2025")
##  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Jump-to-top_icon.svg/20px-Jump-to-top_icon.svg.png)](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#top "Nach oben")Schon gewusst?
[![Acht Schafe, zwei davon grasend, halten sich unter Rebstöcken auf, an denen zahlreiche Reben hängen; im Vordergrund ein Bottich mit Wasser](https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/Schafe_unter_Reben.jpg/120px-Schafe_unter_Reben.jpg)](https://de.wikipedia.org/wiki/Datei:Schafe_unter_Reben.jpg "Unter Rebstöcken weidende Schafe")
  * Die größte Gefahr für [Schafe im Weinbau](https://de.wikipedia.org/wiki/Schafe_im_Weinbau "Schafe im Weinbau") ist Kupfer.
  * [Edward North Buxton](https://de.wikipedia.org/wiki/Edward_North_Buxton_\(Natursch%C3%BCtzer\) "Edward North Buxton \(Naturschützer\)") braute Bier, stiftete Wälder und sammelte Geld für Roosevelts Büchse.
  * Konrad Adenauer brachte seine Familie im [St. Elisabeth-Kranken­haus Köln-Hohen­lind](https://de.wikipedia.org/wiki/St._Elisabeth-Krankenhaus_K%C3%B6ln-Hohenlind "St. Elisabeth-Krankenhaus Köln-Hohenlind") in Sicherheit.
  * _Denn nach „Reform“ lechzt aller­wärts das sehn­suchts­volle Frauen­herz, seit sich der Wunsch bemäch­tigt des Wört­chens „gleich­berech­tigt“!_ schrieb [Luise Elias](https://de.wikipedia.org/wiki/Luise_Elias "Luise Elias") zum Inter­natio­nalen Frauen-Kongress 1904.


  * [Weitere neue Artikel](https://de.wikipedia.org/wiki/Spezial:Neue_Seiten "Spezial:Neue Seiten")
  * [Archiv](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite/Schon_gewusst/Archiv "Wikipedia:Hauptseite/Schon gewusst/Archiv")


##  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Jump-to-top_icon.svg/20px-Jump-to-top_icon.svg.png)](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite#top "Nach oben")Schwesterprojekte
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/20px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/Special:MyLanguage/Main_Page?uselang=de "Commons") [Commons](https://commons.wikimedia.org/wiki/Special:MyLanguage/Main_Page?uselang=de) – Medien
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/20px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/Special:MyLanguage/Main_Page?uselang=de "Meta-Wiki") [Meta-Wiki](https://meta.wikimedia.org/wiki/Special:MyLanguage/Main_Page?uselang=de) – Koordination
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/20px-Wikibooks-logo.svg.png)](https://de.wikibooks.org/wiki/Hauptseite "Wikibooks") [Wikibooks](https://de.wikibooks.org/wiki/Hauptseite "b:Hauptseite") – Lehrbücher
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/Wikidata:Main_Page?uselang=de "Wikidata") [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page?uselang=de) – Wissensdatenbank
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Wikifunctions-logo.svg/20px-Wikifunctions-logo.svg.png)](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page?uselang=de "Wikifunctions") [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page?uselang=de) – Funktionsbibliothek
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://de.wikinews.org/wiki/Hauptseite "Wikinews") [Wikinews](https://de.wikinews.org/wiki/Hauptseite "n:Hauptseite") – Nachrichten
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/20px-Wikiquote-logo.svg.png)](https://de.wikiquote.org/wiki/Hauptseite "q:Hauptseite") [Wikiquote](https://de.wikiquote.org/wiki/Hauptseite "q:Hauptseite") – Zitate
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/20px-Wikisource-logo.svg.png)](https://de.wikisource.org/wiki/Hauptseite "Wikisource") [Wikisource](https://de.wikisource.org/wiki/Hauptseite "s:Hauptseite") – Quellen
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/20px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/Hauptseite "Wikispecies") [Wikispecies](https://species.wikimedia.org/wiki/Hauptseite "species:Hauptseite") – Artenverzeichnis
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/40px-Wikiversity_logo_2017.svg.png)](https://de.wikiversity.org/wiki/Hauptseite "Wikiversity") [Wikiversity](https://de.wikiversity.org/wiki/Hauptseite "v:Hauptseite") – Lernplattform
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/20px-Wikivoyage-Logo-v3-icon.svg.png)](https://de.wikivoyage.org/wiki/Hauptseite "Wikivoyage") [Wikivoyage](https://de.wikivoyage.org/wiki/Hauptseite "voy:Hauptseite") – Reiseführer
  * [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Wiktionary_small.svg/40px-Wiktionary_small.svg.png)](https://de.wiktionary.org/wiki/Wiktionary:Hauptseite "Wiktionary") [Wiktionary](https://de.wiktionary.org/wiki/Wiktionary:Hauptseite "wikt:Wiktionary:Hauptseite") – Wörterbuch


Abgerufen von „[https://de.wikipedia.org/w/index.php?title=Wikipedia:Hauptseite&oldid=247114458](https://de.wikipedia.org/w/index.php?title=Wikipedia:Hauptseite&oldid=247114458)“
[Kategorie](https://de.wikipedia.org/wiki/Wikipedia:Kategorien "Wikipedia:Kategorien"): 
  * [Wikipedia:Hauptseite](https://de.wikipedia.org/wiki/Kategorie:Wikipedia:Hauptseite "Kategorie:Wikipedia:Hauptseite")


Versteckte Kategorien: 
  * [MediaWiki:Gadget/Hauptseite](https://de.wikipedia.org/wiki/Kategorie:MediaWiki:Gadget/Hauptseite "Kategorie:MediaWiki:Gadget/Hauptseite")
  * [MediaWiki:Gadget/Suchfokus-Hauptseite](https://de.wikipedia.org/wiki/Kategorie:MediaWiki:Gadget/Suchfokus-Hauptseite "Kategorie:MediaWiki:Gadget/Suchfokus-Hauptseite")


51 Sprachen
  * [Alemannisch](https://als.wikipedia.org/wiki/ "Schweizerdeutsch")
  * [العربية](https://ar.wikipedia.org/wiki/ "Arabisch")
  * [Boarisch](https://bar.wikipedia.org/wiki/ "Bairisch")
  * [Català](https://ca.wikipedia.org/wiki/ "Katalanisch")
  * [Čeština](https://cs.wikipedia.org/wiki/ "Tschechisch")
  * [Dansk](https://da.wikipedia.org/wiki/ "Dänisch")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/ "Niedersorbisch")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "Griechisch")
  * [English](https://en.wikipedia.org/wiki/ "Englisch")
  * [Español](https://es.wikipedia.org/wiki/ "Spanisch")
  * [فارسی](https://fa.wikipedia.org/wiki/ "Persisch")
  * [Suomi](https://fi.wikipedia.org/wiki/ "Finnisch")
  * [Français](https://fr.wikipedia.org/wiki/ "Französisch")
  * [Arpetan](https://frp.wikipedia.org/wiki/ "Frankoprovenzalisch")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/ "Nordfriesisch")
  * [Frysk](https://fy.wikipedia.org/wiki/ "Westfriesisch")
  * [עברית](https://he.wikipedia.org/wiki/ "Hebräisch")
  * [हिन्दी](https://hi.wikipedia.org/wiki/ "Hindi")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "Kroatisch")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/ "Obersorbisch")
  * [Magyar](https://hu.wikipedia.org/wiki/ "Ungarisch")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "Indonesisch")
  * [Italiano](https://it.wikipedia.org/wiki/ "Italienisch")
  * [日本語](https://ja.wikipedia.org/wiki/ "Japanisch")
  * [한국어](https://ko.wikipedia.org/wiki/ "Koreanisch")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/ "Kölsch")
  * [Latina](https://la.wikipedia.org/wiki/ "Latein")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/ "Luxemburgisch")
  * [Limburgs](https://li.wikipedia.org/wiki/ "Limburgisch")
  * [Lombard](https://lmo.wikipedia.org/wiki/ "Lombardisch")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/ "Niederdeutsch")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "Niederländisch")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "Norwegisch \(Bokmål\)")
  * [Deitsch](https://pdc.wikipedia.org/wiki/ "Pennsylvaniadeutsch")
  * [Polski](https://pl.wikipedia.org/wiki/ "Polnisch")
  * [Português](https://pt.wikipedia.org/wiki/ "Portugiesisch")
  * [Rumantsch](https://rm.wikipedia.org/wiki/ "Rätoromanisch")
  * [Română](https://ro.wikipedia.org/wiki/ "Rumänisch")
  * [Русский](https://ru.wikipedia.org/wiki/ "Russisch")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "Slowakisch")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "Slowenisch")
  * [Shqip](https://sq.wikipedia.org/wiki/ "Albanisch")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "Serbisch")
  * [Seeltersk](https://stq.wikipedia.org/wiki/ "Saterfriesisch")
  * [Svenska](https://sv.wikipedia.org/wiki/ "Schwedisch")
  * [ไทย](https://th.wikipedia.org/wiki/ "Thailändisch")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "Türkisch")
  * [Українська](https://uk.wikipedia.org/wiki/ "Ukrainisch")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "Vietnamesisch")
  * [ייִדיש](https://yi.wikipedia.org/wiki/ "Jiddisch")
  * [中文](https://zh.wikipedia.org/wiki/ "Chinesisch")


  * Diese Seite wurde zuletzt am 26. Juli 2024 um 20:26 Uhr bearbeitet.
  * [Abrufstatistik](https://pageviews.wmcloud.org/?pages=Wikipedia:Hauptseite&project=de.wikipedia.org)
  

Der Text ist unter der Lizenz [„Creative-Commons Namensnennung – Weitergabe unter gleichen Bedingungen“](https://creativecommons.org/licenses/by-sa/4.0/deed.de) verfügbar; Informationen zu den Urhebern und zum Lizenzstatus eingebundener Mediendateien (etwa Bilder oder Videos) können im Regelfall durch Anklicken dieser abgerufen werden. Möglicherweise unterliegen die Inhalte jeweils zusätzlichen Bedingungen. Durch die Nutzung dieser Website erklären Sie sich mit den [Nutzungsbedingungen](https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/de) und der [Datenschutzrichtlinie](https://foundation.wikimedia.org/wiki/Policy:Privacy_policy/de) einverstanden.  

Wikipedia® ist eine eingetragene Marke der Wikimedia Foundation Inc.


  * [Datenschutz](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy/de)
  * [Über Wikipedia](https://de.wikipedia.org/wiki/Wikipedia:%C3%9Cber_Wikipedia)
  * [Impressum](https://de.wikipedia.org/wiki/Wikipedia:Impressum)
  * [Verhaltenskodex](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Entwickler](https://developer.wikimedia.org)
  * [Statistiken](https://stats.wikimedia.org/#/de.wikipedia.org)
  * [Stellungnahme zu Cookies](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Mobile Ansicht](https://de.wikipedia.org/w/index.php?title=Wikipedia:Hauptseite&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://de.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://de.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Suche
Suchen
Wikipedia:Hauptseite
[](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite) [](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite) [](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite) [](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite) [](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite) [](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite) [](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite) [](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite)
51 Sprachen [Abschnitt hinzufügen ](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite)
