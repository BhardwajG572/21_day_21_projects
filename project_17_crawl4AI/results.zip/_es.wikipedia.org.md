[Ir al contenido](https://es.wikipedia.org/wiki/Wikipedia:Portada#bodyContent)
Menú principal
Menú principal
mover a la barra lateral ocultar
Navegación 
  * [Portada](https://es.wikipedia.org/wiki/Wikipedia:Portada "Visitar la página principal \[alt-z\]")
  * [Portal de la comunidad](https://es.wikipedia.org/wiki/Portal:Comunidad "Acerca del proyecto, lo que puedes hacer, dónde encontrar información")
  * [Actualidad](https://es.wikipedia.org/wiki/Portal:Actualidad "Encuentra información de contexto sobre acontecimientos actuales")
  * [Cambios recientes](https://es.wikipedia.org/wiki/Especial:CambiosRecientes "Lista de cambios recientes en la wiki \[alt-r\]")
  * [Páginas nuevas](https://es.wikipedia.org/wiki/Especial:P%C3%A1ginasNuevas)
  * [Página aleatoria](https://es.wikipedia.org/wiki/Especial:Aleatoria "Cargar una página al azar \[alt-x\]")
  * [Ayuda](https://es.wikipedia.org/wiki/Ayuda:Contenidos "El lugar para aprender")
  * [Notificar un error](https://es.wikipedia.org/wiki/Wikipedia:Informes_de_error)
  * [Páginas especiales](https://es.wikipedia.org/wiki/Especial:P%C3%A1ginasEspeciales)


[ ![](https://es.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://es.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![La enciclopedia libre](https://es.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-es.svg) ](https://es.wikipedia.org/wiki/Wikipedia:Portada)
[Buscar ](https://es.wikipedia.org/wiki/Especial:Buscar "Buscar en este wiki \[alt-f\]")
Buscar
Apariencia
Apariencia
mover a la barra lateral ocultar
Texto
  * Pequeño
Estándar
Grande

Esta página siempre usa texto pequeño
Anchura
  * Estándar
Ancho

Esta página siempre es ancha
Color (beta)
  * Automático
Claro
Oscuro

Esta página está siempre en modo claro
  * [Donaciones](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=es.wikipedia.org&uselang=es)
  * [Crear una cuenta](https://es.wikipedia.org/w/index.php?title=Especial:Crear_una_cuenta&returnto=Wikipedia%3APortada "Te recomendamos crear una cuenta e iniciar sesión; sin embargo, no es obligatorio")
  * [Acceder](https://es.wikipedia.org/w/index.php?title=Especial:Entrar&returnto=Wikipedia%3APortada "Te recomendamos iniciar sesión, aunque no es obligatorio \[alt-o\]")


Herramientas personales
  * [Donaciones](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=es.wikipedia.org&uselang=es)
  * [Crear una cuenta](https://es.wikipedia.org/w/index.php?title=Especial:Crear_una_cuenta&returnto=Wikipedia%3APortada "Te recomendamos crear una cuenta e iniciar sesión; sin embargo, no es obligatorio")
  * [Acceder](https://es.wikipedia.org/w/index.php?title=Especial:Entrar&returnto=Wikipedia%3APortada "Te recomendamos iniciar sesión, aunque no es obligatorio \[alt-o\]")


Páginas para editores desconectados [más información](https://es.wikipedia.org/wiki/Ayuda:Introducci%C3%B3n)
  * [Contribuciones](https://es.wikipedia.org/wiki/Especial:MisContribuciones "Una lista de modificaciones hechas desde esta dirección IP \[alt-y\]")
  * [Discusión](https://es.wikipedia.org/wiki/Especial:MiDiscusi%C3%B3n "Discusión sobre ediciones hechas desde esta dirección IP \[alt-n\]")


#  Wikipedia:Portada
  * [Portada](https://es.wikipedia.org/wiki/Wikipedia:Portada "Ver la página del proyecto \[alt-c\]")
  * [Discusión](https://es.wikipedia.org/wiki/Wikipedia_discusi%C3%B3n:Portada "Discusión acerca de la página \[alt-t\]")


español
  * [Leer](https://es.wikipedia.org/wiki/Wikipedia:Portada)
  * [Ver código fuente](https://es.wikipedia.org/w/index.php?title=Wikipedia:Portada&action=edit "Esta página está protegida, pero puedes ver su código fuente \[alt-e\]")
  * [Ver historial](https://es.wikipedia.org/w/index.php?title=Wikipedia:Portada&action=history "Versiones anteriores de esta página \[alt-h\]")


Herramientas
Herramientas
mover a la barra lateral ocultar
Acciones 
  * [Leer](https://es.wikipedia.org/wiki/Wikipedia:Portada)
  * [Ver código fuente](https://es.wikipedia.org/w/index.php?title=Wikipedia:Portada&action=edit)
  * [Ver historial](https://es.wikipedia.org/w/index.php?title=Wikipedia:Portada&action=history)


General 
  * [Lo que enlaza aquí](https://es.wikipedia.org/wiki/Especial:LoQueEnlazaAqu%C3%AD/Wikipedia:Portada "Lista de todas las páginas de la wiki que enlazan aquí \[alt-j\]")
  * [Cambios en enlazadas](https://es.wikipedia.org/wiki/Especial:CambiosEnEnlazadas/Wikipedia:Portada "Cambios recientes en las páginas que enlazan con esta \[alt-k\]")
  * [Subir archivo](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=es "Subir archivos \[alt-u\]")
  * [Enlace permanente](https://es.wikipedia.org/w/index.php?title=Wikipedia:Portada&oldid=164197618 "Enlace permanente a esta versión de la página")
  * [Información de la página](https://es.wikipedia.org/w/index.php?title=Wikipedia:Portada&action=info "Más información sobre esta página")
  * [Obtener URL acortado](https://es.wikipedia.org/w/index.php?title=Especial:Acortador_de_URL&url=https%3A%2F%2Fes.wikipedia.org%2Fwiki%2FWikipedia%3APortada)
  * [Descargar código QR](https://es.wikipedia.org/w/index.php?title=Especial:QrCode&url=https%3A%2F%2Fes.wikipedia.org%2Fwiki%2FWikipedia%3APortada)
  * [Expandir todo](https://es.wikipedia.org/wiki/Wikipedia:Portada "Expandir todos los elementos plegables en la página actual")


Imprimir/exportar 
  * [Crear un libro](https://es.wikipedia.org/w/index.php?title=Especial:Libro&bookcmd=book_creator&referer=Wikipedia%3APortada)
  * [Descargar como PDF](https://es.wikipedia.org/w/index.php?title=Especial:DownloadAsPdf&page=Wikipedia%3APortada&action=show-download-screen)
  * [Versión para imprimir](https://es.wikipedia.org/w/index.php?title=Wikipedia:Portada&printable=yes "Versión imprimible de esta página \[alt-p\]")


En otros proyectos 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Fundación Wikimedia](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Divulgación de Wikimedia](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Wikisource multilingüe](https://wikisource.org/wiki/Main_Page)
  * [Wikiespecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikilibros](https://es.wikibooks.org/wiki/Portada)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunciones](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikinoticias](https://es.wikinews.org/wiki/Portada)
  * [Wikiquote](https://es.wikiquote.org/wiki/Portada)
  * [Wikisource](https://es.wikisource.org/wiki/Portada)
  * [Wikiversidad](https://es.wikiversity.org/wiki/Portada)
  * [Wikiviajes](https://es.wikivoyage.org/wiki/P%C3%A1gina_principal)
  * [Wikcionario](https://es.wiktionary.org/wiki/Wikcionario:Portada)
  * [Elemento de Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Enlace al elemento conectado del repositorio de datos \[alt-g\]")


De Wikipedia, la enciclopedia libre
#  [Bienvenidos](https://es.wikipedia.org/wiki/Wikipedia:Bienvenidos "Wikipedia:Bienvenidos") a Wikipedia,
la enciclopedia de contenido libre  
que [todos pueden editar](https://es.wikipedia.org/wiki/Ayuda:Introducci%C3%B3n "Ayuda:Introducción"). 
[Buscar en 2 064 864 artículos](https://es.wikipedia.org/wiki/Especial:Buscar "Especial:Buscar")
**[2 064 864](https://es.wikipedia.org/wiki/Especial:Estad%C3%ADsticas "Especial:Estadísticas")** artículos [en español](https://es.wikipedia.org/wiki/Wikipedia_en_espa%C3%B1ol "Wikipedia en español").
  * [Café](https://es.wikipedia.org/wiki/Wikipedia:Caf%C3%A9 "Wikipedia:Café")
  * [¿Cómo colaborar?](https://es.wikipedia.org/wiki/Ayuda:C%C3%B3mo_puedes_colaborar "Ayuda:Cómo puedes colaborar")
  * [Primeros pasos](https://es.wikipedia.org/wiki/Ayuda:Introducci%C3%B3n "Ayuda:Introducción")
  * [Ayuda](https://es.wikipedia.org/wiki/Ayuda:Contenidos "Ayuda:Contenidos")
  * [Contacto](https://es.wikipedia.org/wiki/Wikipedia:Contacto "Wikipedia:Contacto")


Artículo destacado
## [Nine Inch Nails](https://es.wikipedia.org/wiki/Nine_Inch_Nails "Nine Inch Nails")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Nine_Inch_Nails_-_20.06.2022_-_O2_Apollo_Manchester.jpg/330px-Nine_Inch_Nails_-_20.06.2022_-_O2_Apollo_Manchester.jpg)](https://commons.wikimedia.org/wiki/File:Nine_Inch_Nails_-_20.06.2022_-_O2_Apollo_Manchester.jpg)Nine Inch Nails en el O2 Apollo Manchester en 2022
**Nine Inch Nails** , comúnmente abreviada como **NIN** —estilizada como **NIИ** —, es una banda [estadounidense](https://es.wikipedia.org/wiki/Estadounidense "Estadounidense") de [_rock_ industrial](https://es.wikipedia.org/wiki/Rock_industrial "Rock industrial"), formada en [Cleveland](https://es.wikipedia.org/wiki/Cleveland "Cleveland") en 1988. Sus miembros son el cantautor, multiinstrumentista y productor [Trent Reznor](https://es.wikipedia.org/wiki/Trent_Reznor "Trent Reznor") y su colaborador frecuente, [Atticus Ross](https://es.wikipedia.org/wiki/Atticus_Ross "Atticus Ross"). Reznor fue anteriormente el único miembro permanente de la banda hasta que Ross fue oficializado en 2016. El álbum debut de la banda, _[Pretty Hate Machine](https://es.wikipedia.org/wiki/Pretty_Hate_Machine "Pretty Hate Machine")_ (1989), fue lanzado a través de [TVT Records](https://es.wikipedia.org/wiki/TVT_Records "TVT Records"). Después de discrepar con TVT sobre cómo se promocionaría el álbum, la banda firmó con [Interscope Records](https://es.wikipedia.org/wiki/Interscope_Records "Interscope Records") y lanzó el EP _[Broken](https://es.wikipedia.org/wiki/Broken_\(%C3%A1lbum_de_Nine_Inch_Nails\) "Broken \(álbum de Nine Inch Nails\)")_ (1992), seguido de los álbumes _[The Downward Spiral](https://es.wikipedia.org/wiki/The_Downward_Spiral "The Downward Spiral")_ (1994) y _[The Fragile](https://es.wikipedia.org/wiki/The_Fragile "The Fragile")_ (1999). 
Después de una pausa, Nine Inch Nails reanudó las giras en 2005 y lanzó su cuarto álbum _[With Teeth](https://es.wikipedia.org/wiki/With_Teeth "With Teeth")_ (2005). Tras el lanzamiento del siguiente álbum _[Year Zero](https://es.wikipedia.org/wiki/Year_Zero "Year Zero")_ (2007), la banda dejó Interscope tras una disputa. Nine Inch Nails continuó de gira y lanzó de forma independiente _[Ghosts I–IV](https://es.wikipedia.org/wiki/Ghosts_I%E2%80%93IV "Ghosts I–IV")_ (2008) y _[The Slip](https://es.wikipedia.org/wiki/The_Slip "The Slip")_ (2008) antes de una segunda pausa. Su octavo álbum, _[Hesitation Marks](https://es.wikipedia.org/wiki/Hesitation_Marks "Hesitation Marks")_ (2013), fue seguido por una trilogía que consistió en los EP _[Not the Actual Events](https://es.wikipedia.org/wiki/Not_the_Actual_Events "Not the Actual Events")_ (2016) y _[Add Violence](https://es.wikipedia.org/wiki/Add_Violence "Add Violence")_ (2017) y su noveno álbum _[Bad Witch](https://es.wikipedia.org/wiki/Bad_Witch "Bad Witch")_ (2018). En 2020, Nine Inch Nails lanzó simultáneamente dos entregas más de la serie _Ghosts_ : _[Ghosts V: Together](https://es.wikipedia.org/wiki/Ghosts_V:_Together "Ghosts V: Together")_ y _[Ghosts VI: Locusts](https://es.wikipedia.org/wiki/Ghosts_VI:_Locusts "Ghosts VI: Locusts")_. En 2025 volvió a los escenarios con la serie de conciertos [Peel It Back Tour](https://es.wikipedia.org/wiki/Peel_It_Back_Tour "Peel It Back Tour"). 
La banda ha vendido más de 20 millones de discos y ha sido nominada a 13 [premios Grammy](https://es.wikipedia.org/wiki/Premios_Grammy "Premios Grammy"), ganando por las canciones «[Wish](https://es.wikipedia.org/wiki/Wish_\(canci%C3%B3n_de_Nine_Inch_Nails\) "Wish \(canción de Nine Inch Nails\)")» en 1992 y «[Happiness in Slavery](https://es.wikipedia.org/wiki/Happiness_in_Slavery "Happiness in Slavery")» en 1996. La revista _[Time](https://es.wikipedia.org/wiki/Time_\(revista\) "Time \(revista\)")_ nombró a Reznor una de sus personas más influyentes en 1997, mientras que la revista _[Spin](https://es.wikipedia.org/wiki/Spin_\(revista\) "Spin \(revista\)")_ lo ha descrito como «el artista más vital en la música». En 2004, la revista _[Rolling Stone](https://es.wikipedia.org/wiki/Rolling_Stone "Rolling Stone")_ colocó a Nine Inch Nails en el puesto n.° 94 de su lista de los 100 mejores artistas de todos los tiempos. Nine Inch Nails fue incluido en el [Salón de la Fama del Rock and Roll](https://es.wikipedia.org/wiki/Sal%C3%B3n_de_la_Fama_del_Rock_and_Roll "Salón de la Fama del Rock and Roll") en 2020, después de haber sido nominado en 2014 —el primer año de elegibilidad de la banda— y nuevamente en 2015. 
  * [ Leer ](https://es.wikipedia.org/wiki/Nine_Inch_Nails "Nine Inch Nails")
  * [ Todos los artículos destacados ](https://es.wikipedia.org/wiki/Wikipedia:Art%C3%ADculos_destacados/%C3%8Dndice "Wikipedia:Artículos destacados/Índice")


![Acciones adicionales](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/OOjs_UI_icon_ellipsis.svg/20px-OOjs_UI_icon_ellipsis.svg.png)
  * [ Candidatos ](https://es.wikipedia.org/wiki/Wikipedia:Candidatos_a_art%C3%ADculos_destacados "Wikipedia:Candidatos a artículos destacados")

    _Anteriores:_
  * [ Invasiones japonesas de Corea ](https://es.wikipedia.org/wiki/Invasiones_japonesas_de_Corea "Invasiones japonesas de Corea")
  * [ Calvia ](https://es.wikipedia.org/wiki/Calvia "Calvia")
  * [ Rita Hayworth ](https://es.wikipedia.org/wiki/Rita_Hayworth "Rita Hayworth")


Artículo bueno
## [Iglesia de Santiago](https://es.wikipedia.org/wiki/Iglesia_de_Santiago_\(Pamplona\) "Iglesia de Santiago \(Pamplona\)")
[![Iglesia de Santiago](https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Iglesia_de_Santiado_en_la_Chantrea-Pamplona_01.jpg/250px-Iglesia_de_Santiado_en_la_Chantrea-Pamplona_01.jpg)](https://commons.wikimedia.org/wiki/File:Iglesia_de_Santiado_en_la_Chantrea-Pamplona_01.jpg "Iglesia de Santiago")Iglesia de Santiago
La **iglesia de Santiago** , en [Pamplona](https://es.wikipedia.org/wiki/Pamplona "Pamplona") ([Navarra](https://es.wikipedia.org/wiki/Navarra "Navarra")), es el templo de la [parroquia](https://es.wikipedia.org/wiki/Parroquia_\(religi%C3%B3n\) "Parroquia \(religión\)") del mismo título, erigida el 4 de abril de 1963, para atender los feligreses de la parte sur del barrio de la [Chantrea](https://es.wikipedia.org/wiki/Chantrea "Chantrea"). Hasta ese momento esa zona formó parte del territorio de la parroquia de San José Obrero, que atendía la [feligresía](https://es.wikipedia.org/wiki/Feligres%C3%ADa "Feligresía") de toda la Chantrea. 
La iglesia fue proyectada en 1966 por el arquitecto [Francisco Javier Guibert Tabar](https://es.wikipedia.org/w/index.php?title=Francisco_Javier_Guibert_Tabar&action=edit&redlink=1 "Francisco Javier Guibert Tabar \(aún no redactado\)"). Situada cerca del [Camino de Santiago](https://es.wikipedia.org/wiki/Camino_de_Santiago_Franc%C3%A9s "Camino de Santiago Francés"), en la entrada a la ciudad, tiene una planta en forma de [rombo](https://es.wikipedia.org/wiki/Rombo "Rombo"), en la que la diagonal de menor longitud sirve de [eje de simetría](https://es.wikipedia.org/wiki/Eje_de_simetr%C3%ADa "Eje de simetría"). En uno de los extremos de este eje se sitúa el [presbiterio](https://es.wikipedia.org/wiki/Presbiterio_\(arquitectura\) "Presbiterio \(arquitectura\)"); y en el lado opuesto el acceso al templo. 
  * [ Leer ](https://es.wikipedia.org/wiki/Iglesia_de_Santiago_\(Pamplona\) "Iglesia de Santiago \(Pamplona\)")
  * [ Todos los artículos buenos ](https://es.wikipedia.org/wiki/Wikipedia:Art%C3%ADculos_buenos/%C3%8Dndice "Wikipedia:Artículos buenos/Índice")


![Acciones adicionales](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/OOjs_UI_icon_ellipsis.svg/20px-OOjs_UI_icon_ellipsis.svg.png)
  * [ Candidatos ](https://es.wikipedia.org/wiki/Wikipedia:Selecci%C3%B3n_de_art%C3%ADculos_buenos/nominaciones "Wikipedia:Selección de artículos buenos/nominaciones")

    _Anteriores:_
  * [ Melocactus zehntneri ](https://es.wikipedia.org/wiki/Melocactus_zehntneri "Melocactus zehntneri")
  * [ Tightlacing ](https://es.wikipedia.org/wiki/Tightlacing "Tightlacing")
  * [ Primer bienio de la Segunda República española ](https://es.wikipedia.org/wiki/Primer_bienio_de_la_Segunda_Rep%C3%BAblica_espa%C3%B1ola "Primer bienio de la Segunda República española")


## [Recurso del día](https://es.wikipedia.org/wiki/Wikipedia:Recurso_del_d%C3%ADa "Wikipedia:Recurso del día")
[![Martín pescador de Santo Tomé](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/S%C3%A3o_Tom%C3%A9_malachite_kingfisher_%28Corythornis_cristatus_thomensis%29.jpg/500px-S%C3%A3o_Tom%C3%A9_malachite_kingfisher_%28Corythornis_cristatus_thomensis%29.jpg)](https://commons.wikimedia.org/wiki/File:S%C3%A3o_Tom%C3%A9_malachite_kingfisher_\(Corythornis_cristatus_thomensis\).jpg "Martín pescador de Santo Tomé")Martín pescador de Santo Tomé
Martín pescador de Santo Tomé 
El **[martín pescador de Santo Tomé](https://es.wikipedia.org/wiki/Corythornis_cristatus_thomensis "Corythornis cristatus thomensis")** (_Corythornis cristatus thomensis_) es un ave de la familia [Alcedinidae](https://es.wikipedia.org/wiki/Alcedinidae "Alcedinidae"). Es endémica de [Santo Tomé](https://es.wikipedia.org/wiki/Isla_de_Santo_Tom%C3%A9 "Isla de Santo Tomé"), una isla frente a la costa oeste de África en el [Golfo de Guinea](https://es.wikipedia.org/wiki/Golfo_de_Guinea "Golfo de Guinea"). Se alimenta principalmente de [peces](https://es.wikipedia.org/wiki/Pez "Pez"), [crustáceos](https://es.wikipedia.org/wiki/Crustacea "Crustacea"), [ranas](https://es.wikipedia.org/wiki/Anura "Anura") y larvas de insectos. 
  * [ Archivo ](https://es.wikipedia.org/wiki/Wikipedia:Recurso_del_d%C3%ADa "Wikipedia:Recurso del día")


## [Actualidad](https://es.wikipedia.org/wiki/Portal:Actualidad "Portal:Actualidad")
  * [Guerras y conflictos](https://es.wikipedia.org/wiki/Anexo:Guerras_y_conflictos_actuales "Anexo:Guerras y conflictos actuales"): [Marruecos](https://es.wikipedia.org/wiki/Protestas_en_Marruecos_de_2025 "Protestas en Marruecos de 2025"), [Estados Unidos-Venezuela](https://es.wikipedia.org/wiki/Crisis_entre_Estados_Unidos_y_Venezuela_de_2025 "Crisis entre Estados Unidos y Venezuela de 2025"), [Gaza-Israel](https://es.wikipedia.org/wiki/Guerra_de_Gaza "Guerra de Gaza"), [Rusia-Ucrania](https://es.wikipedia.org/wiki/Invasi%C3%B3n_rusa_de_Ucrania "Invasión rusa de Ucrania")
  * 3-5 de octubre: [Gran Premio de Indonesia de motociclismo](https://es.wikipedia.org/wiki/Gran_Premio_de_Indonesia_de_Motociclismo_de_2025 "Gran Premio de Indonesia de Motociclismo de 2025")
  * 3-5 de octubre: [Gran Premio de Singapur de Fórmula 1](https://es.wikipedia.org/wiki/Anexo:Gran_Premio_de_Singapur_de_2025 "Anexo:Gran Premio de Singapur de 2025")
  * 3-4 de octubre: [Elecciones legislativas de la República Checa](https://es.wikipedia.org/wiki/Elecciones_legislativas_de_la_Rep%C3%BAblica_Checa_de_2025 "Elecciones legislativas de la República Checa de 2025")
  * 3 de octubre: Coronación de [Guillermo de Luxemburgo](https://es.wikipedia.org/wiki/Guillermo_de_Luxemburgo "Guillermo de Luxemburgo")
  * 2-18 de octubre: [Copa Libertadores Femenina](https://es.wikipedia.org/wiki/Copa_Libertadores_Femenina_2025 "Copa Libertadores Femenina 2025")
  * 2-11 de octubre: [Campeonato Mundial de Halterofilia](https://es.wikipedia.org/wiki/Campeonato_Mundial_de_Halterofilia_de_2025 "Campeonato Mundial de Halterofilia de 2025")
  * 2 de octubre: [Elecciones locales de Georgia](https://es.wikipedia.org/wiki/Elecciones_locales_de_Georgia_de_2025 "Elecciones locales de Georgia de 2025")
  * 1-12 de octubre: [Masters de Shanghái](https://es.wikipedia.org/wiki/Masters_de_Shangh%C3%A1i_2025 "Masters de Shanghái 2025") de tenis
  * 1-5 de octubre: [Campeonato Europeo de Ciclismo en Ruta](https://es.wikipedia.org/wiki/Campeonato_Europeo_de_Ciclismo_en_Ruta_de_2025 "Campeonato Europeo de Ciclismo en Ruta de 2025")
  * 29 de septiembre-4 de octubre: [Campeonato Mundial de Piragüismo en Eslalon](https://es.wikipedia.org/wiki/Campeonato_Mundial_de_Pirag%C3%BCismo_en_Eslalon_de_2025 "Campeonato Mundial de Piragüismo en Eslalon de 2025")
  * 27 de septiembre-19 de octubre: [Copa Mundial de Fútbol Sub-20](https://es.wikipedia.org/wiki/Copa_Mundial_de_F%C3%BAtbol_Sub-20_de_2025 "Copa Mundial de Fútbol Sub-20 de 2025")
  * 24 de septiembre-5 de octubre: [Torneo de Pekín](https://es.wikipedia.org/wiki/Torneo_de_Pek%C3%ADn_2025 "Torneo de Pekín 2025") de tenis



[Fallecimientos](https://es.wikipedia.org/wiki/Anexo:Fallecidos_en_2025 "Anexo:Fallecidos en 2025")

  * 1 de octubre: [Juan Carlos de Lima](https://es.wikipedia.org/wiki/Juan_Carlos_de_Lima "Juan Carlos de Lima"), futbolista uruguayo (63)
  * 1 de octubre: [Stefano Casagranda](https://es.wikipedia.org/wiki/Stefano_Casagranda "Stefano Casagranda"), ciclista italiano (52)
  * 1 de octubre: [José Andrada](https://es.wikipedia.org/wiki/Jos%C3%A9_Andrada "José Andrada"), actor argentino (77)

[![La zoóloga y activista británica Jane Goodall](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Jane_Goodall_HK.jpg/120px-Jane_Goodall_HK.jpg)](https://commons.wikimedia.org/wiki/File:Jane_Goodall_HK.jpg "La zoóloga y activista británica Jane Goodall")La zoóloga y activista británica Jane Goodall
  * 1 de octubre: [Jane Goodall](https://es.wikipedia.org/wiki/Jane_Goodall "Jane Goodall"), zoóloga y activista británica (91; _en la imagen superior_)

[![El obispo católico español José Antonio Álvarez Sánchez](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/JAAlvarezS.jpg/120px-JAAlvarezS.jpg)](https://commons.wikimedia.org/wiki/File:JAAlvarezS.jpg "El obispo católico español José Antonio Álvarez Sánchez")El obispo católico español José Antonio Álvarez Sánchez
  * 1 de octubre: [José Antonio Álvarez Sánchez](https://es.wikipedia.org/wiki/Jos%C3%A9_Antonio_%C3%81lvarez_S%C3%A1nchez "José Antonio Álvarez Sánchez"), obispo católico español (50; _en la imagen inferior_)
  * 30 de septiembre: [Lawrence Moten](https://es.wikipedia.org/wiki/Lawrence_Moten "Lawrence Moten"), baloncestista estadounidense (53)
  * 30 de septiembre: [Pablo Guerrero](https://es.wikipedia.org/wiki/Pablo_Guerrero "Pablo Guerrero"), músico y poeta español (78)
  * 29 de septiembre: [Elijah Lagat](https://es.wikipedia.org/wiki/Elijah_Lagat "Elijah Lagat"), atleta y político keniano (59)
  * 29 de septiembre: [Adriana Aizemberg](https://es.wikipedia.org/wiki/Adriana_Aizemberg "Adriana Aizemberg"), actriz argentina (86)
  * 29 de septiembre: [Javier Sánchez Galindo](https://es.wikipedia.org/wiki/Javier_S%C3%A1nchez_Galindo "Javier Sánchez Galindo"), futbolista mexicano (77)
  * 29 de septiembre: [Jørgen Leth](https://es.wikipedia.org/wiki/J%C3%B8rgen_Leth "Jørgen Leth"), cineasta y poeta danés (88)
  * 28 de septiembre: [Henrique Lins de Barros](https://es.wikipedia.org/wiki/Henrique_Lins_de_Barros "Henrique Lins de Barros"), físico, divulgador científico y artista brasileño (78)
  * 28 de septiembre: [Carlos Fernández Santander](https://es.wikipedia.org/wiki/Carlos_Fern%C3%A1ndez_Santander "Carlos Fernández Santander"), periodista español (80-81)
  * 28 de septiembre: [Terry Farrell](https://es.wikipedia.org/wiki/Terry_Farrell_\(arquitecto\) "Terry Farrell \(arquitecto\)"), arquitecto británico (87)
  * 28 de septiembre: [Javier García Cuesta](https://es.wikipedia.org/wiki/Javier_Garc%C3%ADa_Cuesta "Javier García Cuesta"), balonmanista, entrenador y dirigente deportivo español (78)
  * 28 de septiembre: [Roger Lukaku](https://es.wikipedia.org/wiki/Roger_Lukaku "Roger Lukaku"), futbolista congoleño (58)
  * 27 de septiembre: [Magnus R. Troy](https://es.wikipedia.org/wiki/Magnus_R._Troy "Magnus R. Troy"), músico ecuatoriano (24)



Conmemoraciones y fiestas

  * 3 de octubre: Día Nacional de [Irak](https://es.wikipedia.org/wiki/Irak "Irak")
  * 3 de octubre: Día Nacional de [Alemania](https://es.wikipedia.org/wiki/Alemania "Alemania")
  * 2 de octubre: [Día Internacional de la No Violencia](https://es.wikipedia.org/wiki/D%C3%ADa_Internacional_de_la_No_Violencia "Día Internacional de la No Violencia")
  * 1 de octubre: [Día Internacional de las Personas de Edad](https://es.wikipedia.org/wiki/D%C3%ADa_Internacional_de_las_Personas_de_Edad "Día Internacional de las Personas de Edad")
  * 1 de octubre: [Día Internacional de la Música](https://es.wikipedia.org/wiki/D%C3%ADa_Internacional_de_la_M%C3%BAsica "Día Internacional de la Música")
  * 1 de octubre: Día Nacional de [Tuvalu](https://es.wikipedia.org/wiki/Tuvalu "Tuvalu")
  * 1 de octubre: Día Nacional de [Nigeria](https://es.wikipedia.org/wiki/Nigeria "Nigeria")
  * 1 de octubre: Día Mundial de la [Parálisis Cerebral](https://es.wikipedia.org/wiki/Par%C3%A1lisis_cerebral "Parálisis cerebral")


  
**Véase también:** [Categoría:Actualidad](https://es.wikipedia.org/wiki/Categor%C3%ADa:Actualidad "Categoría:Actualidad"), [2025](https://es.wikipedia.org/wiki/2025 "2025"), [Categoría:2025](https://es.wikipedia.org/wiki/Categor%C3%ADa:2025 "Categoría:2025")
  * [ Otros eventos actuales ](https://es.wikipedia.org/wiki/Portal:Actualidad "Portal:Actualidad")


![Acciones adicionales](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/OOjs_UI_icon_ellipsis.svg/20px-OOjs_UI_icon_ellipsis.svg.png)
  * [ Categoría de actualidad ](https://es.wikipedia.org/wiki/Categor%C3%ADa:Actualidad "Categoría:Actualidad")
  * [ Año 2025 ](https://es.wikipedia.org/wiki/2025 "2025")
  * [ Categoría 2025 ](https://es.wikipedia.org/wiki/Categor%C3%ADa:2025 "Categoría:2025")
  * [ Plantilla ](https://es.wikipedia.org/wiki/Plantilla:Portada:Actualidad "Plantilla:Portada:Actualidad")


Efemérides
## [2 de octubre](https://es.wikipedia.org/wiki/2_de_octubre "2 de octubre")
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/1970_-_Plaza_Theater_-_8_Jul_MC_-_Allentown_PA.jpg/120px-1970_-_Plaza_Theater_-_8_Jul_MC_-_Allentown_PA.jpg)](https://commons.wikimedia.org/wiki/File:1970_-_Plaza_Theater_-_8_Jul_MC_-_Allentown_PA.jpg)
  * **[1950](https://es.wikipedia.org/wiki/1950 "1950")** _(hace 75 años)_ : Comienza a publicarse la tira cómica _**[Peanuts](https://es.wikipedia.org/wiki/Peanuts "Peanuts")**_ , del estadounidense Charles M. Schulz _(en la imagen)_.
  * **[1975](https://es.wikipedia.org/wiki/1975 "1975")** _(hace 50 años)_ : Nace **[Valentina Shevchenko](https://es.wikipedia.org/wiki/Valentina_Shevchenko_\(esquiadora\) "Valentina Shevchenko \(esquiadora\)")** , esquiadora ucraniana.
  * **[2000](https://es.wikipedia.org/wiki/2000 "2000")** _(hace 25 años)_ : En Estados Unidos, se emite el primer episodio de la serie _**[Andrómeda](https://es.wikipedia.org/wiki/Andr%C3%B3meda_\(serie_de_televisi%C3%B3n\) "Andrómeda \(serie de televisión\)")**_.
  * **[2000](https://es.wikipedia.org/wiki/2000 "2000")** _(hace 25 años)_ : La banda británica Radiohead publica el álbum _**[Kid A](https://es.wikipedia.org/wiki/Kid_A "Kid A")**_.
  * **[2000](https://es.wikipedia.org/wiki/2000 "2000")** _(hace 25 años)_ : Fallece **[Nikolái Fedorenko](https://es.wikipedia.org/wiki/Nikol%C3%A1i_Fedorenko "Nikolái Fedorenko")** , diplomático y filólogo ruso (n. 1912).


  * [ 1 de octubre ](https://es.wikipedia.org/wiki/1_de_octubre "1 de octubre")
  * [ 2 de octubre ](https://es.wikipedia.org/wiki/2_de_octubre "2 de octubre")
  * [ 3 de octubre ](https://es.wikipedia.org/wiki/3_de_octubre "3 de octubre")


![Acciones adicionales](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/OOjs_UI_icon_ellipsis.svg/20px-OOjs_UI_icon_ellipsis.svg.png)
  * [ Plantilla ](https://es.wikipedia.org/wiki/Plantilla:Efem%C3%A9rides "Plantilla:Efemérides")


## [Portales](https://es.wikipedia.org/wiki/Wikipedia:Portal "Wikipedia:Portal")
[![Artes](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Nuvola_apps_package_graphics.svg/20px-Nuvola_apps_package_graphics.svg.png)](https://commons.wikimedia.org/wiki/File:Nuvola_apps_package_graphics.svg "Artes")Artes
**[Artes](https://es.wikipedia.org/wiki/Portal:Arte "Portal:Arte")** : [Arquitectura](https://es.wikipedia.org/wiki/Portal:Arquitectura "Portal:Arquitectura") – [Cine](https://es.wikipedia.org/wiki/Portal:Cine "Portal:Cine") – [Danza](https://es.wikipedia.org/wiki/Portal:Danza "Portal:Danza") – [Literatura](https://es.wikipedia.org/wiki/Portal:Literatura "Portal:Literatura") – [Música](https://es.wikipedia.org/wiki/Portal:M%C3%BAsica "Portal:Música") – [Música clásica](https://es.wikipedia.org/wiki/Portal:M%C3%BAsica_cl%C3%A1sica "Portal:Música clásica") – [Pintura](https://es.wikipedia.org/wiki/Portal:Pintura "Portal:Pintura") – [Teatro](https://es.wikipedia.org/wiki/Portal:Teatro "Portal:Teatro")
[![Ciencias sociales](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Sciences_humaines.svg/20px-Sciences_humaines.svg.png)](https://commons.wikimedia.org/wiki/File:Sciences_humaines.svg "Ciencias sociales")Ciencias sociales
**[Ciencias sociales](https://es.wikipedia.org/wiki/Portal:Ciencias_humanas_y_sociales "Portal:Ciencias humanas y sociales")** : [Comunicación](https://es.wikipedia.org/wiki/Portal:Comunicaci%C3%B3n "Portal:Comunicación") – [Deporte](https://es.wikipedia.org/wiki/Portal:Deporte "Portal:Deporte") – [Derecho](https://es.wikipedia.org/wiki/Portal:Derecho "Portal:Derecho") – [Economía](https://es.wikipedia.org/wiki/Portal:Econom%C3%ADa "Portal:Economía") – [Feminismo](https://es.wikipedia.org/wiki/Portal:Feminismo "Portal:Feminismo") – [Filosofía](https://es.wikipedia.org/wiki/Portal:Filosof%C3%ADa "Portal:Filosofía") – [LGBT](https://es.wikipedia.org/wiki/Portal:LGBT "Portal:LGBT") – [Lingüística](https://es.wikipedia.org/wiki/Portal:Ling%C3%BC%C3%ADstica "Portal:Lingüística") – [Psicología](https://es.wikipedia.org/wiki/Portal:Psicolog%C3%ADa "Portal:Psicología") – [Sociología](https://es.wikipedia.org/wiki/Portal:Sociolog%C3%ADa "Portal:Sociología")
[![Ciencias naturales](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Science-symbol-2.svg/20px-Science-symbol-2.svg.png)](https://commons.wikimedia.org/wiki/File:Science-symbol-2.svg "Ciencias naturales")Ciencias naturales
**[Ciencias naturales](https://es.wikipedia.org/wiki/Portal:Ciencias_naturales "Portal:Ciencias naturales")** : [Astronomía](https://es.wikipedia.org/wiki/Portal:Astronom%C3%ADa "Portal:Astronomía") – [Biología](https://es.wikipedia.org/wiki/Portal:Biolog%C3%ADa "Portal:Biología") – [Botánica](https://es.wikipedia.org/wiki/Portal:Bot%C3%A1nica "Portal:Botánica") – [Física](https://es.wikipedia.org/wiki/Portal:F%C3%ADsica "Portal:Física") – [Medicina](https://es.wikipedia.org/wiki/Portal:Medicina "Portal:Medicina") – [Matemática](https://es.wikipedia.org/wiki/Portal:Matem%C3%A1tica "Portal:Matemática") – [Química](https://es.wikipedia.org/wiki/Portal:Qu%C3%ADmica "Portal:Química")
[![Geografía](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Ambox_globe.svg/20px-Ambox_globe.svg.png)](https://commons.wikimedia.org/wiki/File:Ambox_globe.svg "Geografía")Geografía
**[Geografía](https://es.wikipedia.org/wiki/Portal:Geograf%C3%ADa "Portal:Geografía")** : [África](https://es.wikipedia.org/wiki/Portal:%C3%81frica "Portal:África") – [América](https://es.wikipedia.org/wiki/Portal:Am%C3%A9rica "Portal:América") – [Antártida](https://es.wikipedia.org/wiki/Portal:Ant%C3%A1rtida "Portal:Antártida") – [Asia](https://es.wikipedia.org/wiki/Portal:Asia "Portal:Asia") – [Europa](https://es.wikipedia.org/wiki/Portal:Europa "Portal:Europa") – [Oceanía](https://es.wikipedia.org/wiki/Portal:Ocean%C3%ADa "Portal:Oceanía") – [Países](https://es.wikipedia.org/wiki/Portal:Pa%C3%ADses "Portal:Países")
[![Historia](https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/History2.svg/20px-History2.svg.png)](https://commons.wikimedia.org/wiki/File:History2.svg "Historia")Historia
**[Historia](https://es.wikipedia.org/wiki/Portal:Historia "Portal:Historia")** : [Prehistoria](https://es.wikipedia.org/wiki/Portal:Prehistoria "Portal:Prehistoria") – [Edad Antigua](https://es.wikipedia.org/wiki/Portal:Edad_Antigua "Portal:Edad Antigua") – [Edad Media](https://es.wikipedia.org/wiki/Portal:Edad_Media "Portal:Edad Media") – [Edad Moderna](https://es.wikipedia.org/wiki/Portal:Edad_Moderna "Portal:Edad Moderna") – [Edad Contemporánea](https://es.wikipedia.org/wiki/Portal:Edad_Contempor%C3%A1nea "Portal:Edad Contemporánea")
[![Política](https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Vote3_final.png/20px-Vote3_final.png)](https://commons.wikimedia.org/wiki/File:Vote3_final.png "Política")Política
**[Política](https://es.wikipedia.org/wiki/Portal:Pol%C3%ADtica "Portal:Política")** : [Marxismo](https://es.wikipedia.org/wiki/Portal:Marxismo "Portal:Marxismo") – [Nacionalismo](https://es.wikipedia.org/wiki/Portal:Nacionalismo "Portal:Nacionalismo") – [Socialismo](https://es.wikipedia.org/wiki/Portal:Socialismo "Portal:Socialismo") – [Terrorismo](https://es.wikipedia.org/wiki/Portal:Terrorismo "Portal:Terrorismo")
[![Religión](https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/P_religion_world.svg/20px-P_religion_world.svg.png)](https://commons.wikimedia.org/wiki/File:P_religion_world.svg "Religión")Religión
**[Religión](https://es.wikipedia.org/wiki/Portal:Religi%C3%B3n "Portal:Religión")** : [Ateísmo](https://es.wikipedia.org/wiki/Portal:Ate%C3%ADsmo "Portal:Ateísmo") – [Budismo](https://es.wikipedia.org/wiki/Portal:Budismo "Portal:Budismo") – [Cristianismo](https://es.wikipedia.org/wiki/Portal:Cristianismo "Portal:Cristianismo") – [Iglesia católica](https://es.wikipedia.org/wiki/Portal:Iglesia_cat%C3%B3lica "Portal:Iglesia católica") – [Islam](https://es.wikipedia.org/wiki/Portal:Islam "Portal:Islam") – [Judaísmo](https://es.wikipedia.org/wiki/Portal:Juda%C3%ADsmo "Portal:Judaísmo") – [Mitología](https://es.wikipedia.org/wiki/Portal:Mitolog%C3%ADa "Portal:Mitología")
[![Tecnologías](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Tecno-rueda.svg/20px-Tecno-rueda.svg.png)](https://commons.wikimedia.org/wiki/File:Tecno-rueda.svg "Tecnologías")Tecnologías
**[Tecnologías](https://es.wikipedia.org/wiki/Portal:Tecnolog%C3%ADa "Portal:Tecnología")** : [Biotecnología](https://es.wikipedia.org/wiki/Portal:Biotecnolog%C3%ADa "Portal:Biotecnología") – [Exploración espacial](https://es.wikipedia.org/wiki/Portal:Exploraci%C3%B3n_espacial "Portal:Exploración espacial") – [Informática](https://es.wikipedia.org/wiki/Portal:Inform%C3%A1tica "Portal:Informática") – [Ingeniería](https://es.wikipedia.org/wiki/Portal:Ingenier%C3%ADa "Portal:Ingeniería") – [Software libre](https://es.wikipedia.org/wiki/Portal:Software_libre "Portal:Software libre") – [Videojuegos](https://es.wikipedia.org/wiki/Portal:Videojuegos "Portal:Videojuegos")
##  [Otros proyectos](https://meta.wikimedia.org/wiki/Special:MyLanguage/Wikimedia_projects "meta:Special:MyLanguage/Wikimedia projects") de la [Fundación Wikimedia](https://es.wikipedia.org/wiki/Fundaci%C3%B3n_Wikimedia "Fundación Wikimedia")
Wikipedia es uno de los [proyectos Wikimedia](https://foundation.wikimedia.org/wiki/Nuestros_proyectos "wikimedia:Nuestros proyectos"), de contenido libre y administrados técnicamente por la [Fundación Wikimedia](https://es.wikipedia.org/wiki/Fundaci%C3%B3n_Wikimedia "Fundación Wikimedia"), una organización estadounidense sin fines de lucro. 
|  |  |  |  |   
---|---|---|---|---|---  
[![Wikcionario](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://es.wiktionary.org/wiki/ "Wikcionario")Wikcionario |  [**Wikcionario**](https://es.wiktionary.org/wiki/ "wikt:")  
Diccionario con sinónimos  |  [![Wikilibros](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://es.wikibooks.org/wiki/ "Wikilibros")Wikilibros |  [**Wikilibros**](https://es.wikibooks.org/wiki/ "b:")  
Libros de texto y manuales  |  [![Wikiquote](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://es.wikiquote.org/wiki/ "Wikiquote")Wikiquote |  [**Wikiquote**](https://es.wikiquote.org/wiki/ "q:")  
Colección de citas   
[![Wikisource](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://es.wikisource.org/wiki/ "Wikisource")Wikisource |  [**Wikisource**](https://es.wikisource.org/wiki/ "s:")  
La biblioteca libre  |  [![Wikispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/ "Wikispecies")Wikispecies |  [**Wikispecies**](https://species.wikimedia.org/wiki/ "wikispecies:")  
Directorio de especies  |  [![Wikinoticias](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://es.wikinews.org/wiki/ "Wikinoticias")Wikinoticias |  [**Wikinoticias**](https://es.wikinews.org/wiki/ "n:")  
Noticias libres   
[![Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/ "Wikimedia Commons")Wikimedia Commons |  [**Commons**](https://commons.wikimedia.org/wiki/ "c:")  
Imágenes y multimedia  |  [![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/Main_Page/es "Meta-Wiki")Meta-Wiki |  [**Meta-Wiki**](https://meta.wikimedia.org/wiki/Main_Page/es "meta:Main Page/es")  
Coordinación de proyectos  |  [![Wikiversidad](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)](https://es.wikiversity.org/wiki/ "Wikiversidad")Wikiversidad |  [**Wikiversidad**](https://es.wikiversity.org/wiki/ "v:")  
Plataforma educativa libre   
[![Wikiviajes](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://es.wikivoyage.org/wiki/ "Wikiviajes")Wikiviajes |  [**Wikiviajes**](https://es.wikivoyage.org/wiki/ "voy:")  
Guía de viajes  |  [![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "Wikidata")Wikidata |  [**Wikidata**](https://www.wikidata.org/wiki/ "d:")  
Base de datos libre  |  [![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/MediaWiki/es "MediaWiki")MediaWiki |  [**MediaWiki**](https://www.mediawiki.org/wiki/MediaWiki/es "mw:MediaWiki/es")  
Desarrollo de software libre   
Obtenido de «[https://es.wikipedia.org/w/index.php?title=Wikipedia:Portada&oldid=164197618](https://es.wikipedia.org/w/index.php?title=Wikipedia:Portada&oldid=164197618)»
62 idiomas
  * [Aragonés](https://an.wikipedia.org/wiki/ "aragonés")
  * [العربية](https://ar.wikipedia.org/wiki/ "árabe")
  * [Asturianu](https://ast.wikipedia.org/wiki/ "asturiano")
  * [Aymar aru](https://ay.wikipedia.org/wiki/ "aimara")
  * [Български](https://bg.wikipedia.org/wiki/ "búlgaro")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/ "Bishnupriya")
  * [Bosanski](https://bs.wikipedia.org/wiki/ "bosnio")
  * [Català](https://ca.wikipedia.org/wiki/ "catalán")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/ "Chavacano")
  * [Cebuano](https://ceb.wikipedia.org/wiki/ "cebuano")
  * [Chamoru](https://ch.wikipedia.org/wiki/ "chamorro")
  * [Čeština](https://cs.wikipedia.org/wiki/ "checo")
  * [Dansk](https://da.wikipedia.org/wiki/ "danés")
  * [Deutsch](https://de.wikipedia.org/wiki/ "alemán")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "griego")
  * [English](https://en.wikipedia.org/wiki/ "inglés")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "esperanto")
  * [Eesti](https://et.wikipedia.org/wiki/ "estonio")
  * [Euskara](https://eu.wikipedia.org/wiki/ "euskera")
  * [Estremeñu](https://ext.wikipedia.org/wiki/ "Extremaduran")
  * [فارسی](https://fa.wikipedia.org/wiki/ "persa")
  * [Suomi](https://fi.wikipedia.org/wiki/ "finés")
  * [Français](https://fr.wikipedia.org/wiki/ "francés")
  * [Galego](https://gl.wikipedia.org/wiki/ "gallego")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/ "guaraní")
  * [עברית](https://he.wikipedia.org/wiki/ "hebreo")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "croata")
  * [Magyar](https://hu.wikipedia.org/wiki/ "húngaro")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "indonesio")
  * [Italiano](https://it.wikipedia.org/wiki/ "italiano")
  * [日本語](https://ja.wikipedia.org/wiki/ "japonés")
  * [한국어](https://ko.wikipedia.org/wiki/ "coreano")
  * [Latina](https://la.wikipedia.org/wiki/ "latín")
  * [Ladino](https://lad.wikipedia.org/wiki/ "ladino")
  * [Lombard](https://lmo.wikipedia.org/wiki/ "lombardo")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "lituano")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "malayo")
  * [Mirandés](https://mwl.wikipedia.org/wiki/ "mirandés")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/ "Nahuatl")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/ "nevarí")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "neerlandés")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "noruego nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "noruego bokmal")
  * [Occitan](https://oc.wikipedia.org/wiki/ "occitano")
  * [Papiamentu](https://pap.wikipedia.org/wiki/ "papiamento")
  * [Polski](https://pl.wikipedia.org/wiki/ "polaco")
  * [Português](https://pt.wikipedia.org/wiki/ "portugués")
  * [Runa Simi](https://qu.wikipedia.org/wiki/ "quechua")
  * [Română](https://ro.wikipedia.org/wiki/ "rumano")
  * [Русский](https://ru.wikipedia.org/wiki/ "ruso")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "eslovaco")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "esloveno")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "serbio")
  * [Svenska](https://sv.wikipedia.org/wiki/ "sueco")
  * [తెలుగు](https://te.wikipedia.org/wiki/ "telugu")
  * [ไทย](https://th.wikipedia.org/wiki/ "tailandés")
  * [Tagalog](https://tl.wikipedia.org/wiki/ "tagalo")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "turco")
  * [Українська](https://uk.wikipedia.org/wiki/ "ucraniano")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vietnamita")
  * [中文](https://zh.wikipedia.org/wiki/ "chino")


  * Esta página se editó por última vez el 18 dic 2024 a las 15:41.
  * El texto está disponible bajo la [Licencia Creative Commons Atribución-CompartirIgual 4.0](https://es.wikipedia.org/wiki/Wikipedia:Texto_de_la_Licencia_Creative_Commons_Atribuci%C3%B3n-CompartirIgual_4.0_Internacional "Wikipedia:Texto de la Licencia Creative Commons Atribución-CompartirIgual 4.0 Internacional"); pueden aplicarse cláusulas adicionales. Al usar este sitio aceptas nuestros [términos de uso](https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/es) y nuestra [política de privacidad](https://foundation.wikimedia.org/wiki/Policy:Privacy_policy/es).  
Wikipedia® es una marca registrada de la [Fundación Wikimedia](https://wikimediafoundation.org/es/), una organización sin ánimo de lucro.


  * [Política de privacidad](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy/es)
  * [Acerca de Wikipedia](https://es.wikipedia.org/wiki/Wikipedia:Acerca_de)
  * [Limitación de responsabilidad](https://es.wikipedia.org/wiki/Wikipedia:Limitaci%C3%B3n_general_de_responsabilidad)
  * [Código de conducta](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Desarrolladores](https://developer.wikimedia.org)
  * [Estadísticas](https://stats.wikimedia.org/#/es.wikipedia.org)
  * [Declaración de cookies](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement/es)
  * [Versión para móviles](https://es.m.wikipedia.org/w/index.php?title=Wikipedia:Portada&mobileaction=toggle_view_mobile)
  * [Edita configuración de previsualizaciones](https://es.wikipedia.org/wiki/Wikipedia:Portada)


  * [![Wikimedia Foundation](https://es.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://es.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Buscar
Buscar
Wikipedia:Portada
[](https://es.wikipedia.org/wiki/Wikipedia:Portada) [](https://es.wikipedia.org/wiki/Wikipedia:Portada) [](https://es.wikipedia.org/wiki/Wikipedia:Portada) [](https://es.wikipedia.org/wiki/Wikipedia:Portada) [](https://es.wikipedia.org/wiki/Wikipedia:Portada) [](https://es.wikipedia.org/wiki/Wikipedia:Portada) [](https://es.wikipedia.org/wiki/Wikipedia:Portada) [](https://es.wikipedia.org/wiki/Wikipedia:Portada)
62 idiomas [Añadir tema ](https://es.wikipedia.org/wiki/Wikipedia:Portada)
