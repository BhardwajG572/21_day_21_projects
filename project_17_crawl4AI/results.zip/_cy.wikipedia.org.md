[Neidio i'r cynnwys](https://cy.wikipedia.org/wiki/Hafan#bodyContent)
Prif ddewislen
Prif ddewislen
symud i'r bar ochr cuddio
Llywio 
  * [Hafan](https://cy.wikipedia.org/wiki/Hafan "Ymweld â'r Hafan \[z\]")
  * [Porth y Gymuned](https://cy.wikipedia.org/wiki/Wicipedia:Porth_y_Gymuned "Pethau i'w gwneud, adnoddau a thudalennau'r gymuned")
  * [Y Caffi](https://cy.wikipedia.org/wiki/Wicipedia:Y_Caffi)
  * [Materion cyfoes](https://cy.wikipedia.org/wiki/Categori:Materion_cyfoes "Gwybodaeth yn gysylltiedig â materion cyfoes")
  * [Newidiadau diweddar](https://cy.wikipedia.org/wiki/Arbennig:RecentChanges "Rhestr y newidiadau diweddar ar y wici. \[r\]")
  * [Erthygl ar hap](https://cy.wikipedia.org/wiki/Arbennig:Random "Llwytho tudalen ar hap \[x\]")
  * [Cymorth](https://cy.wikipedia.org/wiki/Wicipedia:Cymorth "Tudalennau cymorth")


[ ![](https://cy.wikipedia.org/static/images/icons/wikipedia.png) ![Wicipedia](https://cy.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-cy.svg) ![](https://cy.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-cy.svg) ](https://cy.wikipedia.org/wiki/Hafan)
[Chwilio ](https://cy.wikipedia.org/wiki/Arbennig:Search "Chwilio Wicipedia \[f\]")
Chwilio
Gwedd
  * [Rhoi](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=cy.wikipedia.org&uselang=cy)
  * [Creu cyfrif](https://cy.wikipedia.org/w/index.php?title=Arbennig:CreateAccount&returnto=Hafan "Rydym yn argymell eich bod yn creu cyfri ac yn menwgofnodi. Fodd bynnag, dydy hyn ddim yn orfodol")
  * [Mewngofnodi](https://cy.wikipedia.org/w/index.php?title=Arbennig:UserLogin&returnto=Hafan "Fe'ch anogir i fewngofnodi, er nad oes rhaid gwneud. \[o\]")


Offer personol
  * [Rhoi](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=cy.wikipedia.org&uselang=cy)
  * [Creu cyfrif](https://cy.wikipedia.org/w/index.php?title=Arbennig:CreateAccount&returnto=Hafan "Rydym yn argymell eich bod yn creu cyfri ac yn menwgofnodi. Fodd bynnag, dydy hyn ddim yn orfodol")
  * [Mewngofnodi](https://cy.wikipedia.org/w/index.php?title=Arbennig:UserLogin&returnto=Hafan "Fe'ch anogir i fewngofnodi, er nad oes rhaid gwneud. \[o\]")


# Hafan
  * [Hafan](https://cy.wikipedia.org/wiki/Hafan "Gweld y dudalen bwnc \[c\]")
  * [Sgwrs](https://cy.wikipedia.org/wiki/Sgwrs:Hafan "Sgwrsio am y dudalen \[t\]")


Cymraeg
  * [Darllen](https://cy.wikipedia.org/wiki/Hafan)
  * [Gweld cod](https://cy.wikipedia.org/w/index.php?title=Hafan&action=edit "Mae'r dudalen hon wedi'i diogelu.
Gallwch weld y côd ffynhonnell \[e\]")
  * [Gweld hanes](https://cy.wikipedia.org/w/index.php?title=Hafan&action=history "Fersiynau cynt o'r dudalen hon. \[h\]")


Blwch offer
Blwch offer
symud i'r bar ochr cuddio
Gweithredoedd 
  * [Darllen](https://cy.wikipedia.org/wiki/Hafan)
  * [Gweld cod](https://cy.wikipedia.org/w/index.php?title=Hafan&action=edit)
  * [Gweld hanes](https://cy.wikipedia.org/w/index.php?title=Hafan&action=history)


Cyffredinol 
  * [Beth sy'n cysylltu yma](https://cy.wikipedia.org/wiki/Arbennig:WhatLinksHere/Hafan "Rhestr o bob tudalen sy'n cysylltu â hon \[j\]")
  * [Newidiadau perthnasol](https://cy.wikipedia.org/wiki/Arbennig:RecentChangesLinked/Hafan "Newidiadau diweddar i dudalennau sydd yn cysylltu â hon \[k\]")
  * [Dolen barhaol](https://cy.wikipedia.org/w/index.php?title=Hafan&oldid=13445210 "Dolen barhaol i'r fersiwn hwn y dudalen hon")
  * [Gwybodaeth am y dudalen](https://cy.wikipedia.org/w/index.php?title=Hafan&action=info "Mwy o wybodaeth am y dudalen hon")
  * [Cyfeirio at y dudalen hon](https://cy.wikipedia.org/w/index.php?title=Arbennig:CiteThisPage&page=Hafan&id=13445210&wpFormIdentifier=titleform "Gwybodaeth ar sut i gyfeirio at y dudalen hon")
  * [Cael URL byr](https://cy.wikipedia.org/w/index.php?title=Arbennig:UrlShortener&url=https%3A%2F%2Fcy.wikipedia.org%2Fwiki%2FHafan)
  * [Lawrlwytho cod QR](https://cy.wikipedia.org/w/index.php?title=Arbennig:QrCode&url=https%3A%2F%2Fcy.wikipedia.org%2Fwiki%2FHafan)


Argraffu / allforio 
  * [Llunio llyfr](https://cy.wikipedia.org/w/index.php?title=Arbennig:Book&bookcmd=book_creator&referer=Hafan)
  * [Lawrlwytho fel PDF](https://cy.wikipedia.org/w/index.php?title=Arbennig:DownloadAsPdf&page=Hafan&action=show-download-screen)
  * [Fersiwn argraffu](https://cy.wikipedia.org/w/index.php?title=Hafan&printable=yes "Cynhyrchwch fersiwn o'r dudalen yn barod at ei hargraffu \[p\]")


Mewn prosiectau eraill 
  * [Comin Wikimedia](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWici](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wici](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wicimedia Allgymorth](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Wicidestun Amlieithog](https://wikisource.org/wiki/Main_Page)
  * [Wicifywyd](https://species.wikimedia.org/wiki/Main_Page)
  * [Wicilyfrau](https://cy.wikibooks.org/wiki/Hafan)
  * [Wicidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wiciddyfynnu](https://cy.wikiquote.org/wiki/Hafan)
  * [Wicidestun](https://cy.wikisource.org/wiki/Hafan)
  * [Wiciadur](https://cy.wiktionary.org/wiki/Hafan)
  * [Eitem Wicidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Cysylltu i eitem ystorfa gysylltiedig \[g\]")


Gwedd
symud i'r bar ochr cuddio
Oddi ar Wicipedia
# Croeso i [Wicipedia](https://cy.wikipedia.org/wiki/Wicipedia "Wicipedia")
y [gwyddoniadur](https://cy.wikipedia.org/wiki/Gwyddoniadur "Gwyddoniadur") [rhydd](https://cy.wikipedia.org/wiki/Cynnwys_rhydd "Cynnwys rhydd") ac [agored](https://cy.wikipedia.org/wiki/Wicipedia:Cyflwyniad "Wicipedia:Cyflwyniad"),   
gyda [282,587](https://cy.wikipedia.org/wiki/Arbennig:Statistics "Arbennig:Statistics") o erthyglau [Cymraeg](https://cy.wikipedia.org/wiki/Cymraeg "Cymraeg")
**A wyddoch chi?** Yn ogystal â darllen y gwyddoniadur, gallwch ein cynorthwyo i'w ddatblygu a'i wella! Gall unrhyw un olygu unrhyw erthygl drwy glicio ar y gair **"Golygu"** ar ei brig. Os nad ydyw'n bodoli eto, gallwch greu un newydd! 
## Pigion
[![Hunan-bortread ym 1887](https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/VanGogh_1887_Selbstbildnis.jpg/500px-VanGogh_1887_Selbstbildnis.jpg)](https://cy.wikipedia.org/wiki/Delwedd:VanGogh_1887_Selbstbildnis.jpg "Hunan-bortread ym 1887")Hunan-bortread ym 1887
[Arlunydd](https://cy.wikipedia.org/wiki/Arlunydd "Arlunydd") o'r [Iseldiroedd](https://cy.wikipedia.org/wiki/Iseldiroedd "Iseldiroedd") oedd **[Vincent van Gogh](https://cy.wikipedia.org/wiki/Vincent_van_Gogh "Vincent van Gogh")**. Roedd yn un o'r Ôl-argraffiadwyr, ac mae'n un o'r artistiaid enwocaf erioed. 
Fe'i ganwyd yn Zundert ar y [degfed ar hugain o Fawrth](https://cy.wikipedia.org/wiki/30_Mawrth "30 Mawrth"), [1853](https://cy.wikipedia.org/wiki/1853 "1853"), a bu farw ar y [nawfed ar hugain o Orffennaf](https://cy.wikipedia.org/wiki/29_Gorffennaf "29 Gorffennaf"), [1890](https://cy.wikipedia.org/wiki/1890 "1890") yn Auvers-sur-Oise. 
Yn ddyn ifanc, bu'n fasnachwr celf, yn athro, ac yna'n bregethwr - ond ni fu'n llwyddiannus iawn yn yr un o'r meysydd hyn. Ym [1880](https://cy.wikipedia.org/wiki/1880 "1880") y cychwynnodd ar ei yrfa fel arlunydd, ag yntau'n 27 oed. Un o'r pethau a'i symbylodd i ddechrau arlunio oedd anogaeth ei frawd Theo, a oedd yn werthwr gwaith celf llwyddiannus ym [Mharis](https://cy.wikipedia.org/wiki/Paris "Paris") ar y pryd... [mwy...](https://cy.wikipedia.org/wiki/Vincent_van_Gogh "Vincent van Gogh")
**[Rhagor o bigion](https://cy.wikipedia.org/wiki/Wicipedia:Pigion "Wicipedia:Pigion")**
## Cymraeg
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Flag_of_Wales.svg/250px-Flag_of_Wales.svg.png)](https://cy.wikipedia.org/wiki/Wicipedia:Cymraeg "Wicipedia:Cymraeg")
**You don't speak Cymraeg?** Welsh (Cymraeg) is a member of the Celtic family of languages. It is spoken in the western part of Britain known as Wales, as well as in the Chubut Valley, a Welsh immigrant colony in the Patagonia region of Argentina. There are also speakers of Welsh in England, the United States, Australia and other countries throughout the world. Welsh and English are the official languages in Wales. 
**¿No hablas Cymraeg?** El galés (Cymraeg) es un idioma céltico hablado como lengua principal en el País de Gales, región occidental del Reino Unido, y además en Chubut, comunidad de la región de Patagonia en Argentina. Hay gente que habla galés en Inglaterra, en Estados Unidos, en Australia y en otros países del mundo también. Con el inglés, es uno de los dos idiomas oficiales de Gales. 
**Vous ne parlez pas Cymraeg?** Le gallois (Cymraeg) est une langue celtique, parlée au Pays de Galles (Grande-Bretagne) et au val de Chubut en Patagonie, province de l'Argentine. Il y a des gallophones en Angleterre, aux États-Unis et en Australie ainsi qu'en d'autres pays du monde. Avec l'anglais, c'est une des deux langues officielles du Pays de Galles. 
[**Alemannisch, العربية, Bahasa Melayu, Bân-lâm-gú, Brezhoneg, Български, Català, Česky, Dansk, Deutsch, Dolnoserbski, Eesti, English, Español, Esperanto, Euskara, Français, Frysk, Gaeilge, Gàidhlig. Galego, Hornjoserbsce, 한국어, Bahasa Indonesia, Íslenska, Italiano, עברית, Kapampangan, Kölsch...**](https://cy.wikipedia.org/wiki/Wicipedia:Cymraeg "Wicipedia:Cymraeg")
## Ar y dydd hwn
[![Morfydd Llwyn Owen](https://upload.wikimedia.org/wikipedia/cy/thumb/a/a3/MLOwen.jpg/120px-MLOwen.jpg)](https://cy.wikipedia.org/wiki/Delwedd:MLOwen.jpg "Morfydd Llwyn Owen")
Morfydd Llwyn Owen
**[1 Hydref](https://cy.wikipedia.org/wiki/1_Hydref "1 Hydref")** : Diwrnod annibyniaeth **[Nigeria](https://cy.wikipedia.org/wiki/Nigeria "Nigeria")** ([1960](https://cy.wikipedia.org/wiki/1960 "1960")) 
  * **[1866](https://cy.wikipedia.org/wiki/1866 "1866")** (159 mlynedd yn ôl) – agorwyd **[Rheilffordd Talyllyn](https://cy.wikipedia.org/wiki/Rheilffordd_Talyllyn "Rheilffordd Talyllyn")**
  * **[1891](https://cy.wikipedia.org/wiki/1891 "1891")** (134 mlynedd yn ôl) – ganwyd y gantores a'r gyfansoddwraig **[Morfydd Llwyn Owen](https://cy.wikipedia.org/wiki/Morfydd_Llwyn_Owen "Morfydd Llwyn Owen")** yn [Nhrefforest](https://cy.wikipedia.org/wiki/Trefforest "Trefforest"), [Sir Forgannwg](https://cy.wikipedia.org/wiki/Sir_Forgannwg "Sir Forgannwg")
  * **[1908](https://cy.wikipedia.org/wiki/1908 "1908")** (117 mlynedd yn ôl) – dechreuodd **[Henry Ford](https://cy.wikipedia.org/wiki/Henry_Ford "Henry Ford")** werthu [ceir](https://cy.wikipedia.org/wiki/Car "Car") y _Model T_ yn yr Unol Daleithiau
  * **[1923](https://cy.wikipedia.org/wiki/1923 "1923")** (102 mlynedd yn ôl) – ganwyd y pêl-droediwr **[Trevor Ford](https://cy.wikipedia.org/wiki/Trevor_Ford "Trevor Ford")** yn [Abertawe](https://cy.wikipedia.org/wiki/Abertawe "Abertawe")
  * **[2012](https://cy.wikipedia.org/wiki/2012 "2012")** (13 mlynedd yn ôl) – bu farw yr hanesydd **[Eric Hobsbawm](https://cy.wikipedia.org/wiki/Eric_Hobsbawm "Eric Hobsbawm")**


**[Rhagor o ‘Ar y dydd hwn’](https://cy.wikipedia.org/wiki/Wicipedia:Ar_y_dydd_hwn/Hydref "Wicipedia:Ar y dydd hwn/Hydref")** – **[Rhestr dyddiau'r flwyddyn](https://cy.wikipedia.org/wiki/Rhestr_dyddiau%27r_flwyddyn "Rhestr dyddiau'r flwyddyn")** – **[Materion cyfoes](https://cy.wikipedia.org/wiki/Categori:Materion_cyfoes "Categori:Materion cyfoes")**
## Erthyglau diweddar
  * [Syrcas Nofit State](https://cy.wikipedia.org/wiki/Syrcas_Nofit_State "Syrcas Nofit State")
  * [Un o'r Teulu (drama Ayckbourn)](https://cy.wikipedia.org/wiki/Un_o%27r_Teulu_\(drama_Ayckbourn\) "Un o'r Teulu \(drama Ayckbourn\)")
  * [Thomas Owen Jones (Gwynfor)](https://cy.wikipedia.org/wiki/Thomas_Owen_Jones_\(Gwynfor\) "Thomas Owen Jones \(Gwynfor\)")
  * [Alice Margaret Evans](https://cy.wikipedia.org/wiki/Alice_Margaret_Evans "Alice Margaret Evans")
  * [Berry Pomeroy](https://cy.wikipedia.org/wiki/Berry_Pomeroy "Berry Pomeroy")
  * [Aerfen](https://cy.wikipedia.org/wiki/Aerfen "Aerfen")
  * [Doctor ar ei Waethaf](https://cy.wikipedia.org/wiki/Doctor_ar_ei_Waethaf "Doctor ar ei Waethaf")
  * [Führerprinzip](https://cy.wikipedia.org/wiki/F%C3%BChrerprinzip "Führerprinzip")
  * [Dartington](https://cy.wikipedia.org/wiki/Dartington "Dartington")
  * [Ffilm wyddonias](https://cy.wikipedia.org/wiki/Ffilm_wyddonias "Ffilm wyddonias")
  * [Theatr epig](https://cy.wikipedia.org/wiki/Theatr_epig "Theatr epig")
  * [Cwmni Theatr 7:84](https://cy.wikipedia.org/wiki/Cwmni_Theatr_7:84 "Cwmni Theatr 7:84")
  * [Undebau llafur yn y Deyrnas Unedig](https://cy.wikipedia.org/wiki/Undebau_llafur_yn_y_Deyrnas_Unedig "Undebau llafur yn y Deyrnas Unedig")
  * [Genod Tŷ'r Ysgol](https://cy.wikipedia.org/wiki/Genod_T%C5%B7%27r_Ysgol "Genod Tŷ'r Ysgol")
  * [Drama'r Dioddefaint](https://cy.wikipedia.org/wiki/Drama%27r_Dioddefaint "Drama'r Dioddefaint")
  * [Judith Roberts](https://cy.wikipedia.org/wiki/Judith_Roberts "Judith Roberts")
  * [Ali Kent](https://cy.wikipedia.org/wiki/Ali_Kent "Ali Kent")
  * [Brodyr a Chwiorydd (cyfres deledu)](https://cy.wikipedia.org/wiki/Brodyr_a_Chwiorydd_\(cyfres_deledu\) "Brodyr a Chwiorydd \(cyfres deledu\)")
  * [C.P.D. Basel](https://cy.wikipedia.org/wiki/C.P.D._Basel "C.P.D. Basel")
  * [Gouache](https://cy.wikipedia.org/wiki/Gouache "Gouache")
  * [Rhodd Mam (drama deledu)](https://cy.wikipedia.org/wiki/Rhodd_Mam_\(drama_deledu\) "Rhodd Mam \(drama deledu\)")
  * [Robin Gwyndaf](https://cy.wikipedia.org/wiki/Robin_Gwyndaf "Robin Gwyndaf")
  * [Tegwared y Bais Wen](https://cy.wikipedia.org/wiki/Tegwared_y_Bais_Wen "Tegwared y Bais Wen")
  * [Dyfrlliw](https://cy.wikipedia.org/wiki/Dyfrlliw "Dyfrlliw")
  * [Steve Jones (athletwr)](https://cy.wikipedia.org/wiki/Steve_Jones_\(athletwr\) "Steve Jones \(athletwr\)")


**[Newidiadau diweddar](https://cy.wikipedia.org/wiki/Arbennig:RecentChanges "Arbennig:RecentChanges")**
## [Marwolaethau diweddar](https://cy.wikipedia.org/wiki/Nodyn:Marwolaethau_diweddar "Nodyn:Marwolaethau diweddar")
  * [Jane Goodall](https://cy.wikipedia.org/wiki/Jane_Goodall "Jane Goodall")
  * [Tony Harrison](https://cy.wikipedia.org/wiki/Tony_Harrison "Tony Harrison")
  * [Menzies Campbell](https://cy.wikipedia.org/wiki/Menzies_Campbell "Menzies Campbell")
  * [Claudia Cardinale](https://cy.wikipedia.org/wiki/Claudia_Cardinale "Claudia Cardinale")
  * [Robert Redford](https://cy.wikipedia.org/wiki/Robert_Redford "Robert Redford")


## Cymorth a Chymuned
  * [Polisïau a Chanllawiau](https://cy.wikipedia.org/wiki/Wicipedia:Polis%C3%AFau_a_chanllawiau "Wicipedia:Polisïau a chanllawiau")
  * [Hawlfraint](https://cy.wikipedia.org/wiki/Wicipedia:Hawlfraint "Wicipedia:Hawlfraint")
  * [Ynglŷn â Wicipedia](https://cy.wikipedia.org/wiki/Wicipedia:Yngl%C5%B7n_%C3%A2_Wicipedia "Wicipedia:Ynglŷn â Wicipedia")
  * [Geirfa Wicipedia](https://cy.wikipedia.org/wiki/Wicipedia:Geirfa "Wicipedia:Geirfa")


### Ysgrifennu Erthyglau
  * [Sut i olygu tudalen](https://cy.wikipedia.org/wiki/Wicipedia:Sut_i_olygu_tudalen "Wicipedia:Sut i olygu tudalen") ([canllaw cryno](https://cy.wikipedia.org/wiki/Wicipedia:Canllaw_cryno_-_golygu "Wicipedia:Canllaw cryno - golygu"))
  * [Arddull](https://cy.wikipedia.org/wiki/Wicipedia:Arddull "Wicipedia:Arddull")
  * [Canllawiau iaith](https://cy.wikipedia.org/wiki/Wicipedia:Canllawiau_iaith "Wicipedia:Canllawiau iaith")
  * [WiciBrosiectau](https://cy.wikipedia.org/wiki/Wicipedia:WiciProsiectau "Wicipedia:WiciProsiectau")
  * [Erthyglau hanfodol sydd eu hangen](https://cy.wikipedia.org/wiki/Wicipedia:Erthyglau_hanfodol_coll "Wicipedia:Erthyglau hanfodol coll")
  * [Rhestr o ferched heb erthygl arnynt](https://cy.wikipedia.org/wiki/Wicipedia:Merched_a_anwyd_yng_Nghymru "Wicipedia:Merched a anwyd yng Nghymru")


### Cymuned
  * [Porth y Gymuned](https://cy.wikipedia.org/wiki/Wicipedia:Porth_y_Gymuned "Wicipedia:Porth y Gymuned")
  * [Y Caffi](https://cy.wikipedia.org/wiki/Wicipedia:Y_Caffi "Wicipedia:Y Caffi")
  * [Cornel y Dysgwyr / _Learners' Corner_](https://cy.wikipedia.org/wiki/Wicipedia:Cornel_y_dysgwyr "Wicipedia:Cornel y dysgwyr")


  

## Chwaer brosiectau Wicipedia
Mae [Sefydliad Wikimedia](https://cy.wikipedia.org/wiki/Sefydliad_Wikimedia "Sefydliad Wikimedia") (_Wikimedia Foundation_) yn darparu nifer o [brosiectau ar-lein rhydd eraill](https://cy.wikipedia.org/wiki/Categori:Prosiectau_Wicimedia "Categori:Prosiectau Wicimedia") yn ogystal â Wicipedia, trwy gyfrwng mwy na 280 o ieithoedd. Maent i gyd yn [wicïau](https://cy.wikipedia.org/wiki/Wici "Wici"), sy'n golygu bod pawb yn cael eu hysgrifennu, eu golygu, a'u darllen. Sefydlwyd Wikimedia yn 2003 gan [Jimmy Wales](https://cy.wikipedia.org/wiki/Jimmy_Wales "Jimmy Wales"), ac fe'i gweinyddir yn [Fflorida](https://cy.wikipedia.org/wiki/Fflorida "Fflorida"). ([Mwy am Wikimedia](https://foundation.wikimedia.org/wiki/ "wikimedia:")) [![Comin](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/Hafan "Comin") |  **[Comin](https://commons.wikimedia.org/wiki/Hafan)**   
Delweddau, sain ayb  |  [![MediaWici](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/ "MediaWici") |  **[MediaWici](https://mediawiki.org/)**   
Datblygu meddalwedd rhydd  |  [![Meta-Wici](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/Main_Page/cy "Meta-Wici") |  **[Meta-Wici](https://meta.wikimedia.org/wiki/Main_Page/cy)**   
Wikimedia (Wicimedia)  
---|---|---|---|---|---  
[![Wicilyfrau](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://cy.wikibooks.org/wiki/Hafan "Wicilyfrau") |  **[Wicilyfrau](https://cy.wikibooks.org/wiki/Hafan)**   
Gwerslyfrau a llawlyfrau  |  [![Wicidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/Wikidata:Main_Page "Wicidata") |  **[Wicidata](https://wikidata.org/wiki/Wikidata:Main_Page)**   
Bas-data ar gyfer yr holl brosiectau (Saesneg)  |  [![Wicinewyddion](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://en.wikipedia.org/wiki/n:Main_Page "Wicinewyddion") |  **[Wicinewyddion](https://en.wikinews.org/wiki/Main_Page)**   
Newyddion (Saesneg)  
[![Wiciddyfynnu](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/60px-Wikiquote-logo.svg.png)](https://cy.wikiquote.org/wiki/Hafan "Wiciddyfynnu") |  **[Wiciddyfynnu](https://cy.wikiquote.org/wiki/Hafan)**   
Dyfyniadur Cymraeg |  [![Wicidestun](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://cy.wikisource.org/wiki/Hafan "Wicidestun") |  **[Wicidestun](https://cy.wikisource.org/wiki/Hafan)**   
Testun Cymraeg, gwreiddiol  |  [![Wicifywyd](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/Hafan "Wicifywyd") |  **[Wicifywyd](https://species.wikimedia.org/wiki/Hafan)**   
Rhywogaethau (Saesneg)   
[![Wiciysgol](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/60px-Wikiversity-logo.svg.png)](https://en.wikipedia.org/wiki/v:Wikiversity:Main_Page "Wiciysgol") |  **[Wiciysgol](https://en.wikiversity.org/wiki/Wikiversity:Main_Page)**   
Deunydd a datblygiadau addysgol (Saesneg)  |  [![Wicidaith](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://en.wikivoyage.org/wiki/ "Wicidaith") |  **[Wicidaith](https://incubator.wikimedia.org/wiki/Wy/cy/Hafan)**   
Teithlyfr (fersiwn Cymraeg ar y gweill)  |  [![Wiciadur](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/60px-Wiktionary-logo.svg.png)](https://cy.wiktionary.org/wiki/Hafan "Wiciadur") |  **[Wiciadur](https://cy.wiktionary.org/wiki/Hafan)**   
Geiriadur a thesawrws Cymraeg  
## Ieithoedd Wicipedia
**Mae Wicipedia i'w chael mewn mwy na 300[iaith](https://cy.wikipedia.org/wiki/Iaith "Iaith"). Dyma rai:**
Dros 1,000,000 o erthyglau:  
[Almaeneg](https://de.wikipedia.org/wiki/ "de:") · [Arabeg](https://ar.wikipedia.org/wiki/ "ar:") · [Arabeg yr Aifft](https://arz.wikipedia.org/wiki/ "arz:") · [Cebuano](https://ceb.wikipedia.org/wiki/ "ceb:") · [Eidaleg](https://it.wikipedia.org/wiki/ "it:") · [Fietnameg](https://vi.wikipedia.org/wiki/ "vi:") · [Ffrangeg](https://fr.wikipedia.org/wiki/ "fr:") · [Iseldireg](https://nl.wikipedia.org/wiki/ "nl:") · [Japaneg](https://ja.wikipedia.org/wiki/ "ja:") · [Perseg](https://fa.wikipedia.org/wiki/ "fa:") · [Portiwgaleg](https://pt.wikipedia.org/wiki/ "pt:") · [Pwyleg](https://pl.wikipedia.org/wiki/ "pl:") · [Rwseg](https://ru.wikipedia.org/wiki/ "ru:") · [Saesneg](https://en.wikipedia.org/wiki/ "en:") · [Sbaeneg](https://es.wikipedia.org/wiki/ "es:") · [Swedeg](https://sv.wikipedia.org/wiki/ "sv:") · [Tsieineeg](https://zh.wikipedia.org/wiki/ "zh:") · [Waray](https://war.wikipedia.org/wiki/ "war:") · [Wcreineg](https://uk.wikipedia.org/wiki/ "uk:")
Dros 250,000 o erthyglau:  
[Armeneg](https://hy.wikipedia.org/wiki/ "hy:") · [Bân-lâm-gú](https://zh-min-nan.wikipedia.org/wiki/ "nan:") · [Basgeg](https://eu.wikipedia.org/wiki/ "eu:") · [Bwlgareg](https://bg.wikipedia.org/wiki/ "bg:") · [Catalaneg](https://ca.wikipedia.org/wiki/ "ca:") · [Corëeg](https://ko.wikipedia.org/wiki/ "ko:") · [Cymraeg](https://cy.wikipedia.org/wiki/Cymraeg "Cymraeg") · [Daneg](https://da.wikipedia.org/wiki/ "da:") · [Esperanto](https://eo.wikipedia.org/wiki/ "eo:") · [Ffinneg](https://fi.wikipedia.org/wiki/ "fi:") · [Hebraeg](https://he.wikipedia.org/wiki/ "he:") · [Hwngareg](https://hu.wikipedia.org/wiki/ "hu:") · [Indoneseg](https://id.wikipedia.org/wiki/ "id:") · [Maleieg](https://ms.wikipedia.org/wiki/ "ms:") · [Norwyeg - Bokmål](https://no.wikipedia.org/wiki/ "no:") · [Rwmaneg](https://ro.wikipedia.org/wiki/ "ro:") · [Serbeg](https://sr.wikipedia.org/wiki/ "sr:") · [Serbo-Croateg](https://sh.wikipedia.org/wiki/ "sh:") · [Tatareg](https://tt.wikipedia.org/wiki/ "tt:") · [Tsieceg](https://cs.wikipedia.org/wiki/ "cs:") · [Tsietsnieg](https://ce.wikipedia.org/wiki/ "ce:") · [Twrceg](https://tr.wikipedia.org/wiki/ "tr:")
Mewn ieithoedd Celtaidd eraill:  
[Cernyweg](https://kw.wikipedia.org/wiki/ "kw:") · [Gaeleg yr Alban](https://gd.wikipedia.org/wiki/ "gd:") · [Gwyddeleg](https://ga.wikipedia.org/wiki/ "ga:") · [Llydaweg](https://br.wikipedia.org/wiki/ "br:") · [Manaweg](https://gv.wikipedia.org/wiki/ "gv:") 

**[→ Gweler y rhestr lawn ←](https://meta.wikimedia.org/wiki/List_of_Wikipedias "m:List of Wikipedias")**

Wedi dod o "[https://cy.wikipedia.org/w/index.php?title=Hafan&oldid=13445210](https://cy.wikipedia.org/w/index.php?title=Hafan&oldid=13445210)"
[Categorïau](https://cy.wikipedia.org/wiki/Arbennig:Categories "Arbennig:Categories"): 
  * [Nodiadau gweinyddol](https://cy.wikipedia.org/wiki/Categori:Nodiadau_gweinyddol "Categori:Nodiadau gweinyddol")


Categori cudd: 
  * [Ar y dydd hwn](https://cy.wikipedia.org/wiki/Categori:Ar_y_dydd_hwn "Categori:Ar y dydd hwn")


353 iaith
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page - Affareg")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа - Abchaseg")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue - Acehneg")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ - Circaseg Gorllewinol")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad - Affricaneg")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte - Almaeneg y Swistir")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк - Altäeg Deheuol")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ - Amhareg")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw - Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada - Aragoneg")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet - Hen Saesneg")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu - Obolo")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ - Angika")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة - Arabeg")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ - Aramaeg")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا - Arabeg Moroco")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه - Arabeg yr Aifft")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত - Asameg")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada - Astwrianeg")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin - Atikamekw")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер - Afareg")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola - Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना - Awadhi")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi - Aymareg")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə - Aserbaijaneg")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه - South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит - Bashcorteg")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama - Balïeg")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn - Bavarian")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis - Samogiteg")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman - Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina - Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman - West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка - Belarwseg")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка - Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé - Betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница - Bwlgareg")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना - Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej - Bislama")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian - Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ - Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ - Bambareg")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা - Bengaleg")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། - Tibeteg")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা - Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer - Llydaweg")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana - Bosnieg")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo - Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola - Bwginaeg")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан - Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada - Catalaneg")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina - Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk - Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо - Tsietsieneg")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid - Cebuano")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman - Tsiamorro")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page - Siocto")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ - Tsierocî")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama - Cheyenne")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک - Cwrdeg Sorani")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra - Corseg")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ - Cri")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife - Tyrceg y Crimea")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana - Tsieceg")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna - Kashubian")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница - Hen Slafoneg")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница - Tshwfasheg")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside - Daneg")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu - Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite - Almaeneg")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu - Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït - Dinca")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri - Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok - Sorbeg Isaf")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo - Central Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना - Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ - Difehi")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། - Dzongkha")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ - Ewe")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια - Groeg")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP - Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page - Saesneg")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo - Esperanto")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada - Sbaeneg")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht - Estoneg")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala - Basgeg")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua - Extremadureg")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی - Perseg")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir - Ffanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo - Ffwla")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu - Ffinneg")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht - Võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu - Ffijïeg")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða - Ffaröeg")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn - Fon")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal - Ffrangeg")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla - Arpitaneg")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid - Ffriseg Gogleddol")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl - Ffriwleg")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside - Ffriseg y Gorllewin")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach - Gwyddeleg")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak - Gagauz")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 - Gan")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal - Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag - Gaeleg yr Alban")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada - Galisieg")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ - Gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha - Guaraní")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान - Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo - Gorontalo")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 - Gotheg")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page - Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ - Gwjarati")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü - Wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure - Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan - Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag - Manaweg")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi - Hawsa")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p - Hakka Chinese")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi - Hawäieg")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי - Hebraeg")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ - Hindi")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna - Fiji Hindi")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page - Hiri Motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica - Croateg")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona - Sorbeg Uchaf")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal - Creol Haiti")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap - Hwngareg")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ - Armeneg")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ - Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page - Herero")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal - Interlingua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah - Ibaneg")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama - Indoneseg")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine - Interlingue")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ - Igbo")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo - Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik - Inwpiaceg")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid - Ilocaneg")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув - Ingwsieg")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico - Ido")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða - Islandeg")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale - Eidaleg")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ - Inwctitwt")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ - Japaneeg")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej - Jamaican Creole English")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju - Lojban")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa - Jafanaeg")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი - Georgeg")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet - Cara-Calpaceg")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan - Cabileg")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ - Cabardieg")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu - Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu - Tyapeg")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi - Congo")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang - Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page - Kikuyu")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page - Kuanyama")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет - Casacheg")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa - Kalaallisut")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម - Chmereg")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ - Kannada")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura - Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 - Coreeg")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок - Komi-Permyak")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page - Canwri")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет - Karachay-Balkar")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ - Cashmireg")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk - Cwleneg")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk - Cwrdeg")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir - Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок - Comi")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre - Cernyweg")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак - Cirgiseg")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima - Lladin")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja - Iddew-Sbaeneg")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit - Lwcsembwrgeg")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин - Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин - Lezgheg")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef - Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka - Ganda")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad - Limbwrgeg")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ - Ligwreg")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala - Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala - Lombardeg")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó - Lingala")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ - Laoeg")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ - Luri Gogleddol")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis - Lithwaneg")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa - Latgaleg")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa - Latfieg")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan - Madwreg")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना - Maithili")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama - Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа - Mocsia")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana - Malagaseg")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page - Marsialeg")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык - Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga - Māori")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo - Minangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница - Macedoneg")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ - Malayalam")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас - Mongoleg")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ - Manipwri")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် - Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo - Mosi")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ - Marathi")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш - Mari Gorllewinol")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama - Maleieg")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali - Malteg")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page - Creek")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal - Mirandeg")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ - Byrmaneg")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа - Erzya")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه - Masanderani")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl - Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale - Naplieg")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet - Almaeneg Isel")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad - Sacsoneg Isel")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ - Nepaleg")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ - Newaeg")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu - Ndonga")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama - Nias")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina - Iseldireg")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside - Norwyeg Nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside - Norwyeg Bokmål")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine - Novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ - N’Ko")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page - Ndebele Deheuol")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde - Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele - Sotho Gogleddol")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi - Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos - Nafaho")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu - Nianja")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh - Ocsitaneg")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu - Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura - Oromo")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା - Odia")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс - Oseteg")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ - Pwnjabeg")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong - Pangasineg")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung - Pampanga")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal - Papiamento")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul - Picardeg")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej - Pidgin Nigeria")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt - Almaeneg Pensylfania")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid - Almaeneg Palatin")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta - Pali")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij - Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna - Pwyleg")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada - Piedmonteg")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ - Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα - Ponteg")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ - Pashto")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal - Portiwgaleg")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj - Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa - Quechua")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ - Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala - Románsh")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin - Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru - Rwndi")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală - Rwmaneg")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã - Aromaneg")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále - Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок - Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница - Rwseg")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка - Rusyn")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro - Ciniarŵandeg")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् - Sansgrit")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй - Sakha")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ - Santali")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale - Sardeg")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali - Sisileg")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page - Sgoteg")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو - Sindhi")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu - Sami Gogleddol")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî - Sango")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica - Serbo-Croateg")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut - Tachelhit")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ - Shan")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව - Sinhaleg")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page - Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka - Slofaceg")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت - Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran - Slofeneg")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua - Samöeg")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo - Inari Sami")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga - Shona")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore - Somaleg")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore - Albaneg")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна - Serbeg")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira - Sranan Tongo")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu - Swati")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele - Sesotheg Deheuol")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede - Ffriseg Saterland")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas - Swndaneg")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida - Swedeg")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo - Swahili")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ - Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta - Silesieg")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih - Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் - Tamileg")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan - Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ - Tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ - Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ - Telugu")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk - Tetumeg")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ - Tajiceg")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก - Thai")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ - Tigrinya")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ - Tigreg")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa - Tyrcmeneg")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina - Tagalog")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə - Talysheg")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono - Tswana")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia - Tongeg")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes - Tok Pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa - Tyrceg")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas - Taroko")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu - Tsongaeg")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит - Tatareg")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu - Twmbwca")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw - Twi")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a - Tahitïeg")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын - Twfwnieg")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам - Fotiaceg")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت - Uighur")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка - Wcreineg")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول - Wrdw")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa - Wsbeceg")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani - Fendeg")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio - Feniseg")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ - Feps")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính - Fietnameg")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad - Fflemeg Gorllewinol")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad - Folapük")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje - Walwneg")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli - Winarayeg")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk - Woloff")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 - Wu Tsieineaidd")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх - Calmyceg")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo - Xhosa")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა - Mingrelian")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט - Iddew-Almaeneg")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ - Iorwba")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz - Zhuang")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad - Zêlandeg")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ - Tamaseit Moroco Safonol")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 - Tsieinëeg")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 - Literary Chinese")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h - Minnan")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 - Cantoneeg")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu - Swlw")


[Golygu dolenni](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Golygu dolenni rhyngwici")
  * Golygwyd y dudalen hon ddiwethaf ar 11 Chwefror 2025, am 08:24.
  * Mae'r testun ar gael o dan [Creative Commons Attribution-ShareAlike License](https://creativecommons.org/licenses/by-sa/4.0/deed.en); gall telerau ychwanegol fod yn berthnasol. Gweler y [Telerau Gwasanaeth](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use) am fanylion.


  * [Polisi preifatrwydd](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Ynglŷn â Wicipedia](https://cy.wikipedia.org/wiki/Wicipedia:Yngl%C5%B7n_%C3%A2_Wicipedia)
  * [Gwadiadau](https://cy.wikipedia.org/wiki/Wicipedia:Gwadiad_Cyffredinol)
  * [Cod Ymddygiad](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Datblygwyr](https://developer.wikimedia.org)
  * [Ystadegau](https://stats.wikimedia.org/#/cy.wikipedia.org)
  * [Datganiad cwcis](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Golwg symudol](https://cy.m.wikipedia.org/w/index.php?title=Hafan&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://cy.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://cy.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Chwilio
Chwilio
Hafan
[](https://cy.wikipedia.org/wiki/Hafan) [](https://cy.wikipedia.org/wiki/Hafan) [](https://cy.wikipedia.org/wiki/Hafan) [](https://cy.wikipedia.org/wiki/Hafan) [](https://cy.wikipedia.org/wiki/Hafan) [](https://cy.wikipedia.org/wiki/Hafan) [](https://cy.wikipedia.org/wiki/Hafan) [](https://cy.wikipedia.org/wiki/Hafan)
353 iaith [Ychwanegu adran ](https://cy.wikipedia.org/wiki/Hafan)
