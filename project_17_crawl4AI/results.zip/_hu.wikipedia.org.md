[Ugrás a tartalomhoz](https://hu.wikipedia.org/wiki/Kezd%C5%91lap#bodyContent)
Főmenü
Főmenü
áthelyezés az oldalsávba elrejtés
Navigáció 
  * [Kezdőlap](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "A kezdőlap megtekintése \[z\]")
  * [Tartalom](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Tartalom)
  * [Kiemelt szócikkek](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Kiemelt_sz%C3%B3cikkek_list%C3%A1ja)
  * [Friss változtatások](https://hu.wikipedia.org/wiki/Speci%C3%A1lis:Friss_v%C3%A1ltoztat%C3%A1sok "A wikiben történt legutóbbi változtatások listája \[r\]")
  * [Lap találomra](https://hu.wikipedia.org/wiki/Speci%C3%A1lis:Lap_tal%C3%A1lomra "Egy véletlenszerűen kiválasztott lap betöltése \[x\]")
  * [Tudakozó](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Tudakoz%C3%B3)
  * [Speciális lapok](https://hu.wikipedia.org/wiki/Speci%C3%A1lis:Speci%C3%A1lis_lapok)


Részvétel 
  * [Kezdőknek](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%9Aj_szerkeszt%C5%91knek)
  * [Segítség](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Seg%C3%ADts%C3%A9g)
  * [Közösségi portál](https://hu.wikipedia.org/wiki/Port%C3%A1l:K%C3%B6z%C3%B6ss%C3%A9g "A projektről, miben segíthetsz, mit hol találsz meg")
  * [Kapcsolatfelvétel](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Kapcsolatfelv%C3%A9tel)


[ ![](https://hu.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipédia](https://hu.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-fr.svg) ![](https://hu.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-hu.svg) ](https://hu.wikipedia.org/wiki/Kezd%C5%91lap)
[Keresés ](https://hu.wikipedia.org/wiki/Speci%C3%A1lis:Keres%C3%A9s "Keresés a Wikipédián \[f\]")
Keresés
Megjelenés
  * [Adományok](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=hu.wikipedia.org&uselang=hu)
  * [Fiók létrehozása](https://hu.wikipedia.org/w/index.php?title=Speci%C3%A1lis:Szerkeszt%C5%91i_fi%C3%B3k_l%C3%A9trehoz%C3%A1sa&returnto=Kezd%C5%91lap "Arra bíztatunk, hogy hozz létre egy fiókot, és jelentkezz be, azonban ez nem kötelező")
  * [Bejelentkezés](https://hu.wikipedia.org/w/index.php?title=Speci%C3%A1lis:Bel%C3%A9p%C3%A9s&returnto=Kezd%C5%91lap "Bejelentkezni javasolt, de nem kötelező \[o\]")


Személyes eszközök
  * [Adományok](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=hu.wikipedia.org&uselang=hu)
  * [Közreműködés](https://hu.wikipedia.org/wiki/Speci%C3%A1lis:Contribute)
  * [Fiók létrehozása](https://hu.wikipedia.org/w/index.php?title=Speci%C3%A1lis:Szerkeszt%C5%91i_fi%C3%B3k_l%C3%A9trehoz%C3%A1sa&returnto=Kezd%C5%91lap "Arra bíztatunk, hogy hozz létre egy fiókot, és jelentkezz be, azonban ez nem kötelező")
  * [Bejelentkezés](https://hu.wikipedia.org/w/index.php?title=Speci%C3%A1lis:Bel%C3%A9p%C3%A9s&returnto=Kezd%C5%91lap "Bejelentkezni javasolt, de nem kötelező \[o\]")


Lapok kijelentkezett szerkesztőknek [további információk](https://hu.wikipedia.org/wiki/Seg%C3%ADts%C3%A9g:Bevezet%C3%A9s)
  * [Vitalap](https://hu.wikipedia.org/wiki/Speci%C3%A1lis:Vit%C3%A1m "Az általad használt IP-címről végrehajtott szerkesztések megvitatása \[n\]")


# Kezdőlap
**Ellenőrzött**
  * [Kezdőlap](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "A lap megtekintése \[c\]")
  * [Vitalap](https://hu.wikipedia.org/wiki/Vita:Kezd%C5%91lap "Az oldal tartalmának megvitatása \[t\]")


magyar
  * [Olvasás](https://hu.wikipedia.org/wiki/Kezd%C5%91lap)
  * [Lapforrás](https://hu.wikipedia.org/w/index.php?title=Kezd%C5%91lap&action=edit "Ez egy védett lap. Ide kattintva megnézheted a forrását. \[e\]")
  * [Laptörténet](https://hu.wikipedia.org/w/index.php?title=Kezd%C5%91lap&action=history "A lap korábbi változatai \[h\]")


Eszközök
Eszközök
áthelyezés az oldalsávba elrejtés
Műveletek 
  * [Olvasás](https://hu.wikipedia.org/wiki/Kezd%C5%91lap)
  * [Lapforrás](https://hu.wikipedia.org/w/index.php?title=Kezd%C5%91lap&action=edit)
  * [Laptörténet](https://hu.wikipedia.org/w/index.php?title=Kezd%C5%91lap&action=history)


Általános 
  * [Mi hivatkozik erre?](https://hu.wikipedia.org/wiki/Speci%C3%A1lis:Mi_hivatkozik_erre/Kezd%C5%91lap "Az erre a lapra hivatkozó más lapok listája \[j\]")
  * [Kapcsolódó változtatások](https://hu.wikipedia.org/wiki/Speci%C3%A1lis:Kapcsol%C3%B3d%C3%B3_v%C3%A1ltoztat%C3%A1sok/Kezd%C5%91lap "Az erről a lapról hivatkozott lapok utolsó változtatásai \[k\]")
  * [Hivatkozás erre a változatra](https://hu.wikipedia.org/w/index.php?title=Kezd%C5%91lap&oldid=28321075 "Állandó hivatkozás ezen lap ezen változatához")
  * [Lapinformációk](https://hu.wikipedia.org/w/index.php?title=Kezd%C5%91lap&action=info "További információk erről a lapról")
  * [Hogyan hivatkozz erre a lapra?](https://hu.wikipedia.org/w/index.php?title=Speci%C3%A1lis:Hivatkoz%C3%A1s&page=Kezd%C5%91lap&id=28321075&wpFormIdentifier=titleform "Információk a lap idézésével kapcsolatban")
  * [Rövidített URL készítése](https://hu.wikipedia.org/w/index.php?title=Speci%C3%A1lis:UrlShortener&url=https%3A%2F%2Fhu.wikipedia.org%2Fwiki%2FKezd%25C5%2591lap)
  * [QR-kód letöltése](https://hu.wikipedia.org/w/index.php?title=Speci%C3%A1lis:QrCode&url=https%3A%2F%2Fhu.wikipedia.org%2Fwiki%2FKezd%25C5%2591lap)


Nyomtatás/​exportálás 
  * [Könyv készítése](https://hu.wikipedia.org/w/index.php?title=Speci%C3%A1lis:K%C3%B6nyv&bookcmd=book_creator&referer=Kezd%C5%91lap)
  * [Letöltés PDF-ként](https://hu.wikipedia.org/w/index.php?title=Speci%C3%A1lis:DownloadAsPdf&page=Kezd%C5%91lap&action=show-download-screen)
  * [Nyomtatható változat](https://hu.wikipedia.org/w/index.php?title=Kezd%C5%91lap&printable=yes "A lap nyomtatható változata \[p\]")


Társprojektek 
  * [Wikimédia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimédia Alapítvány](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Többnyelvű Wikiforrás](https://wikisource.org/wiki/Main_Page)
  * [Wikifajok](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikikönyvek](https://hu.wikibooks.org/wiki/Kezd%C5%91lap)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifüggvények](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikihírek](https://hu.wikinews.org/wiki/Kezd%C5%91lap)
  * [Wikidézet](https://hu.wikiquote.org/wiki/Kezd%C5%91lap)
  * [Wikiforrás](https://hu.wikisource.org/wiki/Kezd%C5%91lap)
  * [Wikiszótár](https://hu.wiktionary.org/wiki/Wikisz%C3%B3t%C3%A1r:Kezd%C5%91lap)
  * [Wikidata-adatlap](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Kapcsolt adattárelem \[g\]")


Megjelenés
áthelyezés az oldalsávba elrejtés
A Wikipédiából, a szabad enciklopédiából
## Változat állapota
Ez a lap egy ellenőrzött változata
Ez a [közzétett változat](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Jel%C3%B6lt_lapv%C3%A1ltozatok "Wikipédia:Jelölt lapváltozatok"), [ellenőrizve](https://hu.wikipedia.org/w/index.php?title=Speci%C3%A1lis:Rendszernapl%C3%B3k&type=review&page=Kezd%C5%91lap): _2025. augusztus 11._ Pontosság | ellenőrzött  
---|---  
[Üdvözlünk](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%9Cdv%C3%B6zl%C3%BCnk,_l%C3%A1togat%C3%B3! "Wikipédia:Üdvözlünk, látogató!") a [Wikipédiában](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:R%C3%B3lunk "Wikipédia:Rólunk")! _Ezt az[enciklopédiát](https://hu.wikipedia.org/wiki/Enciklop%C3%A9dia "Enciklopédia") az olvasói [szerkesztik](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Az_els%C5%91_l%C3%A9p%C3%A9sek "Wikipédia:Az első lépések")._  
A [magyar](https://hu.wikipedia.org/wiki/Magyar_Wikip%C3%A9dia "Magyar Wikipédia") változatnak [561 284](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Statisztik%C3%A1k "Wikipédia:Statisztikák") [szócikke](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Sz%C3%B3cikk "Wikipédia:Szócikk") van, ebből [1059](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Kiemelt_sz%C3%B3cikkek_list%C3%A1ja "Wikipédia:Kiemelt szócikkek listája") [kiemelt](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Kiemelt_sz%C3%B3cikk "Wikipédia:Kiemelt szócikk"). |  | 
  * [Biológia](https://hu.wikipedia.org/wiki/Port%C3%A1l:Biol%C3%B3gia "Portál:Biológia")
  * [Fizika](https://hu.wikipedia.org/wiki/Port%C3%A1l:Fizika "Portál:Fizika")
  * [Földrajz](https://hu.wikipedia.org/wiki/Port%C3%A1l:F%C3%B6ldrajz "Portál:Földrajz")

| 
  * [Kultúra](https://hu.wikipedia.org/wiki/Port%C3%A1l:Kult%C3%BAra "Portál:Kultúra")
  * [Matematika](https://hu.wikipedia.org/wiki/Port%C3%A1l:Matematika "Portál:Matematika")
  * [Művészet](https://hu.wikipedia.org/wiki/Port%C3%A1l:M%C5%B1v%C3%A9szet "Portál:Művészet")

| 
  * [Technika](https://hu.wikipedia.org/wiki/Port%C3%A1l:Technika "Portál:Technika")
  * [Társadalom](https://hu.wikipedia.org/wiki/Port%C3%A1l:T%C3%A1rsadalom "Portál:Társadalom")
  * [Történelem](https://hu.wikipedia.org/wiki/Port%C3%A1l:T%C3%B6rt%C3%A9nelem "Portál:Történelem")

| 
  * [Sport](https://hu.wikipedia.org/wiki/Port%C3%A1l:Sport "Portál:Sport")
  * [Természet](https://hu.wikipedia.org/wiki/Port%C3%A1l:Term%C3%A9szet "Portál:Természet")
  * [Vallás](https://hu.wikipedia.org/wiki/Port%C3%A1l:Vall%C3%A1s "Portál:Vallás")

|  **[Összes portál](https://hu.wikipedia.org/wiki/Port%C3%A1l:Port%C3%A1lok "Portál:Portálok")**  
---|---|---|---|---  
[Mobilos változat](https://hu.m.wikipedia.org/wiki/Kezd%C5%91lap)[Kapcsolatfelvétel / Contact](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Kapcsolatfelv%C3%A9tel "Wikipédia:Kapcsolatfelvétel")  
##### Kiemelt cikk [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Kezd%C5%91lap_kiemelt_cikkei/2025-40-2&action=edit)
[![A Kerguelen-szigetek műholdképe](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Kerguelen.jpg/250px-Kerguelen.jpg)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Kerguelen.jpg "A Kerguelen-szigetek műholdképe") A Kerguelen-szigetek műholdképe A **[Kerguelen-szigetek](https://hu.wikipedia.org/wiki/Kerguelen-szigetek "Kerguelen-szigetek")** az [Indiai-óceán](https://hu.wikipedia.org/wiki/Indiai-%C3%B3ce%C3%A1n "Indiai-óceán") déli medencéjének egyik francia fennhatóság alá tartozó szigetcsoportja, a [Francia déli és antarktiszi területek](https://hu.wikipedia.org/wiki/Francia_d%C3%A9li_%C3%A9s_antarktiszi_ter%C3%BCletek "Francia déli és antarktiszi területek") része. Távolsága a legközelebbi szárazföldektől, a [Heard-szigettől és a McDonald-szigetektől](https://hu.wikipedia.org/wiki/Heard-sziget_%C3%A9s_McDonald-szigetek "Heard-sziget és McDonald-szigetek") 435 km, a [Crozet-szigetektől](https://hu.wikipedia.org/wiki/Crozet-szigetek "Crozet-szigetek") 1280 km. A szigetvilág a [Port-aux-Français](https://hu.wikipedia.org/wiki/Port-aux-Fran%C3%A7ais "Port-aux-Français") kutatóállomástól eltekintve lakatlan.  A szigetcsoport a déli szélesség 49., a keleti hosszúság 70. fokánál, [Ausztráliától](https://hu.wikipedia.org/wiki/Ausztr%C3%A1lia_\(kontinens\) "Ausztrália \(kontinens\)") mintegy 4000, a dél-afrikai partoktól 3800, az [Antarktisztól](https://hu.wikipedia.org/wiki/Antarktisz "Antarktisz") pedig 2000 kilométerre található.  A Kerguelen-szigetek – a többi szubantarktikus szárazföldhöz hasonlóan – a [Föld](https://hu.wikipedia.org/wiki/F%C3%B6ld "Föld") legfélreesőbb pontjai közé tartoznak: mivel még nem készült nagyobb repülőgépek landolására alkalmas kifutópálya, csak tengerről érhetők el, a fősziget nagy része pedig a zord terepviszonyok miatt csak [helikopterrel](https://hu.wikipedia.org/wiki/Helikopter "Helikopter") közelíthető meg. Novembertől márciusig rendszeresen közlekedik [Réunion](https://hu.wikipedia.org/wiki/R%C3%A9union "Réunion") szigetéről az 1995-ben épített _„Marion-Dufresne II”_ nevű kutató- és teherhajó, amely a [Crozet-szigeteket](https://hu.wikipedia.org/wiki/Crozet-szigetek "Crozet-szigetek"), a [Szent Pál](https://hu.wikipedia.org/wiki/Szent_P%C3%A1l-sziget_\(Francia_d%C3%A9li_%C3%A9s_antarktiszi_ter%C3%BCletek\) "Szent Pál-sziget \(Francia déli és antarktiszi területek\)")- és az [Amszterdam-szigetet](https://hu.wikipedia.org/wiki/Amszterdam-sziget "Amszterdam-sziget") is felfűzi útvonalára; a francia Paul-Émile Victor Sarkkutató Intézet _(Institut Polaire Français Paul-Émile Victor)_ 120,5 méter hosszú óceánjáróján átlagosan 8–10 napig tart az út. [Tovább a szócikkhez…](https://hu.wikipedia.org/wiki/Kerguelen-szigetek "Kerguelen-szigetek")
* * *
_A kezdőlapon legutóbb megjelent szócikkek:_ [Gorgosaurus](https://hu.wikipedia.org/wiki/Gorgosaurus "Gorgosaurus") • [Hadviselés az ókori Egyiptomban](https://hu.wikipedia.org/wiki/Hadvisel%C3%A9s_az_%C3%B3kori_Egyiptomban "Hadviselés az ókori Egyiptomban") • [2018-as sakkolimpia](https://hu.wikipedia.org/wiki/2018-as_sakkolimpia "2018-as sakkolimpia") • [II. Eduárd angol király](https://hu.wikipedia.org/wiki/II._Edu%C3%A1rd_angol_kir%C3%A1ly "II. Eduárd angol király") • [Durhami vár](https://hu.wikipedia.org/wiki/Durhami_v%C3%A1r "Durhami vár") • [Korea történelme](https://hu.wikipedia.org/wiki/Korea_t%C3%B6rt%C3%A9nelme "Korea történelme") • [Jelling viking emlékei](https://hu.wikipedia.org/wiki/Jelling_viking_eml%C3%A9kei "Jelling viking emlékei") **[További kiemelt lapok…](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Kiemelt_sz%C3%B3cikkek_list%C3%A1ja "Wikipédia:Kiemelt szócikkek listája")** |  | 
#####  [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Napk%C3%A9pe/2025-10-02&action=edit) [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Napk%C3%A9pe/2025-10-02_\(hu\)&action=edit)
[![Egy 1660-70 körül készült pahari festmény Basohliból \(Dzsammu és Kasmír, India\), amely Bhadrakali hindu istennőt ábrázolja, akit a hinduizmus három legfőbb istene: Brahma, a teremtő, Visnu, a megőrző és Siva, a pusztító imád, hogy megbékítsék, miután megölte a Mahisasura nevű démont, akit sem ők, sem az emberek, sem más istenek nem tudtak megölni. A démon feletti győzelmét a hinduk a jónak a rossz felett aratott győzelmeként ünneplik a Vijajadashami napján](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg/250px-Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg "Egy 1660-70 körül készült pahari festmény Basohliból \(Dzsammu és Kasmír, India\), amely Bhadrakali hindu istennőt ábrázolja, akit a hinduizmus három legfőbb istene: Brahma, a teremtő, Visnu, a megőrző és Siva, a pusztító imád, hogy megbékítsék, miután megölte a Mahisasura nevű démont, akit sem ők, sem az emberek, sem más istenek nem tudtak megölni. A démon feletti győzelmét a hinduk a jónak a rossz felett aratott győzelmeként ünneplik a Vijajadashami napján")   
Egy 1660-70 körül készült pahari festmény Basohliból ([Dzsammu és Kasmír](https://hu.wikipedia.org/wiki/Dzsammu_%C3%A9s_Kasm%C3%ADr "Dzsammu és Kasmír"), [India](https://hu.wikipedia.org/wiki/India "India")), amely Bhadrakali hindu istennőt ábrázolja, akit a [hinduizmus három legfőbb istene](https://hu.wikipedia.org/wiki/Trim%C3%BArti "Trimúrti"): [Brahma](https://hu.wikipedia.org/wiki/Brahma "Brahma"), a teremtő, [Visnu](https://hu.wikipedia.org/wiki/Visnu "Visnu"), a megőrző és [Siva](https://hu.wikipedia.org/wiki/Siva "Siva"), a pusztító imád, hogy megbékítsék, miután megölte a Mahisasura nevű démont, akit sem ők, sem az emberek, sem más istenek nem tudtak megölni. A démon feletti győzelmét a hinduk a jónak a rossz felett aratott győzelmeként ünneplik a Vijajadashami napján [Teljes méret](https://hu.wikipedia.org/wiki/F%C3%A1jl:Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg "Fájl:Goddess Bhadrakali Worshipped by the Gods- from a tantric Devi series - Google Art Project.jpg") • [Archívum](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:A_nap_k%C3%A9pe "Wikipédia:A nap képe") [![RSS ikon](https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Feed-icon.svg/20px-Feed-icon.svg.png)](https://hu.wikipedia.org/w/api.php?action=featuredfeed&feed=potd "Kiemelt kép RSS")
##### [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Kezd%C5%91lap_%C3%A9rdekess%C3%A9gei/2025-40-2&action=edit)
[![Kolerás beteg rehidratálása](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Cholera_rehydration_nurses.jpg/250px-Cholera_rehydration_nurses.jpg)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Cholera_rehydration_nurses.jpg "Kolerás beteg rehidratálása") Kolerás beteg rehidratálása
  * …a [kolera](https://hu.wikipedia.org/wiki/Kolera "Kolera") a járványtan egyik klasszikus betegsége, mely napjainkban is okozhat fertőző megbetegedést?
  * …a [Rozellomyceta](https://hu.wikipedia.org/wiki/Rozellomyceta "Rozellomyceta") két kládja a [kisspórások](https://hu.wikipedia.org/wiki/Kissp%C3%B3r%C3%A1sok "Kisspórások") és a [Rozellida](https://hu.wikipedia.org/wiki/Rozellida "Rozellida")?
  * …a [geokémia](https://hu.wikipedia.org/wiki/Geok%C3%A9mia "Geokémia") tudományágát sokáig csak érckutatásra használták, napjainkra az elméleti földtudományi kutatások fő segédeszköze lett?
  * …a [fehér gólya](https://hu.wikipedia.org/wiki/Feh%C3%A9r_g%C3%B3lya "Fehér gólya") Litvánia és Fehéroroszország nemzeti madara, de nemzeti szimbólumként tekintenek rá a szlovéniai Muravidéken, sőt a franciaországi Elzászban és Lotharingiában is?

**[Archívum](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Kezd%C5%91lapra_ker%C3%BClt_%C3%A9rdekess%C3%A9gek_list%C3%A1ja "Wikipédia:Kezdőlapra került érdekességek listája")** [![Kiemelt szócikk RSS](https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Feed-icon.svg/20px-Feed-icon.svg.png)](https://hu.wikipedia.org/w/api.php?action=featuredfeed&feed=dyk "Kiemelt szócikk RSS")  
---|---|---  
##### [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Kezd%C5%91lap_aktualit%C3%A1sai&action=edit)
[![Palesztina nemzetközi elismertsége](https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Palestine_recognition_only.svg/250px-Palestine_recognition_only.svg.png)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Palestine_recognition_only.svg "Palesztina nemzetközi elismertsége") [Palesztina nemzetközi elismertsége](https://hu.wikipedia.org/wiki/Palesztina_nemzetk%C3%B6zi_elismerts%C3%A9ge "Palesztina nemzetközi elismertsége")
  * Szeptember 21-én és 22-én az [ENSZ](https://hu.wikipedia.org/wiki/Egyes%C3%BClt_Nemzetek_Szervezete "Egyesült Nemzetek Szervezete")-közgyűlés idején tíz ország is bejelentette, hogy [elismerte](https://hu.wikipedia.org/wiki/Palesztina_nemzetk%C3%B6zi_elismerts%C3%A9ge "Palesztina nemzetközi elismertsége") [Palesztina](https://hu.wikipedia.org/wiki/Palesztina "Palesztina") függetlenségét.
  * Szeptember 16-án az [ENSZ](https://hu.wikipedia.org/wiki/Egyes%C3%BClt_Nemzetek_Szervezete "Egyesült Nemzetek Szervezete") kinevezett bizottsága kijelentette, hogy [Izrael](https://hu.wikipedia.org/wiki/Izrael "Izrael") [népirtást követ el](https://hu.wikipedia.org/wiki/G%C3%A1zai_n%C3%A9pirt%C3%A1s "Gázai népirtás") a [Gázai övezetben](https://hu.wikipedia.org/wiki/G%C3%A1zai_%C3%B6vezet "Gázai övezet").
  * Szeptember 12-én a brazil legfelsőbb bíróság bűnösnek mondta ki puccskísérlet előkészítése miatt [Jair Bolsonaro](https://hu.wikipedia.org/wiki/Jair_Bolsonaro "Jair Bolsonaro") egykori elnököt és 27 év börtönbüntetésre ítélte.
  * Szeptember 9-én lemondott [Franciaország](https://hu.wikipedia.org/wiki/Franciaorsz%C3%A1g "Franciaország") [miniszterelnöke](https://hu.wikipedia.org/wiki/Franciaorsz%C3%A1g_minisztereln%C3%B6keinek_list%C3%A1ja "Franciaország miniszterelnökeinek listája"), [François Bayrou](https://hu.wikipedia.org/wiki/Fran%C3%A7ois_Bayrou "François Bayrou") és utódja, [Sébastien Lecornu](https://hu.wikipedia.org/wiki/S%C3%A9bastien_Lecornu "Sébastien Lecornu") a hivatalába lépett.
  * Szeptember 7-én lemondott [Japán](https://hu.wikipedia.org/wiki/Jap%C3%A1n "Japán") [miniszterelnöke](https://hu.wikipedia.org/wiki/Jap%C3%A1n_minisztereln%C3%B6ke "Japán miniszterelnöke"), [Isiba Sigeru](https://hu.wikipedia.org/wiki/Isiba_Sigeru "Isiba Sigeru").

**[Az év aktualitásai](https://hu.wikipedia.org/wiki/2025 "2025"):** [Izrael–Hamász-háború](https://hu.wikipedia.org/wiki/2023-as_Izrael%E2%80%93Ham%C3%A1sz-h%C3%A1bor%C3%BA "2023-as Izrael–Hamász-háború") ([népirtás](https://hu.wikipedia.org/wiki/G%C3%A1zai_n%C3%A9pirt%C3%A1s "Gázai népirtás")) – [orosz invázió Ukrajna ellen](https://hu.wikipedia.org/wiki/2022-es_orosz_inv%C3%A1zi%C3%B3_Ukrajna_ellen "2022-es orosz invázió Ukrajna ellen")
* * *
**[Halálesetek a közelmúltban](https://hu.wikipedia.org/wiki/Hal%C3%A1loz%C3%A1sok_2025-ben "Halálozások 2025-ben")** : [Jane Goodall](https://hu.wikipedia.org/wiki/Jane_Goodall "Jane Goodall") – [Elek Judit](https://hu.wikipedia.org/wiki/Elek_Judit "Elek Judit") – [Medgyesi Mária](https://hu.wikipedia.org/wiki/Medgyesi_M%C3%A1ria_\(sz%C3%ADnm%C5%B1v%C3%A9sz\) "Medgyesi Mária \(színművész\)") – [José Araquistáin](https://hu.wikipedia.org/wiki/Jos%C3%A9_Araquist%C3%A1in "José Araquistáin") – [Lucian Mureșan](https://hu.wikipedia.org/wiki/Lucian_Mure%C8%99an "Lucian Mureșan") – [Bartusz György](https://hu.wikipedia.org/wiki/Bartusz_Gy%C3%B6rgy "Bartusz György") – [Claudia Cardinale](https://hu.wikipedia.org/wiki/Claudia_Cardinale "Claudia Cardinale")
##### Ezen a napon [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Kezd%C5%91lap_esem%C3%A9nyei&action=edit)
**Ma[2025](https://hu.wikipedia.org/wiki/2025 "2025"). [október 2.](https://hu.wikipedia.org/wiki/Okt%C3%B3ber_2. "Október 2.") van,** [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:%C3%9Cnnepek/10-02&action=edit)
  * [Petra](https://hu.wikipedia.org/wiki/Petra_\(keresztn%C3%A9v\) "Petra \(keresztnév\)") névnapja

[![Mahátma Gandhi](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Portrait_Gandhi.jpg/120px-Portrait_Gandhi.jpg)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Portrait_Gandhi.jpg "Mahátma Gandhi") [Mahátma Gandhi](https://hu.wikipedia.org/wiki/Mohand%C3%A1sz_Karamcsand_Gandhi "Mohandász Karamcsand Gandhi")
  * az [erőszakmentesség világnapja](https://hu.wikipedia.org/w/index.php?title=Er%C5%91szakmentess%C3%A9g_vil%C3%A1gnapja&action=edit&redlink=1 "Erőszakmentesség világnapja \(a lap nem létezik\)")[(wd)](https://www.wikidata.org/wiki/Q1419461#sitelinks-wikipedia "d:Q1419461") [Mahátma Gandhi](https://hu.wikipedia.org/wiki/Mohand%C3%A1sz_Karamcsand_Gandhi "Mohandász Karamcsand Gandhi") születésnapján
  * [Gandhi Dzsajanti](https://hu.wikipedia.org/w/index.php?title=Gandhi_Dzsajanti&action=edit&redlink=1 "Gandhi Dzsajanti \(a lap nem létezik\)")[(wd)](https://www.wikidata.org/wiki/Q658185#sitelinks-wikipedia "d:Q658185") [Indiában](https://hu.wikipedia.org/wiki/India "India") [Mahátma Gandhi](https://hu.wikipedia.org/wiki/Mohand%C3%A1sz_Karamcsand_Gandhi "Mohandász Karamcsand Gandhi") születésének emlékére
  * a [függetlenség napja](https://hu.wikipedia.org/wiki/F%C3%BCggetlens%C3%A9g_napja "Függetlenség napja") [Guineában](https://hu.wikipedia.org/wiki/Guinea "Guinea") az 1958-ban kikiáltott függetlenség emlékére
  * a [sztómások világnapja](https://hu.wikipedia.org/w/index.php?title=Szt%C3%B3m%C3%A1sok_vil%C3%A1gnapja&action=edit&redlink=1 "Sztómások világnapja \(a lap nem létezik\)")

**Évfordulók** [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:%C3%89vfordul%C3%B3k/%E2%80%990_%C3%A9s_%E2%80%995/10-02&action=edit)
  * **125 éve** , [1900](https://hu.wikipedia.org/wiki/1900 "1900")-ban házasságot kötött [Albert flamand gróf](https://hu.wikipedia.org/wiki/I._Albert_belga_kir%C3%A1ly "I. Albert belga király"), belga királyi herceg és [Wittelsbach Erzsébet hercegnő](https://hu.wikipedia.org/wiki/Erzs%C3%A9bet_belga_kir%C3%A1lyn%C3%A9 "Erzsébet belga királyné").
  * **115 éve** , [1910](https://hu.wikipedia.org/wiki/1910 "1910")-ben első alkalommal ütközött össze két [repülőgép](https://hu.wikipedia.org/wiki/Rep%C3%BCl%C5%91g%C3%A9p "Repülőgép") a levegőben ([Milánó](https://hu.wikipedia.org/wiki/Mil%C3%A1n%C3%B3 "Milánó") fölött).
  * **105 éve** , [1920](https://hu.wikipedia.org/wiki/1920 "1920")-ban hunyt el [Max Bruch](https://hu.wikipedia.org/wiki/Max_Bruch "Max Bruch") német zeneszerző és karmester (* [1838](https://hu.wikipedia.org/wiki/1838 "1838")).
  * **100 éve** , [1925](https://hu.wikipedia.org/wiki/1925 "1925")-ben született [Falus Róbert](https://hu.wikipedia.org/wiki/Falus_R%C3%B3bert "Falus Róbert") irodalomtörténész, klasszika-filológus, egyetemi tanár († [1983](https://hu.wikipedia.org/wiki/1983 "1983")).
  * **80 éve** , [1945](https://hu.wikipedia.org/wiki/1945 "1945")-ben született [Martin Hellman](https://hu.wikipedia.org/wiki/Martin_Hellman "Martin Hellman") amerikai [kriptográfus](https://hu.wikipedia.org/wiki/Kriptogr%C3%A1fia "Kriptográfia"), a nyílt kulcsú [kriptográfia](https://hu.wikipedia.org/wiki/Kriptogr%C3%A1fia "Kriptográfia") társfeltalálója [Whitfield Diffie](https://hu.wikipedia.org/wiki/Whitfield_Diffie "Whitfield Diffie")-vel és [Ralph Merkle](https://hu.wikipedia.org/w/index.php?title=Ralph_Merkle&action=edit&redlink=1 "Ralph Merkle \(a lap nem létezik\)")[(wd)](https://www.wikidata.org/wiki/Q92884#sitelinks-wikipedia "d:Q92884")-vel.
  * **75 éve** , [1950](https://hu.wikipedia.org/wiki/1950 "1950")-ben hunyt el [Tomcsányi Béla](https://hu.wikipedia.org/w/index.php?title=Tomcs%C3%A1nyi_B%C3%A9la&action=edit&redlink=1 "Tomcsányi Béla \(a lap nem létezik\)") villamosmérnök, postamérnök, a magyar rádiós műsorsugárzás kiemelkedő alakja (* [1897](https://hu.wikipedia.org/wiki/1897 "1897")).
  * **70 éve** , [1955](https://hu.wikipedia.org/wiki/1955 "1955")-ben az [ENIAC](https://hu.wikipedia.org/wiki/ENIAC "ENIAC"), az [1946](https://hu.wikipedia.org/wiki/1946 "1946")-ban elkészült első programozható, elektronikus, digitális [számítógép](https://hu.wikipedia.org/wiki/Sz%C3%A1m%C3%ADt%C3%B3g%C3%A9p "Számítógép") évtizedes használat után befejezte működését.
  * **55 éve** , [1970](https://hu.wikipedia.org/wiki/1970 "1970")-ben született [Erős Antónia](https://hu.wikipedia.org/wiki/Er%C5%91s_Ant%C3%B3nia "Erős Antónia"), újságíró, műsorvezető.
  * **45 éve** , [1980](https://hu.wikipedia.org/wiki/1980 "1980")-ban hunyt el [A. Tóth Sándor](https://hu.wikipedia.org/wiki/A._T%C3%B3th_S%C3%A1ndor "A. Tóth Sándor") középiskolai rajztanár, festőművész, bábművész (* [1904](https://hu.wikipedia.org/wiki/1904 "1904")).
  * **35 éve** , [1990](https://hu.wikipedia.org/wiki/1990 "1990")-ben elsőként indult a [Mir űrállomásra](https://hu.wikipedia.org/wiki/Mir "Mir") civil személy, [Akijama Tojohiro](https://hu.wikipedia.org/wiki/Akijama_Tojohiro "Akijama Tojohiro") japán újságíró, a _[Szojuz TM–11](https://hu.wikipedia.org/wiki/Szojuz_TM%E2%80%9311 "Szojuz TM–11")_ fedélzetén.

[![Az ENIAC](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Glen_Beck_and_Betty_Snyder_program_the_ENIAC_in_building_328_at_the_Ballistic_Research_Laboratory.jpg/250px-Glen_Beck_and_Betty_Snyder_program_the_ENIAC_in_building_328_at_the_Ballistic_Research_Laboratory.jpg)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Glen_Beck_and_Betty_Snyder_program_the_ENIAC_in_building_328_at_the_Ballistic_Research_Laboratory.jpg "Az ENIAC") Az [ENIAC](https://hu.wikipedia.org/wiki/ENIAC "ENIAC") [![Martin Hellman](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Martin-Hellman.jpg/120px-Martin-Hellman.jpg)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Martin-Hellman.jpg "Martin Hellman") [Martin Hellman](https://hu.wikipedia.org/wiki/Martin_Hellman "Martin Hellman") [![Max Bruch](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Max_bruch.jpg/120px-Max_bruch.jpg)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Max_bruch.jpg "Max Bruch") [Max Bruch](https://hu.wikipedia.org/wiki/Max_Bruch "Max Bruch") [![A belga királyi pár eljegyzési képe](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Verlovingsfoto_-Hertog_van_Brabant.jpg/120px-Verlovingsfoto_-Hertog_van_Brabant.jpg)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Verlovingsfoto_-Hertog_van_Brabant.jpg "A belga királyi pár eljegyzési képe") A belga királyi pár eljegyzési képe   
**[További ünnepek](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%9Cnnepek "Wikipédia:Ünnepek")** [![Ünnepek RSS](https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Feed-icon.svg/20px-Feed-icon.svg.png)](http://feeds.feedburner.com/huwiki-unnepek "Ünnepek RSS") **[További évfordulók](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%89vfordul%C3%B3k "Wikipédia:Évfordulók")** [![Évfordulók RSS](https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Feed-icon.svg/20px-Feed-icon.svg.png)](http://feeds.feedburner.com/huwiki-evfordulok "Évfordulók RSS") | 
##### [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Kezd%C5%91lap_ismerked%C3%A9s&action=edit)
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Contactus-wmcolors.svg/120px-Contactus-wmcolors.svg.png)](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%9Cdv%C3%B6zl%C3%BCnk,_l%C3%A1togat%C3%B3!)
  * **[Üdvözlőlap](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%9Cdv%C3%B6zl%C3%BCnk,_l%C3%A1togat%C3%B3! "Wikipédia:Üdvözlünk, látogató!")** – Bemutatkozik a Wikipédia.
  * **[Első lépések](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Az_els%C5%91_l%C3%A9p%C3%A9sek "Wikipédia:Az első lépések")** – Didaktikusan felépített bevezető a Wikipédia szerkesztésébe.
  * **[Segítség](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Seg%C3%ADts%C3%A9g "Wikipédia:Segítség")** – Egyszerű, közepes és haladó szerkesztési tippek, útmutatók.
  * **[Wikifogalmak](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Wikifogalmak_jegyz%C3%A9ke "Wikipédia:Wikifogalmak jegyzéke")** – Minden, ami elsőre kínaiul hangzik a Wikipédián, itt magyarázatra lel.
  * **[Kocsmafal kezdőknek](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Kocsmafal_\(kezd%C5%91knek\) "Wikipédia:Kocsmafal \(kezdőknek\)")** – Az új szerkesztő kérdez, aki tud, válaszol.
  * **[Próbalap](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Pr%C3%B3balap "Wikipédia:Próbalap")** – Újdonsült szerkesztőinknek ajánljuk.
  * **[Homokozó](https://hu.wikipedia.org/wiki/Cikkjel%C3%B6lt:Homokoz%C3%B3 "Cikkjelölt:Homokozó")** – Újdonsült szerkesztőink szabadon garázdálkodhatnak benne.
  * **[Mentorálás](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%9Aj_szerkeszt%C5%91k_t%C3%A1mogat%C3%A1sa/Mentor%C3%A1l%C3%A1s "Wikipédia:Új szerkesztők támogatása/Mentorálás")** – Kezdeti lépéseidhez támogatást kaphatsz egy tapasztaltabb szerkesztőtől.


##### [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Kezd%C5%91lap_k%C3%B6z%C3%B6ss%C3%A9g&action=edit)
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Wiki3A.jpg/120px-Wiki3A.jpg)](https://hu.wikipedia.org/wiki/Port%C3%A1l:K%C3%B6z%C3%B6ss%C3%A9g "Portál:Közösség")
  * **[Nagykövetség / Embassy](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Nagyk%C3%B6vets%C3%A9g "Wikipédia:Nagykövetség")** – Kapcsolat más nyelvű Wikipédiákkal.
  * **[Üzenőfalak](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%9Czen%C5%91fal "Wikipédia:Üzenőfal")** – A Wikipédia különböző tisztségviselőihez intézhető kérések és kérdések platformja.
  * **[Adminisztrátorok üzenőfala](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Adminisztr%C3%A1torok_%C3%BCzen%C5%91fala "Wikipédia:Adminisztrátorok üzenőfala")** – Az [adminisztrátori](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Adminisztr%C3%A1torok "Wikipédia:Adminisztrátorok") beavatkozást igénylő esetekre.
  * **[Járőrök üzenőfala](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:J%C3%A1r%C5%91r%C3%B6k_%C3%BCzen%C5%91fala "Wikipédia:Járőrök üzenőfala")** – A [járőri](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Friss_v%C3%A1ltoztat%C3%A1sok_j%C3%A1r%C5%91r%C3%B6z%C3%A9se "Wikipédia:Friss változtatások járőrözése") beavatkozást igénylő esetekre.
  * **[Wikipédia a sajtóban](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Wikip%C3%A9dia_a_sajt%C3%B3ban "Wikipédia:Wikipédia a sajtóban")** – Mit írnak a Wikipédiáról?


##### [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:K%C3%B6z%C3%B6ss%C3%A9gi_port%C3%A1l/Blogbejegyz%C3%A9sek&action=edit)
  * [500 000 szócikk a magyar Wikipédián!](https://huwiki.blogspot.com/2022/02/500K.html) | 2022. február 16.

  
##### [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Kezd%C5%91lap_nyelvek&action=edit)
Most a [2003](https://hu.wikipedia.org/wiki/2003 "2003")-ban indult [magyar nyelvű](https://hu.wikipedia.org/wiki/Magyar_nyelv "Magyar nyelv") Wikipédiát olvasod, de a Wikipédia sok más nyelven is elérhető. 
  * A legnagyobb Wikipédiák (több mint 2 millió szócikkel): [angol](https://en.wikipedia.org/wiki/ "en:"), [francia](https://fr.wikipedia.org/wiki/ "fr:"), [holland](https://nl.wikipedia.org/wiki/ "nl:"), [német](https://de.wikipedia.org/wiki/ "de:"), [orosz](https://ru.wikipedia.org/wiki/ "ru:"), [spanyol](https://es.wikipedia.org/wiki/ "es:"), [svéd](https://sv.wikipedia.org/wiki/ "sv:"), [szebuano](https://ceb.wikipedia.org/wiki/ "ceb:").


  * Wikipédiák a [Magyarországon](https://hu.wikipedia.org/wiki/Magyarorsz%C3%A1g "Magyarország") hivatalosan elismert [nemzetiségek](https://hu.wikipedia.org/wiki/Magyarorsz%C3%A1g_nemzetis%C3%A9gei "Magyarország nemzetiségei") nyelvein: [bolgár](https://bg.wikipedia.org/wiki/ "bg:"), [cigány](https://rmy.wikipedia.org/wiki/ "rmy:"), [görög](https://el.wikipedia.org/wiki/ "el:"), [horvát](https://hr.wikipedia.org/wiki/ "hr:"), [lengyel](https://pl.wikipedia.org/wiki/ "pl:"), [német](https://de.wikipedia.org/wiki/ "de:"), [örmény](https://hy.wikipedia.org/wiki/ "hy:"), [román](https://ro.wikipedia.org/wiki/ "ro:"), [ruszin](https://rue.wikipedia.org/wiki/ "rue:"), [szerb](https://sr.wikipedia.org/wiki/ "sr:"), [szerbhorvát](https://sh.wikipedia.org/wiki/ "sh:"), [szlovák](https://sk.wikipedia.org/wiki/ "sk:"), [szlovén](https://sl.wikipedia.org/wiki/ "sl:"), [ukrán](https://uk.wikipedia.org/wiki/ "uk:").

**[További nyelvek…](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Wikip%C3%A9di%C3%A1k_list%C3%A1ja "Wikipédia:Wikipédiák listája")**
##### [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Kezd%C5%91lap_t%C3%A1rslapok&action=edit)
A Wikipédiát a nonprofit [Wikimédia Alapítvány](https://hu.wikipedia.org/wiki/Wikim%C3%A9dia_Alap%C3%ADtv%C3%A1ny "Wikimédia Alapítvány") üzemelteti. A Wikimédia számos többnyelvű és [nyílt tartalmú](https://hu.wikipedia.org/wiki/Ny%C3%ADlt_tartalom "Nyílt tartalom") társlapot üzemeltet:  | [![Wikiszótár](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://hu.wiktionary.org/wiki/ "Wikiszótár") |  [Wikiszótár](https://hu.wiktionary.org/wiki/ "wikt:")  
Többnyelvű szótár és szinonimaszótár  
---|---  
[![Wikimédia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/Kezd%C5%91lap "Wikimédia Commons") |  [Wikimédia Commons](https://commons.wikimedia.org/wiki/Kezd%C5%91lap "commons:Kezdőlap")  
Szabad médiaállományok gyűjteménye  
---|---  
[![Wikidézet](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://hu.wikiquote.org/wiki/ "Wikidézet") |  [Wikidézet](https://hu.wikiquote.org/wiki/ "q:")  
Többnyelvű idézet- és szólásgyűjtemény  
---|---  
[![Wikiegyetem](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/60px-Wikiversity-logo.svg.png)](https://en.wikiversity.org/wiki/ "Wikiegyetem") |  [Wikiegyetem](https://en.wikiversity.org/wiki/ "wikiversity:")  
Jegyzetek és tanulási segédletek  
---|---  
[![Wikifajok](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/Kezd%C5%91lap "Wikifajok") |  [Wikifajok](https://species.wikimedia.org/wiki/Kezd%C5%91lap "wikispecies:Kezdőlap")  
Rendszertani adatbázis  
---|---  
[![Wikiforrás](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://hu.wikisource.org/wiki/ "Wikiforrás") |  [Wikiforrás](https://hu.wikisource.org/wiki/ "s:")  
Szabad forrásmunkák  
---|---  
[![Wikikönyvek](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://hu.wikibooks.org/wiki/ "Wikikönyvek") |  [Wikikönyvek](https://hu.wikibooks.org/wiki/ "b:")  
Szabad kézikönyvek és útmutatók  
---|---  
[![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "Wikidata") |  [Wikidata](https://www.wikidata.org/wiki/Wikidata:Kezd%C5%91lap "d:Wikidata:Kezdőlap")  
Szabad központi tudásbázis  
---|---  
[![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://en.wikivoyage.org/wiki/ "Wikivoyage") |  [Wikivoyage](https://en.wikivoyage.org/wiki/ "wikivoyage:")  
Szabad útikalauz  
---|---  
[![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/Kezd%C5%91lap "Meta-Wiki") |  [Meta-Wiki](https://meta.wikimedia.org/wiki/Kezd%C5%91lap "m:Kezdőlap")  
A Wikimédia-projektek koordinációja  
---|---  
##### [ ](https://hu.wikipedia.org/w/index.php?title=Sablon:Kezd%C5%91lap_felt%C3%A9telek&action=edit)
A Wikipédiában található szövegekre és egyes képekre a [Creative Commons _Nevezd meg! – Így add tovább!_ 4.0](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:CC-BY-SA-4.0 "Wikipédia:CC-BY-SA-4.0") _(CC-BY-SA-4.0)_ licenc vonatkozik.
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Cc.logo.circle.svg/40px-Cc.logo.circle.svg.png)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Cc.logo.circle.svg)[![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Cc-by_new.svg/40px-Cc-by_new.svg.png)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Cc-by_new.svg)[![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Cc-sa.svg/40px-Cc-sa.svg.png)](https://hu.wikipedia.org/wiki/F%C3%A1jl:Cc-sa.svg)
  * **Minden szerkesztésed** ezen licenc elfogadását és alkalmazását jelenti, mellyel hozzájárulsz, hogy a művet bárki módosíthatja, azt bármilyen célra felhasználhatja.
  * A Wikipédia tartalmának _újrafelhasználásakor_ (átdolgozás esetén is) meg kell adnod, hogy a műre a fenti licenc vonatkozik, továbbá meg kell nevezned a forrásul szolgáló szócikket; internetes közzététel esetén a forrásműre mutató linket kell elhelyezned honlapodon.
  * A képek felhasználási feltételeit külön kell ellenőrizned.


  * [Felhasználási feltételek](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Felhaszn%C3%A1l%C3%A1si_felt%C3%A9telek "Wikipédia:Felhasználási feltételek")
  * [Jogi nyilatkozat](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Jogi_nyilatkozat "Wikipédia:Jogi nyilatkozat")
  * [Újrafelhasználási útmutató](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:%C3%9Ajrafelhaszn%C3%A1l%C3%A1si_seg%C3%A9dlet "Wikipédia:Újrafelhasználási segédlet")

  
A lap eredeti címe: „[https://hu.wikipedia.org/w/index.php?title=Kezdőlap&oldid=28321075](https://hu.wikipedia.org/w/index.php?title=Kezd%C5%91lap&oldid=28321075)”
Rejtett kategóriák: 
  * [Lefordítandó cikkekre való utalást tartalmazó lapok](https://hu.wikipedia.org/wiki/Kateg%C3%B3ria:Leford%C3%ADtand%C3%B3_cikkekre_val%C3%B3_utal%C3%A1st_tartalmaz%C3%B3_lapok "Kategória:Lefordítandó cikkekre való utalást tartalmazó lapok")
  * [Kezdőlap](https://hu.wikipedia.org/wiki/Kateg%C3%B3ria:Kezd%C5%91lap "Kategória:Kezdőlap")


53 nyelv
  * [English](https://en.wikipedia.org/wiki/ "angol")
  * [العربية](https://ar.wikipedia.org/wiki/ "arab")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/ "azerbajdzsáni")
  * [Български](https://bg.wikipedia.org/wiki/ "bolgár")
  * [Català](https://ca.wikipedia.org/wiki/ "katalán")
  * [Čeština](https://cs.wikipedia.org/wiki/ "cseh")
  * [Dansk](https://da.wikipedia.org/wiki/ "dán")
  * [Deutsch](https://de.wikipedia.org/wiki/ "német")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "görög")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "eszperantó")
  * [Español](https://es.wikipedia.org/wiki/ "spanyol")
  * [Eesti](https://et.wikipedia.org/wiki/ "észt")
  * [Euskara](https://eu.wikipedia.org/wiki/ "baszk")
  * [فارسی](https://fa.wikipedia.org/wiki/ "perzsa")
  * [Suomi](https://fi.wikipedia.org/wiki/ "finn")
  * [Français](https://fr.wikipedia.org/wiki/ "francia")
  * [Galego](https://gl.wikipedia.org/wiki/ "gallego")
  * [עברית](https://he.wikipedia.org/wiki/ "héber")
  * [हिन्दी](https://hi.wikipedia.org/wiki/ "hindi")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "horvát")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/ "haiti kreol")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "indonéz")
  * [Italiano](https://it.wikipedia.org/wiki/ "olasz")
  * [日本語](https://ja.wikipedia.org/wiki/ "japán")
  * [ქართული](https://ka.wikipedia.org/wiki/ "grúz")
  * [한국어](https://ko.wikipedia.org/wiki/ "koreai")
  * [Latina](https://la.wikipedia.org/wiki/ "latin")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "litván")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "maláj")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/ "nevari")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "holland")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "norvég \(nynorsk\)")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "norvég \(bokmål\)")
  * [Polski](https://pl.wikipedia.org/wiki/ "lengyel")
  * [Piemontèis](https://pms.wikipedia.org/wiki/ "Piedmontese")
  * [Português](https://pt.wikipedia.org/wiki/ "portugál")
  * [Română](https://ro.wikipedia.org/wiki/ "román")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/ "aromán")
  * [Русский](https://ru.wikipedia.org/wiki/ "orosz")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "szlovák")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "szlovén")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "szerb")
  * [Svenska](https://sv.wikipedia.org/wiki/ "svéd")
  * [తెలుగు](https://te.wikipedia.org/wiki/ "telugu")
  * [ไทย](https://th.wikipedia.org/wiki/ "thai")
  * [Tagalog](https://tl.wikipedia.org/wiki/ "tagalog")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "török")
  * [Українська](https://uk.wikipedia.org/wiki/ "ukrán")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vietnámi")
  * [Volapük](https://vo.wikipedia.org/wiki/ "volapük")
  * [Winaray](https://war.wikipedia.org/wiki/ "varaó")
  * [中文](https://zh.wikipedia.org/wiki/ "kínai")


  * A lap utolsó módosítása: 2025. augusztus 11., 04:02
  * A lap szövege [Creative Commons Nevezd meg! – Így add tovább! 4.0](http://creativecommons.org/licenses/by-sa/4.0/deed.hu) licenc alatt van; egyes esetekben más módon is felhasználható. Részletekért lásd a [felhasználási feltételeket](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Felhaszn%C3%A1l%C3%A1si_felt%C3%A9telek "Wikipédia:Felhasználási feltételek").


  * [Adatvédelmi irányelvek](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [A Wikipédiáról](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:R%C3%B3lunk)
  * [Jogi nyilatkozat](https://hu.wikipedia.org/wiki/Wikip%C3%A9dia:Jogi_nyilatkozat)
  * [Magatartási kódex](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Fejlesztők](https://developer.wikimedia.org)
  * [Statisztikák](https://stats.wikimedia.org/#/hu.wikipedia.org)
  * [Sütinyilatkozat](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Mobil nézet](https://hu.m.wikipedia.org/w/index.php?title=Kezd%C5%91lap&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://hu.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://hu.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Keresés
Keresés
Kezdőlap
[](https://hu.wikipedia.org/wiki/Kezd%C5%91lap) [](https://hu.wikipedia.org/wiki/Kezd%C5%91lap) [](https://hu.wikipedia.org/wiki/Kezd%C5%91lap) [](https://hu.wikipedia.org/wiki/Kezd%C5%91lap) [](https://hu.wikipedia.org/wiki/Kezd%C5%91lap) [](https://hu.wikipedia.org/wiki/Kezd%C5%91lap) [](https://hu.wikipedia.org/wiki/Kezd%C5%91lap) [](https://hu.wikipedia.org/wiki/Kezd%C5%91lap)
53 nyelv [Új téma nyitása ](https://hu.wikipedia.org/wiki/Kezd%C5%91lap)
