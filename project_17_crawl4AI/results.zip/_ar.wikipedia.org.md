[انتقل إلى المحتوى](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9#bodyContent)
القائمة الرئيسية
القائمة الرئيسية
انقل للشريط الجانبي أخف
الموسوعة 
  * [الصفحة الرئيسة](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "زر الصفحة الرئيسية \[z\]")
  * [الأحداث الجارية](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A3%D8%AD%D8%AF%D8%A7%D8%AB_%D8%AC%D8%A7%D8%B1%D9%8A%D8%A9 "مطالعة سريعة لأهم الأحداث الجارية")
  * [أحدث التغييرات](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A3%D8%AD%D8%AF%D8%AB_%D8%A7%D9%84%D8%AA%D8%BA%D9%8A%D9%8A%D8%B1%D8%A7%D8%AA "قائمة أحدث التغييرات في الويكي. \[r\]")
  * [أحدث التغييرات الأساسية](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A3%D8%AD%D8%AF%D8%AB_%D8%A7%D9%84%D8%AA%D8%BA%D9%8A%D9%8A%D8%B1%D8%A7%D8%AA_%D8%A7%D9%84%D9%85%D9%88%D8%B5%D9%88%D9%84%D8%A9/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B5%D9%81%D8%AD%D8%A7%D8%AA_%D9%85%D9%87%D9%85%D8%A9)


تصفح 
  * [المواضيع](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AA%D8%B5%D9%81%D8%AD)
  * [أبجدي](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%81%D9%87%D8%B1%D8%B3_%D8%B3%D8%B1%D9%8A%D8%B9)
  * [بوابات](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%AA%D8%B5%D9%81%D8%AD)
  * [مقالة عشوائية](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%B9%D8%B4%D9%88%D8%A7%D8%A6%D9%8A "حمل صفحة عشوائية \[x\]")
  * [تصفح من غير إنترنت](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%83%D9%8A%D9%88%D9%8A%D9%83%D8%B3)


مشاركة 
  * [تواصل مع ويكيبيديا](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D8%AA%D8%B5%D9%84_%D8%A8%D9%86%D8%A7)
  * [مساعدة](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D9%85%D8%AD%D8%AA%D9%88%D9%8A%D8%A7%D8%AA "حيث تجد المساعدة")
  * [الميدان](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D9%84%D9%85%D9%8A%D8%AF%D8%A7%D9%86)
  * [صفحات خاصة](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%B5%D9%81%D8%AD%D8%A7%D8%AA_%D8%AE%D8%A7%D8%B5%D8%A9)


[ ![](https://ar.wikipedia.org/static/images/icons/wikipedia.png) ![ويكيبيديا](https://ar.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-ar.svg) ![](https://ar.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-ar.svg) ](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9)
[بحث ](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A8%D8%AD%D8%AB "ابحث في ويكيبيديا \[f\]")
بحث
المظهر
  * [تبرع](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ar.wikipedia.org&uselang=ar)
  * [إنشاء حساب](https://ar.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%A5%D9%86%D8%B4%D8%A7%D8%A1_%D8%AD%D8%B3%D8%A7%D8%A8&returnto=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9+%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "نشجعك على عمل حساب وتسجيل دخولك؛ لكنه غير ضروري على اي حال")
  * [دخول](https://ar.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%AF%D8%AE%D9%88%D9%84_%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D8%AE%D8%AF%D9%85&returnto=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9+%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "يفضل أن تسجل الدخول، لكنه ليس إلزاميا. \[o\]")


أدوات شخصية
  * [تبرع](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=ar.wikipedia.org&uselang=ar)
  * [إنشاء حساب](https://ar.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%A5%D9%86%D8%B4%D8%A7%D8%A1_%D8%AD%D8%B3%D8%A7%D8%A8&returnto=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9+%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "نشجعك على عمل حساب وتسجيل دخولك؛ لكنه غير ضروري على اي حال")
  * [دخول](https://ar.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%AF%D8%AE%D9%88%D9%84_%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D8%AE%D8%AF%D9%85&returnto=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9+%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "يفضل أن تسجل الدخول، لكنه ليس إلزاميا. \[o\]")


# الصفحة الرئيسة
  * [الصفحة الرئيسة](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "اعرض صفحة المحتوى \[c\]")
  * [نقاش](https://ar.wikipedia.org/wiki/%D9%86%D9%82%D8%A7%D8%B4:%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "نقاش صفحة المحتوى \[t\]")


العربية
  * [اقرأ](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9)
  * [عرض المصدر](https://ar.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&action=edit "هذه الصفحة محمية.
يمكنك مطالعة مصدرها. \[e\]")
  * [تاريخ](https://ar.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&action=history "النسخ السابقة لهذه الصفحة \[h\]")


أدوات
أدوات
انقل للشريط الجانبي أخف
إجراءات 
  * [اقرأ](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9)
  * [عرض المصدر](https://ar.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&action=edit)
  * [تاريخ](https://ar.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&action=history)


عام 
  * [ماذا يصل هنا](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D9%85%D8%A7%D8%B0%D8%A7_%D9%8A%D8%B5%D9%84_%D9%87%D9%86%D8%A7/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "قائمة بكل صفحات الويكي التي تصل هنا \[j\]")
  * [تغييرات ذات علاقة](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A3%D8%AD%D8%AF%D8%AB_%D8%A7%D9%84%D8%AA%D8%BA%D9%8A%D9%8A%D8%B1%D8%A7%D8%AA_%D8%A7%D9%84%D9%85%D9%88%D8%B5%D9%88%D9%84%D8%A9/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "أحدث التغييرات في الصفحات الموصولة من هذه الصفحة \[k\]")
  * [رفع ملف](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B1%D9%81%D8%B9 "ارفع ملفات \[u\]")
  * [وصلة دائمة](https://ar.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&oldid=70907266 "وصلة دائمة لهذه النسخة من الصفحة")
  * [معلومات الصفحة](https://ar.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&action=info "المزيد من المعلومات عن هذه الصفحة")
  * [استشهد بهذه الصفحة](https://ar.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%A7%D8%B3%D8%AA%D8%B4%D9%87%D8%A7%D8%AF&page=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&id=70907266&wpFormIdentifier=titleform "معلومات عن كيفية الاستشهاد بالصفحة")
  * [احصل على مسار مختصر](https://ar.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D8%AA%D9%82%D8%B5%D9%8A%D8%B1_%D8%A7%D9%84%D9%85%D8%B3%D8%A7%D8%B1&url=https%3A%2F%2Far.wikipedia.org%2Fwiki%2F%25D8%25A7%25D9%2584%25D8%25B5%25D9%2581%25D8%25AD%25D8%25A9_%25D8%25A7%25D9%2584%25D8%25B1%25D8%25A6%25D9%258A%25D8%25B3%25D8%25A9)
  * [تنزيل رمز الاستجابة السريعة](https://ar.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:QrCode&url=https%3A%2F%2Far.wikipedia.org%2Fwiki%2F%25D8%25A7%25D9%2584%25D8%25B5%25D9%2581%25D8%25AD%25D8%25A9_%25D8%25A7%25D9%2584%25D8%25B1%25D8%25A6%25D9%258A%25D8%25B3%25D8%25A9)


طباعة/تصدير 
  * [إنشاء كتاب](https://ar.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:%D9%83%D8%AA%D8%A7%D8%A8&bookcmd=book_creator&referer=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9+%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9)
  * [تحميل بصيغة PDF](https://ar.wikipedia.org/w/index.php?title=%D8%AE%D8%A7%D8%B5:DownloadAsPdf&page=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&action=show-download-screen)
  * [نسخة للطباعة](https://ar.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&printable=yes "نسخة للطباعة لهذه الصفحة \[p\]")


في مشاريع أخرى 
  * [ويكيميديا كومنز](https://commons.wikimedia.org/wiki/Main_Page)
  * [مؤسسة ويكيميديا](https://foundation.wikimedia.org/wiki/Home)
  * [ميدياويكي](https://www.mediawiki.org/wiki/MediaWiki)
  * [ميتاويكي](https://meta.wikimedia.org/wiki/Main_Page)
  * [التواصل مع ويكيميديا](https://outreach.wikimedia.org/wiki/Main_Page)
  * [ويكي مصدر متعدد اللغات](https://wikisource.org/wiki/Main_Page)
  * [ويكي الأنواع](https://species.wikimedia.org/wiki/Main_Page)
  * [ويكي الكتب](https://ar.wikibooks.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9)
  * [ويكي بيانات](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [ويكي الدوال](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [ويكي الأخبار](https://ar.wikinews.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9)
  * [ويكي الاقتباس](https://ar.wikiquote.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9)
  * [ويكي مصدر](https://ar.wikisource.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9)
  * [ويكي الجامعة](https://ar.wikiversity.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9)
  * [ويكاموس](https://ar.wiktionary.org/wiki/%D9%88%D9%8A%D9%83%D8%A7%D9%85%D9%88%D8%B3:%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9)
  * [عنصر ويكي بيانات](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "وصلة إلى المادة المرتبطة في مستودع البيانات المركزي \[g\]")


المظهر
انقل للشريط الجانبي أخف
من ويكيبيديا، الموسوعة الحرة
[![مرحبًا بكم في ويكيبيديا](https://upload.wikimedia.org/wikipedia/ar/thumb/1/1b/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7-%D8%A7%D9%84%D8%AB%D9%84%D8%AB-%D8%A8%D8%A7%D9%84%D8%AD%D9%84%D9%8A%D8%A9.png/960px-%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7-%D8%A7%D9%84%D8%AB%D9%84%D8%AB-%D8%A8%D8%A7%D9%84%D8%AD%D9%84%D9%8A%D8%A9.png)](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7 "مرحبًا بكم في ويكيبيديا") **مشروع[موسوعة](https://ar.wikipedia.org/wiki/%D9%85%D9%88%D8%B3%D9%88%D8%B9%D8%A9 "موسوعة") [حرة](https://ar.wikipedia.org/wiki/%D9%85%D8%AD%D8%AA%D9%88%D9%89_%D8%AD%D8%B1 "محتوى حر") [يستطيع الجميع تحريرها](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D9%85%D9%82%D8%AF%D9%85%D8%A9 "مساعدة:مقدمة"). توجد الآن [1٬282٬161](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A5%D8%AD%D8%B5%D8%A7%D8%A1%D8%A7%D8%AA "خاص:إحصاءات") مقالة [بالعربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D8%A9_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9 "اللغة العربية").** |  **[محتوى متميز](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D9%85%D8%AD%D8%AA%D9%88%D9%89_%D9%85%D8%AA%D9%85%D9%8A%D8%B2 "بوابة:محتوى متميز") · [التصنيفات](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AA%D8%B5%D9%81%D8%AD "ويكيبيديا:تصفح") · [فهرس أ-ي](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%81%D9%87%D8%B1%D8%B3_%D8%B3%D8%B1%D9%8A%D8%B9 "ويكيبيديا:فهرس سريع")** |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/P_religion_world.svg/40px-P_religion_world.svg.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A7%D9%84%D8%A3%D8%AF%D9%8A%D8%A7%D9%86 "بوابة:الأديان") [أديان](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A7%D9%84%D8%A3%D8%AF%D9%8A%D8%A7%D9%86 "بوابة:الأديان")   
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/P_vip.svg/20px-P_vip.svg.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A3%D8%B9%D9%84%D8%A7%D9%85 "بوابة:أعلام") [أعلام](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A3%D8%B9%D9%84%D8%A7%D9%85 "بوابة:أعلام")   
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/P_history.svg/40px-P_history.svg.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A7%D9%84%D8%AA%D8%A7%D8%B1%D9%8A%D8%AE "بوابة:التاريخ") [تاريخ](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A7%D9%84%D8%AA%D8%A7%D8%B1%D9%8A%D8%AE "بوابة:التاريخ")  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/P_technology.png/40px-P_technology.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%AA%D9%82%D9%86%D9%8A%D8%A9 "بوابة:تقنية") [تقانة](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%AA%D9%82%D8%A7%D9%86%D8%A9 "بوابة:تقانة")   
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/P_literature.svg/40px-P_literature.svg.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%AB%D9%82%D8%A7%D9%81%D8%A9 "بوابة:ثقافة") [ثقافة](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%AB%D9%82%D8%A7%D9%81%D8%A9 "بوابة:ثقافة")   
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/P_globe.svg/40px-P_globe.svg.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%AC%D8%BA%D8%B1%D8%A7%D9%81%D9%8A%D8%A7 "بوابة:جغرافيا") [جغرافيا](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%AC%D8%BA%D8%B1%D8%A7%D9%81%D9%8A%D8%A7 "بوابة:جغرافيا")  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/P_mathematics.svg/40px-P_mathematics.svg.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%B1%D9%8A%D8%A7%D8%B6%D9%8A%D8%A7%D8%AA "بوابة:رياضيات") [رياضيات](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%B1%D9%8A%D8%A7%D8%B6%D9%8A%D8%A7%D8%AA "بوابة:رياضيات")   
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/P_medicine3.png/40px-P_medicine3.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%B7%D8%A8 "بوابة:طب") [طب](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%B7%D8%A8 "بوابة:طب")   
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/P_WWII.png/40px-P_WWII.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%B7%D9%8A%D8%B1%D8%A7%D9%86 "بوابة:طيران") [طيران](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%B7%D9%8A%D8%B1%D8%A7%D9%86 "بوابة:طيران")   
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/P_Science.png/40px-P_Science.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%B9%D9%84%D9%88%D9%85 "بوابة:علوم") [علوم](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%B9%D9%84%D9%88%D9%85 "بوابة:علوم")   
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/P_sport.svg/20px-P_sport.svg.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%B1%D9%8A%D8%A7%D8%B6%D8%A9 "بوابة:رياضة") [رياضة](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%B1%D9%8A%D8%A7%D8%B6%D8%A9 "بوابة:رياضة")  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/P_chemistry.svg/40px-P_chemistry.svg.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D9%83%D9%8A%D9%85%D9%8A%D8%A7%D8%A1 "بوابة:كيمياء") [كيمياء](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A7%D9%84%D9%83%D9%8A%D9%85%D9%8A%D8%A7%D8%A1 "بوابة:الكيمياء")   
  
---|---|---  
[**تصفح كل البوابات**](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%AA%D8%B5%D9%81%D8%AD "بوابة:تصفح")  
|  [![الحساب الرسمي على فيسبوك](https://upload.wikimedia.org/wikipedia/commons/thumb/2/22/Icon_Facebook.svg/20px-Icon_Facebook.svg.png)](https://www.facebook.com/ArabicWikipedia/ "الحساب الرسمي على فيسبوك") [![الحساب الرسمي على تويتر](https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/X_icon_-_Gray.svg/20px-X_icon_-_Gray.svg.png)](https://x.com/ArabicWikipedia/ "الحساب الرسمي على تويتر") [![الحساب الرسمي على إنستغرام](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Instagram_circle.svg/20px-Instagram_circle.svg.png)](https://www.instagram.com/arabicwikipedia/ "الحساب الرسمي على إنستغرام") [![الحساب الرسمي على يوتيوب](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/YouTube_social_dark_circle_%282017%29.svg/20px-YouTube_social_dark_circle_%282017%29.svg.png)](https://www.youtube.com/@ArabicWikipedia "الحساب الرسمي على يوتيوب")  
---  
[عن ويكيبيديا](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B9%D9%86 "ويكيبيديا:عن") **·** [مرحبًا بالزوار الجدد](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AA%D8%B1%D8%AD%D9%8A%D8%A8_%D8%A8%D8%A7%D9%84%D9%82%D8%A7%D8%AF%D9%85%D9%8A%D9%86_%D8%A7%D9%84%D8%AC%D8%AF%D8%AF "ويكيبيديا:ترحيب بالقادمين الجدد") **·** [كيفية تعديل الصفحات](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D9%85%D9%82%D8%AF%D9%85%D8%A9 "مساعدة:مقدمة") **·** [حقوق النشر](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AD%D9%82%D9%88%D9%82_%D8%A7%D9%84%D8%AA%D8%A3%D9%84%D9%8A%D9%81_%D9%88%D8%A7%D9%84%D9%86%D8%B4%D8%B1 "ويكيبيديا:حقوق التأليف والنشر") **·** [أسئلة](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D8%A3%D8%B3%D8%A6%D9%84%D8%A9_\(%D8%AA%D9%88%D8%B6%D9%8A%D8%AD\) "مساعدة:أسئلة \(توضيح\)") **·** [مساعدة](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D9%85%D8%AD%D8%AA%D9%88%D9%8A%D8%A7%D8%AA "مساعدة:محتويات") **·** [يحدث الآن في ويكيبيديا](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A3%D8%AD%D8%AF%D8%AB_%D8%A7%D9%84%D8%AA%D8%BA%D9%8A%D9%8A%D8%B1%D8%A7%D8%AA "خاص:أحدث التغييرات")
الخميس [2 أكتوبر](https://ar.wikipedia.org/wiki/2_%D8%A3%D9%83%D8%AA%D9%88%D8%A8%D8%B1 "2 أكتوبر")/[تشرين الأول](https://ar.wikipedia.org/wiki/%D8%AA%D8%B4%D8%B1%D9%8A%D9%86_%D8%A7%D9%84%D8%A3%D9%88%D9%84 "تشرين الأول") [2025](https://ar.wikipedia.org/wiki/2025 "2025") الموافق [10 ربيع الآخر](https://ar.wikipedia.org/wiki/10_%D8%B1%D8%A8%D9%8A%D8%B9_%D8%A7%D9%84%D8%A2%D8%AE%D8%B1 "10 ربيع الآخر") [1447 هـ](https://ar.wikipedia.org/wiki/1447_%D9%87%D9%80 "1447 هـ")  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/HSutvald3.svg/40px-HSutvald3.svg.png)
مقالة اليوم المختارة
[![طابع بريدي فرنسي يظهر رجال إيزيديين في ماردين، تركيا في أواخر القرن التاسع عشر](https://upload.wikimedia.org/wikipedia/commons/thumb/0/00/Yezidismardino.JPG/250px-Yezidismardino.JPG)](https://ar.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Yezidismardino.JPG "طابع بريدي فرنسي يظهر رجال إيزيديين في ماردين، تركيا في أواخر القرن التاسع عشر")طابع بريدي فرنسي يظهر رجال إيزيديين في ماردين، تركيا في أواخر القرن التاسع عشر
**[الإيزيديون](https://ar.wikipedia.org/wiki/%D9%8A%D8%B2%D9%8A%D8%AF%D9%8A%D8%A9 "يزيدية")** أو **[اليزيديون](https://ar.wikipedia.org/wiki/%D9%8A%D8%B2%D9%8A%D8%AF%D9%8A%D8%A9 "يزيدية")** ([بـالكردية](https://ar.wikipedia.org/wiki/%D9%83%D8%B1%D8%AF%D9%8A%D8%A9_\(%D8%AA%D9%88%D8%B6%D9%8A%D8%AD\) "كردية \(توضيح\)"): Êzidî أو ئێزیدی) هي مجموعة دينية كردية تتمركز في العراق وسوريا. يعيش أغلبهم قرب [الموصل](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%85%D9%88%D8%B5%D9%84 "الموصل") ومنطقة جبال [سنجار](https://ar.wikipedia.org/wiki/%D8%B3%D9%86%D8%AC%D8%A7%D8%B1 "سنجار") في [العراق](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B9%D8%B1%D8%A7%D9%82 "العراق")، وتعيش مجموعات أصغر في [تركيا](https://ar.wikipedia.org/wiki/%D8%AA%D8%B1%D9%83%D9%8A%D8%A7 "تركيا")، [وسوريا](https://ar.wikipedia.org/wiki/%D8%B3%D9%88%D8%B1%D9%8A%D8%A7 "سوريا")، [وألمانيا](https://ar.wikipedia.org/wiki/%D8%A3%D9%84%D9%85%D8%A7%D9%86%D9%8A%D8%A7 "ألمانيا")، [وجورجيا](https://ar.wikipedia.org/wiki/%D8%AC%D9%88%D8%B1%D8%AC%D9%8A%D8%A7 "جورجيا") [وأرمينيا](https://ar.wikipedia.org/wiki/%D8%A3%D8%B1%D9%85%D9%8A%D9%86%D9%8A%D8%A7 "أرمينيا"). ينتمون عرقياً إلى أصلٍ كرديٍ ذي جذور [هندية أوروبية](https://ar.wikipedia.org/wiki/%D9%84%D8%BA%D8%A7%D8%AA_%D9%87%D9%86%D8%AF%D9%8A%D8%A9_%D8%A3%D9%88%D8%B1%D9%88%D8%A8%D9%8A%D8%A9 "لغات هندية أوروبية") مع أنهم متأثرون بمحيطهم الفسيفسائي المتكون من ثقافات عربية وآشورية سريانية. يرى الإيزيديون أن شعبهم ودينهم قد وُجدا منذ وجود [آدم](https://ar.wikipedia.org/wiki/%D8%A2%D8%AF%D9%85 "آدم") [وحواء](https://ar.wikipedia.org/wiki/%D8%AD%D9%88%D8%A7%D8%A1 "حواء") على الأرض ويرى باحثوهم أن ديانتهم قد انبثقت عن الديانة البابلية القديمة في بلاد ما بين النهرين. ويرى بعض الباحثين الإسلاميين وغيرهم أن الديانة الإيزيدية هي ديانة منشقة ومنحرفة عن [الإسلام](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%A5%D8%B3%D9%84%D8%A7%D9%85 "الإسلام"). بينما يرى آخرون أن الديانة هي خليط من عدة ديانات قديمة مثل [الزردشتية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B2%D8%B1%D8%A7%D8%AF%D8%B4%D8%AA%D9%8A%D8%A9 "الزرادشتية") [والمانوية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%85%D8%A7%D9%86%D9%88%D9%8A%D8%A9 "المانوية") أو امتداد للديانة الميثرائية. الديانة الإيزيدية غير تبشيرية حيث لا يستطيع الأشخاص من الديانات الأخرى الانتماء إليها، وبذلك يعدها العديد (من ضمنهم أمير الإيزيدية [تحسين بيك](https://ar.wikipedia.org/wiki/%D8%AA%D8%AD%D8%B3%D9%8A%D9%86_%D8%A8%D9%83_%D8%B3%D8%B9%D9%8A%D8%AF "تحسين بك سعيد")) قوميةً مستقلة وديانةً، في حين يرى الكثير من الإيزيديين أنفسهم كرد القومية كما يصفهم [مسعود بارزاني](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%B9%D9%88%D8%AF_%D8%A8%D8%A7%D8%B1%D8%B2%D8%A7%D9%86%D9%8A "مسعود بارزاني") بأنهم "أعرق الكرد". في حين قسم ثالث من الإيزيديين يرون أنفسهم عرب القومية كإيزيدية [بعشيقة](https://ar.wikipedia.org/wiki/%D8%A8%D8%B9%D8%B4%D9%8A%D9%82%D8%A9 "بعشيقة") وبحزاني. تشير الأبحاث الحديثة أن اسم الإيزيديين مأخوذ من اللفظ الفارسي "إيزيد" الذي يعني الملاك أو المعبود، وأن كلمة الإيزيديين تعني ببساطة "عبدة الله" أو هكذا يصف أتباع هذه الديانة أنفسهم. ويطلق الإيزيديون على أنفسهم لقب "داسين"، وهي كلمة مأخوذة من اسم أبرشية تتبع [الكنيسة المسيحية الشرقية القديمة](https://ar.wikipedia.org/wiki/%D9%83%D9%86%D9%8A%D8%B3%D8%A9_%D8%A7%D9%84%D9%85%D8%B4%D8%B1%D9%82 "كنيسة المشرق"). وتذهب أبحاث تاريخية أخرى إلى القول إن معتقدات هذه الطائفة منحدرة من ديانات فارسية قديمة مثل [الزردشتية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B2%D8%B1%D8%A7%D8%AF%D8%B4%D8%AA%D9%8A%D8%A9 "الزرادشتية") [والمانوية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%85%D8%A7%D9%86%D9%88%D9%8A%D8%A9 "المانوية"). ويزعم بعض الباحثين أن اسم الإيزيديّين جاء من اسم الخليفة الأموي الثاني [يزيد بن معاوية](https://ar.wikipedia.org/wiki/%D9%8A%D8%B2%D9%8A%D8%AF_%D8%A8%D9%86_%D9%85%D8%B9%D8%A7%D9%88%D9%8A%D8%A9 "يزيد بن معاوية"). ومن الأسباب التي أدت إلى هذا الزعم القول بأن يزيد يعتبره الإيزيديون تجسيداً لروح الشخصية المقدسة "سلطان إيزي". ويشير علماء آخرون إلى أن كلمة "إيزيدية" مشتقة من "يزاتا" الفارسية القديمة بمعنى "المقدس" أو "يزدان" (الله). ويشير البعض إلى أن سبب تسمية الإيزيديين بعبدة الشيطان أساسها رفضهم الجمع بين حرفي الشين والطاء، وتشاؤمهم من أي لعن، بما فيه لعن [إبليس](https://ar.wikipedia.org/wiki/%D8%A5%D8%A8%D9%84%D9%8A%D8%B3 "إبليس") لأنه لم يسجد [لآدم](https://ar.wikipedia.org/wiki/%D8%A2%D8%AF%D9%85 "آدم") فإنه بذلك ـ في نظرهم ـ يعتبر الموحد الأول الذي لم ينس وصية الرب بعدم السجود لغيره في حين نسيها الملائكة فسجدوا، وإن أمر السجود لآدم كان مجرد اختبار، وقد نجح إبليس في هذا الاختبار فهو بذلك أول الموحدين. 
[تابع القراءة](https://ar.wikipedia.org/wiki/%D9%8A%D8%B2%D9%8A%D8%AF%D9%8A%D8%A9 "يزيدية")
**مقالات مختارة أخرى:** [جمال عبد الناصر](https://ar.wikipedia.org/wiki/%D8%AC%D9%85%D8%A7%D9%84_%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D9%86%D8%A7%D8%B5%D8%B1 "جمال عبد الناصر") – [اعتداء توتنهام](https://ar.wikipedia.org/wiki/%D8%A7%D8%B9%D8%AA%D8%AF%D8%A7%D8%A1_%D8%AA%D9%88%D8%AA%D9%86%D9%87%D8%A7%D9%85 "اعتداء توتنهام") – [أحمد فضل القمندان](https://ar.wikipedia.org/wiki/%D8%A3%D8%AD%D9%85%D8%AF_%D9%81%D8%B6%D9%84_%D8%A7%D9%84%D9%82%D9%85%D9%86%D8%AF%D8%A7%D9%86 "أحمد فضل القمندان")  
[ما هي المقالات المختارة؟](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%85%D9%82%D8%A7%D9%84%D8%A7%D8%AA_%D9%85%D8%AE%D8%AA%D8%A7%D8%B1%D8%A9 "ويكيبيديا:مقالات مختارة") – [بوابة أديان](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A3%D8%AF%D9%8A%D8%A7%D9%86 "بوابة:أديان") – [بوابة الهلال الخصيب](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A7%D9%84%D9%87%D9%84%D8%A7%D9%84_%D8%A7%D9%84%D8%AE%D8%B5%D9%8A%D8%A8 "بوابة:الهلال الخصيب")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/HSUtvaldgrey.png/40px-HSUtvaldgrey.png)
مقالة اليوم الجيدة
**[ثلاثة بلهاء](https://ar.wikipedia.org/wiki/3_%D8%A8%D9%84%D9%87%D8%A7%D8%A1 "3 بلهاء")** ([بالهندية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D8%A9_%D8%A7%D9%84%D9%87%D9%86%D8%AF%D9%8A%D8%A9 "اللغة الهندية"): ३ इडियट्स) [فيلم](https://ar.wikipedia.org/wiki/%D9%81%D9%8A%D9%84%D9%85 "فيلم") [دراما](https://ar.wikipedia.org/wiki/%D8%AF%D8%B1%D8%A7%D9%85%D8%A7 "دراما") [كوميدي](https://ar.wikipedia.org/wiki/%D9%83%D9%88%D9%85%D9%8A%D8%AF%D9%8A%D8%A7 "كوميديا") شبابي [هندي](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%87%D9%86%D8%AF "الهند"). أُنتج في [الهند](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%87%D9%86%D8%AF "الهند") وصدر سنة [2009](https://ar.wikipedia.org/wiki/2009 "2009"). الفيلم من إخراج [راجكومار هيراني](https://ar.wikipedia.org/wiki/%D8%B1%D8%A7%D8%AC%D9%83%D9%88%D9%85%D8%A7%D8%B1_%D9%87%D9%8A%D8%B1%D8%A7%D9%86%D9%8A "راجكومار هيراني")، وإنتاج [فيدو فينود تشوبرا](https://ar.wikipedia.org/wiki/%D9%81%D9%8A%D8%AF%D9%88_%D9%81%D9%8A%D9%86%D9%88%D8%AF_%D8%AA%D8%B4%D9%88%D8%A8%D8%B1%D8%A7 "فيدو فينود تشوبرا")، وكتب السناريو [ابهيجات جوشي](https://ar.wikipedia.org/wiki/%D8%A7%D8%A8%D9%87%D9%8A%D8%AC%D8%A7%D8%AA_%D8%AC%D9%88%D8%B4%D9%8A "ابهيجات جوشي") بمساعدة المخرج. أُستوحيَ الفيلم وأُقتُبِسَ بتساهل من رواية [خمسة نقاط لشخص ما](https://ar.wikipedia.org/wiki/%D8%AE%D9%85%D8%B3%D8%A9_%D9%86%D9%82%D8%A7%D8%B7_%D9%84%D8%B4%D8%AE%D8%B5_%D9%85%D8%A7 "خمسة نقاط لشخص ما") للمؤلف [تشيتان بهجت](https://ar.wikipedia.org/wiki/%D8%AA%D8%B4%D9%8A%D8%AA%D8%A7%D9%86_%D8%A8%D9%87%D8%AC%D8%AA "تشيتان بهجت"). والفيلم من بطولة [عامر خان](https://ar.wikipedia.org/wiki/%D8%B9%D8%A7%D9%85%D8%B1_%D8%AE%D8%A7%D9%86 "عامر خان")، [وكارينا كابور](https://ar.wikipedia.org/wiki/%D9%83%D8%A7%D8%B1%D9%8A%D9%86%D8%A7_%D9%83%D8%A7%D8%A8%D9%88%D8%B1 "كارينا كابور")، [وبومان إيراني](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D9%85%D8%A7%D9%86_%D8%A5%D9%8A%D8%B1%D8%A7%D9%86%D9%8A "بومان إيراني")، [وشرمان جوشي](https://ar.wikipedia.org/wiki/%D8%B4%D8%B1%D9%85%D8%A7%D9%86_%D8%AC%D9%88%D8%B4%D9%8A "شرمان جوشي")، [ومادهافان](https://ar.wikipedia.org/wiki/%D9%85%D8%A7%D8%AF%D9%87%D8%A7%D9%81%D8%A7%D9%86 "مادهافان"). ينتقد الفيلم أوضاع التعليم [الجامعيّ](https://ar.wikipedia.org/wiki/%D8%AC%D8%A7%D9%85%D8%B9%D8%A9 "جامعة") في الهند والوسائل التقليدية المتبعة به في إطار رومنسي كوميدي يجذب المشاهد، ويعتبر من أنجح أفلام السينما الهندية للممثل [عامر خان](https://ar.wikipedia.org/wiki/%D8%B9%D8%A7%D9%85%D8%B1_%D8%AE%D8%A7%D9%86 "عامر خان"). عند إصداره، كَسَرَ الفيلم كل الأرقام القياسية لشباك التذاكر الهندي. فقد حصّلَ أعلى أرباح افتتاح فيلم بنهاية الأسبوع، وأعلى مجموع لأرباح فيلم يوم الافتتاح في [بوليود](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D9%84%D9%8A%D9%88%D9%88%D8%AF "بوليوود"). وحافظ أيضاً على أعلى مجموع أرباح لفيلم طيلة أسبوعه الأول في بوليود. وليس هذا فحسب فقد أصبح الفيلم واحد من أعلى الأفلام الهندية نجاحاً في شرق آسيا مثل الصين. وواحد من الأفلام المدرجة في قائمة الأفلام الأكثر إقبالاً في تاريخ السينما الهندية. والفيلم أُدرِجَ في [موسوعة غينيس للأرقام القياسية](https://ar.wikipedia.org/wiki/%D9%85%D9%88%D8%B3%D9%88%D8%B9%D8%A9_%D8%BA%D9%8A%D9%86%D9%8A%D8%B3_%D9%84%D9%84%D8%A3%D8%B1%D9%82%D8%A7%D9%85_%D8%A7%D9%84%D9%82%D9%8A%D8%A7%D8%B3%D9%8A%D8%A9 "موسوعة غينيس للأرقام القياسية") لتسجيله أعلى إجمالي لفيلم بشباك التذاكر في [بوليوود](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D9%84%D9%8A%D9%88%D9%88%D8%AF "بوليوود"). حتى تم تحطيم رقمه من فيلم [دووم 3](https://ar.wikipedia.org/wiki/%D8%AF%D9%88%D9%88%D9%85_3 "دووم 3") عام 2013. الفيلم فاز بالكثير من الجوائز بأكثر من 40 جائزة مثل [جوائز فيلم فير](https://ar.wikipedia.org/wiki/%D8%AC%D9%88%D8%A7%D8%A6%D8%B2_%D9%81%D9%8A%D9%84%D9%85_%D9%81%D9%8A%D8%B1 "جوائز فيلم فير")، [وستارداست](https://ar.wikipedia.org/wiki/%D8%AC%D9%88%D8%A7%D8%A6%D8%B2_%D8%B3%D8%AA%D8%A7%D8%B1%D8%AF%D8%A7%D8%B3%D8%AA "جوائز ستارداست")، [ونجم الشاشة الهندية](https://ar.wikipedia.org/wiki/%D8%AC%D9%88%D8%A7%D8%A6%D8%B2_%D8%A7%D9%84%D8%B4%D8%A7%D8%B4%D8%A9 "جوائز الشاشة")، [والفيلم الوطني](https://ar.wikipedia.org/wiki/%D8%AC%D9%88%D8%A7%D8%A6%D8%B2_%D8%A7%D9%84%D8%B3%D9%8A%D9%86%D9%85%D8%A7_%D8%A7%D9%84%D9%88%D8%B7%D9%86%D9%8A%D8%A9 "جوائز السينما الوطنية")، و [نجم النقابة](https://ar.wikipedia.org/wiki/%D8%AC%D9%88%D8%A7%D8%A6%D8%B2_%D9%86%D8%AC%D9%85_%D8%A7%D9%84%D9%86%D9%82%D8%A7%D8%A8%D8%A9 "جوائز نجم النقابة")، [والأكاديمية الدولية للفيلم الهندي](https://ar.wikipedia.org/wiki/%D8%AC%D9%88%D8%A7%D8%A6%D8%B2_%D8%A7%D9%84%D8%A3%D9%83%D8%A7%D8%AF%D9%8A%D9%85%D9%8A%D8%A9_%D8%A7%D9%84%D8%AF%D9%88%D9%84%D9%8A%D8%A9_%D9%84%D9%84%D9%81%D9%8A%D9%84%D9%85_%D8%A7%D9%84%D9%87%D9%86%D8%AF%D9%8A "جوائز الأكاديمية الدولية للفيلم الهندي") وغيرها. وتم تقييم الفيلم على [قاعدة بيانات الأفلام على الإنترنت](https://ar.wikipedia.org/wiki/%D9%82%D8%A7%D8%B9%D8%AF%D8%A9_%D8%A8%D9%8A%D8%A7%D9%86%D8%A7%D8%AA_%D8%A7%D9%84%D8%A3%D9%81%D9%84%D8%A7%D9%85_%D8%B9%D9%84%D9%89_%D8%A7%D9%84%D8%A5%D9%86%D8%AA%D8%B1%D9%86%D8%AA "قاعدة بيانات الأفلام على الإنترنت") وأدرِجَ بقائمة أفضل 250 فيلم بالعالم وحصّلَ المرتبة 116، وتقييم 8.5. تم إعادة صنع الفيلم لاحقاً في [2012](https://ar.wikipedia.org/wiki/2012 "2012")، ودُبلجَ بلغات من [شرق آسيا](https://ar.wikipedia.org/wiki/%D8%B4%D8%B1%D9%82_%D8%A2%D8%B3%D9%8A%D8%A7 "شرق آسيا") مثل [اليابانية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D8%A9_%D8%A7%D9%84%D9%8A%D8%A7%D8%A8%D8%A7%D9%86%D9%8A%D8%A9 "اللغة اليابانية"). 
[تابع القراءة](https://ar.wikipedia.org/wiki/%D8%AB%D9%84%D8%A7%D8%AB%D8%A9_%D8%A8%D9%84%D9%87%D8%A7%D8%A1_\(%D9%81%D9%8A%D9%84%D9%85\) "ثلاثة بلهاء \(فيلم\)")
**مقالات جيدة أخرى:** [روبرت هوك](https://ar.wikipedia.org/wiki/%D8%B1%D9%88%D8%A8%D8%B1%D8%AA_%D9%87%D9%88%D9%83 "روبرت هوك") – [البوم الأمريكي اللاتيني (أدب)](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%A8%D9%88%D9%85_%D8%A7%D9%84%D8%A3%D9%85%D8%B1%D9%8A%D9%83%D9%8A_%D8%A7%D9%84%D9%84%D8%A7%D8%AA%D9%8A%D9%86%D9%8A_\(%D8%A3%D8%AF%D8%A8\) "البوم الأمريكي اللاتيني \(أدب\)") – [أبو هريرة](https://ar.wikipedia.org/wiki/%D8%A3%D8%A8%D9%88_%D9%87%D8%B1%D9%8A%D8%B1%D8%A9 "أبو هريرة")  
[ما هي المقالات الجيدة؟](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%85%D9%82%D8%A7%D9%84%D8%A7%D8%AA_%D8%AC%D9%8A%D8%AF%D8%A9 "ويكيبيديا:مقالات جيدة") – [بوابة بوليوود](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A8%D9%88%D9%84%D9%8A%D9%88%D9%88%D8%AF "بوابة:بوليوود") – [بوابة الهند](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A7%D9%84%D9%87%D9%86%D8%AF "بوابة:الهند")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/HS_Liste.svg/40px-HS_Liste.svg.png)
قائمة اليوم المختارة
[![مدرج الجم الروماني، أحد مواقع التراث العالمي في تونس.](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Colis%C3%A9e_d%27El_Djem_vue_panoramique.jpg/250px-Colis%C3%A9e_d%27El_Djem_vue_panoramique.jpg)](https://ar.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Colis%C3%A9e_d%27El_Djem_vue_panoramique.jpg "مدرج الجم الروماني، أحد مواقع التراث العالمي في تونس.")مدرج الجم الروماني، أحد مواقع التراث العالمي في تونس.
**[قائمة مواقع التراث العالمي في تونس](https://ar.wikipedia.org/wiki/%D9%82%D8%A7%D8%A6%D9%85%D8%A9_%D9%85%D9%88%D8%A7%D9%82%D8%B9_%D8%A7%D9%84%D8%AA%D8%B1%D8%A7%D8%AB_%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85%D9%8A_%D9%81%D9%8A_%D8%AA%D9%88%D9%86%D8%B3 "قائمة مواقع التراث العالمي في تونس")** هي قائمةٌ بمواقع التراث العالمي الطبيعية، أو الثقافية أو المختلطة (طبيعيّةٌ وثقافيّةٌ بنفس الوقت)، التي تقوم [لجنة التراث العالمي](https://ar.wikipedia.org/wiki/%D9%84%D8%AC%D9%86%D8%A9_%D8%A7%D9%84%D8%AA%D8%B1%D8%A7%D8%AB_%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85%D9%8A "لجنة التراث العالمي") التابعة لمنظمة [اليونسكو](https://ar.wikipedia.org/wiki/%D9%8A%D9%88%D9%86%D8%B3%D9%83%D9%88 "يونسكو") بترشيحها ليتم إدراجها ضمن برنامج مواقع التراث العالمي الذي تديره اليونسكو. وتشمل [المواقع الطبيعية](https://ar.wikipedia.org/wiki/%D8%AA%D8%B1%D8%A7%D8%AB_%D8%B7%D8%A8%D9%8A%D8%B9%D9%8A "تراث طبيعي") معالم مميزة من صنع ونحت الطبيعة كالجبال، الغابات، السهوب، البراكين والجزر إلخ. أما [المواقع الثقافيّة](https://ar.wikipedia.org/wiki/%D8%AA%D8%B1%D8%A7%D8%AB_%D8%AB%D9%82%D8%A7%D9%81%D9%8A "تراث ثقافي") فهي معالمٌ من صنع الإنسان كالمدن والقلاع والمساجد والكنائس وغيرها، وفي بعض الحالات تكون المواقعُ مختلطةً أي تجمع بين الطبيعي والثقافي في نفس الموقع (مثل موقع طبيعي مُميّز ومشيّد فيه مبانٍ ذات قيمة تاريخية). وقد تمكنت [تونس](https://ar.wikipedia.org/wiki/%D8%AA%D9%88%D9%86%D8%B3 "تونس") من تسجيل 8 مواقع في [لائحة التراث العالمي](https://ar.wikipedia.org/wiki/%D9%85%D9%88%D9%82%D8%B9_%D8%AA%D8%B1%D8%A7%D8%AB_%D8%B9%D8%A7%D9%84%D9%85%D9%8A "موقع تراث عالمي")، معظمها في عهد الرئيس السابق [المنصف المرزوقي](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%85%D9%86%D8%B5%D9%81_%D8%A7%D9%84%D9%85%D8%B1%D8%B2%D9%88%D9%82%D9%8A "المنصف المرزوقي") التي عرفت إعدادًا محكمًا لملفات ترشيحها ليتم المصادقة عليها، ومعظمها في المدن القديمة والعتيقة. وقد صُنّف أغلبها ضمن القسم الثقافي، بينما سجّلت موقعًا ضمن الصنف الطبيعي. وفي "[القائمة الارشادية المؤقتة لمواقع التراث العالمي](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%82%D8%A7%D8%A6%D9%85%D8%A9_%D8%A7%D9%84%D8%A5%D8%B1%D8%B4%D8%A7%D8%AF%D9%8A%D8%A9_%D8%A7%D9%84%D9%85%D8%A4%D9%82%D8%AA%D8%A9_%D9%84%D9%85%D9%88%D8%A7%D9%82%D8%B9_%D8%A7%D9%84%D8%AA%D8%B1%D8%A7%D8%AB_%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85%D9%8A "القائمة الإرشادية المؤقتة لمواقع التراث العالمي")" تسجل تونس 10 مواقع، سبعةٌ منها ثقافيّة وثلاثةٌ طبيعيّة، وواحد منا موقعٌ مختلط (ثقافي/طبيعي). 
[تابع القراءة](https://ar.wikipedia.org/wiki/%D9%82%D8%A7%D8%A6%D9%85%D8%A9_%D9%85%D9%88%D8%A7%D9%82%D8%B9_%D8%A7%D9%84%D8%AA%D8%B1%D8%A7%D8%AB_%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85%D9%8A_%D9%81%D9%8A_%D8%AA%D9%88%D9%86%D8%B3 "قائمة مواقع التراث العالمي في تونس")
[ما هي القوائم المختارة؟](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%82%D9%88%D8%A7%D8%A6%D9%85_%D9%85%D8%AE%D8%AA%D8%A7%D8%B1%D8%A9 "ويكيبيديا:قوائم مختارة") **·** [اقرأ قائمةً أُخرى](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%B9%D8%B4%D9%88%D8%A7%D8%A6%D9%8A_%D9%81%D9%8A_%D8%AA%D8%B5%D9%86%D9%8A%D9%81/%D9%82%D9%88%D8%A7%D8%A6%D9%85_%D9%85%D8%AE%D8%AA%D8%A7%D8%B1%D8%A9 "خاص:عشوائي في تصنيف/قوائم مختارة")
  

![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/HSBild.svg/40px-HSBild.svg.png)
صورة اليوم المختارة
[![منظرٌ أمامي لبق ورقي القدم](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Lederwanze-JR-T3-I267-2024-08-01.jpg/500px-Lederwanze-JR-T3-I267-2024-08-01.jpg)](https://ar.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Lederwanze-JR-T3-I267-2024-08-01.jpg "منظرٌ أمامي لبق ورقي القدم")منظرٌ أمامي [لبق ورقي القدم](https://ar.wikipedia.org/wiki/%D8%A8%D9%82_%D9%88%D8%B1%D9%82%D9%8A_%D8%A7%D9%84%D9%82%D8%AF%D9%85 "بق ورقي القدم")
منظرٌ أمامي [لبق ورقي القدم](https://ar.wikipedia.org/wiki/%D8%A8%D9%82_%D9%88%D8%B1%D9%82%D9%8A_%D8%A7%D9%84%D9%82%D8%AF%D9%85 "بق ورقي القدم")
[معرض الصور المختارة](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B5%D9%88%D8%B1_%D9%85%D8%AE%D8%AA%D8%A7%D8%B1%D8%A9 "ويكيبيديا:صور مختارة") **·** [رشح صورك لتكون مختارة](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AA%D8%B1%D8%B4%D9%8A%D8%AD%D8%A7%D8%AA_%D8%A7%D9%84%D8%B5%D9%88%D8%B1_%D8%A7%D9%84%D9%85%D8%AE%D8%AA%D8%A7%D8%B1%D8%A9 "ويكيبيديا:ترشيحات الصور المختارة")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/HSHome.svg/40px-HSHome.svg.png)
بوابة اليوم المختارة
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Flag-map_of_Iraq.svg/120px-Flag-map_of_Iraq.svg.png)](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A7%D9%84%D8%B9%D8%B1%D8%A7%D9%82 "بوابة:العراق")  
---  
[بوّابة جمهوريّة العراق](https://ar.wikipedia.org/wiki/%D8%A8%D9%88%D8%A7%D8%A8%D8%A9:%D8%A7%D9%84%D8%B9%D8%B1%D8%A7%D9%82 "بوابة:العراق")  
[ما هي البوابات المختارة؟](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A8%D9%88%D8%A7%D8%A8%D8%A7%D8%AA_%D9%85%D8%AE%D8%AA%D8%A7%D8%B1%D8%A9 "ويكيبيديا:بوابات مختارة") **·** [اطلع على بوابة أخرى](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%B9%D8%B4%D9%88%D8%A7%D8%A6%D9%8A_%D9%81%D9%8A_%D8%AA%D8%B5%D9%86%D9%8A%D9%81/%D8%A8%D9%88%D8%A7%D8%A8%D8%A7%D8%AA_%D9%85%D8%AE%D8%AA%D8%A7%D8%B1%D8%A9 "خاص:عشوائي في تصنيف/بوابات مختارة")
  

![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/HSWPedia.svg/40px-HSWPedia.svg.png)
ما هي ويكيبيديا؟
**[ويكيبيديا](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B9%D9%86 "ويكيبيديا:عن")** مشروع تعاوني متعدد اللغات يضم [ويكيات](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A "ويكي") بأكثر من 300 لغة للعمل في مشاريع [موسوعات](https://ar.wikipedia.org/wiki/%D9%85%D9%88%D8%B3%D9%88%D8%B9%D8%A9 "موسوعة") حرة ودقيقة ومتكاملة ومتنوعة ومحايدة، يستطيع الجميع المساهمة في تحريرها. نشأت ويكيبيديا في عام 2001، حيث نمت وتطورت بسرعة لتصبح واحدة من أكبر المواقع على الإنترنت. بدأت [النسخة العربية](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9 "ويكيبيديا العربية") في [يوليو/تموز 2003](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AA%D8%A7%D8%B1%D9%8A%D8%AE_%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9 "ويكيبيديا:تاريخ ويكيبيديا العربية").  
لدى ويكيبيديا بعض [السياسات والإرشادات](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B3%D9%8A%D8%A7%D8%B3%D8%A7%D8%AA_%D9%88%D8%A5%D8%B1%D8%B4%D8%A7%D8%AF%D8%A7%D8%AA "ويكيبيديا:سياسات وإرشادات") التي تساعد متطوعيها على العمل فيها، بعض هذه السياسات لا تزال في طور التشكل، بينما استقرت سياسات أخرى منذ زمن، ومع أن سياسات ويكيبيديا مستمرة في النمو، إلا أن بعض [الويكيبيديين](https://ar.wikipedia.org/wiki/%D9%85%D8%AC%D8%AA%D9%85%D8%B9_%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7 "مجتمع ويكيبيديا") يشعرون أن كتابة القواعد أمر لا يمكن له أن يغطي كل تنويعة على السلوك المثير أو الهادف لضرر. هؤلاء الذين يحررون [بنية حسنة](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D9%81%D8%AA%D8%B1%D8%B6_%D8%AD%D8%B3%D9%86_%D8%A7%D9%84%D9%86%D9%8A%D8%A9 "ويكيبيديا:افترض حسن النية") ويظهرون [سلوكًا مدنيًّا](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A3%D8%AF%D8%A8 "ويكيبيديا:أدب") ويسعون وراء [التوافق](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AA%D9%88%D8%A7%D9%81%D9%82 "ويكيبيديا:توافق") ويعملون لتحقيق هدفهم بالمشاركة في مشروع [موسوعي محايد](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%88%D8%AC%D9%87%D8%A9_%D8%A7%D9%84%D9%86%D8%B8%D8%B1_%D8%A7%D9%84%D9%85%D8%AD%D8%A7%D9%8A%D8%AF%D8%A9 "ويكيبيديا:وجهة النظر المحايدة")، سيجدون أنفسهم في [بيئة مرحبة](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A3%D8%AF%D8%A8 "ويكيبيديا:أدب").  
يمكنك دائمًا المساعدة في بناء ويكيبيديا وتحسينها بالتعاون مع [المجتمع](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A8%D9%88%D8%A7%D8%A8%D8%A9_%D8%A7%D9%84%D9%85%D8%AC%D8%AA%D9%85%D8%B9 "ويكيبيديا:بوابة المجتمع") عن طريق [التحرير](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D8%AA%D8%AD%D8%B1%D9%8A%D8%B1_%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A7%D8%AA "مساعدة:تحرير الصفحات") [وإنشاء مقالات جديدة](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D9%85%D9%82%D8%A7%D9%84%D8%AA%D9%83_%D8%A7%D9%84%D8%A3%D9%88%D9%84%D9%89 "مساعدة:مقالتك الأولى"). انظر [قسم المساعدة](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D9%85%D8%AD%D8%AA%D9%88%D9%8A%D8%A7%D8%AA "مساعدة:محتويات") للحصول على نصائح، أو توجه إلى [الميدان](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D9%84%D9%85%D9%8A%D8%AF%D8%A7%D9%86 "ويكيبيديا:الميدان") لطرح الاستفسارات العامة حول أساليب التحرير وسياسات ويكيبيديا والقضايا التقنية أو اللغوية. 
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/HSAktuell.svg/40px-HSAktuell.svg.png)
في الأخبار
[![جين جودل](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Jane_Goodall_2010_%28cropped%29.jpg/120px-Jane_Goodall_2010_%28cropped%29.jpg)](https://ar.wikipedia.org/wiki/%D8%AC%D9%8A%D9%86_%D8%AC%D9%88%D8%AF%D9%84 "جين جودل")
  * 1 أكتوبر وفاة [عالمة الرئيسيات](https://ar.wikipedia.org/wiki/%D8%B9%D9%84%D9%85_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A7%D8%AA "علم الرئيسيات") [والسلوك الحيواني](https://ar.wikipedia.org/wiki/%D8%B9%D9%84%D9%85_%D8%A7%D9%84%D8%B3%D9%84%D9%88%D9%83_%D8%A7%D9%84%D8%AD%D9%8A%D9%88%D8%A7%D9%86%D9%8A "علم السلوك الحيواني") الشهيرة **[جين جودل](https://ar.wikipedia.org/wiki/%D8%AC%D9%8A%D9%86_%D8%AC%D9%88%D8%AF%D9%84 "جين جودل")** (في الصورة) عن إحدى وتسعين سنة.
  * 30 سبتمبر مقتل ما لا يقل عن 69 شخصًا وإصابة أكثر من 290 آخرين إثر وقوع [**زلزال شديد**](https://ar.wikipedia.org/wiki/%D8%B2%D9%84%D8%B2%D8%A7%D9%84_%D8%B3%D9%8A%D8%A8%D9%88_2025 "زلزال سيبو 2025") ضرب منطقة [سيبو](https://ar.wikipedia.org/wiki/%D8%B3%D9%8A%D8%A8%D9%88 "سيبو") في [الفلبين](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%81%D9%84%D8%A8%D9%8A%D9%86 "الفلبين").
  * 27 سبتمبر مقتل 41 شخصًا وإصابة ما يزيد عن 80 شخصًا في [**حادثة تدافع**](https://ar.wikipedia.org/wiki/%D8%AD%D8%A7%D8%AF%D8%AB%D8%A9_%D8%AA%D8%AF%D8%A7%D9%81%D8%B9_%D9%83%D8%A7%D8%B1%D9%88%D8%B1_2025 "حادثة تدافع كارور 2025") وقعت في كارور بولاية [تاميل نادو](https://ar.wikipedia.org/wiki/%D8%AA%D9%85%D9%84%D9%86%D8%A7%D8%AF%D8%A9 "تملنادة") في [الهند](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%87%D9%86%D8%AF "الهند").
  * 25 سبتمبر إعلان فوز **[بيتر موثاريكا](https://ar.wikipedia.org/wiki/%D8%A8%D9%8A%D8%AA%D8%B1_%D9%85%D9%88%D8%AB%D8%A7%D8%B1%D9%8A%D9%83%D8%A7 "بيتر موثاريكا")** في [**الانتخابات العامة**](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%A7%D9%86%D8%AA%D8%AE%D8%A7%D8%A8%D8%A7%D8%AA_%D8%A7%D9%84%D8%B9%D8%A7%D9%85%D8%A9_%D9%81%D9%8A_%D9%85%D8%A7%D9%84%D8%A7%D9%88%D9%8A_2025 "الانتخابات العامة في مالاوي 2025") في [مالاوي](https://ar.wikipedia.org/wiki/%D9%85%D8%A7%D9%84%D8%A7%D9%88%D9%8A "مالاوي") بنسبة 57% من المصوتين، وبلغت نسبة التصويت 76.39%.
  * 18 سبتمبر **[مقتل جنديين إسرائيليين](https://ar.wikipedia.org/wiki/%D8%B9%D9%85%D9%84%D9%8A%D8%A9_%D8%A5%D8%B7%D9%84%D8%A7%D9%82_%D8%A7%D9%84%D9%86%D8%A7%D8%B1_%D9%81%D9%8A_%D9%85%D8%B9%D8%A8%D8%B1_%D8%A7%D9%84%D9%83%D8%B1%D8%A7%D9%85%D8%A9_2025 "عملية إطلاق النار في معبر الكرامة 2025")** بيد [جندي أردني متقاعد](https://ar.wikipedia.org/wiki/%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D9%85%D8%B7%D9%84%D8%A8_%D8%A7%D9%84%D9%82%D9%8A%D8%B3%D9%8A "عبد المطلب القيسي") كان يحمل مساعداتٍ إلى [قطاع غزة](https://ar.wikipedia.org/wiki/%D9%82%D8%B7%D8%A7%D8%B9_%D8%BA%D8%B2%D8%A9 "قطاع غزة")، عند [معبر جسر الكرامة](https://ar.wikipedia.org/wiki/%D8%AC%D8%B3%D8%B1_%D8%A7%D9%84%D9%85%D9%84%D9%83_%D8%AD%D8%B3%D9%8A%D9%86 "جسر الملك حسين").
  * 17 سبتمبر [السعودية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B3%D8%B9%D9%88%D8%AF%D9%8A%D8%A9 "السعودية") [وباكستان](https://ar.wikipedia.org/wiki/%D8%A8%D8%A7%D9%83%D8%B3%D8%AA%D8%A7%D9%86 "باكستان") تُبرما **[اتفاقيةً للدفاع الاستراتيجي المشترك](https://ar.wikipedia.org/wiki/%D8%A7%D8%AA%D9%81%D8%A7%D9%82%D9%8A%D8%A9_%D8%A7%D9%84%D8%AF%D9%81%D8%A7%D8%B9_%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D8%B1%D8%A7%D8%AA%D9%8A%D8%AC%D9%8A_%D8%A7%D9%84%D9%85%D8%B4%D8%AA%D8%B1%D9%83 "اتفاقية الدفاع الاستراتيجي المشترك")** تلتزمان بموجبها [بمعاملة أي عدوانٍ على إحداهما عدوانًا على كلتيهما](https://ar.wikipedia.org/wiki/%D8%A3%D9%85%D9%86_%D9%85%D8%B4%D8%AA%D8%B1%D9%83 "أمن مشترك").
  * 11 سبتمبر [**الحكم**](https://ar.wikipedia.org/wiki/%D9%82%D8%B6%D9%8A%D8%A9_AP_2668 "قضية AP 2668") بسجن الرئيس البرازيلي السابق [جايير بولسونارو](https://ar.wikipedia.org/wiki/%D8%AC%D8%A7%D9%8A%D9%8A%D8%B1_%D8%A8%D9%88%D9%84%D8%B3%D9%88%D9%86%D8%A7%D8%B1%D9%88 "جايير بولسونارو") لمدة 27 عامًا بتهمة التورط في [**مؤامرة انقلابية**](https://ar.wikipedia.org/wiki/%D9%85%D8%AD%D8%A7%D9%88%D9%84%D8%A9_%D8%A7%D9%86%D9%82%D9%84%D8%A7%D8%A8_%D8%A7%D9%84%D8%A8%D8%B1%D8%A7%D8%B2%D9%8A%D9%84_2022 "محاولة انقلاب البرازيل 2022") على الرئيس [لولا دا سيلفا](https://ar.wikipedia.org/wiki/%D9%84%D9%88%D9%8A%D8%B3_%D8%A5%D9%8A%D9%86%D8%A7%D8%B3%D9%8A%D9%88_%D9%84%D9%88%D9%84%D8%A7_%D8%AF%D8%A7_%D8%B3%D9%8A%D9%84%D9%81%D8%A7 "لويس إيناسيو لولا دا سيلفا").


* * *
  * **[أحداث جارية](https://ar.wikipedia.org/wiki/%D8%AA%D8%B5%D9%86%D9%8A%D9%81:%D8%A3%D8%AD%D8%AF%D8%A7%D8%AB_%D8%AC%D8%A7%D8%B1%D9%8A%D8%A9 "تصنيف:أحداث جارية")** : [الحرب الفلسطينية الإسرائيلية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%AD%D8%B1%D8%A8_%D8%A7%D9%84%D9%81%D9%84%D8%B3%D8%B7%D9%8A%D9%86%D9%8A%D8%A9_%D8%A7%D9%84%D8%A5%D8%B3%D8%B1%D8%A7%D8%A6%D9%8A%D9%84%D9%8A%D8%A9_\(2023_%E2%80%93_%D8%A7%D9%84%D8%A2%D9%86\) "الحرب الفلسطينية الإسرائيلية \(2023 – الآن\)") **·** [الغزو الإسرائيلي لسوريا](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%BA%D8%B2%D9%88_%D8%A7%D9%84%D8%A5%D8%B3%D8%B1%D8%A7%D8%A6%D9%8A%D9%84%D9%8A_%D9%84%D8%B3%D9%88%D8%B1%D9%8A%D8%A7_\(2024_%E2%80%93_%D8%A7%D9%84%D8%A2%D9%86\) "الغزو الإسرائيلي لسوريا \(2024 – الآن\)") **·** [الغزو الروسي لأوكرانيا](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%BA%D8%B2%D9%88_%D8%A7%D9%84%D8%B1%D9%88%D8%B3%D9%8A_%D9%84%D8%A3%D9%88%D9%83%D8%B1%D8%A7%D9%86%D9%8A%D8%A7 "الغزو الروسي لأوكرانيا") **·** [اشتباكات السودان](https://ar.wikipedia.org/wiki/%D8%AD%D8%B1%D8%A8_%D8%A7%D9%84%D8%B3%D9%88%D8%AF%D8%A7%D9%86_\(2023%E2%80%93%D8%A7%D9%84%D8%A2%D9%86\) "حرب السودان \(2023–الآن\)") **·** [أزمة البحر الأحمر](https://ar.wikipedia.org/wiki/%D8%A3%D8%B2%D9%85%D8%A9_%D8%A7%D9%84%D8%A8%D8%AD%D8%B1_%D8%A7%D9%84%D8%A3%D8%AD%D9%85%D8%B1 "أزمة البحر الأحمر")
  * **[وفيات حديثة](https://ar.wikipedia.org/wiki/%D8%AA%D8%B5%D9%86%D9%8A%D9%81:%D9%88%D9%81%D9%8A%D8%A7%D8%AA_%D8%AD%D8%AF%D9%8A%D8%AB%D8%A9 "تصنيف:وفيات حديثة")** : [داود الفرحان](https://ar.wikipedia.org/wiki/%D8%AF%D8%A7%D9%88%D8%AF_%D8%A7%D9%84%D9%81%D8%B1%D8%AD%D8%A7%D9%86 "داود الفرحان") **·** [حمد المزيني](https://ar.wikipedia.org/wiki/%D8%AD%D9%85%D8%AF_%D8%A7%D9%84%D9%85%D8%B2%D9%8A%D9%86%D9%8A "حمد المزيني") **·** [ديفيد هيرست](https://ar.wikipedia.org/wiki/%D8%AF%D9%8A%D9%81%D9%8A%D8%AF_%D9%87%D9%8A%D8%B1%D8%B3%D8%AA "ديفيد هيرست") **·** [عبد العزيز بن عبد الله آل الشيخ](https://ar.wikipedia.org/wiki/%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D8%B9%D8%B2%D9%8A%D8%B2_%D8%A8%D9%86_%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D9%84%D9%87_%D8%A2%D9%84_%D8%A7%D9%84%D8%B4%D9%8A%D8%AE "عبد العزيز بن عبد الله آل الشيخ") **·** [كلاوديا كردينالي](https://ar.wikipedia.org/wiki/%D9%83%D9%84%D8%A7%D9%88%D8%AF%D9%8A%D8%A7_%D9%83%D8%B1%D8%AF%D9%8A%D9%86%D8%A7%D9%84%D9%8A "كلاوديا كردينالي") **·** [ناثي مثيثوا](https://ar.wikipedia.org/wiki/%D9%86%D8%A7%D8%AB%D9%8A_%D9%85%D8%AB%D9%8A%D8%AB%D9%88%D8%A7 "ناثي مثيثوا") **·** [جين جودل](https://ar.wikipedia.org/wiki/%D8%AC%D9%8A%D9%86_%D8%AC%D9%88%D8%AF%D9%84 "جين جودل")


[وفيات حديثة](https://ar.wikipedia.org/wiki/%D9%88%D9%81%D9%8A%D8%A7%D8%AA_2025 "وفيات 2025") **·** [ويكي الأخبار](https://ar.wikinews.org/wiki/ "n:") **·** [إضافة خبر جديد](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%81%D9%8A_%D8%A7%D9%84%D8%A3%D8%AE%D8%A8%D8%A7%D8%B1/%D8%B7%D9%84%D8%A8%D8%A7%D8%AA "ويكيبيديا:في الأخبار/طلبات")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Datum02.svg/40px-Datum02.svg.png)
في هذا اليوم
**[2 أكتوبر](https://ar.wikipedia.org/wiki/2_%D8%A3%D9%83%D8%AA%D9%88%D8%A8%D8%B1 "2 أكتوبر")** : [عيد الاستقلال](https://ar.wikipedia.org/wiki/%D8%B9%D9%8A%D8%AF_%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D9%82%D9%84%D8%A7%D9%84 "عيد الاستقلال") في [غينيا](https://ar.wikipedia.org/wiki/%D8%BA%D9%8A%D9%86%D9%8A%D8%A7 "غينيا") **·** [اليوم العالمي للاعنف](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%8A%D9%88%D9%85_%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85%D9%8A_%D9%84%D9%84%D8%A7%D8%B9%D9%86%D9%81 "اليوم العالمي للاعنف")
[![لا إطار](https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Ivan_the_Terrible_%28cropped%29.JPG/120px-Ivan_the_Terrible_%28cropped%29.JPG)](https://ar.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Ivan_the_Terrible_\(cropped\).JPG "لا إطار")لا إطار
  * [1187](https://ar.wikipedia.org/wiki/1187 "1187") - انتهاء [حصار القدس](https://ar.wikipedia.org/wiki/%D8%AD%D8%B5%D8%A7%D8%B1_%D8%A7%D9%84%D9%82%D8%AF%D8%B3_\(1187\) "حصار القدس \(1187\)") باسترجاع المسلمين بقيادة [صلاح الدين الأيوبي](https://ar.wikipedia.org/wiki/%D8%B5%D9%84%D8%A7%D8%AD_%D8%A7%D9%84%D8%AF%D9%8A%D9%86_%D8%A7%D9%84%D8%A3%D9%8A%D9%88%D8%A8%D9%8A "صلاح الدين الأيوبي") للمدينة بعد 88 عامًا من حكم [الصليبيين](https://ar.wikipedia.org/wiki/%D8%AD%D9%85%D9%84%D8%A7%D8%AA_%D8%B5%D9%84%D9%8A%D8%A8%D9%8A%D8%A9 "حملات صليبية") لها.
  * [1552](https://ar.wikipedia.org/wiki/1552 "1552") - قيصر [روسيا](https://ar.wikipedia.org/wiki/%D8%B1%D9%88%D8%B3%D9%8A%D8%A7_%D8%A7%D9%84%D9%82%D9%8A%D8%B5%D8%B1%D9%8A%D8%A9 "روسيا القيصرية") [إيفان الرابع](https://ar.wikipedia.org/wiki/%D8%A5%D9%8A%D9%81%D8%A7%D9%86_%D8%A7%D9%84%D8%B1%D9%87%D9%8A%D8%A8 "إيفان الرهيب") (في الصورة) يستولي على مدينة [قازان](https://ar.wikipedia.org/wiki/%D9%82%D8%A7%D8%B2%D8%A7%D9%86 "قازان") [التترية](https://ar.wikipedia.org/wiki/%D8%AA%D8%AA%D8%A7%D8%B1%D8%B3%D8%AA%D8%A7%D9%86 "تتارستان").
  * [1789](https://ar.wikipedia.org/wiki/1789 "1789") - الرئيس [الأمريكي](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%88%D9%84%D8%A7%D9%8A%D8%A7%D8%AA_%D8%A7%D9%84%D9%85%D8%AA%D8%AD%D8%AF%D8%A9 "الولايات المتحدة") [جورج واشنطن](https://ar.wikipedia.org/wiki/%D8%AC%D9%88%D8%B1%D8%AC_%D9%88%D8%A7%D8%B4%D9%86%D8%B7%D9%86 "جورج واشنطن") يرسل التعديلات الدستورية المقترحة المعروفة باسم [وثيقة الحقوق الأمريكية](https://ar.wikipedia.org/wiki/%D9%88%D8%AB%D9%8A%D9%82%D8%A9_%D8%AD%D9%82%D9%88%D9%82_%D8%A7%D9%84%D9%88%D9%84%D8%A7%D9%8A%D8%A7%D8%AA_%D8%A7%D9%84%D9%85%D8%AA%D8%AD%D8%AF%D8%A9 "وثيقة حقوق الولايات المتحدة") إلى الولايات لإقرارها.
  * [1987](https://ar.wikipedia.org/wiki/1987 "1987") - الرئيس [التونسي](https://ar.wikipedia.org/wiki/%D8%AA%D9%88%D9%86%D8%B3 "تونس") [الحبيب بورقيبة](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%AD%D8%A8%D9%8A%D8%A8_%D8%A8%D9%88%D8%B1%D9%82%D9%8A%D8%A8%D8%A9 "الحبيب بورقيبة") يعين وزير الداخلية [زين العابدين بن علي](https://ar.wikipedia.org/wiki/%D8%B2%D9%8A%D9%86_%D8%A7%D9%84%D8%B9%D8%A7%D8%A8%D8%AF%D9%8A%D9%86_%D8%A8%D9%86_%D8%B9%D9%84%D9%8A "زين العابدين بن علي") رئيسًا للحكومة.
  * [2003](https://ar.wikipedia.org/wiki/2003 "2003") - فريق [أمريكي](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%88%D9%84%D8%A7%D9%8A%D8%A7%D8%AA_%D8%A7%D9%84%D9%85%D8%AA%D8%AD%D8%AF%D8%A9 "الولايات المتحدة") للبحث عن [أسلحة الدمار الشامل](https://ar.wikipedia.org/wiki/%D8%B3%D9%84%D8%A7%D8%AD_%D8%AF%D9%85%D8%A7%D8%B1_%D8%B4%D8%A7%D9%85%D9%84 "سلاح دمار شامل") [العراقية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B9%D8%B1%D8%A7%D9%82 "العراق") ينشر أول تقرير له منذ بدء عمله يؤكد فيه أنه لم يعثر على أي من هذه الأسلحة.


أحداث أخرى: [1 أكتوبر](https://ar.wikipedia.org/wiki/1_%D8%A3%D9%83%D8%AA%D9%88%D8%A8%D8%B1 "1 أكتوبر") **·** **[2 أكتوبر](https://ar.wikipedia.org/wiki/2_%D8%A3%D9%83%D8%AA%D9%88%D8%A8%D8%B1 "2 أكتوبر")** **·** [3 أكتوبر](https://ar.wikipedia.org/wiki/3_%D8%A3%D9%83%D8%AA%D9%88%D8%A8%D8%B1 "3 أكتوبر")
**[الأرشيف](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%81%D9%8A_%D9%87%D8%B0%D8%A7_%D8%A7%D9%84%D9%8A%D9%88%D9%85/%D8%A3%D9%83%D8%AA%D9%88%D8%A8%D8%B1 "ويكيبيديا:في هذا اليوم/أكتوبر")** **·** **[مواليد هذا اليوم](https://ar.wikipedia.org/wiki/%D8%AA%D8%B5%D9%86%D9%8A%D9%81:%D9%85%D9%88%D8%A7%D9%84%D9%8A%D8%AF_2_%D8%A3%D9%83%D8%AA%D9%88%D8%A8%D8%B1 "تصنيف:مواليد 2 أكتوبر")** **·** **[قائمة أيام السنة](https://ar.wikipedia.org/wiki/%D9%82%D8%A7%D8%A6%D9%85%D8%A9_%D8%A3%D9%8A%D8%A7%D9%85_%D8%A7%D9%84%D8%B3%D9%86%D8%A9 "قائمة أيام السنة")**
اليوم الخميس [2 أكتوبر](https://ar.wikipedia.org/wiki/2_%D8%A3%D9%83%D8%AA%D9%88%D8%A8%D8%B1 "2 أكتوبر") [2025](https://ar.wikipedia.org/wiki/2025 "2025") (وَفق [التوقيت العالمي المنسق](https://ar.wikipedia.org/wiki/%D8%AA%D9%88%D9%82%D9%8A%D8%AA_%D8%B9%D8%A7%D9%84%D9%85%D9%8A_%D9%85%D9%86%D8%B3%D9%82 "توقيت عالمي منسق")) **·** [حدّث الصفحة](https://ar.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&action=purge)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/HS_RTL_Exclamation.svg/40px-HS_RTL_Exclamation.svg.png)
هل تعلم
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Gnpapanikolaou.jpg/120px-Gnpapanikolaou.jpg)](https://ar.wikipedia.org/wiki/%D9%85%D9%84%D9%81:Gnpapanikolaou.jpg)
  * ...أن العالم اليوناني **[جورجيوس بابانيكولاو](https://ar.wikipedia.org/wiki/%D8%AC%D9%88%D8%B1%D8%AC%D9%8A%D9%88%D8%B3_%D8%A8%D8%A7%D8%A8%D8%A7%D9%86%D9%8A%D9%83%D9%88%D9%84%D8%A7%D9%88 "جورجيوس بابانيكولاو")** (في الصورة) قد ابتكرَ [لطاخة](https://ar.wikipedia.org/wiki/%D9%84%D8%B7%D8%A7%D8%AE%D8%A9_%D8%A8%D8%A7%D8%A8%D8%A7%D9%86%D9%8A%D9%83%D9%88%D9%84%D8%A7%D9%88 "لطاخة بابانيكولاو") تُستعمل في الكشف المبكر عن [سرطان عنق الرحم](https://ar.wikipedia.org/wiki/%D8%B3%D8%B1%D8%B7%D8%A7%D9%86_%D8%B9%D9%86%D9%82_%D8%A7%D9%84%D8%B1%D8%AD%D9%85 "سرطان عنق الرحم")؟
  * ...أن **كلمة[الأرجنتين](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%A3%D8%B1%D8%AC%D9%86%D8%AA%D9%8A%D9%86 "الأرجنتين")** مشتقة من اللفظة اللاتينية "أرجنتيوم" والتي تعني [الفضة](https://ar.wikipedia.org/wiki/%D9%81%D8%B6%D8%A9 "فضة")، مع العلم أن الأرجنتين لا تحتوي على أي مصادر للفضة، ولكن سُمّيت بهذا لأن [الغزاة الإسبان](https://ar.wikipedia.org/wiki/%D9%83%D9%88%D9%86%D9%83%D9%8A%D8%B3%D8%AA%D8%AF%D9%88%D8%B1 "كونكيستدور") أتوا إلى تلك الأراضي بعد انتشار الشائعات بأنها تحوي جبالًا من الفضة؟
  * ...أن **[متحف الفن السيئ](https://ar.wikipedia.org/wiki/%D9%85%D8%AA%D8%AD%D9%81_%D8%A7%D9%84%D9%81%D9%86_%D8%A7%D9%84%D8%B3%D9%8A%D8%A6 "متحف الفن السيئ")** هو المتحف الوحيد في العالم المُكرس لجمع وعرض الفن السيء، حيثُ أنَّ مهمة العاملين فيه جلب أسوأ القطع الفنية وعرضها فيه؟
  * ...أن **مصطلح[الشرق الأدنى القديم](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B4%D8%B1%D9%82_%D8%A7%D9%84%D8%A3%D8%AF%D9%86%D9%89_%D8%A7%D9%84%D9%82%D8%AF%D9%8A%D9%85 "الشرق الأدنى القديم")** يشير إلى الحضارات التي نشأت في ما يسمى اليوم [بالشرق الأوسط](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B4%D8%B1%D9%82_%D8%A7%D9%84%D8%A3%D9%88%D8%B3%D8%B7 "الشرق الأوسط")، وتحديداً: [بلاد الرافدين](https://ar.wikipedia.org/wiki/%D8%A8%D9%84%D8%A7%D8%AF_%D8%A7%D9%84%D8%B1%D8%A7%D9%81%D8%AF%D9%8A%D9%86 "بلاد الرافدين") [ومصر القديمة](https://ar.wikipedia.org/wiki/%D9%85%D8%B5%D8%B1_%D8%A7%D9%84%D9%82%D8%AF%D9%8A%D9%85%D8%A9 "مصر القديمة") [وإيران القديمة](https://ar.wikipedia.org/wiki/%D8%AA%D8%A7%D8%B1%D9%8A%D8%AE_%D8%A5%D9%8A%D8%B1%D8%A7%D9%86 "تاريخ إيران") [وأرمينيا](https://ar.wikipedia.org/wiki/%D8%A3%D8%B1%D9%85%D9%8A%D9%86%D9%8A%D8%A7 "أرمينيا") [والأناضول](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%A3%D9%86%D8%A7%D8%B6%D9%88%D9%84 "الأناضول")؟
  * ...أن **[الحبيب بورقيبة](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%AD%D8%A8%D9%8A%D8%A8_%D8%A8%D9%88%D8%B1%D9%82%D9%8A%D8%A8%D8%A9 "الحبيب بورقيبة")** يعد أول رئيس [للجمهورية التونسية](https://ar.wikipedia.org/wiki/%D8%AA%D9%88%D9%86%D8%B3 "تونس")، بعد [إلغاء الملكية وإعلان الجمهورية](https://ar.wikipedia.org/wiki/%D8%A5%D8%B9%D9%84%D8%A7%D9%86_%D8%A7%D9%84%D8%AC%D9%85%D9%87%D9%88%D8%B1%D9%8A%D8%A9_%D8%A7%D9%84%D8%AA%D9%88%D9%86%D8%B3%D9%8A%D8%A9 "إعلان الجمهورية التونسية") في 25 يوليو 1957؟
  * ...أن **[أوتو فاربورغ](https://ar.wikipedia.org/wiki/%D8%A3%D9%88%D8%AA%D9%88_%D9%81%D8%A7%D8%B1%D8%A8%D9%88%D8%B1%D8%BA "أوتو فاربورغ")** حصل على [جائزة نوبل في الطب](https://ar.wikipedia.org/wiki/%D8%AC%D8%A7%D8%A6%D8%B2%D8%A9_%D9%86%D9%88%D8%A8%D9%84_%D9%81%D9%8A_%D8%A7%D9%84%D8%B7%D8%A8_%D8%A3%D9%88_%D8%B9%D9%84%D9%85_%D9%88%D8%B8%D8%A7%D8%A6%D9%81_%D8%A7%D9%84%D8%A3%D8%B9%D8%B6%D8%A7%D8%A1 "جائزة نوبل في الطب أو علم وظائف الأعضاء") لاكتشافه طبيعة وطريقة عمل [الإنزيم](https://ar.wikipedia.org/wiki/%D8%A5%D9%86%D8%B2%D9%8A%D9%85 "إنزيم") في [الجهاز التنفسي](https://ar.wikipedia.org/wiki/%D8%AC%D9%87%D8%A7%D8%B2_%D8%AA%D9%86%D9%81%D8%B3%D9%8A "جهاز تنفسي")؟


[رشح معلومة جديدة](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%87%D9%84_%D8%AA%D8%B9%D9%84%D9%85#%D8%A7%D9%82%D8%AA%D8%B1%D8%A7%D8%AD_%D9%85%D8%B9%D9%84%D9%88%D9%85%D8%A9 "ويكيبيديا:هل تعلم")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/HSBook.svg/40px-HSBook.svg.png)
قيل
31
” | إن من [خياركم](https://ar.wikipedia.org/wiki/%D8%AE%D9%8A%D8%B1 "خير") أحسنكم [أخلاقًا](https://ar.wikipedia.org/wiki/%D8%A3%D8%AE%D9%84%D8%A7%D9%82 "أخلاق") |  “  
---|---|---  
| — [محمد بن عبد الله](https://ar.wikipedia.org/wiki/%D9%85%D8%AD%D9%85%D8%AF "محمد") |   
  

[ويكي الاقتباس](https://ar.wikiquote.org/wiki/ "q:") **·** [قائمة الأقوال](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AC%D8%AF%D9%88%D9%84_%D9%83%D9%84%D9%85%D8%A9_%D8%A7%D9%84%D9%8A%D9%88%D9%85/%D8%B9%D8%B1%D8%B6_%D8%A7%D9%84%D9%83%D9%84%D9%85%D8%A7%D8%AA_%D9%83%D9%84%D9%87%D8%A7 "ويكيبيديا:جدول كلمة اليوم/عرض الكلمات كلها")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/HS_Korganizer.svg/40px-HS_Korganizer.svg.png)
الصحيح في [اللغة](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D8%A9_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9 "اللغة العربية")
_لا تقل_ : يدل تغير **عامود** الماء   
_بل قل_ : يدل تغير **عمود** الماء  
جاء في معجم الفقهاء في مادة عَمُود:  
بفتح العين وضم الميم هي الدعامة الأساسية   
التي يعتمد عليها البناء وجمعه أَعمِدة وعُمُدٌ وعَمَدٌ.  
  
---  
  

[ويكاموس](https://ar.wiktionary.org/wiki/ "wikt:") **·** [قائمة الملاحظات](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D9%84%D8%B4%D8%A7%D8%A6%D8%B9_%D9%81%D9%8A_%D8%A7%D9%84%D9%84%D8%BA%D8%A9/%D8%B9%D8%B1%D8%B6_%D8%A7%D9%84%D9%85%D9%84%D8%A7%D8%AD%D8%B8%D8%A7%D8%AA_%D9%83%D9%84%D9%87%D8%A7 "ويكيبيديا:الشائع في اللغة/عرض الملاحظات كلها")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/HSEditor.svg/40px-HSEditor.svg.png)
هل تود إنشاء مقالة؟
في ويكيبيديا العربية **[1٬282٬161](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A5%D8%AD%D8%B5%D8%A7%D8%A1%D8%A7%D8%AA "خاص:إحصاءات")** مقالة حتى الآن، لذا فاحتمال وجود مقالةٍ حول الموضوع الذي تريد الكتابة عنه كبير. استخدم [صفحة البحث](https://ar.wikipedia.org/wiki/%D8%AE%D8%A7%D8%B5:%D8%A8%D8%AD%D8%AB "خاص:بحث") لمعرفة ما إذا كانت المقالة موجودةً، وربما تحت مسمًّى آخر مختلف. إن لم تكن، اكتب اسم المقالة في الصندوق أدناه وأنشئها، واتبع الإرشادات أعلى صندوق التحرير بحرص. 
  

[شاهد بعض الفيديوهات الإرشادية](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D8%A7%D9%84%D9%81%D9%8A%D8%AF%D9%8A%D9%88%D9%87%D8%A7%D8%AA_%D8%A7%D9%84%D8%A5%D8%B1%D8%B4%D8%A7%D8%AF%D9%8A%D8%A9 "مساعدة:الفيديوهات الإرشادية")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/HSWPedia.svg/40px-HSWPedia.svg.png)
ما هي ويكيبيديا؟
**[ويكيبيديا](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B9%D9%86 "ويكيبيديا:عن")** مشروع تعاوني متعدد اللغات يضم [ويكيات](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A "ويكي") بأكثر من 300 لغة للعمل في مشاريع [موسوعات](https://ar.wikipedia.org/wiki/%D9%85%D9%88%D8%B3%D9%88%D8%B9%D8%A9 "موسوعة") حرة ودقيقة ومتكاملة ومتنوعة ومحايدة، يستطيع الجميع المساهمة في تحريرها. نشأت ويكيبيديا في عام 2001، حيث نمت وتطورت بسرعة لتصبح واحدة من أكبر المواقع على الإنترنت. بدأت [النسخة العربية](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9 "ويكيبيديا العربية") في [يوليو/تموز 2003](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AA%D8%A7%D8%B1%D9%8A%D8%AE_%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9 "ويكيبيديا:تاريخ ويكيبيديا العربية").  
لدى ويكيبيديا بعض [السياسات والإرشادات](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B3%D9%8A%D8%A7%D8%B3%D8%A7%D8%AA_%D9%88%D8%A5%D8%B1%D8%B4%D8%A7%D8%AF%D8%A7%D8%AA "ويكيبيديا:سياسات وإرشادات") التي تساعد متطوعيها على العمل فيها، بعض هذه السياسات لا تزال في طور التشكل، بينما استقرت سياسات أخرى منذ زمن، ومع أن سياسات ويكيبيديا مستمرة في النمو، إلا أن بعض [الويكيبيديين](https://ar.wikipedia.org/wiki/%D9%85%D8%AC%D8%AA%D9%85%D8%B9_%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7 "مجتمع ويكيبيديا") يشعرون أن كتابة القواعد أمر لا يمكن له أن يغطي كل تنويعة على السلوك المثير أو الهادف لضرر. هؤلاء الذين يحررون [بنية حسنة](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D9%81%D8%AA%D8%B1%D8%B6_%D8%AD%D8%B3%D9%86_%D8%A7%D9%84%D9%86%D9%8A%D8%A9 "ويكيبيديا:افترض حسن النية") ويظهرون [سلوكًا مدنيًّا](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A3%D8%AF%D8%A8 "ويكيبيديا:أدب") ويسعون وراء [التوافق](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%AA%D9%88%D8%A7%D9%81%D9%82 "ويكيبيديا:توافق") ويعملون لتحقيق هدفهم بالمشاركة في مشروع [موسوعي محايد](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%88%D8%AC%D9%87%D8%A9_%D8%A7%D9%84%D9%86%D8%B8%D8%B1_%D8%A7%D9%84%D9%85%D8%AD%D8%A7%D9%8A%D8%AF%D8%A9 "ويكيبيديا:وجهة النظر المحايدة")، سيجدون أنفسهم في [بيئة مرحبة](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A3%D8%AF%D8%A8 "ويكيبيديا:أدب").  
يمكنك دائمًا المساعدة في بناء ويكيبيديا وتحسينها بالتعاون مع [المجتمع](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A8%D9%88%D8%A7%D8%A8%D8%A9_%D8%A7%D9%84%D9%85%D8%AC%D8%AA%D9%85%D8%B9 "ويكيبيديا:بوابة المجتمع") عن طريق [التحرير](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D8%AA%D8%AD%D8%B1%D9%8A%D8%B1_%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A7%D8%AA "مساعدة:تحرير الصفحات") [وإنشاء مقالات جديدة](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D9%85%D9%82%D8%A7%D9%84%D8%AA%D9%83_%D8%A7%D9%84%D8%A3%D9%88%D9%84%D9%89 "مساعدة:مقالتك الأولى"). انظر [قسم المساعدة](https://ar.wikipedia.org/wiki/%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9:%D9%85%D8%AD%D8%AA%D9%88%D9%8A%D8%A7%D8%AA "مساعدة:محتويات") للحصول على نصائح، أو توجه إلى [الميدان](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A7%D9%84%D9%85%D9%8A%D8%AF%D8%A7%D9%86 "ويكيبيديا:الميدان") لطرح الاستفسارات العامة حول أساليب التحرير وسياسات ويكيبيديا والقضايا التقنية أو اللغوية. 
![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Blue-bg_rounded_cropped_right.svg/250px-Blue-bg_rounded_cropped_right.svg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Wikimedia-logo-circle.svg/40px-Wikimedia-logo-circle.svg.png)
مشاريع شقيقة
**مشروع ويكيبيديا أحد المشاريع التابعة[لمؤسسة ويكيميديا](https://ar.wikipedia.org/wiki/%D9%85%D8%A4%D8%B3%D8%B3%D8%A9_%D9%88%D9%8A%D9%83%D9%8A%D9%85%D9%8A%D8%AF%D9%8A%D8%A7 "مؤسسة ويكيميديا")، وهي منظمة غير ربحية تستضيف كذلك مجموعة من [المشاريع الأخرى](https://wikimediafoundation.org/ar/our-work/wikimedia-projects/):**
  * [![Commons logo](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/ "Commons")
[كومنز](https://commons.wikimedia.org/wiki/ "c:")  
مستودع الملفات المشتركة
  * [![MediaWiki logo](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/ "MediaWiki")
[ميدياويكي](https://www.mediawiki.org/wiki/ "mw:")  
برمجيات ويكي حرة
  * [![Meta-Wiki logo](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/ "Meta-Wiki")
[ميتا ويكي](https://meta.wikimedia.org/wiki/ "m:")  
تنسيق مشاريع ويكيميديا
  * [![Wikibooks logo](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://ar.wikibooks.org/wiki/ "Wikibooks")
[ويكي الكتب](https://ar.wikibooks.org/wiki/ "b:")  
كتب مفتوحة لعالم حر
  * [![Wikidata logo](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "Wikidata")
[ويكي بيانات](https://www.wikidata.org/wiki/ "d:")  
قاعدة بيانات حرة
  * [![Wikinews logo](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png)](https://ar.wikinews.org/wiki/ "Wikinews")
[ويكي أخبار](https://ar.wikinews.org/wiki/ "n:")  
مصدر أخبار حرة
  * [![Wikiquote logo](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://ar.wikiquote.org/wiki/ "Wikiquote")
[ويكي الاقتباس](https://ar.wikiquote.org/wiki/ "q:")  
أقوال مأثورة ومشهورة
  * [![Wikisource logo](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://ar.wikisource.org/wiki/ "Wikisource")
[ويكي مصدر](https://ar.wikisource.org/wiki/ "s:")  
مكتبة حرة
  * [![Wikispecies logo](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/ "Wikispecies")
[ويكي أنواع](https://species.wikimedia.org/wiki/ "species:")  
دليل للأنواع الحية
  * [![Wikiversity logo](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Wikiversity_logo_2017.svg/60px-Wikiversity_logo_2017.svg.png)](https://ar.wikiversity.org/wiki/ "Wikiversity")
[ويكي الجامعة](https://ar.wikiversity.org/wiki/ "v:")  
مصدر تعليم حر
  * [![Wikivoyage logo](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://ar.wikivoyage.org/wiki/ "Wikivoyage")
[ويكي الرحلات](https://ar.wikivoyage.org/wiki/ "voy:")  
دليل سفر حر
  * [![Wiktionary logo](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://ar.wiktionary.org/wiki/ "Wiktionary")[![Wiktionary logo](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/60px-Wiktionary-logo.svg.png)](https://ar.wiktionary.org/wiki/ "Wiktionary")
[ويكاموس](https://ar.wiktionary.org/wiki/ "wikt:")  
قاموس حر


  * [قائمة الويكيبيديات](https://meta.wikimedia.org/wiki/List_of_Wikipedias/ar "m:List of Wikipedias/ar")
  * [إحصاءات ويكيبيديا العربية](https://stats.wikimedia.org/#/ar.wikipedia.org)
  * [أفرغ كاش الخادم](https://ar.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&action=purge): لتحديث الصفحة الرئيسة


مجلوبة من «[https://ar.wikipedia.org/w/index.php?title=الصفحة_الرئيسة&oldid=70907266](https://ar.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&oldid=70907266)»
تصنيفات مخفية: 
  * [مقالات تحوي نصا بالهندية](https://ar.wikipedia.org/wiki/%D8%AA%D8%B5%D9%86%D9%8A%D9%81:%D9%85%D9%82%D8%A7%D9%84%D8%A7%D8%AA_%D8%AA%D8%AD%D9%88%D9%8A_%D9%86%D8%B5%D8%A7_%D8%A8%D8%A7%D9%84%D9%87%D9%86%D8%AF%D9%8A%D8%A9 "تصنيف:مقالات تحوي نصا بالهندية")
  * [صفحات تستخدم قوالب اللغة](https://ar.wikipedia.org/wiki/%D8%AA%D8%B5%D9%86%D9%8A%D9%81:%D8%B5%D9%81%D8%AD%D8%A7%D8%AA_%D8%AA%D8%B3%D8%AA%D8%AE%D8%AF%D9%85_%D9%82%D9%88%D8%A7%D9%84%D8%A8_%D8%A7%D9%84%D9%84%D8%BA%D8%A9 "تصنيف:صفحات تستخدم قوالب اللغة")
  * [Gadget-MainPage](https://ar.wikipedia.org/wiki/%D8%AA%D8%B5%D9%86%D9%8A%D9%81:Gadget-MainPage "تصنيف:Gadget-MainPage")


60 لغة
  * [الدارجة](https://ary.wikipedia.org/wiki/ "Moroccan Arabic")
  * [مصرى](https://arz.wikipedia.org/wiki/ "Egyptian Arabic")
  * [Asturianu](https://ast.wikipedia.org/wiki/ "الأسترية")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/ "South Azerbaijani")
  * [Български](https://bg.wikipedia.org/wiki/ "البلغارية")
  * [Bosanski](https://bs.wikipedia.org/wiki/ "البوسنية")
  * [Català](https://ca.wikipedia.org/wiki/ "الكتالانية")
  * [کوردی](https://ckb.wikipedia.org/wiki/ "السورانية الكردية")
  * [Čeština](https://cs.wikipedia.org/wiki/ "التشيكية")
  * [Dansk](https://da.wikipedia.org/wiki/ "الدانمركية")
  * [Deutsch](https://de.wikipedia.org/wiki/ "الألمانية")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "اليونانية")
  * [English](https://en.wikipedia.org/wiki/ "الإنجليزية")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "الإسبرانتو")
  * [Español](https://es.wikipedia.org/wiki/ "الإسبانية")
  * [Eesti](https://et.wikipedia.org/wiki/ "الإستونية")
  * [Euskara](https://eu.wikipedia.org/wiki/ "الباسكية")
  * [فارسی](https://fa.wikipedia.org/wiki/ "الفارسية")
  * [Suomi](https://fi.wikipedia.org/wiki/ "الفنلندية")
  * [Français](https://fr.wikipedia.org/wiki/ "الفرنسية")
  * [Galego](https://gl.wikipedia.org/wiki/ "الجاليكية")
  * [گیلکی](https://glk.wikipedia.org/wiki/ "Gilaki")
  * [עברית](https://he.wikipedia.org/wiki/ "العبرية")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "الكرواتية")
  * [Magyar](https://hu.wikipedia.org/wiki/ "الهنغارية")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "الإندونيسية")
  * [Italiano](https://it.wikipedia.org/wiki/ "الإيطالية")
  * [日本語](https://ja.wikipedia.org/wiki/ "اليابانية")
  * [한국어](https://ko.wikipedia.org/wiki/ "الكورية")
  * [کٲشُر](https://ks.wikipedia.org/wiki/ "الكشميرية")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/ "اللرية الشمالية")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "الليتوانية")
  * [Latviešu](https://lv.wikipedia.org/wiki/ "اللاتفية")
  * [മലയാളം](https://ml.wikipedia.org/wiki/ "المالايالامية")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "الماليزية")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/ "المازندرانية")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/ "مين-نان الصينية")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "الهولندية")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "النرويجية نينورسك")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "النرويجية بوكمال")
  * [Polski](https://pl.wikipedia.org/wiki/ "البولندية")
  * [پنجابی](https://pnb.wikipedia.org/wiki/ "Western Punjabi")
  * [پښتو](https://ps.wikipedia.org/wiki/ "البشتو")
  * [Português](https://pt.wikipedia.org/wiki/ "البرتغالية")
  * [Română](https://ro.wikipedia.org/wiki/ "الرومانية")
  * [Русский](https://ru.wikipedia.org/wiki/ "الروسية")
  * [سنڌي](https://sd.wikipedia.org/wiki/ "السندية")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "صربية-كرواتية")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "السلوفاكية")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "السلوفانية")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "الصربية")
  * [Svenska](https://sv.wikipedia.org/wiki/ "السويدية")
  * [ไทย](https://th.wikipedia.org/wiki/ "التايلاندية")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "التركية")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/ "الأويغورية")
  * [Українська](https://uk.wikipedia.org/wiki/ "الأوكرانية")
  * [اردو](https://ur.wikipedia.org/wiki/ "الأوردية")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "الفيتنامية")
  * [中文](https://zh.wikipedia.org/wiki/ "الصينية")


  * آخر تعديل لهذه الصفحة كان يوم 27 مايو 2025، الساعة 14:06.
  * النصوص متاحة تحت [رخصة المشاع الإبداعي الملزمة بنسبة العمل لمؤلفه وبترخيص الأعمال المشتقة بالمثل 4.0](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D9%86%D8%B5_%D8%B1%D8%AE%D8%B5%D8%A9_%D8%A7%D9%84%D9%85%D8%B4%D8%A7%D8%B9_%D8%A7%D9%84%D8%A5%D8%A8%D8%AF%D8%A7%D8%B9%D9%8A:_%D8%A7%D9%84%D9%86%D8%B3%D8%A8%D8%A9-%D8%A7%D9%84%D8%AA%D8%B1%D8%AE%D9%8A%D8%B5_%D8%A8%D8%A7%D9%84%D9%85%D8%AB%D9%84_4.0 "ويكيبيديا:نص رخصة المشاع الإبداعي: النسبة-الترخيص بالمثل 4.0")؛ قد تُطبّق شروط إضافية. استخدامُك هذا الموقع هو موافقةٌ على [شروط الاستخدام](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use "foundation:Special:MyLanguage/Policy:Terms of Use") [وسياسة الخصوصية](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy "foundation:Special:MyLanguage/Policy:Privacy policy"). ويكيبيديا ® هي علامة تجارية مسجلة [لمؤسسة ويكيميديا](https://wikimediafoundation.org/)، وهي منظمة غير ربحية.


  * [سياسة الخصوصية](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy/ar)
  * [حول ويكيبيديا](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%B9%D9%86)
  * [إخلاء مسؤولية](https://ar.wikipedia.org/wiki/%D9%88%D9%8A%D9%83%D9%8A%D8%A8%D9%8A%D8%AF%D9%8A%D8%A7:%D8%A5%D8%AE%D9%84%D8%A7%D8%A1_%D9%85%D8%B3%D8%A4%D9%88%D9%84%D9%8A%D8%A9_%D8%B9%D8%A7%D9%85)
  * [القواعد السلوكية](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [المطورون](https://developer.wikimedia.org)
  * [إحصائيات](https://stats.wikimedia.org/#/ar.wikipedia.org)
  * [بيان تعريف الارتباطات](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [نسخة للأجهزة المحمولة](https://ar.m.wikipedia.org/w/index.php?title=%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://ar.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://ar.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


بحث
بحث
الصفحة الرئيسة
[](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9) [](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9) [](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9) [](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9) [](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9) [](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9) [](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9) [](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9)
60 لغة [أضف موضوعًا ](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9)
