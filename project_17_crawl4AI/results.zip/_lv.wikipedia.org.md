[Pāriet uz saturu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa#bodyContent)
Galvenā izvēlne
Galvenā izvēlne
pārvietot uz sānjoslu paslēpt
Navigācija 
  * [Sākumlapa](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Iet uz sākumlapu \[z\]")
  * [Kopienas portāls](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Kopienas_port%C4%81ls "Šeit Tu vari uzdot sev interesējošus jautājumus")
  * [Aktualitātes](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Aktualit%C4%81tes "Uzzini, kas nesen noticis Vikipēdijā")
  * [Pēdējās izmaiņas](https://lv.wikipedia.org/wiki/Special:RecentChanges "Izmaiņas, kas nesen izdarītas Vikipēdijā \[r\]")
  * [Nejauša lapa](https://lv.wikipedia.org/wiki/Special:Random "Iet uz nejauši izvēlētu lapu \[x\]")
  * [Palīdzība](https://lv.wikipedia.org/wiki/Pal%C4%ABdz%C4%ABba:Saturs "Vieta, kur uzzināt par Vikipēdiju vairāk")
  * [Paziņot par kļūdu](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Pazi%C5%86ojumi_par_k%C4%BC%C5%ABd%C4%81m)
  * [Kontakti](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Kontakti)
  * [Īpašās lapas](https://lv.wikipedia.org/wiki/Special:SpecialPages)


[ ![](https://lv.wikipedia.org/static/images/icons/wikipedia.png) ![Vikipēdija](https://lv.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-lv.svg) ![Brīvā enciklopēdija](https://lv.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-lv.svg) ](https://lv.wikipedia.org/wiki/S%C4%81kumlapa)
[Meklēt ](https://lv.wikipedia.org/wiki/Special:Search "Meklēt Vikipēdijā \[f\]")
Meklēt
Izskats
  * [Ziedojumi](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=lv.wikipedia.org&uselang=lv)
  * [Izveidot jaunu Vikipēdijas kontu](https://lv.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=S%C4%81kumlapa "Ieteicams izveidot kontu un pieslēgties; tomēr tas nav obligāti.")
  * [Ieiet Vikipēdijā](https://lv.wikipedia.org/w/index.php?title=Special:UserLogin&returnto=S%C4%81kumlapa "Aicinām tevi ieiet Vikipēdijā, tomēr tas nav obligāti. \[o\]")


Dalībnieka rīki
  * [Ziedojumi](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=lv.wikipedia.org&uselang=lv)
  * [Izveidot jaunu Vikipēdijas kontu](https://lv.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=S%C4%81kumlapa "Ieteicams izveidot kontu un pieslēgties; tomēr tas nav obligāti.")
  * [Ieiet Vikipēdijā](https://lv.wikipedia.org/w/index.php?title=Special:UserLogin&returnto=S%C4%81kumlapa "Aicinām tevi ieiet Vikipēdijā, tomēr tas nav obligāti. \[o\]")


# Sākumlapa
  * [Sākumlapa](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Apskatīt rakstu \[c\]")
  * [Diskusija](https://lv.wikipedia.org/wiki/Diskusija:S%C4%81kumlapa "Diskusija par šī raksta lapu \[t\]")


latviešu
  * [Skatīt](https://lv.wikipedia.org/wiki/S%C4%81kumlapa)
  * [Aplūkot kodu](https://lv.wikipedia.org/w/index.php?title=S%C4%81kumlapa&action=edit "Šī lapa ir aizsargāta. Tu vari apskatīt tās izejas kodu. \[e\]")
  * [Hronoloģija](https://lv.wikipedia.org/w/index.php?title=S%C4%81kumlapa&action=history "Šīs lapas iepriekšējās versijas. \[h\]")


Rīki
Rīki
pārvietot uz sānjoslu paslēpt
Darbības 
  * [Skatīt](https://lv.wikipedia.org/wiki/S%C4%81kumlapa)
  * [Aplūkot kodu](https://lv.wikipedia.org/w/index.php?title=S%C4%81kumlapa&action=edit)
  * [Hronoloģija](https://lv.wikipedia.org/w/index.php?title=S%C4%81kumlapa&action=history)


Vispārīgi 
  * [Norādes uz šo rakstu](https://lv.wikipedia.org/wiki/Special:WhatLinksHere/S%C4%81kumlapa "Visas Vikipēdijas lapas, kurās ir saites uz šejieni \[j\]")
  * [Saistītās izmaiņas](https://lv.wikipedia.org/wiki/Special:RecentChangesLinked/S%C4%81kumlapa "Izmaiņas, kas nesen izdarītas lapās, kurās ir saites uz šo lapu \[k\]")
  * [Pastāvīgā saite](https://lv.wikipedia.org/w/index.php?title=S%C4%81kumlapa&oldid=3673304 "Paliekoša saite uz šo lapas versiju")
  * [Lapas informācija](https://lv.wikipedia.org/w/index.php?title=S%C4%81kumlapa&action=info "Vairāk informācijas par šo lapu")
  * [Atsauce uz šo lapu](https://lv.wikipedia.org/w/index.php?title=Special:CiteThisPage&page=S%C4%81kumlapa&id=3673304&wpFormIdentifier=titleform "Kā pareizi atsaukties uz šo rakstu")
  * [Iegūt saīsinātu URL](https://lv.wikipedia.org/w/index.php?title=Special:UrlShortener&url=https%3A%2F%2Flv.wikipedia.org%2Fwiki%2FS%25C4%2581kumlapa)
  * [Lejupielādēt QR kodu](https://lv.wikipedia.org/w/index.php?title=Special:QrCode&url=https%3A%2F%2Flv.wikipedia.org%2Fwiki%2FS%25C4%2581kumlapa)


Drukāt/eksportēt 
  * [Izveidot grāmatu](https://lv.wikipedia.org/w/index.php?title=Special:Book&bookcmd=book_creator&referer=S%C4%81kumlapa)
  * [Lejupielādēt kā PDF](https://lv.wikipedia.org/w/index.php?title=Special:DownloadAsPdf&page=S%C4%81kumlapa&action=show-download-screen)
  * [Drukājama versija](https://lv.wikipedia.org/w/index.php?title=S%C4%81kumlapa&printable=yes "Drukājama lapas versija \[p\]")


Citos projektos 
  * [Vikikrātuve](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Vikigrāmatas](https://lv.wikibooks.org/wiki/S%C4%81kumlapa)
  * [Vikidati](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wiktionary](https://lv.wiktionary.org/wiki/S%C4%81kumlapa)
  * [Ieraksts Vikidatos](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Saistītais Vikidatu ieraksts \[g\]")


Izskats
pārvietot uz sānjoslu paslēpt
Vikipēdijas lapa
|  [Laipni lūdzam](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Laipni_l%C5%ABdzam_Vikip%C4%93dij%C4%81 "Vikipēdija:Laipni lūdzam Vikipēdijā") [Vikipēdijā](https://lv.wikipedia.org/wiki/Vikip%C4%93dija "Vikipēdija"), brīvajā enciklopēdijā, kuru arī Tu vari [papildināt](https://lv.wikipedia.org/wiki/Pal%C4%ABdz%C4%ABba:Redi%C4%A3%C4%93%C5%A1ana,_noform%C4%93%C5%A1ana "Palīdzība:Rediģēšana, noformēšana")! Šobrīd [latviešu valodā](https://lv.wikipedia.org/wiki/Latvie%C5%A1u_valoda "Latviešu valoda") ir **[137 682 raksti](https://lv.wikipedia.org/wiki/Special:Statistics "Special:Statistics")**.  
---  
  * Pagājušajā nedēļā skatītākais:  
[Miķeļi](https://lv.wikipedia.org/wiki/Mi%C4%B7e%C4%BCi "Miķeļi")
  * [Latvija](https://lv.wikipedia.org/wiki/Latvija "Latvija")
  * [Starptautisko tālsarunu kodu saraksts](https://lv.wikipedia.org/wiki/Starptautisko_t%C4%81lsarunu_kodu_saraksts "Starptautisko tālsarunu kodu saraksts")
  * [Rainis](https://lv.wikipedia.org/wiki/Rainis "Rainis")
  * [Aspazija](https://lv.wikipedia.org/wiki/Aspazija "Aspazija")
  * [Dainis Īvāns](https://lv.wikipedia.org/wiki/Dainis_%C4%AAv%C4%81ns "Dainis Īvāns")
  * [Eiropas Padomes konvencija par vardarbības pret sievietēm un vardarbību ģimenē novēršanu un apkarošanu](https://lv.wikipedia.org/wiki/Eiropas_Padomes_konvencija_par_vardarb%C4%ABbas_pret_sieviet%C4%93m_un_vardarb%C4%ABbu_%C4%A3imen%C4%93_nov%C4%93r%C5%A1anu_un_apkaro%C5%A1anu "Eiropas Padomes konvencija par vardarbības pret sievietēm un vardarbību ģimenē novēršanu un apkarošanu")
  * [Latvijas Televīzija](https://lv.wikipedia.org/wiki/Latvijas_Telev%C4%ABzija "Latvijas Televīzija")
  * [Anete Sietiņa](https://lv.wikipedia.org/wiki/Anete_Sieti%C5%86a "Anete Sietiņa")
  * [Rīga](https://lv.wikipedia.org/wiki/R%C4%ABga "Rīga")

  
|   
---  
_No Vikipēdijas latviešu valodā[jaunākajiem rakstiem](https://lv.wikipedia.org/wiki/Special:NewPages "Special:NewPages"):_ [![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Stende_Evangelic_Lutheran_Church.jpg/250px-Stende_Evangelic_Lutheran_Church.jpg)](https://lv.wikipedia.org/wiki/Att%C4%93ls:Stende_Evangelic_Lutheran_Church.jpg)
  * ... **[Stendes luterāņu baznīca](https://lv.wikipedia.org/wiki/Stendes_luter%C4%81%C5%86u_bazn%C4%ABca "Stendes luterāņu baznīca")** (attēlā) ir celta ar pārtraukumiem no 1668. līdz 1751. gadam un kopš tā laika nav paplašināta vai pārbūvēta, tikai vairākkārt remontēta?
  * ... **[Karolingu impērija](https://lv.wikipedia.org/wiki/Karolingu_imp%C4%93rija "Karolingu impērija")** [Rietumeiropā](https://lv.wikipedia.org/wiki/Rietumeiropa "Rietumeiropa") izveidojās [800. gada](https://lv.wikipedia.org/wiki/800._gads "800. gads") 25. decembrī, kad pāvests [Leons III](https://lv.wikipedia.org/wiki/Leons_III "Leons III") [Romā](https://lv.wikipedia.org/wiki/Roma "Roma") kronēja [franku valsts](https://lv.wikipedia.org/wiki/Franku_valsts "Franku valsts") karali [Kārli Lielo](https://lv.wikipedia.org/wiki/K%C4%81rlis_Lielais "Kārlis Lielais") ar imperatora kroni?
  * ... mazākā daļa **[aleutu](https://lv.wikipedia.org/wiki/Aleuti "Aleuti")** runā aleutu valodā, bet lielākoties tie lieto [angļu valodu](https://lv.wikipedia.org/wiki/Ang%C4%BCu_valoda "Angļu valoda"), kā arī [krievu](https://lv.wikipedia.org/wiki/Krievu_valoda "Krievu valoda") valodu [Krievijas](https://lv.wikipedia.org/wiki/Krievija "Krievija") [Kamčatkas novadā](https://lv.wikipedia.org/wiki/Kam%C4%8Datkas_novads "Kamčatkas novads")?


  * ... tā kā [ASV](https://lv.wikipedia.org/wiki/Amerikas_Savienot%C4%81s_Valstis "Amerikas Savienotās Valstis") tāla darbības rādiusa raķete _**[Tomahawk](https://lv.wikipedia.org/wiki/Tomahawk "Tomahawk")**_ lido ar zemskaņas ātrumu, nevar manevrēt ar lielu pārslodzi un nevar izmantot mānekļus, to var iznīcināt modernas [pretgaisa](https://lv.wikipedia.org/wiki/Pretgaisa_aizsardz%C4%ABba "Pretgaisa aizsardzība") un pretraķešu aizsardzības sistēmas?
  * ... **[Reihstāga dedzināšanai](https://lv.wikipedia.org/wiki/Reihst%C4%81ga_dedzin%C4%81%C5%A1ana "Reihstāga dedzināšana")** [1933. gada](https://lv.wikipedia.org/wiki/1933._gads "1933. gads") 27. februārī bija liela nozīme [nacistu](https://lv.wikipedia.org/wiki/Nacisti "Nacisti") varas nostiprināšanā [Vācijā](https://lv.wikipedia.org/wiki/Tre%C5%A1ais_reihs "Trešais reihs"); saskaņā ar oficiālo versiju dedzināšanu bija sarīkojis holandiešu [komunists](https://lv.wikipedia.org/wiki/Komunisms "Komunisms") Marinuss van der Lube, par ko viņam tika piespriests [nāvessods](https://lv.wikipedia.org/wiki/N%C4%81vessods "Nāvessods")?
  * ... **[Jaunzēlandes demogrāfija](https://lv.wikipedia.org/wiki/Jaunz%C4%93landes_demogr%C4%81fija "Jaunzēlandes demogrāfija")** ir unikāla [Rietumu pasaulē](https://lv.wikipedia.org/wiki/Rietumu_pasaule "Rietumu pasaule") ar tās iedzīvotāju augsto etniski jaukto [laulību](https://lv.wikipedia.org/wiki/Laul%C4%ABbas "Laulības") līmeni?

  
[![Krievijas 2022. gada iebrukums Ukrainā](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/2022_Russian_invasion_of_Ukraine.svg/250px-2022_Russian_invasion_of_Ukraine.svg.png)](https://lv.wikipedia.org/wiki/Krievijas_2022._gada_iebrukums_Ukrain%C4%81 "Krievijas 2022. gada iebrukums Ukrainā")Krievijas 2022. gada iebrukums Ukrainā **[Krievijas 2022. gada iebrukums Ukrainā](https://lv.wikipedia.org/wiki/Krievijas_uzbrukums_Ukrainai_\(kop%C5%A1_2022._gada\) "Krievijas uzbrukums Ukrainai \(kopš 2022. gada\)")** ir Krievijas—Ukrainas kara plaša mēroga militāra operācija, ko 24. februāra rītā pēc [Krievijas prezidenta](https://lv.wikipedia.org/wiki/Krievijas_Feder%C4%81cijas_prezidents "Krievijas Federācijas prezidents") [Vladimira Putina](https://lv.wikipedia.org/wiki/Vladimirs_Putins "Vladimirs Putins") pavēles uzsāka [Krievijas Bruņotie spēki](https://lv.wikipedia.org/wiki/Krievijas_Feder%C4%81cijas_Bru%C5%86otie_sp%C4%93ki "Krievijas Federācijas Bruņotie spēki"), kas kopš 2021. gada marta [lielā skaitā bija izvietoti](https://lv.wikipedia.org/wiki/Krievijas%E2%80%94Ukrainas%E2%80%94NATO_kr%C4%ABze_\(kop%C5%A1_2021\) "Krievijas—Ukrainas—NATO krīze \(kopš 2021\)") netālu no Ukrainas robežas ar Krieviju, Baltkrieviju un [Krievijas 2014. gadā okupēto](https://lv.wikipedia.org/wiki/Krimas_okup%C4%81cija "Krimas okupācija") [Krimu](https://lv.wikipedia.org/wiki/Krima "Krima"). Operāciju ievadīja Krievijas Bruņoto spēku atklāta ievešana pašpasludināto [Doneckas](https://lv.wikipedia.org/wiki/Doneckas_tautas_republika "Doneckas tautas republika") un [Luhanskas](https://lv.wikipedia.org/wiki/Luhanskas_tautas_republika "Luhanskas tautas republika") tautas republiku teritorijā 2022. gada 21. februārī, un to neatkarības atzīšana visa [Doneckas](https://lv.wikipedia.org/wiki/Doneckas_apgabals "Doneckas apgabals") un [Luhanskas apgabala](https://lv.wikipedia.org/wiki/Luhanskas_apgabals "Luhanskas apgabals") robežās dienu vēlāk.  24. februārī plkst. 5.50 pēc [Maskavas](https://lv.wikipedia.org/wiki/Maskava "Maskava") laika ([UTC+3](https://lv.wikipedia.org/wiki/UTC%2B3 "UTC+3")) Putins izsludināja vispārēju [iebrukumu](https://lv.wikipedia.org/wiki/Iebrukums "Iebrukums") Ukrainā kā "īpašu militāru operāciju" ar mērķi "panākt Ukrainas demilitarizāciju un denacifikāciju". 10 minūtes vēlāk Krievijas Bruņotie spēki veica raķešu triecienus lidostām un militārajiem objektiem [Kijivā](https://lv.wikipedia.org/wiki/Kijiva "Kijiva"), [Harkivā](https://lv.wikipedia.org/wiki/Harkiva "Harkiva") un [Dņipro](https://lv.wikipedia.org/wiki/D%C5%86ipro "Dņipro") un sāka virzīties dziļāk Ukrainas teritorijā. Vienlaikus [Doneckas](https://lv.wikipedia.org/wiki/Doneckas_tautas_republika "Doneckas tautas republika") un [Luhanskas](https://lv.wikipedia.org/wiki/Luhanskas_tautas_republika "Luhanskas tautas republika") tautas republiku bruņotie formējumi visā Donbasa frontes līnijā atsāka karadarbību pret Ukrainas Bruņotajiem spēkiem un vairākās vietās pārgāja uzbrukumā.  [**Lasīt vairāk...**](https://lv.wikipedia.org/wiki/Krievijas_uzbrukums_Ukrainai_\(kop%C5%A1_2022._gada\) "Krievijas uzbrukums Ukrainai \(kopš 2022. gada\)")  
|  |   
---  
[![Džeimsa Armisteda cilnis slimnīcas fasādē](https://upload.wikimedia.org/wikipedia/lv/thumb/1/12/Armitsteda_slimn_cilnis.JPG/250px-Armitsteda_slimn_cilnis.JPG)](https://lv.wikipedia.org/wiki/Att%C4%93ls:Armitsteda_slimn_cilnis.JPG "Džeimsa Armisteda cilnis slimnīcas fasādē")
  * [1574](https://lv.wikipedia.org/wiki/1574._gads "1574. gads"). — neveiksmi cieta [Spānijas](https://lv.wikipedia.org/wiki/Sp%C4%81nija "Spānija") mēģinājums aplenkt [Leideni](https://lv.wikipedia.org/wiki/Leidene "Leidene") [Nīderlandē](https://lv.wikipedia.org/wiki/N%C4%ABderlande "Nīderlande"): vētras izraisītie plūdi pārrāva netālu esošos dambjus un aizskaloja 20 000 spāņu karavīru.
  * [1865](https://lv.wikipedia.org/wiki/1865._gads "1865. gads"). — [Latgalē](https://lv.wikipedia.org/wiki/Latgale "Latgale") stājās spēkā [latīņu drukas aizliegums](https://lv.wikipedia.org/wiki/Lat%C4%AB%C5%86u_drukas_aizliegums_Latgal%C4%93 "Latīņu drukas aizliegums Latgalē"), aizsākot cara valdības [pārkrievošanas](https://lv.wikipedia.org/wiki/P%C4%81rkrievo%C5%A1ana "Pārkrievošana") politiku.
  * [1870](https://lv.wikipedia.org/wiki/1870._gads "1870. gads"). — [Romā](https://lv.wikipedia.org/wiki/Roma "Roma") notika plebiscīts, pēc kura Roma un [Latija](https://lv.wikipedia.org/wiki/Lacio "Lacio") tika pievienota [Itālijas Karalistei](https://lv.wikipedia.org/wiki/It%C4%81lijas_Karaliste_\(1861%E2%80%941946\) "Itālijas Karaliste \(1861—1946\)").
  * [1899](https://lv.wikipedia.org/wiki/1899._gads_Latvij%C4%81 "1899. gads Latvijā"). — [Rīgā](https://lv.wikipedia.org/wiki/R%C4%ABga "Rīga"), [Torņakalnā](https://lv.wikipedia.org/wiki/Tor%C5%86akalns "Torņakalns") atklāja par [Džeimsa Armisteda](https://lv.wikipedia.org/wiki/D%C5%BEeimss_Armitsteds "Džeimss Armitsteds") atstāto mantojumu uzcelto pirmo [bērnu klīnisko slimnīcu](https://lv.wikipedia.org/wiki/B%C4%93rnu_kl%C4%ABnisk%C4%81_universit%C4%81tes_slimn%C4%ABca "Bērnu klīniskā universitātes slimnīca") (attēlā).
  * [1990](https://lv.wikipedia.org/wiki/1990._gads "1990. gads"). — beidza pastāvēt [Vācijas Demokrātiskā Republika](https://lv.wikipedia.org/wiki/V%C4%81cijas_Demokr%C4%81tisk%C4%81_Republika "Vācijas Demokrātiskā Republika").

Vairāk notikumu: [1. oktobrī](https://lv.wikipedia.org/wiki/1._oktobris "1. oktobris") — **[2. oktobrī](https://lv.wikipedia.org/wiki/2._oktobris "2. oktobris")** — [3. oktobrī](https://lv.wikipedia.org/wiki/3._oktobris "3. oktobris") **[Arhīvs](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Izmekl%C4%93ti_notikumi/Oktobris "Vikipēdija:Izmeklēti notikumi/Oktobris")** Šobrīd ir [2025](https://lv.wikipedia.org/wiki/2025._gads "2025. gads"). gada [2. oktobris](https://lv.wikipedia.org/wiki/2._oktobris "2. oktobris") ([UTC](https://lv.wikipedia.org/wiki/Univers%C4%81lais_koordin%C4%93tais_laiks "Universālais koordinētais laiks")) – [Atjaunināt lapu](https://lv.wikipedia.org/w/index.php?title=S%C4%81kumlapa&action=purge)  
## Izveido rakstu  
  

  * [Raksta izveidošana](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Raksta_izveido%C5%A1ana "Vikipēdija:Raksta izveidošana")
  * [Rakstu vednis](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Rakstu_vednis "Vikipēdija:Rakstu vednis")
  * [Iedvesmai](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Vajadz%C4%ABgo_rakstu_lapu_uzskait%C4%ABjums "Vikipēdija:Vajadzīgo rakstu lapu uzskaitījums")
  * [Smilšu kaste eksperimentiem](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Smil%C5%A1u_kaste "Vikipēdija:Smilšu kaste")
  * [Dalībnieku uzvedības noteikumi](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Dal%C4%ABbnieku_uzved%C4%ABbas_noteikumi "Vikipēdija:Dalībnieku uzvedības noteikumi")
  * [Administrācija](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Administr%C4%81cija "Vikipēdija:Administrācija")

  
## [Vikikrātuves dienas attēls](https://commons.wikimedia.org/wiki/Commons:Picture_of_the_day "commons:Commons:Picture of the day")  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg/330px-Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)](https://lv.wikipedia.org/wiki/Att%C4%93ls:Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)  
| Vikipēdija ir pieejama arī [citās valodās](https://meta.wikimedia.org/wiki/Complete_list_of_language_Wikipedias_available "m:Complete list of language Wikipedias available"), to skaitā:   
---  
[Eesti](https://et.wikipedia.org/wiki/ "et:") |  [Lietuvių](https://lt.wikipedia.org/wiki/ "lt:") |  [Latgaļu](https://ltg.wikipedia.org/wiki/ "ltg:") |  [Līvõ](https://incubator.wikimedia.org/wiki/Wp/liv/Kuodl%C4%93%E1%B8%91 "incubator:Wp/liv/Kuodlēḑ") |  [Võro](https://fiu-vro.wikipedia.org/wiki/ "fiu-vro:") |  [Žemaitiu](https://bat-smg.wikipedia.org/wiki/ "bat-smg:") |  [Українська](https://uk.wikipedia.org/wiki/ "uk:") |  [Français](https://fr.wikipedia.org/wiki/ "fr:") |  [Deutsch](https://de.wikipedia.org/wiki/ "de:") |  [English](https://en.wikipedia.org/wiki/ "en:")  
---|---|---|---|---|---|---|---|---|---  
Vikipēdija ir bezpeļņas organizācijas _[Wikimedia Foundation](https://lv.wikipedia.org/wiki/Wikimedia_Foundation "Wikimedia Foundation")_ projekts, kas saistīts arī ar vairākiem citiem [brīvi pieejama satura](https://en.wikipedia.org/wiki/Wikipedia:Copyrights "w:Wikipedia:Copyrights") projektiem:
[![Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/ "Commons")
[**Commons**](https://commons.wikimedia.org/wiki/S%C4%81kumlapa "commons:Sākumlapa")  
Kopīga multimediju krātuve 
[![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/ "MediaWiki")
**[MediaWiki](https://mediawiki.org/)**   
_wiki_ programmatūras izstrāde 
[![Meta-Wiki](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/ "Meta-Wiki")
[**Meta-Wiki**](https://meta.wikimedia.org/wiki/ "meta:")  
 _[Wikimedia Foundation](https://lv.wikipedia.org/wiki/Wikimedia_Foundation "Wikimedia Foundation")_ projektu koordinēšana 
[![Wikibooks](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://incubator.wikimedia.org/wiki/Wb/lv/S%C4%81kumlapa "Wikibooks")
[**Wikibooks**](https://incubator.wikimedia.org/wiki/Wb/lv/S%C4%81kumlapa "incubator:Wb/lv/Sākumlapa")  
Rokasgrāmatas un pamācības 
[![Wikidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "Wikidata")
[**Wikidata**](https://www.wikidata.org/wiki/ "d:")  
Brīva zinību bāze 
[![Wikiquote](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://incubator.wikimedia.org/wiki/Wq/lv/S%C4%81kumlapa "Wikiquote")
[**Wikiquote**](https://incubator.wikimedia.org/wiki/Wq/lv/S%C4%81kumlapa "incubator:Wq/lv/Sākumlapa")  
Citātu kolekcija 
[![Wikisource](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://wikisource.org/wiki/Main_Page:Latvian "Wikisource")
[**Wikisource**](https://wikisource.org/wiki/Main_Page:Latvian "oldwikisource:Main Page:Latvian")  
 _Free source_ dokumenti 
[![Wikivoyage](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://incubator.wikimedia.org/wiki/Wy/lv/S%C4%81kumlapa "Wikivoyage")
[**Wikivoyage**](https://incubator.wikimedia.org/wiki/Wy/lv/S%C4%81kumlapa "incubator:Wy/lv/Sākumlapa")  
Ceļvedis 
[![Wiktionary](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)](https://lv.wiktionary.org/wiki/lv:S%C4%81kumlapa "Wiktionary")
[**Wiktionary**](https://lv.wiktionary.org/wiki/lv:S%C4%81kumlapa "wikt:lv:Sākumlapa")  
Vārdnīca   
Saturs iegūts no "[https://lv.wikipedia.org/w/index.php?title=Sākumlapa&oldid=3673304](https://lv.wikipedia.org/w/index.php?title=S%C4%81kumlapa&oldid=3673304)"
37 valodas
  * [العربية](https://ar.wikipedia.org/wiki/ "arābu")
  * [Беларуская](https://be.wikipedia.org/wiki/ "baltkrievu")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/ "Belarusian \(Taraškievica orthography\)")
  * [Català](https://ca.wikipedia.org/wiki/ "katalāņu")
  * [Čeština](https://cs.wikipedia.org/wiki/ "čehu")
  * [Dansk](https://da.wikipedia.org/wiki/ "dāņu")
  * [Deutsch](https://de.wikipedia.org/wiki/ "vācu")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "grieķu")
  * [English](https://en.wikipedia.org/wiki/ "angļu")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "esperanto")
  * [Español](https://es.wikipedia.org/wiki/ "spāņu")
  * [Eesti](https://et.wikipedia.org/wiki/ "igauņu")
  * [فارسی](https://fa.wikipedia.org/wiki/ "persiešu")
  * [Suomi](https://fi.wikipedia.org/wiki/ "somu")
  * [Français](https://fr.wikipedia.org/wiki/ "franču")
  * [עברית](https://he.wikipedia.org/wiki/ "ivrits")
  * [Magyar](https://hu.wikipedia.org/wiki/ "ungāru")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "indonēziešu")
  * [Italiano](https://it.wikipedia.org/wiki/ "itāļu")
  * [日本語](https://ja.wikipedia.org/wiki/ "japāņu")
  * [한국어](https://ko.wikipedia.org/wiki/ "korejiešu")
  * [Latina](https://la.wikipedia.org/wiki/ "latīņu")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "lietuviešu")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/ "Latgalian")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "holandiešu")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "norvēģu bukmols")
  * [Polski](https://pl.wikipedia.org/wiki/ "poļu")
  * [Português](https://pt.wikipedia.org/wiki/ "portugāļu")
  * [Română](https://ro.wikipedia.org/wiki/ "rumāņu")
  * [Русский](https://ru.wikipedia.org/wiki/ "krievu")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "slovāku")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "serbu")
  * [Svenska](https://sv.wikipedia.org/wiki/ "zviedru")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "turku")
  * [Українська](https://uk.wikipedia.org/wiki/ "ukraiņu")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vjetnamiešu")
  * [中文](https://zh.wikipedia.org/wiki/ "ķīniešu")


  * Šī lapa pēdējoreiz labota: 2022. gada 21. augusts plkst. 10.00.
  * Teksts ir pieejams saskaņā ar [Creative Commons Attribution/Share-Alike licenci](https://creativecommons.org/licenses/by-sa/4.0/); var pastāvēt papildu ierobežojumi. Plašākai informācijai skatīt [lietošanas noteikumus](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Lieto%C5%A1anas_noteikumi "Vikipēdija:Lietošanas noteikumi").


  * [Privātuma politika](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Par Vikipēdiju](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Par)
  * [Saistību atrunas](https://lv.wikipedia.org/wiki/Vikip%C4%93dija:Saist%C4%ABbu_atrunas)
  * [Uzvedības kodekss](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Izstrādātāji](https://developer.wikimedia.org)
  * [Statistika](https://stats.wikimedia.org/#/lv.wikipedia.org)
  * [Sīkdatņu deklarācija](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Mobilais skats](https://lv.m.wikipedia.org/w/index.php?title=S%C4%81kumlapa&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://lv.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://lv.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Meklēt
Meklēt
Sākumlapa
[](https://lv.wikipedia.org/wiki/S%C4%81kumlapa) [](https://lv.wikipedia.org/wiki/S%C4%81kumlapa) [](https://lv.wikipedia.org/wiki/S%C4%81kumlapa) [](https://lv.wikipedia.org/wiki/S%C4%81kumlapa) [](https://lv.wikipedia.org/wiki/S%C4%81kumlapa) [](https://lv.wikipedia.org/wiki/S%C4%81kumlapa) [](https://lv.wikipedia.org/wiki/S%C4%81kumlapa) [](https://lv.wikipedia.org/wiki/S%C4%81kumlapa)
37 valodas [Jauna sadaļa ](https://lv.wikipedia.org/wiki/S%C4%81kumlapa)
