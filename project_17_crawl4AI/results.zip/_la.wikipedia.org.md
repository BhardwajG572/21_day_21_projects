[Jump to content](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima#bodyContent)
Main menu
Main menu
move to sidebar hide
Navigatio 
  * [Pagina prima](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Ire ad paginam primam \[z\]")
  * [Novissima](https://la.wikipedia.org/wiki/Vicipaedia:Novissima "Eventus novissimi")
  * [Pagina fortuita](https://la.wikipedia.org/wiki/Specialis:Pagina_fortuita "Ire ad paginam fortuitam \[x\]")
  * [Categoriae](https://la.wikipedia.org/wiki/Categoria:Omnia)
  * [Nuper mutata](https://la.wikipedia.org/wiki/Specialis:Nuper_mutata "Index nuper mutatorum in hac vici \[r\]")
  * [Paginae speciales](https://la.wikipedia.org/wiki/Specialis:Paginae_speciales)


Communitas 
  * [Invitatio](https://la.wikipedia.org/wiki/Vicipaedia:Invitatio)
  * [Taberna](https://la.wikipedia.org/wiki/Vicipaedia:Taberna)
  * [Auxilium](https://la.wikipedia.org/wiki/Vicipaedia:Praefatio "Adiumentum ad hoc incepto utendum")


[ ![](https://la.wikipedia.org/static/images/icons/wikipedia.png) ![Vicipaedia](https://la.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-la.svg) ![Libera encyclopaedia](https://la.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-la.svg) ](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima)
[Quaerere ](https://la.wikipedia.org/wiki/Specialis:Quaerere "Quaerere apud Vicipaediam \[f\]")
Quaerere
Appearance
  * [Donationes](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=la.wikipedia.org&uselang=la)
  * [Sibi nomen imponere](https://la.wikipedia.org/w/index.php?title=Specialis:Rationem_creare&returnto=Vicipaedia%3APagina+prima "Suademus, ut nomen tibi imponas, neque cogeris")
  * [Nomen dare](https://la.wikipedia.org/w/index.php?title=Specialis:Conventum_aperire&returnto=Vicipaedia%3APagina+prima "Te nomen dare hortamur neque cogimus \[o\]")


Instrumenta personalia
  * [Donationes](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=la.wikipedia.org&uselang=la)
  * [Sibi nomen imponere](https://la.wikipedia.org/w/index.php?title=Specialis:Rationem_creare&returnto=Vicipaedia%3APagina+prima "Suademus, ut nomen tibi imponas, neque cogeris")
  * [Nomen dare](https://la.wikipedia.org/w/index.php?title=Specialis:Conventum_aperire&returnto=Vicipaedia%3APagina+prima "Te nomen dare hortamur neque cogimus \[o\]")


# Bene advenisti in Vicipaediam!
353 languages
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – Afarica")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – Abasca")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – Acehnese")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – Adyghe")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – Africana")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – Alemannic")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – Southern Altai")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – Amharica")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – Aragonensis")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – Old English")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – Obolo")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – Angika")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – Arabica")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – Aramaic")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – Moroccan Arabic")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – Egyptian Arabic")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – Assamica")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – Asturian")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – Atikamekw")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – Avaric")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – Awadhi")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – Aymara")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – Atropatenica")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – Bashkir")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Balinese")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – Bavarian")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – Samogitian")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Ruthenica Alba")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – Betawi")
  * [Български](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Начална страница – Bulgarica")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – Bislama")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – Bambara")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – Bengalica")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – Tibetana")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – Britonica")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – Bosnica")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – Buginese")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – Catalana")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – Chechen")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – Cebuano")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – Chamoruana")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – Choctaw")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – Cherokee")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – Cheyenne")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – Central Kurdish")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – Corsa")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – Cree")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – Crimean Tatar")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana – Bohemica")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – Kashubian")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – Slavonica antiqua")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – Chuvassica")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – Cambrica")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside – Danica")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – Germanica")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – Dinka")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – Lower Sorbian")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – Central Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – Dhivehi")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – Dzongkha")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – Ewe")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – Graeca")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – Anglica")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – Esperantica")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – Hispanica")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht – Estonica")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala – Vasconica")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – Extremaduran")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – Persica")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – Fanti")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – Fula")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – Finnica")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – Võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – Fijian")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – Faroensis")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – Fon")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal – Francogallica")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – Arpitan")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – Northern Frisian")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – Friulian")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – Western Frisian")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – Hibernica")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – Gagauz")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – Gan")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – Scotica")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – Gallaica")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – Gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – Guaranica")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – Gorontalo")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – Gothic")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – Gujaratensis")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – Wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – Monensis")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – Hausa")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – Hakka Chinese")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – Hawaiian")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – Hebraica")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – Hindica")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – Fiji Hindi")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – Hiri Motu")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – Croatica")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – Upper Sorbian")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Creolus Haitianus")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – Hungarica")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ – Armenica")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – Herero")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – Interlingua")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – Iban")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama – Indonesia")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – Interlingue")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – Igbonica")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – Inupiaq")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – Iloko")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – Ingush")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – Ido")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – Islandica")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – Italiana")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – Inuktitut")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – Iaponica")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – Jamaican Creole English")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – Lojban")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – Iavensis")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – Georgiana")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – Kara-Kalpak")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – Kabyle")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – Kabardian")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – Tyap")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – Kongo")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – Kikuyu")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – Kuanyama")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – Cazachica")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – Groenlandica")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – Chmerica")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – Cannadica")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – Coreana")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – Komi-Permyak")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – Kanuri")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – Karachay-Balkar")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – Casmirica")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – Colognian")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – Curdica")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – Komi")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – Cornubica")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – Chirgisica")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – Ladino")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – Luxemburgica")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – Lezghian")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – Ganda")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – Limburgica")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – Ligurian")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – Lombard")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – Lingala")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – Lao")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – Northern Luri")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – Lithuanica")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – Latgalian")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – Lettonica")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – Madurese")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – Maithili")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – Moksha")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – Malagasiana")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – Marshallese")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – Maoriana")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – Minangkabau")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – Macedonica")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – Malabarica")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – Mongolica")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – Manipuri")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – Mossi")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – Marathica")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – Western Mari")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – Malayana")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – Melitensis")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – Muscogee")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – Mirandese")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – Birmanica")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – Erzya")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – Mazanderani")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – Neapolitan")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – Low German")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – Low Saxon")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – Nepalensis")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – Newari")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – Ndonga")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – Nias")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina – Batava")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – Norwegian Nynorsk")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – Norwegian Bokmål")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – Novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – N’Ko")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – South Ndebele")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – Northern Sotho")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – Navajo")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – Nyanja")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – Occitana")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – Oromo")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – Orissensis")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – Ossetica")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – Panjabica")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – Pangasinan")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – Pampanga")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – Papiamento")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – Picard")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – Nigerian Pidgin")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – Pennsylvania German")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – Palatine German")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – Palica")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – Polonica")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – Piedmontese")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – Pontic")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – Afganica")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – Lusitana")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – Quechuae")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – Rhaetica")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – Rundi")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – Dacoromanica")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – Aromanian")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – Russica")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – Rusyn")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – Kinyarwanda")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – Sanscrita")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – Yakut")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – Santali")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – Sarda")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – Sicilian")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – Scots")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – Sindhuica")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – Samica septentrionalis")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – Sango")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – Serbo-Croatian")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – Tachelhit")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – Shan")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – Singhalensis")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – Slovaca")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – Slovena")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – Samoana")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – Inari Sami")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – Shona")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – Somalica")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – Albanica")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – Serbica")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – Sranan Tongo")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – Swati")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – Southern Sotho")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – Saterland Frisian")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – Sundanese")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – Suecica")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – Suahili")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – Silesian")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – Tamulica")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – Tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – Telingana")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – Tetum")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – Tadzikica")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – Thai")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – Tigrinya")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – Tigre")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – Turcomannica")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – Tagalog")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – Talysh")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – Tswana")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – Tongana")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – Tok Pisin")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – Turcica")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – Taroko")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – Tsonga")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – Tatarica")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – Tumbuka")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – Twi")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – Tahitian")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – Tuvinian")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – Udmurt")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – Uyghur")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – Ucrainica")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – Urdu")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – Uzbecica")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – Venda")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – Venetian")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – Veps")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – Vietnamica")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – West Flemish")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – Volapük")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – Walloon")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – Waray")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – Wolof")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – Wu")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – Kalmyk")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – Xhosa")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – Mingrelian")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – Iudaeogermanica")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – Yoruba")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – Zhuang")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – Zeelandic")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – Standard Moroccan Tamazight")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 – Sinica")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – Literary Chinese")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – Minnan")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – Cantonese")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – Zuluana")


[Nexus recensere](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Nexus inter linguas recensere")
  * [Pagina prima](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Videre paginam inceptorum \[c\]")
  * [Disputatio](https://la.wikipedia.org/wiki/Disputatio_Vicipaediae:Pagina_prima "Disputatio de hac pagina \[t\]")


Latina
  * [Legere](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima)
  * [Fontem inspicere](https://la.wikipedia.org/w/index.php?title=Vicipaedia:Pagina_prima&action=edit "Haec pagina protecta est. Inspicere quidem fontem licet. \[e\]")
  * [Historiam inspicere](https://la.wikipedia.org/w/index.php?title=Vicipaedia:Pagina_prima&action=history "Superiores huius paginae versiones \[h\]")


Instrumenta
Tools
move to sidebar hide
Actions 
  * [Legere](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima)
  * [Fontem inspicere](https://la.wikipedia.org/w/index.php?title=Vicipaedia:Pagina_prima&action=edit)
  * [Historiam inspicere](https://la.wikipedia.org/w/index.php?title=Vicipaedia:Pagina_prima&action=history)


General 
  * [Nexus ad paginam](https://la.wikipedia.org/wiki/Specialis:Nexus_ad_paginam/Vicipaedia:Pagina_prima "Index paginarum quae hic nectunt \[j\]")
  * [Nuper mutata annexorum](https://la.wikipedia.org/wiki/Specialis:Nuper_mutata_annexorum/Vicipaedia:Pagina_prima "Nuper mutata in paginis quibus haec pagina nectit \[k\]")
  * [Fasciculum imponere](https://commons.wikimedia.org/wiki/Special:UploadWizard?uselang=la "Fasciculos imponere \[u\]")
  * [Nexus perpetuus](https://la.wikipedia.org/w/index.php?title=Vicipaedia:Pagina_prima&oldid=3872691 "Nexus perpetuus ad hanc paginae redactionem")
  * [De hac pagina](https://la.wikipedia.org/w/index.php?title=Vicipaedia:Pagina_prima&action=info "More information about this page")
  * [Get shortened URL](https://la.wikipedia.org/w/index.php?title=Specialis:UrlShortener&url=https%3A%2F%2Fla.wikipedia.org%2Fwiki%2FVicipaedia%3APagina_prima)
  * [Download QR code](https://la.wikipedia.org/w/index.php?title=Specialis:QrCode&url=https%3A%2F%2Fla.wikipedia.org%2Fwiki%2FVicipaedia%3APagina_prima)


Imprimere vel exportare 
  * [Librum creare](https://la.wikipedia.org/w/index.php?title=Specialis:Book&bookcmd=book_creator&referer=Vicipaedia%3APagina+prima)
  * [Paginam prehendere formá PDF](https://la.wikipedia.org/w/index.php?title=Specialis:DownloadAsPdf&page=Vicipaedia%3APagina_prima&action=show-download-screen)
  * [Forma impressibilis](https://la.wikipedia.org/w/index.php?title=Vicipaedia:Pagina_prima&printable=yes "Forma impressibilis huius paginae \[p\]")


Inceptis aliis 
  * [Vicimedia Communia](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Vicispecies](https://species.wikimedia.org/wiki/Main_Page)
  * [Vicilibri](https://la.wikibooks.org/wiki/Pagina_prima)
  * [Vicidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Vicicitatio](https://la.wikiquote.org/wiki/Pagina_prima)
  * [Vicifons](https://la.wikisource.org/wiki/Pagina_prima)
  * [Victionarium](https://la.wiktionary.org/wiki/Victionarium:Pagina_prima)
  * [Res Wikidata](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Nexus ad rem repositorii Vicibasis \[g\]")


Appearance
move to sidebar hide
E Vicipaedia
Vicipaedia est libera [encyclopaedia](https://la.wikipedia.org/wiki/Encyclopaedia "Encyclopaedia"), ad quam augendam [omnes invitantur](https://la.wikipedia.org/wiki/Vicipaedia:Salve "Vicipaedia:Salve").
[Mercurii](https://la.wikipedia.org/wiki/Dies_Mercurii "Dies Mercurii") die [1 mensis Octobris](https://la.wikipedia.org/wiki/1_Octobris "1 Octobris") [2025](https://la.wikipedia.org/wiki/2025 "2025").  
[140 573](https://la.wikipedia.org/wiki/Specialis:Census "Specialis:Census") [paginarum](https://la.wikipedia.org/wiki/Specialis:Paginae_omnes "Specialis:Paginae omnes") Latine scriptarum.
Ars & litterae
  * [Litterae](https://la.wikipedia.org/wiki/Litterae "Litterae")
  * [Ars](https://la.wikipedia.org/wiki/Ars "Ars")
    * [Bellae artes](https://la.wikipedia.org/wiki/Bellae_artes "Bellae artes")
      * [Architectura](https://la.wikipedia.org/wiki/Architectura "Architectura")
      * [Musica](https://la.wikipedia.org/wiki/Musica "Musica")
      * [Poësis](https://la.wikipedia.org/wiki/Po%C3%ABsis "Poësis")
      * [Cinematographia](https://la.wikipedia.org/wiki/Cinematographia "Cinematographia")
      * [Photographia](https://la.wikipedia.org/wiki/Photographia "Photographia")
      * [Drama](https://la.wikipedia.org/wiki/Drama_\(fictio\) "Drama \(fictio\)")
      * [Saltatio](https://la.wikipedia.org/wiki/Saltatio "Saltatio")
      * [Sculptura](https://la.wikipedia.org/wiki/Sculptura "Sculptura")
      * [Pictura](https://la.wikipedia.org/wiki/Pictura "Pictura")
    * [Artes liberales](https://la.wikipedia.org/wiki/Artes_liberales "Artes liberales")


Scientia
  * [Res principalis](https://la.wikipedia.org/wiki/Scientia_\(ratio\) "Scientia \(ratio\)")


Empirica rei naturalis:
  * [Astronomia](https://la.wikipedia.org/wiki/Astronomia "Astronomia")
  * [Biologia](https://la.wikipedia.org/wiki/Biologia "Biologia")
  * [Chemia](https://la.wikipedia.org/wiki/Chemia "Chemia")
  * [Geographia](https://la.wikipedia.org/wiki/Geographia "Geographia")
  * [Geologia](https://la.wikipedia.org/wiki/Geologia "Geologia")
  * [Medicina](https://la.wikipedia.org/wiki/Medicina "Medicina")
  * [Physica](https://la.wikipedia.org/wiki/Physica "Physica")


Axiomatica:
  * [Logica](https://la.wikipedia.org/wiki/Logica "Logica")
  * [Mathematica](https://la.wikipedia.org/wiki/Mathematica "Mathematica")


Rei humanae:
  * [Anthropologia](https://la.wikipedia.org/wiki/Anthropologia "Anthropologia")
  * [Archaeologia](https://la.wikipedia.org/wiki/Archaeologia "Archaeologia")
  * [Civilitas](https://la.wikipedia.org/wiki/Civilitas "Civilitas")
  * [Historia](https://la.wikipedia.org/wiki/Historia "Historia")
  * [Ius](https://la.wikipedia.org/wiki/Ius "Ius")
  * [Linguistica](https://la.wikipedia.org/wiki/Linguistica "Linguistica")
  * [Oeconomia](https://la.wikipedia.org/wiki/Oeconomia "Oeconomia")
  * [Philologia](https://la.wikipedia.org/wiki/Philologia "Philologia")
  * [Philosophia](https://la.wikipedia.org/wiki/Philosophia "Philosophia")
  * [Psychologia](https://la.wikipedia.org/wiki/Psychologia "Psychologia")
  * [Scientia mediorum](https://la.wikipedia.org/wiki/Scientia_mediorum "Scientia mediorum")
  * [Scientia religionum](https://la.wikipedia.org/wiki/Scientia_religionum "Scientia religionum")
  * [Sociologia](https://la.wikipedia.org/wiki/Sociologia "Sociologia")


Arcana:
  * [Astrologia](https://la.wikipedia.org/wiki/Astrologia "Astrologia")
  * [Theologia](https://la.wikipedia.org/wiki/Theologia "Theologia")


Societas
  * [Res principalis](https://la.wikipedia.org/wiki/Societas_humana "Societas humana")
  * [Calendarium](https://la.wikipedia.org/wiki/Calendarium "Calendarium")
  * [Civilitas](https://la.wikipedia.org/wiki/Civilitas "Civilitas")
  * [Ecclesia](https://la.wikipedia.org/wiki/Ecclesia "Ecclesia")
  * [Geopolitica](https://la.wikipedia.org/wiki/Opus:Geopoliticum "Opus:Geopoliticum")
  * [Homines clari](https://la.wikipedia.org/wiki/Categoria:Homines "Categoria:Homines")
  * [Linguae mundi](https://la.wikipedia.org/wiki/Linguae_mundi "Linguae mundi")
  * [Ludus](https://la.wikipedia.org/wiki/Ludus "Ludus")
  * [Ludus athleticus](https://la.wikipedia.org/wiki/Ludus_athleticus "Ludus athleticus")
  * [Mythologia](https://la.wikipedia.org/wiki/Mythologia "Mythologia")
  * [Nationes mundi](https://la.wikipedia.org/wiki/Nationes_mundi "Nationes mundi")
  * [Religio](https://la.wikipedia.org/wiki/Religio "Religio")
  * [Res militaris](https://la.wikipedia.org/wiki/Res_militaris "Res militaris")
  * [Collegia](https://la.wikipedia.org/wiki/Collegium_\(ius\) "Collegium \(ius\)")
  * [Universitates](https://la.wikipedia.org/wiki/Universitas "Universitas")


Technologia
  * [Res principalis](https://la.wikipedia.org/wiki/Technologia "Technologia")
  * [Ars ingeniaria](https://la.wikipedia.org/wiki/Ars_ingeniaria "Ars ingeniaria")
  * [Agricultura](https://la.wikipedia.org/wiki/Agricultura "Agricultura")
  * [Computatra](https://la.wikipedia.org/wiki/Computatrum "Computatrum")
  * [Electronica](https://la.wikipedia.org/wiki/Electronica "Electronica")
  * [Informatica](https://la.wikipedia.org/wiki/Informatica "Informatica")
  * [Interrete](https://la.wikipedia.org/wiki/Interrete "Interrete")
  * [Vehicula](https://la.wikipedia.org/wiki/Vehiculum "Vehiculum")


Lingua Latina
  * [Res principalis](https://la.wikipedia.org/wiki/Lingua_Latina "Lingua Latina")
  * [Institutiones](https://la.wikipedia.org/wiki/Institutiones_Latinae "Institutiones Latinae")
  * [Latinitas](https://la.wikipedia.org/wiki/Latinitas_viva "Latinitas viva")
  * [Lexica](https://la.wikipedia.org/wiki/Lexicon "Lexicon")
  * [Libri](https://la.wikipedia.org/wiki/Libri_Latini "Libri Latini")
  * [Sententiae](https://la.wikipedia.org/wiki/Sententia_\(gnome\) "Sententia \(gnome\)")
  * [Usus](https://la.wikipedia.org/wiki/Usus_Latinae_Linguae "Usus Latinae Linguae")
  * [Professores rerum classicarum](https://la.wikipedia.org/wiki/Categoria:Professores_rerum_Classicarum "Categoria:Professores rerum Classicarum")


Pagina cottidiana
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Bojanus_Ludwig_Heinrich_1776-1827.png/250px-Bojanus_Ludwig_Heinrich_1776-1827.png)](https://la.wikipedia.org/wiki/Fasciculus:Bojanus_Ludwig_Heinrich_1776-1827.png)
**[Ludovicus Henricus Bojanus](https://la.wikipedia.org/wiki/Ludovicus_Henricus_Bojanus "Ludovicus Henricus Bojanus")** ,  

[Medicus](https://la.wikipedia.org/wiki/Medicus "Medicus") [Germanicus](https://la.wikipedia.org/wiki/Germania "Germania") praesertim ob opera [zoologica](https://la.wikipedia.org/wiki/Zoologia "Zoologia") memoratus
[ad paginas priores percurrendas vel novas proponendas](https://la.wikipedia.org/wiki/Vicipaedia:Index_paginarum_cottidianarum "Vicipaedia:Index paginarum cottidianarum")
Pellicula mensis
_[Institutio Christianae Religionis](https://la.wikipedia.org/wiki/Institutio_Christianae_Religionis "Institutio Christianae Religionis")_ , Capiltulum primum, a [Joanne Calvino](https://la.wikipedia.org/wiki/Ioannes_Calvinus "Ioannes Calvinus").
_[Institutio Christianae Religionis](https://la.wikipedia.org/wiki/Institutio_Christianae_Religionis "Institutio Christianae Religionis")_ , Capiltulum primum, a [Joanne Calvino](https://la.wikipedia.org/wiki/Ioannes_Calvinus "Ioannes Calvinus"). 
[ad mensium pelliculas priores spectandas vel novas proponendas](https://la.wikipedia.org/wiki/Vicipaedia:Pellicula_mensis "Vicipaedia:Pellicula mensis")
Pagina mensis
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Berlin_Alexanderplatz_Berolina.jpg/250px-Berlin_Alexanderplatz_Berolina.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Berlin_Alexanderplatz_Berolina.jpg)Dea [Berolina](https://la.wikipedia.org/wiki/Berolina "Berolina") stat in foro Alexandri (_Alexanderplatz_)
**[Berolinum](https://la.wikipedia.org/wiki/Berolinum "Berolinum")** , (-i, _n._ ; [Theodisce](https://la.wikipedia.org/wiki/Theodisce "Theodisce") _[Berlin](https://de.wikipedia.org/wiki/Berlin "de:Berlin")_) est [urbs](https://la.wikipedia.org/wiki/Urbs "Urbs") maxima Germaniae, [caput](https://la.wikipedia.org/wiki/Caput_\(oppidum\) "Caput \(oppidum\)") [Rei publicae foederalis Germaniae](https://la.wikipedia.org/wiki/Germania "Germania"), caput etiam [Archidioecesis Berolinensis](https://la.wikipedia.org/wiki/Archidioecesis_Berolinensis "Archidioecesis Berolinensis"). Incolas (_Berolinenses_ appellatos) habet circa 3 500 000. Berolinum est et urbs et [terra foederalis](https://la.wikipedia.org/wiki/Terra_Foederalis_Germaniae "Terra Foederalis Germaniae") (_Land_) in duodecim [regiones](https://la.wikipedia.org/wiki/Regio "Regio") (_Bezirke_) divisa. Urbs circa annum [1230](https://la.wikipedia.org/wiki/1230 "1230") condita est. 
Haec urbs opulentissima habet universitates quattuor, odeia tria, orchestra symphonica duo, ecclesias, theatra, scholas, gymnasia, balnea innumera. Commercium fit per vias stratas et quidem [maximas](https://de.wikipedia.org/wiki/Stadtautobahn "de:Stadtautobahn"), per ferroviarium, per metropolitanam, per carros [omnibus](https://la.wikipedia.org/wiki/Omnibus "Omnibus") vehi volentibus accommodatos et vi aut electrica aut petrolei impulsos. 
Incolae originis [teutonicae](https://la.wikipedia.org/wiki/Germani "Germani") fidem aut nullam aut [Christianam](https://la.wikipedia.org/wiki/Christiani "Christiani") sectae [Lutheraneae](https://la.wikipedia.org/wiki/Martinus_Lutherus "Martinus Lutherus") maxima ex parte confitentur, [Polonicae](https://la.wikipedia.org/wiki/Polonia "Polonia"), quorum non pauci sunt, [catholicam](https://la.wikipedia.org/wiki/Ecclesia_Catholica "Ecclesia Catholica"), [Hebraicae](https://la.wikipedia.org/wiki/Populus_Iudaicus "Populus Iudaicus") [Iudaicam](https://la.wikipedia.org/wiki/Religio_Iudaica "Religio Iudaica"), [Turcicae](https://la.wikipedia.org/wiki/Turcia "Turcia") atque [Arabicae](https://la.wikipedia.org/wiki/Arabia "Arabia"), quorum forsitan vel plures, [Musulmanicam](https://la.wikipedia.org/wiki/Religio_Islamica "Religio Islamica").  

[ad mensium paginas priores inspiciendas vel novas proponendas](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_mensis "Vicipaedia:Pagina mensis")
Imago mensis
[![Bulla saponis in ramum abietis](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Frozen_soap_bubble_behind_fir_twigs_%28Unsplash_BojuZpqw4zM%29.jpg/330px-Frozen_soap_bubble_behind_fir_twigs_%28Unsplash_BojuZpqw4zM%29.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Frozen_soap_bubble_behind_fir_twigs_\(Unsplash_BojuZpqw4zM\).jpg "Bulla saponis in ramum abietis")[Bulla](https://la.wikipedia.org/wiki/Bulla "Bulla") [saponis](https://la.wikipedia.org/wiki/Sapo "Sapo") in ramum [abietis](https://la.wikipedia.org/wiki/Abies "Abies")
[Bulla](https://la.wikipedia.org/wiki/Bulla "Bulla") [saponis](https://la.wikipedia.org/wiki/Sapo "Sapo") in ramum [abietis](https://la.wikipedia.org/wiki/Abies "Abies")
[ad mensium imagines priores inspiciendas vel novas proponendas](https://la.wikipedia.org/wiki/Vicipaedia:Imago_mensis "Vicipaedia:Imago mensis")
Nuntii
  * 30 Iulii: [Terrae motus](https://la.wikipedia.org/wiki/Terrae_motus "Terrae motus") magnitudinis 8.8 litora [Camtschatcae](https://la.wikipedia.org/wiki/Camtschatca "Camtschatca") et [insularum Curilensium](https://la.wikipedia.org/wiki/Curiles "Curiles") concutit; [portus](https://la.wikipedia.org/wiki/Portus "Portus") Urbis Curilensis Borealis (_Severo-Kuril'sk_) [megacymate](https://la.wikipedia.org/wiki/Megacyma "Megacyma") devastatur. Mense Augusto ineunte post terrae motum [mons Fontinalis](https://la.wikipedia.org/wiki/Mons_Fontinalis "Mons Fontinalis") et [mons Krascheninnikovii](https://la.wikipedia.org/wiki/Mons_Krascheninnikovii "Mons Krascheninnikovii") erumpunt.
  * 22 Iunii: [Civitates Foederatae Americae](https://la.wikipedia.org/wiki/Civitates_Foederatae_Americae "Civitates Foederatae Americae") iussu praesidis [Donaldi Trump](https://la.wikipedia.org/wiki/Donaldus_Trump "Donaldus Trump") in [Irania](https://la.wikipedia.org/wiki/Irania "Irania") officinas uranii subterraneas telis bombisque explosivis devastant.
  * 15 Maii: [Grex septem civitatum (G 7)](https://la.wikipedia.org/wiki/G8 "G8") in Canada convenit.
  * 13 Maii: [Israel](https://la.wikipedia.org/wiki/Israel "Israel") [Iraniam](https://la.wikipedia.org/wiki/Irania "Irania") ex aëre late aggreditur, quo bellum inter has civitates incipit.
  * 12 Maii: [Amedebati](https://la.wikipedia.org/wiki/Amedebatum "Amedebatum") in India aeroplanum vix profectum in domos cadit et plus quam ducentos homines necat.

[![Leo XIV](https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Leo_XIV_%28june_2025%29.jpg/120px-Leo_XIV_%28june_2025%29.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Leo_XIV_\(june_2025\).jpg "Leo XIV")[Leo XIV](https://la.wikipedia.org/wiki/Leo_XIV "Leo XIV")
  * 8 Maii: [Leo XIV](https://la.wikipedia.org/wiki/Leo_XIV "Leo XIV") (natus Robertus Franciscus Prevost) pontifex eligitur.

[![Fridericus Merz](https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/2025-05-05_Unterzeichnung_des_Koalitionsvertrages_der_21._Wahlperiode_des_Bundestages_by_Sandro_Halank%E2%80%93007.jpg/120px-2025-05-05_Unterzeichnung_des_Koalitionsvertrages_der_21._Wahlperiode_des_Bundestages_by_Sandro_Halank%E2%80%93007.jpg)](https://la.wikipedia.org/wiki/Fasciculus:2025-05-05_Unterzeichnung_des_Koalitionsvertrages_der_21._Wahlperiode_des_Bundestages_by_Sandro_Halank%E2%80%93007.jpg "Fridericus Merz")[Fridericus Merz](https://la.wikipedia.org/wiki/Fridericus_Merz "Fridericus Merz")
  * 6 Maii: [Fridericus Merz](https://la.wikipedia.org/wiki/Fridericus_Merz "Fridericus Merz") [cancellarius foederalis](https://la.wikipedia.org/wiki/Cancellarius_foederalis "Cancellarius foederalis") [Germaniae](https://la.wikipedia.org/wiki/Germania "Germania") eligitur.

[![Franciscus mense Iunio 2024](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Pope_Francis%2C_June_2024_%28cropped%29.jpg/120px-Pope_Francis%2C_June_2024_%28cropped%29.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Pope_Francis,_June_2024_\(cropped\).jpg "Franciscus mense Iunio 2024")Franciscus mense Iunio 2024
  * 21 Aprilis: [Franciscus pontifex](https://la.wikipedia.org/wiki/Franciscus_\(papa\) "Franciscus \(papa\)") moritur.

[![Marius Vargas Llosa](https://upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Mario_Vargas_Llosa_%28crop_2%29.jpg/120px-Mario_Vargas_Llosa_%28crop_2%29.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Mario_Vargas_Llosa_\(crop_2\).jpg "Marius Vargas Llosa")[Marius Vargas Llosa](https://la.wikipedia.org/wiki/Marius_Vargas_Llosa "Marius Vargas Llosa")
  * 13 Aprilis: [Marius Vargas Llosa](https://la.wikipedia.org/wiki/Marius_Vargas_Llosa "Marius Vargas Llosa"), scriptor [Peruvianus](https://la.wikipedia.org/wiki/Peruvia "Peruvia"), moritur.

[![Expo 2025](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/EXPO2025_textlogo.svg/120px-EXPO2025_textlogo.svg.png)](https://la.wikipedia.org/wiki/Fasciculus:EXPO2025_textlogo.svg "Expo 2025")[Expo 2025](https://la.wikipedia.org/wiki/Expo_2025 "Expo 2025")
  * 12 Aprilis: Expositio mundana "[Expo 2025](https://la.wikipedia.org/wiki/Expo_2025 "Expo 2025")" [Osakae](https://la.wikipedia.org/wiki/Osaka "Osaka") in [Iaponia](https://la.wikipedia.org/wiki/Iaponia "Iaponia") patefit.
  * 28 Martii: [Terrae motus](https://la.wikipedia.org/wiki/Terrae_motus "Terrae motus") magnitudinis 7.7 circa [Sagaing](https://la.wikipedia.org/wiki/Sagaing "Sagaing"), urbem [Birmaniae](https://la.wikipedia.org/wiki/Birmania "Birmania"), factus usque ad [Bancocum](https://la.wikipedia.org/wiki/Bancocum "Bancocum"), caput [Thailandiae](https://la.wikipedia.org/wiki/Thailandia "Thailandia"), vastum damnum causat et multos homines necat.

[![Rodericus Duterte](https://upload.wikimedia.org/wikipedia/commons/thumb/5/54/Rody_duterte.jpg/120px-Rody_duterte.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Rody_duterte.jpg "Rodericus Duterte")[Rodericus Duterte](https://la.wikipedia.org/wiki/Rodericus_Duterte "Rodericus Duterte")
  * 11 Martii: [Rodericus Duterte](https://la.wikipedia.org/wiki/Rodericus_Duterte "Rodericus Duterte"), [Philippinarum](https://la.wikipedia.org/wiki/Philippinae "Philippinae") praeses pristinus, in [Manila](https://la.wikipedia.org/wiki/Manila "Manila") a [Tribunali criminali internationali](https://la.wikipedia.org/wiki/Tribunal_criminale_internationale "Tribunal criminale internationale") arreptus est.

[![Horstius Köhler](https://upload.wikimedia.org/wikipedia/commons/thumb/4/49/Koehlerhorst08032007.jpg/120px-Koehlerhorst08032007.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Koehlerhorst08032007.jpg "Horstius Köhler")[Horstius Köhler](https://la.wikipedia.org/wiki/Horstius_K%C3%B6hler "Horstius Köhler")
  * 1 Februarii: [Horstius Köhler](https://la.wikipedia.org/wiki/Horstius_K%C3%B6hler "Horstius Köhler"), pristinus [praeses foederalis Germaniae](https://la.wikipedia.org/wiki/Praeses_foederalis_Germaniae "Praeses foederalis Germaniae"), 81 annos natus moritur.

[![Iacobus Carter](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Jimmy_Carter_%281988%29.jpg/120px-Jimmy_Carter_%281988%29.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Jimmy_Carter_\(1988\).jpg "Iacobus Carter")[Iacobus Carter](https://la.wikipedia.org/wiki/Iacobus_Earl_Carter "Iacobus Earl Carter")
  * 29 Decembris: [Iacobus (_Jimmy_) Carter](https://la.wikipedia.org/wiki/Iacobus_Earl_Carter "Iacobus Earl Carter"), pristinus praeses Civitatum Foederatarum Americae centum annos natus moritur.

[![Speculatrum Parker Solar](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Parker_Solar_Probe.jpg/120px-Parker_Solar_Probe.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Parker_Solar_Probe.jpg "Speculatrum Parker Solar")Speculatrum _Parker Solar_
  * 24 Decembris: Ad celeritatem 700 000 chiliometrorum per horam [speculatrum spatiale](https://la.wikipedia.org/wiki/Speculatrum_spatiale "Speculatrum spatiale") [_Parker_](https://la.wikipedia.org/wiki/Parker_\(speculatrum_solare\) "Parker \(speculatrum solare\)") prope solis superficiem volat, tantum 6.1 decies centena milia chiliometrorum abducit superestque congressus extremi.

[![Forum Magdeburgense post trucidationem](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Gedenkort_an_der_Johanniskirche.jpg/120px-Gedenkort_an_der_Johanniskirche.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Gedenkort_an_der_Johanniskirche.jpg "Forum Magdeburgense post trucidationem")Forum Magdeburgense post trucidationem
  * 20 Decembris: [Magdeburgi](https://la.wikipedia.org/wiki/Magdeburgum "Magdeburgum") in Germania [medicus](https://la.wikipedia.org/wiki/Medicus "Medicus") quidam [Saudianus](https://la.wikipedia.org/wiki/Arabia_Saudita "Arabia Saudita") sex homines necat et plus quam 200 vulnerat autocineto per forum celebre currens.


[ad novos nuntios addendos](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima/Nuntii "Vicipaedia:Pagina prima/Nuntii")
Translatio hebdomadalis
[![Canonsburgum Pennsilvaniense anno 1897](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Map_of_Canonsburg_1897.jpg/250px-Map_of_Canonsburg_1897.jpg)](https://la.wikipedia.org/wiki/Fasciculus:Map_of_Canonsburg_1897.jpg "Canonsburgum Pennsilvaniense\(en\)\(d\) anno 1897")[Canonsburgum Pennsilvaniense](https://la.wikipedia.org/w/index.php?title=Canonsburgum_Pennsilvaniense&action=edit&redlink=1 "Canonsburgum Pennsilvaniense \(non est haec pagina\)")[(en)](https://en.wikipedia.org/wiki/Canonsburg,_Pennsylvania "en:Canonsburg, Pennsylvania")[(d)](https://www.wikidata.org/wiki/Q509115 "d:Q509115") anno [1897](https://la.wikipedia.org/wiki/1897 "1897")
Hanc paginam Latine converte s.t.p.: 
**[en:Pictorial map](https://en.wikipedia.org/wiki/Pictorial_map "en:Pictorial map") → ??**  
[Tabula geographica](https://la.wikipedia.org/wiki/Tabula_geographica "Tabula geographica") mente [aestheticā](https://la.wikipedia.org/wiki/Aesthetica "Aesthetica") potius quam technicā picta
[de incepto translationum hebdomadalium](https://la.wikipedia.org/wiki/Vicipaedia:Translatio_hebdomadalis "Vicipaedia:Translatio hebdomadalis")  
[de translationibus prioribus et futuris](https://meta.wikimedia.org/wiki/Translation_of_the_week "meta:Translation of the week")
Participatio tua
[de](https://la.wikipedia.org/wiki/Vicipaedia:Ops_nexusque_usoribus_novis/de "Vicipaedia:Ops nexusque usoribus novis/de") / [en](https://la.wikipedia.org/wiki/Vicipaedia:Ops_nexusque_usoribus_novis/en "Vicipaedia:Ops nexusque usoribus novis/en") / [eo](https://la.wikipedia.org/wiki/Vicipaedia:Ops_nexusque_usoribus_novis/eo "Vicipaedia:Ops nexusque usoribus novis/eo") / [es](https://la.wikipedia.org/wiki/Vicipaedia:Ops_nexusque_usoribus_novis/es "Vicipaedia:Ops nexusque usoribus novis/es") / [ia](https://la.wikipedia.org/wiki/Vicipaedia:Ops_nexusque_usoribus_novis/ia "Vicipaedia:Ops nexusque usoribus novis/ia") / [it](https://la.wikipedia.org/wiki/Vicipaedia:Ops_nexusque_usoribus_novis/it "Vicipaedia:Ops nexusque usoribus novis/it") / [no](https://la.wikipedia.org/wiki/Vicipaedia:Ops_nexusque_usoribus_novis/no "Vicipaedia:Ops nexusque usoribus novis/no") / [ro](https://la.wikipedia.org/wiki/Vicipaedia:Ops_nexusque_usoribus_novis/ro "Vicipaedia:Ops nexusque usoribus novis/ro") / [ru](https://la.wikipedia.org/wiki/Vicipaedia:Ops_nexusque_usoribus_novis/ru "Vicipaedia:Ops nexusque usoribus novis/ru") / [tl](https://la.wikipedia.org/wiki/Vicipaedia:Ops_nexusque_usoribus_novis/tl "Vicipaedia:Ops nexusque usoribus novis/tl")
[Vicipaedia](https://la.wikipedia.org/wiki/Vicipaedia_Latina "Vicipaedia Latina") est opus commune quo [encyclopaedia](https://la.wikipedia.org/wiki/Encyclopaedia "Encyclopaedia") libera interretialis creatur. Tu quoque [adiuvare](https://la.wikipedia.org/wiki/Vicipaedia:Invitatio "Vicipaedia:Invitatio") potes. Ecce **[taberna](https://la.wikipedia.org/wiki/Vicipaedia:Taberna "Vicipaedia:Taberna")** nostra et **[legatio](https://la.wikipedia.org/wiki/Vicipaedia:Legatio_nostra "Vicipaedia:Legatio nostra")** , in quibus poteris quamlibet linguam adhibere. 
Opes et commendationes
  * [Praefatio](https://la.wikipedia.org/wiki/Vicipaedia:Praefatio "Vicipaedia:Praefatio")
  * [De recensendo](https://la.wikipedia.org/wiki/Auxilium:De_recensendo "Auxilium:De recensendo")
  * [Structura paginae](https://la.wikipedia.org/wiki/Vicipaedia:Structura_paginae "Vicipaedia:Structura paginae")
  * [Hierarchia paginarum](https://la.wikipedia.org/wiki/Vicipaedia:Hierarchia_paginarum "Vicipaedia:Hierarchia paginarum")
  * [Qualitas paginarum](https://la.wikipedia.org/wiki/Vicipaedia:Qualitas_paginarum "Vicipaedia:Qualitas paginarum")
  * [De orthographia](https://la.wikipedia.org/wiki/Vicipaedia:De_orthographia "Vicipaedia:De orthographia")
  * [De Latinitate](https://la.wikipedia.org/wiki/Vicipaedia:De_Latinitate "Vicipaedia:De Latinitate")
  * [De nominibus propriis](https://la.wikipedia.org/wiki/Vicipaedia:De_nominibus_propriis "Vicipaedia:De nominibus propriis")
  * [Fontes nominum Latinorum](https://la.wikipedia.org/wiki/Vicipaedia:Fontes_nominum_Latinorum "Vicipaedia:Fontes nominum Latinorum")
  * [De bibliographiis etc.](https://la.wikipedia.org/wiki/Vicipaedia:De_bibliographiis_et_nexibus_externis "Vicipaedia:De bibliographiis et nexibus externis")
  * [De categoriis](https://la.wikipedia.org/wiki/Vicipaedia:De_categoriis "Vicipaedia:De categoriis")
  * [Tutela Vicipaediae](https://la.wikipedia.org/wiki/Vicipaedia:Tutela "Vicipaedia:Tutela")
  * [Formulae](https://la.wikipedia.org/wiki/Categoria:Formulae "Categoria:Formulae")
  * [Paginae novae](https://la.wikipedia.org/wiki/Specialis:Paginae_novae "Specialis:Paginae novae")
  * [Paginae speciales](https://la.wikipedia.org/wiki/Specialis:Paginae_speciales "Specialis:Paginae speciales")
  * [Paginae non annexae](https://la.wikipedia.org/wiki/Categoria:Paginae_non_annexae "Categoria:Paginae non annexae")
  * [Omnes paginae](https://la.wikipedia.org/wiki/Specialis:Paginae_omnes "Specialis:Paginae omnes")
  * [Categoriarum caput](https://la.wikipedia.org/wiki/Categoria:Omnia "Categoria:Omnia")
  * [Categoriarum arbor](https://la.wikipedia.org/wiki/Specialis:Categoriarum_arbor "Specialis:Categoriarum arbor")
  * [Paginae admeliorandae](https://la.wikipedia.org/wiki/Categoria:Corrigenda "Categoria:Corrigenda")
  * [Harenarium](https://la.wikipedia.org/wiki/Vicipaedia:Harenarium "Vicipaedia:Harenarium")
  * [Gratulatio](https://la.wikipedia.org/wiki/Vicipaedia:Gratulatio "Vicipaedia:Gratulatio")


Eruditio Latina
Et magistris et discipulis licet nostram **[portam eruditionis](https://la.wikipedia.org/wiki/Vicipaedia:Porta_eruditionis "Vicipaedia:Porta eruditionis")** visitare. 
Alia incepta
Vicipaedia a [![Vicimedia](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/40px-Wikimedia-logo.svg.png)](https://la.wikipedia.org/wiki/Wikimedia "Vicimedia") [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/ "wikimedia:") administratur, cuius alia incepta multilinguia et libera sunt: 
[![Vicilibri](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://la.wikibooks.org/wiki/ "Vicilibri") |  **[Vicilibri](https://la.wikibooks.org/wiki/ "b:")**  
Tractatus enchiridiaque   
---|---  
[![Victionarium](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Wiktionary-logo-la.png/40px-Wiktionary-logo-la.png)](https://la.wiktionary.org/wiki/ "Victionarium") |  **[Victionarium](https://la.wiktionary.org/wiki/ "wikt:")**  
Dictionarium liberum   
[![Vicicitatio](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://la.wikiquote.org/wiki/ "Vicicitatio") |  **[Vicicitatio](https://la.wikiquote.org/wiki/ "q:")**  
Citationum collectio   
[![Vicimedia Communia](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/ "Vicimedia Communia") |  **[Communia](https://commons.wikimedia.org/wiki/Pagina_prima "commons:Pagina prima")**  
Thesaurus imaginum et sonorum   
[![Vicifons](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://la.wikisource.org/wiki/ "Vicifons") |  **[Vicifons](https://la.wikisource.org/wiki/ "s:")**  
Fontes liberae   
[![Viciversitas](https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)](https://beta.wikiversity.org/wiki/Pagina_prima "Viciversitas") |  **[Viciversitas](https://beta.wikiversity.org/wiki/Pagina_prima "betawikiversity:Pagina prima")**  
Libera instrumenta discendi   
[![Vicispecies](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/ "Vicispecies") |  **[Vicispecies](https://species.wikimedia.org/wiki/ "wikispecies:")**  
Index specierum   
[![Vicidata](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/40px-Wikidata-logo.svg.png)](https://www.wikidata.org/wiki/ "Vicidata") |  **[Vicidata](https://www.wikidata.org/wiki/ "d:")**  
Repositorium datorum liberum   
[![Vicifunctiones](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Wikifunctions-logo.svg/40px-Wikifunctions-logo.svg.png)](https://www.wikifunctions.org/wiki/ "Vicifunctiones") |  **[Vicifunctiones](https://www.wikifunctions.org/wiki/ "f:")**  
Repositorium functionum liberum   
[![MediaWiki](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/ "MediaWiki") |  **[MediaWiki](https://www.mediawiki.org/wiki/ "mw:")**  
Programma interretiale vici liberum   
[![Vicivia](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://incubator.wikimedia.org/wiki/Wy/la/Pagina_prima "Vicivia") |  **[Vicivia](https://incubator.wikimedia.org/wiki/Wy/la/Pagina_prima "incubator:Wy/la/Pagina prima")**  
Directorium viaticum liberum   
[![Vicinuntii](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](http://www.wikinews.org/ "Vicinuntii") |  **[Vicinuntii](https://www.wikinews.org/)**  
Nuntii liberi   
[![Meta](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/ "Meta") |  **[Meta](https://meta.wikimedia.org/wiki/ "m:")**  
Inceptorum Vicimediorum coordinatio   
[![Incubator](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Incubator-logo.svg/40px-Incubator-logo.svg.png)](https://incubator.wikimedia.org/wiki/ "Incubatrix") |  **[Incubatrix](https://incubator.wikimedia.org/wiki/ "incubator:")**  
Vicipaediae nondum probatae   
Receptum de "[https://la.wikipedia.org/w/index.php?title=Vicipaedia:Pagina_prima&oldid=3872691](https://la.wikipedia.org/w/index.php?title=Vicipaedia:Pagina_prima&oldid=3872691)"
[Categoria](https://la.wikipedia.org/wiki/Specialis:Categoriae "Specialis:Categoriae"): 
  * [Pagina prima](https://la.wikipedia.org/wiki/Categoria:Pagina_prima "Categoria:Pagina prima")


Categoria celata: 
  * [Paginae novas paginas petentes](https://la.wikipedia.org/wiki/Categoria:Paginae_novas_paginas_petentes "Categoria:Paginae novas paginas petentes")


  * Novissima mutatio die 13 Ianuarii 2025 hora 21:05 facta.
  * Nonobstantibus ceteris condicionibus hunc textum tractare licet secundum ["Creative Commons Attribution-ShareAlike License"](https://creativecommons.org/licenses/by-sa/4.0/). Vide [modos et condiciones](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use).


  * [Consilium de secreto](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [De Vicipaedia](https://la.wikipedia.org/wiki/Vicipaedia:De_Vicipaedia)
  * [Repudiationes](https://la.wikipedia.org/wiki/Vicipaedia:Repudiationes)
  * [Code of Conduct](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Elaboratores](https://developer.wikimedia.org)
  * [Statistica](https://stats.wikimedia.org/#/la.wikipedia.org)
  * [Cookie statement](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Pagina mobilis](https://la.m.wikipedia.org/w/index.php?title=Vicipaedia:Pagina_prima&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://la.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://la.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Quaerere
Quaerere
Bene advenisti in Vicipaediam!
[](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima) [](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima) [](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima) [](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima) [](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima) [](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima) [](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima) [](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima)
353 languages [Partem novam addere ](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima)
  *[s.t.p.]: “Si tibi placet”
