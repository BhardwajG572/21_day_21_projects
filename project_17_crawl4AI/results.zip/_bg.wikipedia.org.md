[Направо към съдържанието](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0#bodyContent)
Главно меню
Главно меню
преместване към страничната лента скриване
Навигация 
  * [Начална страница](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Началната страница \[alt-z\]")
  * [Случайна статия](https://bg.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%A1%D0%BB%D1%83%D1%87%D0%B0%D0%B9%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Зареждане на случайна страница \[alt-x\]")


Полезно 
  * [Последни промени](https://bg.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%9F%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8_%D0%BF%D1%80%D0%BE%D0%BC%D0%B5%D0%BD%D0%B8 "Списък на последните промени в уикито \[alt-r\]")
  * [Общи разговори](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%A0%D0%B0%D0%B7%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D0%B8)
  * [Обсъждани статии](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%90%D0%BA%D1%82%D0%B8%D0%B2%D0%BD%D0%B8_%D0%B1%D0%B5%D1%81%D0%B5%D0%B4%D0%B8)
  * [Администратори](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%97%D0%B0%D1%8F%D0%B2%D0%BA%D0%B8_%D0%BA%D1%8A%D0%BC_%D0%B0%D0%B4%D0%BC%D0%B8%D0%BD%D0%B8%D1%81%D1%82%D1%80%D0%B0%D1%82%D0%BE%D1%80%D0%B8%D1%82%D0%B5)
  * [Изтривания](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%A1%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B8_%D0%B7%D0%B0_%D0%B8%D0%B7%D1%82%D1%80%D0%B8%D0%B2%D0%B0%D0%BD%D0%B5)
  * [За контакти](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%97%D0%B0_%D0%BA%D0%BE%D0%BD%D1%82%D0%B0%D0%BA%D1%82%D0%B8)
  * [Специални страници](https://bg.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B8)


Включете се! 
  * [Защо?](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9A%D0%BE%D0%B9_%D1%81%D1%8A%D0%B7%D0%B4%D0%B0%D0%B2%D0%B0_%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F)
  * [Помощ](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9F%D1%8A%D1%80%D0%B2%D0%B8_%D1%81%D1%82%D1%8A%D0%BF%D0%BA%D0%B8 "Място, където може да се информирате")
  * [Картинки](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:10_%D0%BD%D0%B5%D1%89%D0%B0,_%D0%BA%D0%BE%D0%B8%D1%82%D0%BE_%D1%82%D1%80%D1%8F%D0%B1%D0%B2%D0%B0_%D0%B4%D0%B0_%D1%81%D0%B5_%D0%B7%D0%BD%D0%B0%D1%8F%D1%82_%D0%B7%D0%B0_%D0%BA%D0%B0%D1%80%D1%82%D0%B8%D0%BD%D0%BA%D0%B8%D1%82%D0%B5_%D0%B2_%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F)
  * [Поведение](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9F%D0%BE%D0%B2%D0%B5%D0%B4%D0%B5%D0%BD%D0%B8%D0%B5)
  * [Изпробване](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9F%D1%8F%D1%81%D1%8A%D1%87%D0%BD%D0%B8%D0%BA)
  * [Нова статия](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%92%D1%8A%D0%BB%D1%88%D0%B5%D0%B1%D0%BD%D0%B8%D0%BA)


Общувайте 
  * [Блог на общността](https://blog.wikimedia.bg/)
  * [Фейсбук страница](https://www.facebook.com/WikipediaBG)
  * [Фейсбук група](https://www.facebook.com/groups/WikipediaBG)
  * [🎮 Дискорд](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%94%D0%B8%D1%81%D0%BA%D0%BE%D1%80%D0%B4)
  * [Телеграм](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%A2%D0%B5%D0%BB%D0%B5%D0%B3%D1%80%D0%B0%D0%BC)
  * [IRC](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:IRC)
  * [GitHub](https://github.com/wikimedia-bg)


[ ![](https://bg.wikipedia.org/static/images/icons/wikipedia.png) ![Уикипедия](https://bg.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-bg.svg) ![Свободната енциклопедия](https://bg.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-bg.svg) ](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
[Търсене ](https://bg.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%A2%D1%8A%D1%80%D1%81%D0%B5%D0%BD%D0%B5 "Претърсване на Уикипедия \[alt-f\]")
Търсене
Облик
Облик
преместване към страничната лента скриване
Текст
  * Малък
Стандартен
Голям

Тази страница използва винаги малък размер на шрифта.
Ширина
  * Стандартен
Широк

Съдържанието е възможно най-широко за прозореца на браузъра Ви.
Цвят (бета)
  * Автоматичен
Светъл
Тъмен

Тази страница е винаги в светъл режим.
  * [Направете дарение](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=bg.wikipedia.org&uselang=bg)
  * [Създаване на сметка](https://bg.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%A1%D1%8A%D0%B7%D0%B4%D0%B0%D0%B2%D0%B0%D0%BD%D0%B5_%D0%BD%D0%B0_%D1%81%D0%BC%D0%B5%D1%82%D0%BA%D0%B0&returnto=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0+%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Насърчаваме Ви да си създадете сметка и да влезете, въпреки че не е задължително.")
  * [Влизане](https://bg.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%A0%D0%B5%D0%B3%D0%B8%D1%81%D1%82%D1%80%D0%B8%D1%80%D0%B0%D0%BD%D0%B5_%D0%B8%D0%BB%D0%B8_%D0%B2%D0%BB%D0%B8%D0%B7%D0%B0%D0%BD%D0%B5&returnto=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0+%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Препоръчваме Ви да влезете, въпреки, че не е задължително. \[alt-o\]")


Лични инструменти
  * [Направете дарение](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=bg.wikipedia.org&uselang=bg)
  * [Създаване на сметка](https://bg.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%A1%D1%8A%D0%B7%D0%B4%D0%B0%D0%B2%D0%B0%D0%BD%D0%B5_%D0%BD%D0%B0_%D1%81%D0%BC%D0%B5%D1%82%D0%BA%D0%B0&returnto=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0+%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Насърчаваме Ви да си създадете сметка и да влезете, въпреки че не е задължително.")
  * [Влизане](https://bg.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%A0%D0%B5%D0%B3%D0%B8%D1%81%D1%82%D1%80%D0%B8%D1%80%D0%B0%D0%BD%D0%B5_%D0%B8%D0%BB%D0%B8_%D0%B2%D0%BB%D0%B8%D0%B7%D0%B0%D0%BD%D0%B5&returnto=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0+%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Препоръчваме Ви да влезете, въпреки, че не е задължително. \[alt-o\]")


# Начална страница
  * [Начална страница](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Преглед на основната страница \[alt-c\]")
  * [Беседа](https://bg.wikipedia.org/wiki/%D0%91%D0%B5%D1%81%D0%B5%D0%B4%D0%B0:%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Беседа за страницата \[alt-t\]")


български
  * [Преглед](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
  * [Преглед на кода](https://bg.wikipedia.org/w/index.php?title=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&action=edit "Страницата е защитена. Можете да разгледате изходният ѝ код. \[alt-e\]")
  * [История](https://bg.wikipedia.org/w/index.php?title=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&action=history "Предишни версии на страницата \[alt-h\]")


Инструменти
Инструменти
преместване към страничната лента скриване
Действия 
  * [Преглед](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
  * [Преглед на кода](https://bg.wikipedia.org/w/index.php?title=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&action=edit)
  * [История](https://bg.wikipedia.org/w/index.php?title=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&action=history)


Основни 
  * [Какво сочи насам](https://bg.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%9A%D0%B0%D0%BA%D0%B2%D0%BE_%D1%81%D0%BE%D1%87%D0%B8_%D0%BD%D0%B0%D1%81%D0%B0%D0%BC/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Списък на всички страници, сочещи насам \[alt-j\]")
  * [Свързани промени](https://bg.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%A1%D0%B2%D1%8A%D1%80%D0%B7%D0%B0%D0%BD%D0%B8_%D0%BF%D1%80%D0%BE%D0%BC%D0%B5%D0%BD%D0%B8/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Последните промени на страници, сочени от тази страница \[alt-k\]")
  * [Качване на файл](https://bg.wikipedia.org/wiki/MediaWiki:Uploadtext "Качи файлове \[alt-u\]")
  * [Постоянна препратка](https://bg.wikipedia.org/w/index.php?title=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&oldid=11662729 "Постоянна препратка към тази версия на страницата")
  * [Информация за страницата](https://bg.wikipedia.org/w/index.php?title=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&action=info "Повече за тази страница")
  * [Цитиране на статията](https://bg.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%A6%D0%B8%D1%82%D0%B8%D1%80%D0%B0%D0%BD%D0%B5&page=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&id=11662729&wpFormIdentifier=titleform "Информация за начините за цитиране на тази страница")
  * [Кратък URL адрес](https://bg.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:UrlShortener&url=https%3A%2F%2Fbg.wikipedia.org%2Fwiki%2F%25D0%259D%25D0%25B0%25D1%2587%25D0%25B0%25D0%25BB%25D0%25BD%25D0%25B0_%25D1%2581%25D1%2582%25D1%2580%25D0%25B0%25D0%25BD%25D0%25B8%25D1%2586%25D0%25B0)
  * [Изтегляне на QR код](https://bg.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:QrCode&url=https%3A%2F%2Fbg.wikipedia.org%2Fwiki%2F%25D0%259D%25D0%25B0%25D1%2587%25D0%25B0%25D0%25BB%25D0%25BD%25D0%25B0_%25D1%2581%25D1%2582%25D1%2580%25D0%25B0%25D0%25BD%25D0%25B8%25D1%2586%25D0%25B0)
  * [Подстраници](https://bg.wikipedia.org/wiki/Special:Prefixindex/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0/)
  * [Редактиране на междуезиковите препратки](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Редактиране на междуезиковите препратки")


Отпечатване/изнасяне 
  * [Създаване на книга](https://bg.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:Book&bookcmd=book_creator&referer=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0+%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
  * [Изтегляне като PDF](https://bg.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:DownloadAsPdf&page=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&action=show-download-screen)
  * [Версия за печат](https://bg.wikipedia.org/w/index.php?title=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&printable=yes "Версия за печат на страницата \[alt-p\]")


В други проекти 
  * [Общомедия](https://commons.wikimedia.org/wiki/Main_Page)
  * [Фондация Уикимедия](https://foundation.wikimedia.org/wiki/Home)
  * [МедияУики](https://www.mediawiki.org/wiki/MediaWiki)
  * [Мета-уики](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Уикивидове](https://species.wikimedia.org/wiki/Main_Page)
  * [Уикикниги](https://bg.wikibooks.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
  * [Уикиданни](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Уикиновини](https://bg.wikinews.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
  * [Уикицитат](https://bg.wikiquote.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
  * [Уикиизточник](https://bg.wikisource.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
  * [Уикиречник](https://bg.wiktionary.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D1%80%D0%B5%D1%87%D0%BD%D0%B8%D0%BA:%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
  * [Обект в Уикиданни](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Препратка към свързания обект от хранилището за данни \[alt-g\]")


от Уикипедия, свободната енциклопедия
|  |  Добре дошли в [Уикипедия](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F "Уикипедия"), [свободната](https://bg.wikipedia.org/wiki/%D0%A1%D0%B2%D0%BE%D0%B1%D0%BE%D0%B4%D0%BD%D0%BE_%D1%81%D1%8A%D0%B4%D1%8A%D1%80%D0%B6%D0%B0%D0%BD%D0%B8%D0%B5 "Свободно съдържание") [енциклопедия](https://bg.wikipedia.org/wiki/%D0%95%D0%BD%D1%86%D0%B8%D0%BA%D0%BB%D0%BE%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F "Енциклопедия"), която [всеки може да редактира](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9F%D1%8A%D1%80%D0%B2%D0%B8_%D1%81%D1%82%D1%8A%D0%BF%D0%BA%D0%B8 "Уикипедия:Първи стъпки").  
Съдържа [305 914](https://bg.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B5%D1%86%D0%B8%D0%B0%D0%BB%D0%BD%D0%B8:%D0%A1%D1%82%D0%B0%D1%82%D0%B8%D1%81%D1%82%D0%B8%D0%BA%D0%B0 "Специални:Статистика") статии на [български език](https://bg.wikipedia.org/wiki/%D0%91%D1%8A%D0%BB%D0%B3%D0%B0%D1%80%D1%81%D0%BA%D0%B8_%D0%B5%D0%B7%D0%B8%D0%BA "Български език").  
---  
| 
  * [Астрономия](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%90%D1%81%D1%82%D1%80%D0%BE%D0%BD%D0%BE%D0%BC%D0%B8%D1%8F "Портал:Астрономия")
  * [Биология](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%91%D0%B8%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F "Портал:Биология")
  * [България](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%91%D1%8A%D0%BB%D0%B3%D0%B0%D1%80%D0%B8%D1%8F "Портал:България")

| 
  * [География](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%93%D0%B5%D0%BE%D0%B3%D1%80%D0%B0%D1%84%D0%B8%D1%8F "Портал:География")
  * [Избрани статии](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%98%D0%B7%D0%B1%D1%80%D0%B0%D0%BD%D0%B8_%D1%81%D1%82%D0%B0%D1%82%D0%B8%D0%B8 "Портал:Избрани статии")
  * [Изкуство](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%98%D0%B7%D0%BA%D1%83%D1%81%D1%82%D0%B2%D0%BE "Портал:Изкуство")

| 
  * [История](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%98%D1%81%D1%82%D0%BE%D1%80%D0%B8%D1%8F "Портал:История")
  * [Македония](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%9C%D0%B0%D0%BA%D0%B5%D0%B4%D0%BE%D0%BD%D0%B8%D1%8F "Портал:Македония")
  * [Медицина](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%9C%D0%B5%D0%B4%D0%B8%D1%86%D0%B8%D0%BD%D0%B0 "Портал:Медицина")

| 
  * [Физика](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%A4%D0%B8%D0%B7%D0%B8%D0%BA%D0%B0 "Портал:Физика")
  * [Философия](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%A4%D0%B8%D0%BB%D0%BE%D1%81%D0%BE%D1%84%D0%B8%D1%8F "Портал:Философия")
  * **[Всички портали](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB%D0%B8 "Уикипедия:Портали")**

  
---|---|---|---  
**[Уикипедия](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F "Уикипедия")** е [свободна](https://bg.wikipedia.org/wiki/%D0%A1%D0%B2%D0%BE%D0%B1%D0%BE%D0%B4%D0%BD%D0%BE_%D1%81%D1%8A%D0%B4%D1%8A%D1%80%D0%B6%D0%B0%D0%BD%D0%B8%D0%B5 "Свободно съдържание") енциклопедия, която всеки може да редактира, развива и обогатява. Ако не знаете откъде да започнете, препоръчваме ви да прочетете **[помощната страница](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9F%D1%8A%D1%80%D0%B2%D0%B8_%D1%81%D1%82%D1%8A%D0%BF%D0%BA%D0%B8 "Уикипедия:Първи стъпки")**.  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Papapishu-Wizard-in-blue-hat.svg/20px-Papapishu-Wizard-in-blue-hat.svg.png)](https://bg.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Papapishu-Wizard-in-blue-hat.svg) Ако не сте сигурни как да започнете нова статия – опитайте помощта на нашия [Вълшебник](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%92%D1%8A%D0%BB%D1%88%D0%B5%D0%B1%D0%BD%D0%B8%D0%BA "Уикипедия:Вълшебник")! [![](https://upload.wikimedia.org/wikipedia/commons/c/c1/%D0%9F%D0%BE%D1%80%D1%82%D1%80%D0%B5%D1%82_%D0%91%D0%B0%D0%B3%D1%80%D0%B0%D0%BC%D1%8F%D0%BD%D0%B0_%D0%B2_%D1%86%D0%B2%D0%B5%D1%82%D0%B5.jpg)](https://bg.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:%D0%9F%D0%BE%D1%80%D1%82%D1%80%D0%B5%D1%82_%D0%91%D0%B0%D0%B3%D1%80%D0%B0%D0%BC%D1%8F%D0%BD%D0%B0_%D0%B2_%D1%86%D0%B2%D0%B5%D1%82%D0%B5.jpg) **[Ованес (Иван) Баграмян](https://bg.wikipedia.org/wiki/%D0%98%D0%B2%D0%B0%D0%BD_%D0%91%D0%B0%D0%B3%D1%80%D0%B0%D0%BC%D1%8F%D0%BD "Иван Баграмян")** е [съветски](https://bg.wikipedia.org/wiki/%D0%A1%D1%8A%D1%8E%D0%B7_%D0%BD%D0%B0_%D1%81%D1%8A%D0%B2%D0%B5%D1%82%D1%81%D0%BA%D0%B8%D1%82%D0%B5_%D1%81%D0%BE%D1%86%D0%B8%D0%B0%D0%BB%D0%B8%D1%81%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8_%D1%80%D0%B5%D0%BF%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B8 "Съюз на съветските социалистически републики") командир от арменски произход и [маршал](https://bg.wikipedia.org/wiki/%D0%9C%D0%B0%D1%80%D1%88%D0%B0%D0%BB "Маршал") на Съветската армия. През [Втората световна война](https://bg.wikipedia.org/wiki/%D0%92%D1%82%D0%BE%D1%80%D0%B0%D1%82%D0%B0_%D1%81%D0%B2%D0%B5%D1%82%D0%BE%D0%B2%D0%BD%D0%B0_%D0%B2%D0%BE%D0%B9%D0%BD%D0%B0 "Втората световна война") Баграмян става първият командир на фронт от неславянски произход. Той е един от няколкото арменци, заемащи висши офицерски постове в [Червената армия](https://bg.wikipedia.org/wiki/%D0%A7%D0%B5%D1%80%D0%B2%D0%B5%D0%BD%D0%B0%D1%82%D0%B0_%D0%B0%D1%80%D0%BC%D0%B8%D1%8F "Червената армия") по време на войната, и един от петдесетте арменци, получили званието [генерал](https://bg.wikipedia.org/wiki/%D0%93%D0%B5%D0%BD%D0%B5%D1%80%D0%B0%D0%BB "Генерал").  Опитът на Баграмян във военното планиране му позволява да се отличи като превъзходен командир в ранните етапи на съветската контраофанзива срещу [Нацистка Германия](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%86%D0%B8%D1%81%D1%82%D0%BA%D0%B0_%D0%93%D0%B5%D1%80%D0%BC%D0%B0%D0%BD%D0%B8%D1%8F "Нацистка Германия"). През [1942](https://bg.wikipedia.org/wiki/1942 "1942") за първи път оглавява военна част, а през [1943](https://bg.wikipedia.org/wiki/1943 "1943") г. е назначен за командващ офицер (КО) на Първи балтийски фронт. Като такъв той участва в настъплението на Съветската армия на запад и изтласкването на [Вермахта](https://bg.wikipedia.org/wiki/%D0%92%D0%B5%D1%80%D0%BC%D0%B0%D1%85%D1%82%D0%B0 "Вермахта") от териториите на [Прибалтийските републики](https://bg.wikipedia.org/wiki/%D0%9F%D1%80%D0%B8%D0%B1%D0%B0%D0%BB%D1%82%D0%B8%D0%B9%D1%81%D0%BA%D0%B8_%D1%80%D0%B5%D0%BF%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B8 "Прибалтийски републики").  Иван Баграмян не става член на [КПСС](https://bg.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BC%D1%83%D0%BD%D0%B8%D1%81%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B0_%D0%BF%D0%B0%D1%80%D1%82%D0%B8%D1%8F_%D0%BD%D0%B0_%D0%A1%D1%8A%D0%B2%D0%B5%D1%82%D1%81%D0%BA%D0%B8%D1%8F_%D1%81%D1%8A%D1%8E%D0%B7 "Комунистическа партия на Съветския съюз") веднага след [Октомврийската революция](https://bg.wikipedia.org/wiki/%D0%9E%D0%BA%D1%82%D0%BE%D0%BC%D0%B2%D1%80%D0%B8%D0%B9%D1%81%D0%BA%D0%B0_%D1%80%D0%B5%D0%B2%D0%BE%D0%BB%D1%8E%D1%86%D0%B8%D1%8F "Октомврийска революция"), а през [1941](https://bg.wikipedia.org/wiki/1941 "1941") г. — нещо нетипично за съветските военни лица. След Втората световна война работи като член на [Върховния съвет](https://bg.wikipedia.org/wiki/%D0%92%D1%8A%D1%80%D1%85%D0%BE%D0%B2%D0%B5%D0%BD_%D1%81%D1%8A%D0%B2%D0%B5%D1%82_%D0%BD%D0%B0_%D0%A1%D0%A1%D0%A1%D0%A0 "Върховен съвет на СССР") в [Латвийската](https://bg.wikipedia.org/wiki/%D0%9B%D0%B0%D1%82%D0%B2%D0%B8%D0%B9%D1%81%D0%BA%D0%B0_%D1%81%D1%8A%D0%B2%D0%B5%D1%82%D1%81%D0%BA%D0%B0_%D1%81%D0%BE%D1%86%D0%B8%D0%B0%D0%BB%D0%B8%D1%81%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B0_%D1%80%D0%B5%D0%BF%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B0 "Латвийска съветска социалистическа република") и [Арменската съветски социалистически републики](https://bg.wikipedia.org/wiki/%D0%90%D1%80%D0%BC%D0%B5%D0%BD%D1%81%D0%BA%D0%B0_%D1%81%D1%8A%D0%B2%D0%B5%D1%82%D1%81%D0%BA%D0%B0_%D1%81%D0%BE%D1%86%D0%B8%D0%B0%D0%BB%D0%B8%D1%81%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B0_%D1%80%D0%B5%D0%BF%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B0 "Арменска съветска социалистическа република") и редовно присъства на партийните конгреси. През [1952](https://bg.wikipedia.org/wiki/1952 "1952") г. се кандидатира за член на [ЦК на КПСС](https://bg.wikipedia.org/wiki/%D0%A6%D0%9A_%D0%BD%D0%B0_%D0%9A%D0%9F%D0%A1%D0%A1 "ЦК на КПСС"), а през [1961](https://bg.wikipedia.org/wiki/1961 "1961") г. става негов пълноправен член. Поради приноса си към победите на Съветската армия по време на Втората световна война Баграмян е считан за национален герой в СССР и продължава да бъде считан за такъв и от арменците. [още »](https://bg.wikipedia.org/wiki/%D0%98%D0%B2%D0%B0%D0%BD_%D0%91%D0%B0%D0%B3%D1%80%D0%B0%D0%BC%D1%8F%D0%BD "Иван Баграмян") [Още избрани статии](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%80%D1%82%D0%B0%D0%BB:%D0%98%D0%B7%D0%B1%D1%80%D0%B0%D0%BD%D0%B8_%D1%81%D1%82%D0%B0%D1%82%D0%B8%D0%B8 "Портал:Избрани статии")
  * … че **[най-гледаният филм в историята на Латвия](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D1%82%D0%BE%D0%BF_\(%D1%84%D0%B8%D0%BB%D0%BC,_2024\) "Потоп \(филм, 2024\)")** е анимация ?
  * … кога танк **[блъска група хора](https://bg.wikipedia.org/wiki/%D0%98%D0%BD%D1%86%D0%B8%D0%B4%D0%B5%D0%BD%D1%82_%D0%BD%D0%B0_%D0%94%D0%B5%D0%B2%D0%B5%D1%82%D0%BE%D1%81%D0%B5%D0%BF%D1%82%D0%B5%D0%BC%D0%B2%D1%80%D0%B8%D0%B9%D1%81%D0%BA%D0%B0%D1%82%D0%B0_%D0%BC%D0%B0%D0%BD%D0%B8%D1%84%D0%B5%D1%81%D1%82%D0%B0%D1%86%D0%B8%D1%8F_%D0%BF%D1%80%D0%B5%D0%B7_1950_%D0%B3%D0%BE%D0%B4%D0%B8%D0%BD%D0%B0 "Инцидент на Деветосептемврийската манифестация през 1950 година")** на [Жълтите павета](https://bg.wikipedia.org/wiki/%D0%96%D1%8A%D0%BB%D1%82%D0%B8_%D0%BF%D0%B0%D0%B2%D0%B5%D1%82%D0%B0 "Жълти павета") в София?
  * … как съветски войник допринася за **[един от най-големите пожари](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D0%B6%D0%B0%D1%80_%D0%BD%D0%B0_%D0%9F%D1%80%D0%B8%D1%81%D1%82%D0%B0%D0%BD%D0%B8%D1%89%D0%B5_%E2%80%9E%D0%91%D1%83%D1%80%D0%B3%D0%B0%D1%81%E2%80%9C "Пожар на Пристанище „Бургас“")** в България?
  * … кога настъпва **[прегряване на икономиката](https://bg.wikipedia.org/wiki/%D0%9F%D1%80%D0%B5%D0%B3%D1%80%D1%8F%D0%B2%D0%B0%D0%BD%D0%B5_%D0%BD%D0%B0_%D0%B8%D0%BA%D0%BE%D0%BD%D0%BE%D0%BC%D0%B8%D0%BA%D0%B0%D1%82%D0%B0 "Прегряване на икономиката")**?
  * … колко [часа](https://bg.wikipedia.org/wiki/%D0%A7%D0%B0%D1%81 "Час") [годишно](https://bg.wikipedia.org/wiki/%D0%93%D0%BE%D0%B4%D0%B8%D0%BD%D0%B0 "Година") е [**слънчевото греене**](https://bg.wikipedia.org/wiki/%D0%A1%D0%BB%D1%8A%D0%BD%D1%87%D0%B5%D0%B2%D0%BE_%D0%B3%D1%80%D0%B5%D0%B5%D0%BD%D0%B5_%D0%B2_%D0%91%D1%8A%D0%BB%D0%B3%D0%B0%D1%80%D0%B8%D1%8F "Слънчево греене в България") в [България](https://bg.wikipedia.org/wiki/%D0%91%D1%8A%D0%BB%D0%B3%D0%B0%D1%80%D0%B8%D1%8F "България")?

[![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/20140615_Sofia_047.jpg/120px-20140615_Sofia_047.jpg)](https://bg.wikipedia.org/wiki/%D0%94%D0%B5%D0%BD_%D0%BD%D0%B0_%D0%BF%D1%80%D0%B8%D0%B7%D0%BD%D0%B0%D1%82%D0%B5%D0%BB%D0%BD%D0%BE%D1%81%D1%82_%D0%B8_%D0%BF%D0%BE%D1%87%D0%B8%D1%82_%D0%BA%D1%8A%D0%BC_%D0%B6%D0%B5%D1%80%D1%82%D0%B2%D0%B8%D1%82%D0%B5_%D0%BD%D0%B0_%D0%BA%D0%BE%D0%BC%D1%83%D0%BD%D0%B8%D1%81%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D1%8F_%D1%80%D0%B5%D0%B6%D0%B8%D0%BC "Ден на признателност и почит към жертвите на комунистическия режим")
  * … кога в България официално **[се отдава почит](https://bg.wikipedia.org/wiki/%D0%94%D0%B5%D0%BD_%D0%BD%D0%B0_%D0%BF%D1%80%D0%B8%D0%B7%D0%BD%D0%B0%D1%82%D0%B5%D0%BB%D0%BD%D0%BE%D1%81%D1%82_%D0%B8_%D0%BF%D0%BE%D1%87%D0%B8%D1%82_%D0%BA%D1%8A%D0%BC_%D0%B6%D0%B5%D1%80%D1%82%D0%B2%D0%B8%D1%82%D0%B5_%D0%BD%D0%B0_%D0%BA%D0%BE%D0%BC%D1%83%D0%BD%D0%B8%D1%81%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D1%8F_%D1%80%D0%B5%D0%B6%D0%B8%D0%BC "Ден на признателност и почит към жертвите на комунистическия режим")** на жертвите на [комунистическия режим](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%80%D0%BE%D0%B4%D0%BD%D0%B0_%D1%80%D0%B5%D0%BF%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B0_%D0%91%D1%8A%D0%BB%D0%B3%D0%B0%D1%80%D0%B8%D1%8F "Народна република България")?
  * … кое **[предприятие в Стара Загора](https://bg.wikipedia.org/wiki/%D0%90%D0%B7%D0%BE%D1%82%D0%BD%D0%BE%D1%82%D0%BE%D1%80%D0%BE%D0%B2_%D0%B7%D0%B0%D0%B2%D0%BE%D0%B4_%E2%80%93_%D0%A1%D1%82%D0%B0%D1%80%D0%B0_%D0%97%D0%B0%D0%B3%D0%BE%D1%80%D0%B0 "Азотноторов завод – Стара Загора")** е сред десетте най-големи в света от този вид при откриването си през 1963 година?
  * … кой е [**най-старият все още съществуващ международен спортен турнир в света**](https://bg.wikipedia.org/wiki/%D0%9A%D1%83%D0%BF%D0%B0_%D0%BD%D0%B0_%D0%90%D0%BC%D0%B5%D1%80%D0%B8%D0%BA%D0%B0 "Купа на Америка"), който държи рекорда и за най-дълга победна серия във всеки спорт?

[![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/The_Sun_by_the_Atmospheric_Imaging_Assembly_of_NASA%27s_Solar_Dynamics_Observatory_-_20100819.jpg/120px-The_Sun_by_the_Atmospheric_Imaging_Assembly_of_NASA%27s_Solar_Dynamics_Observatory_-_20100819.jpg)](https://bg.wikipedia.org/wiki/%D0%A5%D0%B5%D0%BB%D0%B8%D0%B9 "Хелий")
  * … кой е [**единственият химичен елемент**](https://bg.wikipedia.org/wiki/%D0%A5%D0%B5%D0%BB%D0%B8%D0%B9 "Хелий"), открит първо в [Слънцето](https://bg.wikipedia.org/wiki/%D0%A1%D0%BB%D1%8A%D0%BD%D1%86%D0%B5%D1%82%D0%BE "Слънцето")?
  * … колко хора са напуснали родината си при [**Украинската бежанска криза от 2022 г.?**](https://bg.wikipedia.org/wiki/%D0%A3%D0%BA%D1%80%D0%B0%D0%B8%D0%BD%D1%81%D0%BA%D0%B0_%D0%B1%D0%B5%D0%B6%D0%B0%D0%BD%D1%81%D0%BA%D0%B0_%D0%BA%D1%80%D0%B8%D0%B7%D0%B0_\(2022\) "Украинска бежанска криза \(2022\)")
  * … как се казва и [къде](https://bg.wikipedia.org/wiki/%D0%98%D0%BD%D1%81%D1%82%D0%B8%D1%82%D1%83%D1%82_%D0%BF%D0%BE_%D0%B8%D0%BD%D1%84%D0%BE%D1%80%D0%BC%D0%B0%D1%86%D0%B8%D0%BE%D0%BD%D0%BD%D0%B8_%D0%B8_%D0%BA%D0%BE%D0%BC%D1%83%D0%BD%D0%B8%D0%BA%D0%B0%D1%86%D0%B8%D0%BE%D0%BD%D0%BD%D0%B8_%D1%82%D0%B5%D1%85%D0%BD%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D0%B8 "Институт по информационни и комуникационни технологии") работи [**вторият**](https://bg.wikipedia.org/wiki/%D0%90%D0%B2%D0%B8%D1%82%D0%BE%D1%85%D0%BE%D0%BB_\(%D1%81%D1%83%D0%BF%D0%B5%D1%80%D0%BA%D0%BE%D0%BC%D0%BF%D1%8E%D1%82%D1%8A%D1%80\) "Авитохол \(суперкомпютър\)") български [суперкомпютър](https://bg.wikipedia.org/wiki/%D0%A1%D1%83%D0%BF%D0%B5%D1%80%D0%BA%D0%BE%D0%BC%D0%BF%D1%8E%D1%82%D1%8A%D1%80 "Суперкомпютър")?
  * … каква е разликата между [**дигиталното**](https://bg.wikipedia.org/wiki/%D0%94%D0%B8%D0%B3%D0%B8%D1%82%D0%B0%D0%BB%D0%BD%D0%BE_%D0%BD%D0%BE%D0%BC%D0%B0%D0%B4%D1%81%D1%82%D0%B2%D0%BE "Дигитално номадство") и [**политическото номадство**](https://bg.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BB%D0%B8%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%BE_%D0%BD%D0%BE%D0%BC%D0%B0%D0%B4%D1%81%D1%82%D0%B2%D0%BE "Политическо номадство")?

  
[Архив](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9F%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8_%D0%BF%D0%BE%D0%BF%D1%8A%D0%BB%D0%BD%D0%B5%D0%BD%D0%B8%D1%8F#%D0%90%D1%80%D1%85%D0%B8%D0%B2 "Уикипедия:Последни попълнения")   
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg/500px-Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)](https://bg.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Goddess_Bhadrakali_Worshipped_by_the_Gods-_from_a_tantric_Devi_series_-_Google_Art_Project.jpg)  
Индуистката богиня [Бхадракали](https://bg.wikipedia.org/w/index.php?title=%D0%91%D1%85%D0%B0%D0%B4%D1%80%D0%B0%D0%BA%D0%B0%D0%BB%D0%B8&action=edit&redlink=1 "Бхадракали \(страницата не съществува\)") побеждава демона [Махишасура](https://bg.wikipedia.org/w/index.php?title=%D0%9C%D0%B0%D1%85%D0%B8%D1%88%D0%B0%D1%81%D1%83%D1%80%D0%B0&action=edit&redlink=1 "Махишасура \(страницата не съществува\)"), картина от XVII век  
(На 2 октомври е празникът [Виджаядашами](https://bg.wikipedia.org/w/index.php?title=%D0%92%D0%B8%D0%B4%D0%B6%D0%B0%D1%8F%D0%B4%D0%B0%D1%88%D0%B0%D0%BC%D0%B8&action=edit&redlink=1 "Виджаядашами \(страницата не съществува\)"), отбелязващ победата на Бхадракали.) [Проблем с картинката?](https://bg.wikipedia.org/wiki/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD:%D0%9A%D0%B0%D1%80%D1%82%D0%B8%D0%BD%D0%BA%D0%B0_%D0%BD%D0%B0_%D0%B4%D0%B5%D0%BD%D1%8F_%D0%B2_%D0%9E%D0%B1%D1%89%D0%BE%D0%BC%D0%B5%D0%B4%D0%B8%D1%8F#%D0%92%D1%8A%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%B8_%D0%BF%D1%80%D0%BE%D0%B1%D0%BB%D0%B5%D0%BC%D0%B8 "Шаблон:Картинка на деня в Общомедия") [Още избрани картинки](https://commons.wikimedia.org/wiki/Commons:Featured_pictures "commons:Commons:Featured pictures")
  * [1187](https://bg.wikipedia.org/wiki/1187 "1187") г. – [сарацинският](https://bg.wikipedia.org/wiki/%D0%A1%D0%B0%D1%80%D0%B0%D1%86%D0%B8%D0%BD%D0%B8 "Сарацини") султан **[Саладин](https://bg.wikipedia.org/wiki/%D0%A1%D0%B0%D0%BB%D0%B0%D0%B4%D0%B8%D0%BD "Саладин")** превзема [Йерусалим](https://bg.wikipedia.org/wiki/%D0%99%D0%B5%D1%80%D1%83%D1%81%D0%B0%D0%BB%D0%B8%D0%BC "Йерусалим") след 88-годишно управление от [кръстоносците](https://bg.wikipedia.org/wiki/%D0%9A%D1%80%D1%8A%D1%81%D1%82%D0%BE%D0%BD%D0%BE%D1%81%D1%86%D0%B8 "Кръстоносци").

[![Чарлз Дарвин](https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Charles_Darwin.jpg/120px-Charles_Darwin.jpg)](https://bg.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Charles_Darwin.jpg "Чарлз Дарвин")Чарлз Дарвин
  * [1836](https://bg.wikipedia.org/wiki/1836 "1836") г. – **[Чарлз Дарвин](https://bg.wikipedia.org/wiki/%D0%A7%D0%B0%D1%80%D0%BB%D0%B7_%D0%94%D0%B0%D1%80%D0%B2%D0%B8%D0%BD "Чарлз Дарвин")** _(на снимката)_ се завръща в [Англия](https://bg.wikipedia.org/wiki/%D0%90%D0%BD%D0%B3%D0%BB%D0%B8%D1%8F "Англия") след 5-годишно изследователско пътешествие в южните океани на борда на кораба [HMS Бигъл](https://bg.wikipedia.org/wiki/HMS_%D0%91%D0%B8%D0%B3%D1%8A%D0%BB "HMS Бигъл").
  * [1941](https://bg.wikipedia.org/wiki/1941 "1941") г. – започва **[Операция Тайфун](https://bg.wikipedia.org/wiki/%D0%9E%D0%BF%D0%B5%D1%80%D0%B0%D1%86%D0%B8%D1%8F_%D0%A2%D0%B0%D0%B9%D1%84%D1%83%D0%BD "Операция Тайфун")** срещу [Москва](https://bg.wikipedia.org/wiki/%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0 "Москва"). Сформирана е [Вяземската фронтова отбранителна операция](https://bg.wikipedia.org/wiki/%D0%92%D1%8F%D0%B7%D0%B5%D0%BC%D1%81%D0%BA%D0%B0_%D1%84%D1%80%D0%BE%D0%BD%D1%82%D0%BE%D0%B2%D0%B0_%D0%BE%D1%82%D0%B1%D1%80%D0%B0%D0%BD%D0%B8%D1%82%D0%B5%D0%BB%D0%BD%D0%B0_%D0%BE%D0%BF%D0%B5%D1%80%D0%B0%D1%86%D0%B8%D1%8F "Вяземска фронтова отбранителна операция").
  * [1944](https://bg.wikipedia.org/wiki/1944 "1944") г. – [Втората световна война](https://bg.wikipedia.org/wiki/%D0%92%D1%82%D0%BE%D1%80%D0%B0%D1%82%D0%B0_%D1%81%D0%B2%D0%B5%D1%82%D0%BE%D0%B2%D0%BD%D0%B0_%D0%B2%D0%BE%D0%B9%D0%BD%D0%B0 "Втората световна война"): германците потушават **[Варшавското въстание](https://bg.wikipedia.org/wiki/%D0%92%D0%B0%D1%80%D1%88%D0%B0%D0%B2%D1%81%D0%BA%D0%BE%D1%82%D0%BE_%D0%B2%D1%8A%D1%81%D1%82%D0%B0%D0%BD%D0%B8%D0%B5 "Варшавското въстание")** ; съветските войски изчакват в близост до града.
  * [1956](https://bg.wikipedia.org/wiki/1956 "1956") г. – в [Ню Йорк](https://bg.wikipedia.org/wiki/%D0%9D%D1%8E_%D0%99%D0%BE%D1%80%D0%BA "Ню Йорк") е представен първият в света **[атомен часовник](https://bg.wikipedia.org/wiki/%D0%90%D1%82%D0%BE%D0%BC%D0%B5%D0%BD_%D1%87%D0%B0%D1%81%D0%BE%D0%B2%D0%BD%D0%B8%D0%BA "Атомен часовник")**.

[Всички дати](https://bg.wikipedia.org/wiki/%D0%98%D1%81%D1%82%D0%BE%D1%80%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8_%D0%B3%D0%BE%D0%B4%D0%B8%D1%88%D0%BD%D0%B8%D0%BD%D0%B8 "Исторически годишнини") – [Още събития...](https://bg.wikipedia.org/wiki/2_%D0%BE%D0%BA%D1%82%D0%BE%D0%BC%D0%B2%D1%80%D0%B8 "2 октомври")   
![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Cscr-featured.svg/20px-Cscr-featured.svg.png) **Избрани статии:** _гласуване_ за отстраняване на [Международна космическа станция](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%98%D0%B7%D0%B1%D1%80%D0%B0%D0%BD%D0%B8_%D1%81%D1%82%D0%B0%D1%82%D0%B8%D0%B8/%D0%9F%D1%80%D0%B5%D0%B4%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D1%8F_%D0%B7%D0%B0_%D0%BE%D1%82%D1%81%D1%82%D1%80%D0%B0%D0%BD%D1%8F%D0%B2%D0%B0%D0%BD%D0%B5/%D0%9C%D0%B5%D0%B6%D0%B4%D1%83%D0%BD%D0%B0%D1%80%D0%BE%D0%B4%D0%BD%D0%B0_%D0%BA%D0%BE%D1%81%D0%BC%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B0_%D1%81%D1%82%D0%B0%D0%BD%D1%86%D0%B8%D1%8F "Уикипедия:Избрани статии/Предложения за отстраняване/Международна космическа станция"), [Колизей](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%98%D0%B7%D0%B1%D1%80%D0%B0%D0%BD%D0%B8_%D1%81%D1%82%D0%B0%D1%82%D0%B8%D0%B8/%D0%9F%D1%80%D0%B5%D0%B4%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D1%8F_%D0%B7%D0%B0_%D0%BE%D1%82%D1%81%D1%82%D1%80%D0%B0%D0%BD%D1%8F%D0%B2%D0%B0%D0%BD%D0%B5/%D0%9A%D0%BE%D0%BB%D0%B8%D0%B7%D0%B5%D0%B9 "Уикипедия:Избрани статии/Предложения за отстраняване/Колизей"); _обсъждане_ на отстраняване на [Ар нуво](https://bg.wikipedia.org/wiki/%D0%91%D0%B5%D1%81%D0%B5%D0%B4%D0%B0:%D0%90%D1%80_%D0%BD%D1%83%D0%B2%D0%BE#%D0%9E%D1%82%D1%81%D1%82%D1%80%D0%B0%D0%BD%D1%8F%D0%B2%D0%B0%D0%BD%D0%B5_%D0%BE%D1%82_%D0%B8%D0%B7%D0%B1%D1%80%D0%B0%D0%BD%D0%B8 "Беседа:Ар нуво"), [Пийнътс](https://bg.wikipedia.org/wiki/%D0%91%D0%B5%D1%81%D0%B5%D0%B4%D0%B0:%D0%9F%D0%B8%D0%B9%D0%BD%D1%8A%D1%82%D1%81#%D0%9E%D1%82%D1%81%D1%82%D1%80%D0%B0%D0%BD%D1%8F%D0%B2%D0%B0%D0%BD%D0%B5_%D0%BE%D1%82_%D0%B8%D0%B7%D0%B1%D1%80%D0%B0%D0%BD%D0%B8 "Беседа:Пийнътс"), [Луна](https://bg.wikipedia.org/wiki/%D0%91%D0%B5%D1%81%D0%B5%D0%B4%D0%B0:%D0%9B%D1%83%D0%BD%D0%B0#%D0%9E%D1%82%D1%81%D1%82%D1%80%D0%B0%D0%BD%D1%8F%D0%B2%D0%B0%D0%BD%D0%B5_%D0%BE%D1%82_%D0%B8%D0%B7%D0%B1%D1%80%D0%B0%D0%BD%D0%B8 "Беседа:Луна"), [Черна дупка](https://bg.wikipedia.org/wiki/%D0%91%D0%B5%D1%81%D0%B5%D0%B4%D0%B0:%D0%A7%D0%B5%D1%80%D0%BD%D0%B0_%D0%B4%D1%83%D0%BF%D0%BA%D0%B0#%D0%9E%D1%82%D1%81%D1%82%D1%80%D0%B0%D0%BD%D1%8F%D0%B2%D0%B0%D0%BD%D0%B5_%D0%BE%D1%82_%D0%B8%D0%B7%D0%B1%D1%80%D0%B0%D0%BD%D0%B8 "Беседа:Черна дупка"), [Ензим](https://bg.wikipedia.org/wiki/%D0%91%D0%B5%D1%81%D0%B5%D0%B4%D0%B0:%D0%95%D0%BD%D0%B7%D0%B8%D0%BC#%D0%9E%D1%82%D1%81%D1%82%D1%80%D0%B0%D0%BD%D1%8F%D0%B2%D0%B0%D0%BD%D0%B5_%D0%BE%D1%82_%D0%B8%D0%B7%D0%B1%D1%80%D0%B0%D0%BD%D0%B8 "Беседа:Ензим") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Gartoon-Incandescent-Bulb.svg/20px-Gartoon-Incandescent-Bulb.svg.png) **[Идеи за нови статии](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%98%D0%B4%D0%B5%D0%B8_%D0%B7%D0%B0_%D1%81%D1%82%D0%B0%D1%82%D0%B8%D0%B8 "Уикипедия:Идеи за статии"):** [Стара крепост](https://bg.wikipedia.org/w/index.php?title=%D0%A1%D1%82%D0%B0%D1%80%D0%B0_%D0%BA%D1%80%D0%B5%D0%BF%D0%BE%D1%81%D1%82&action=edit&redlink=1 "Стара крепост \(страницата не съществува\)") ([крепост в Гърция](https://www.wikidata.org/wiki/Q606185 "d:Q606185")), [електрическа самобръсначка](https://bg.wikipedia.org/w/index.php?title=%D0%95%D0%BB%D0%B5%D0%BA%D1%82%D1%80%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B0_%D1%81%D0%B0%D0%BC%D0%BE%D0%B1%D1%80%D1%8A%D1%81%D0%BD%D0%B0%D1%87%D0%BA%D0%B0&action=edit&redlink=1 "Електрическа самобръсначка \(страницата не съществува\)") ([устройство](https://www.wikidata.org/wiki/Q17457835 "d:Q17457835")), [фашизъм в Европа](https://bg.wikipedia.org/w/index.php?title=%D0%A4%D0%B0%D1%88%D0%B8%D0%B7%D1%8A%D0%BC_%D0%B2_%D0%95%D0%B2%D1%80%D0%BE%D0%BF%D0%B0&action=edit&redlink=1 "Фашизъм в Европа \(страницата не съществува\)") ([Q5436685](https://www.wikidata.org/wiki/Q5436685 "d:Q5436685")); хора, родени на 2 октомври: [Ани Лейбовиц](https://bg.wikipedia.org/w/index.php?title=%D0%90%D0%BD%D0%B8_%D0%9B%D0%B5%D0%B9%D0%B1%D0%BE%D0%B2%D0%B8%D1%86&action=edit&redlink=1 "Ани Лейбовиц \(страницата не съществува\)") ([американска фотографка](https://www.wikidata.org/wiki/Q225283 "d:Q225283")), [Лорейн Брако](https://bg.wikipedia.org/w/index.php?title=%D0%9B%D0%BE%D1%80%D0%B5%D0%B9%D0%BD_%D0%91%D1%80%D0%B0%D0%BA%D0%BE&action=edit&redlink=1 "Лорейн Брако \(страницата не съществува\)") ([американска актриса](https://www.wikidata.org/wiki/Q229319 "d:Q229319")), [Шо Сасаки](https://bg.wikipedia.org/w/index.php?title=%D0%A8%D0%BE_%D0%A1%D0%B0%D1%81%D0%B0%D0%BA%D0%B8&action=edit&redlink=1 "Шо Сасаки \(страницата не съществува\)") ([японски футболист](https://www.wikidata.org/wiki/Q7499700 "d:Q7499700")) _[[р.](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%A0%D0%BE%D0%B6%D0%B4%D0%B5%D0%BD%D0%B8%D1%86%D0%B8/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD%D0%B8/10-02 "Уикипедия:Рожденици/Шаблони/10-02"), [всички](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%A0%D0%BE%D0%B6%D0%B4%D0%B5%D0%BD%D0%B8%D1%86%D0%B8/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD%D0%B8 "Уикипедия:Рожденици/Шаблони")]_ ![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/N_write.svg/20px-N_write.svg.png) **[Микромъничета](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9C%D0%B8%D0%BA%D1%80%D0%BE%D0%BC%D1%8A%D0%BD%D0%B8%D1%87%D0%B5 "Уикипедия:Микромъниче"):** [Иван Бирта](https://bg.wikipedia.org/wiki/%D0%98%D0%B2%D0%B0%D0%BD_%D0%91%D0%B8%D1%80%D1%82%D0%B0 "Иван Бирта") [Патрик-Габриел Галчев](https://bg.wikipedia.org/wiki/%D0%9F%D0%B0%D1%82%D1%80%D0%B8%D0%BA-%D0%93%D0%B0%D0%B1%D1%80%D0%B8%D0%B5%D0%BB_%D0%93%D0%B0%D0%BB%D1%87%D0%B5%D0%B2 "Патрик-Габриел Галчев") [Народно читалище „Дружба – 1870“](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%80%D0%BE%D0%B4%D0%BD%D0%BE_%D1%87%D0%B8%D1%82%D0%B0%D0%BB%D0%B8%D1%89%D0%B5_%E2%80%9E%D0%94%D1%80%D1%83%D0%B6%D0%B1%D0%B0_%E2%80%93_1870%E2%80%9C "Народно читалище „Дружба – 1870“") ![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b0/Songbird-egg.svg/20px-Songbird-egg.svg.png) **[Инкубатор](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%98%D0%BD%D0%BA%D1%83%D0%B1%D0%B0%D1%82%D0%BE%D1%80 "Уикипедия:Инкубатор"):** [Списък на статиите](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%98%D0%BD%D0%BA%D1%83%D0%B1%D0%B0%D1%82%D0%BE%D1%80/%D0%A1%D0%BF%D0%B8%D1%81%D1%8A%D0%BA_%D0%BD%D0%B0_%D1%81%D1%82%D0%B0%D1%82%D0%B8%D0%B8%D1%82%D0%B5 "Уикипедия:Инкубатор/Списък на статиите") ([помощ](https://bg.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D0%B5%D0%B3%D0%BE%D1%80%D0%B8%D1%8F:%D0%A1%D1%82%D0%B0%D1%82%D0%B8%D0%B8_%D0%B7%D0%B0_%D0%BF%D0%BE%D0%BC%D0%BE%D1%89 "Категория:Статии за помощ"), [проверка](https://bg.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D0%B5%D0%B3%D0%BE%D1%80%D0%B8%D1%8F:%D0%A1%D1%82%D0%B0%D1%82%D0%B8%D0%B8_%D0%B7%D0%B0_%D0%BF%D1%80%D0%BE%D0%B2%D0%B5%D1%80%D0%BA%D0%B0 "Категория:Статии за проверка")) ![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/25/Symbol_a_class.svg/20px-Symbol_a_class.svg.png) **[1000 статии](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:1000_%D1%81%D1%82%D0%B0%D1%82%D0%B8%D0%B8 "Уикипедия:1000 статии"):** _място_ : **7** ; _рейтинг_ : **85.52** ; _предложения_ : [Кожа](https://bg.wikipedia.org/wiki/%D0%9A%D0%BE%D0%B6%D0%B0 "Кожа"), [Адолф Хитлер](https://bg.wikipedia.org/wiki/%D0%90%D0%B4%D0%BE%D0%BB%D1%84_%D0%A5%D0%B8%D1%82%D0%BB%D0%B5%D1%80 "Адолф Хитлер"), [Ум Кулсум](https://bg.wikipedia.org/wiki/%D0%A3%D0%BC_%D0%9A%D1%83%D0%BB%D1%81%D1%83%D0%BC "Ум Кулсум"), [Пирамида (архитектура)](https://bg.wikipedia.org/wiki/%D0%9F%D0%B8%D1%80%D0%B0%D0%BC%D0%B8%D0%B4%D0%B0_\(%D0%B0%D1%80%D1%85%D0%B8%D1%82%D0%B5%D0%BA%D1%82%D1%83%D1%80%D0%B0\) "Пирамида \(архитектура\)"), [Часова зона](https://bg.wikipedia.org/wiki/%D0%A7%D0%B0%D1%81%D0%BE%D0%B2%D0%B0_%D0%B7%D0%BE%D0%BD%D0%B0 "Часова зона"), [Търговия](https://bg.wikipedia.org/wiki/%D0%A2%D1%8A%D1%80%D0%B3%D0%BE%D0%B2%D0%B8%D1%8F "Търговия"), [Звук](https://bg.wikipedia.org/wiki/%D0%97%D0%B2%D1%83%D0%BA "Звук").  
---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/Bgwiki_Bg_Site_2009_Plaquette.jpg/250px-Bgwiki_Bg_Site_2009_Plaquette.jpg)](https://bg.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Bgwiki_Bg_Site_2009_Plaquette.jpg) Специална награда на [БГ Сайт](https://bg.wikipedia.org/wiki/%D0%91%D0%93_%D0%A1%D0%B0%D0%B9%D1%82 "БГ Сайт") 2009 за Уикипедия на български език за принос в българското уеб пространство.  |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Distinctive_sign_from_the_Bulgarian_Archives_State_Agency.jpg/250px-Distinctive_sign_from_the_Bulgarian_Archives_State_Agency.jpg)](https://bg.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Distinctive_sign_from_the_Bulgarian_Archives_State_Agency.jpg) Отличителен знак **„Приятел на архивите 2016“** от [Държавна агенция „Архиви“](https://bg.wikipedia.org/wiki/%D0%94%D1%8A%D1%80%D0%B6%D0%B0%D0%B2%D0%BD%D0%B0_%D0%B0%D0%B3%D0%B5%D0%BD%D1%86%D0%B8%D1%8F_%E2%80%9E%D0%90%D1%80%D1%85%D0%B8%D0%B2%D0%B8%E2%80%9C "Държавна агенция „Архиви“") за Уикипедия на български език  
_„за принос в популяризирането на[архивни документи](https://commons.wikimedia.org/wiki/Category:Images_from_the_Bulgarian_Archives_State_Agency "c:Category:Images from the Bulgarian Archives State Agency") за личности и събития от българската история и [ползотворно сътрудничество с архивите](https://commons.wikimedia.org/wiki/Commons:%D0%94%D1%8A%D1%80%D0%B6%D0%B0%D0%B2%D0%BD%D0%B0_%D0%B0%D0%B3%D0%B5%D0%BD%D1%86%D0%B8%D1%8F_%22%D0%90%D1%80%D1%85%D0%B8%D0%B2%D0%B8%22 "c:Commons:Държавна агенция "Архиви"")“_.   
---|---  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/Wikiquote-logo.png/40px-Wikiquote-logo.png)](https://bg.wikiquote.org/wiki/ "Уикицитат") |  [**Уикицитат**](https://bg.wikiquote.org/wiki/ "q:")   
Цитати, афоризми, крилати фрази  |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Wiktionary-logo-en.png/40px-Wiktionary-logo-en.png)](https://bg.wiktionary.org/wiki/ "Уикиречник") |  [**Уикиречник**](https://bg.wiktionary.org/wiki/ "wikt:")   
Многоезичен речник  |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Wikibooks-logo.png/60px-Wikibooks-logo.png)](https://bg.wikibooks.org/wiki/ "Уикикниги") |  [**Уикикниги**](https://bg.wikibooks.org/wiki/ "b:")   
Книги, учебници и ръководства  |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/Wikidata-logo-en.svg/60px-Wikidata-logo-en.svg.png)](https://www.wikidata.org/wiki/ "Уикиданни") |  [**Уикиданни**](https://www.wikidata.org/wiki/ "d:")   
Свободна база знания  |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/40px-Wikivoyage-Logo-v3-icon.svg.png)](https://incubator.wikimedia.org/wiki/Wy/bg/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Уикипътешественик") |  [**Уикипътешественик**](https://incubator.wikimedia.org/wiki/Wy/bg/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "incubator:Wy/bg/Начална страница")   
Световен пътеводител   
---|---|---|---|---|---|---|---|---|---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/40px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Общомедия") |  [**Общомедия**](https://commons.wikimedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "commons:Начална страница")   
Свободно хранилище  |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Wikisource-logo.png/40px-Wikisource-logo.png)](https://bg.wikisource.org/wiki/ "Уикиизточник") |  [**Уикиизточник**](https://bg.wikisource.org/wiki/ "s:")   
Свободни източници  |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/Wikispecies-logo.png/40px-Wikispecies-logo.png)](https://species.wikimedia.org/wiki/ "Уикивидове") |  [**Уикивидове**](https://species.wikimedia.org/wiki/ "wikispecies:")   
Регистър на видовете  |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Wikimedia-logo.png/40px-Wikimedia-logo.png)](https://meta.wikimedia.org/wiki/ "Метауики") |  [**Метауики**](https://meta.wikimedia.org/wiki/ "m:")   
Съгласуване на проектите  |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/MediaWiki-2020-icon.svg/40px-MediaWiki-2020-icon.svg.png)](https://www.mediawiki.org/wiki/ "МедияУики") |  [**МедияУики**](https://www.mediawiki.org/wiki/ "mw:")   
Софтуерна уики платформа   
_Сродните на Уикипедия проекти се поддържат от[Фондация Уикимедия](https://bg.wikipedia.org/wiki/%D0%A4%D0%BE%D0%BD%D0%B4%D0%B0%D1%86%D0%B8%D1%8F_%D0%A3%D0%B8%D0%BA%D0%B8%D0%BC%D0%B5%D0%B4%D0%B8%D1%8F "Фондация Уикимедия")._  
_If you don't speak Bulgarian, please visit[our embassy](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9F%D0%BE%D1%81%D0%BE%D0%BB%D1%81%D1%82%D0%B2%D0%BE "Уикипедия:Посолство")._
  

Взето от „[https://bg.wikipedia.org/w/index.php?title=Начална_страница&oldid=11662729](https://bg.wikipedia.org/w/index.php?title=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&oldid=11662729)“.
353 езика
  * [Qafár af](https://aa.wikipedia.org/wiki/Main_Page "Main Page – афарски")
  * [Аԥсшәа](https://ab.wikipedia.org/wiki/%D0%98%D1%85%D0%B0%D0%B4%D0%BE%D1%83_%D0%B0%D0%B4%D0%B0%D2%9F%D1%8C%D0%B0 "Ихадоу адаҟьа – абхазки")
  * [Acèh](https://ace.wikipedia.org/wiki/%C3%94n_Keue "Ôn Keue – ачешки")
  * [Адыгабзэ](https://ady.wikipedia.org/wiki/%D0%9D%D1%8D%D0%BA%D3%80%D1%83%D0%B1%D0%B3%D1%8A%D0%BE_%D1%88%D1%8A%D1%85%D1%8C%D0%B0%D3%80 "НэкӀубгъо шъхьаӀ – адигейски")
  * [Afrikaans](https://af.wikipedia.org/wiki/Tuisblad "Tuisblad – африканс")
  * [Alemannisch](https://als.wikipedia.org/wiki/Wikipedia:Houptsyte "Wikipedia:Houptsyte – швейцарски немски")
  * [Алтай тил](https://alt.wikipedia.org/wiki/%D0%A2%D3%A7%D1%81_%D0%B1%D3%B1%D0%BA "Тӧс бӱк – южноалтайски")
  * [አማርኛ](https://am.wikipedia.org/wiki/%E1%8B%8B%E1%8A%93%E1%8B%8D_%E1%8C%88%E1%8C%BD "ዋናው ገጽ – амхарски")
  * [Pangcah](https://ami.wikipedia.org/wiki/Sa%E2%80%99ayayaw_pising_no_tyin-naw "Sa’ayayaw pising no tyin-naw – Amis")
  * [Aragonés](https://an.wikipedia.org/wiki/Portalada "Portalada – арагонски")
  * [Ænglisc](https://ang.wikipedia.org/wiki/Heafodtramet "Heafodtramet – староанглийски")
  * [Obolo](https://ann.wikipedia.org/wiki/Uwu "Uwu – оболо")
  * [अंगिका](https://anp.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – ангика")
  * [العربية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D8%A9 "الصفحة الرئيسة – арабски")
  * [ܐܪܡܝܐ](https://arc.wikipedia.org/wiki/%DC%A6%DC%90%DC%AC%DC%90_%DC%AA%DC%9D%DC%AB%DC%9D%DC%AC%DC%90 "ܦܐܬܐ ܪܝܫܝܬܐ – арамейски")
  * [الدارجة](https://ary.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9_%D8%A7%D9%84%D9%84%D9%88%D9%84%D8%A7 "الصفحة اللولا – Moroccan Arabic")
  * [مصرى](https://arz.wikipedia.org/wiki/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D9%87_%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D9%87 "الصفحه الرئيسيه – Egyptian Arabic")
  * [অসমীয়া](https://as.wikipedia.org/wiki/%E0%A6%AC%E0%A7%87%E0%A6%9F%E0%A7%81%E0%A6%AA%E0%A6%BE%E0%A6%A4 "বেটুপাত – асамски")
  * [Asturianu](https://ast.wikipedia.org/wiki/Portada "Portada – астурски")
  * [Atikamekw](https://atj.wikipedia.org/wiki/Otitikowin "Otitikowin – атикамеку")
  * [Авар](https://av.wikipedia.org/wiki/%D0%91%D0%B5%D1%82%D3%80%D0%B5%D1%80%D0%B0%D0%B1_%D0%B3%D1%8C%D1%83%D0%BC%D0%B5%D1%80 "БетӀераб гьумер – аварски")
  * [Kotava](https://avk.wikipedia.org/wiki/Xadola "Xadola – Kotava")
  * [अवधी](https://awa.wikipedia.org/wiki/%E0%A4%AA%E0%A5%8D%E0%A4%B0%E0%A4%A7%E0%A4%BE%E0%A4%A8_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "प्रधान पन्ना – авади")
  * [Aymar aru](https://ay.wikipedia.org/wiki/Nayriri_u%C3%B1stawi "Nayriri uñstawi – аймара")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/Ana_s%C9%99hif%C9%99 "Ana səhifə – азербайджански")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/%D8%A2%D9%86%D8%A7_%D8%B5%D9%81%D8%AD%D9%87 "آنا صفحه – South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – башкирски")
  * [Basa Bali](https://ban.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – балийски")
  * [Boarisch](https://bar.wikipedia.org/wiki/Wikipedia:Hoamseitn "Wikipedia:Hoamseitn – Bavarian")
  * [Žemaitėška](https://bat-smg.wikipedia.org/wiki/P%C4%97rms_poslapis "Pėrms poslapis – Samogitian")
  * [Batak Toba](https://bbc.wikipedia.org/wiki/Pogu_ni_Alaman "Pogu ni Alaman – Batak Toba")
  * [Bikol Central](https://bcl.wikipedia.org/wiki/Panginot_na_Pahina "Panginot na Pahina – Central Bikol")
  * [Bajau Sama](https://bdr.wikipedia.org/wiki/Tekokon_Laman "Tekokon Laman – West Coast Bajau")
  * [Беларуская](https://be.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – беларуски")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/%D0%93%D0%B0%D0%BB%D0%BE%D1%9E%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D0%B0%D1%80%D0%BE%D0%BD%D0%BA%D0%B0 "Галоўная старонка – Belarusian \(Taraškievica orthography\)")
  * [Betawi](https://bew.wikipedia.org/wiki/Bal%C3%A9-bal%C3%A9 "Balé-balé – Betawi")
  * [भोजपुरी](https://bh.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Bhojpuri")
  * [Bislama](https://bi.wikipedia.org/wiki/Nambawan_Pej "Nambawan Pej – бислама")
  * [Banjar](https://bjn.wikipedia.org/wiki/Laman_Tatambaian "Laman Tatambaian – Banjar")
  * [ပအိုဝ်ႏဘာႏသာႏ](https://blk.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%9C%E1%80%AD%E1%80%90%E1%80%BA%E1%80%99%E1%80%B2%E1%80%B7%E1%80%84%E1%80%AB "အဓိကလိတ်မဲ့ငါ – Pa'O")
  * [Bamanankan](https://bm.wikipedia.org/wiki/Ny%C9%9B_f%C9%94l%C9%94 "Nyɛ fɔlɔ – бамбара")
  * [বাংলা](https://bn.wikipedia.org/wiki/%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A7%E0%A6%BE%E0%A6%A8_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "প্রধান পাতা – бенгалски")
  * [བོད་ཡིག](https://bo.wikipedia.org/wiki/%E0%BD%82%E0%BD%99%E0%BD%BC%E0%BC%8B%E0%BD%84%E0%BD%BC%E0%BD%A6%E0%BC%8D "གཙོ་ངོས། – тибетски")
  * [বিষ্ণুপ্রিয়া মণিপুরী](https://bpy.wikipedia.org/wiki/%E0%A6%AA%E0%A6%AF%E0%A6%BC%E0%A6%B2%E0%A6%BE_%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE "পয়লা পাতা – Bishnupriya")
  * [Brezhoneg](https://br.wikipedia.org/wiki/Degemer "Degemer – бретонски")
  * [Bosanski](https://bs.wikipedia.org/wiki/Po%C4%8Detna_strana "Početna strana – босненски")
  * [Batak Mandailing](https://btm.wikipedia.org/wiki/Alaman_Utamo "Alaman Utamo – Batak Mandailing")
  * [Basa Ugi](https://bug.wikipedia.org/wiki/Watangpola "Watangpola – бугински")
  * [Буряад](https://bxr.wikipedia.org/wiki/%D0%9D%D1%8E%D1%83%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D2%BB%D0%B0%D0%BD "Нюур хуудаһан – Russia Buriat")
  * [Català](https://ca.wikipedia.org/wiki/Portada "Portada – каталонски")
  * [Chavacano de Zamboanga](https://cbk-zam.wikipedia.org/wiki/El_Primero_Pagina "El Primero Pagina – Chavacano")
  * [閩東語 / Mìng-dĕ̤ng-ngṳ̄](https://cdo.wikipedia.org/wiki/T%C3%A0u_Hi%C4%95k "Tàu Hiĕk – Mindong")
  * [Нохчийн](https://ce.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8C%D1%80%D1%82%D0%B0_%D0%B0%D0%B3%D3%80%D0%BE "Коьрта агӀо – чеченски")
  * [Cebuano](https://ceb.wikipedia.org/wiki/Unang_Panid "Unang Panid – себуански")
  * [Chamoru](https://ch.wikipedia.org/wiki/Fanhaluman "Fanhaluman – чаморо")
  * [Chahta anumpa](https://cho.wikipedia.org/wiki/Main_Page "Main Page – чокто")
  * [ᏣᎳᎩ](https://chr.wikipedia.org/wiki/%E1%8E%A4%E1%8E%B5%E1%8E%AE%E1%8E%B5%E1%8F%8D%E1%8F%97 "ᎤᎵᎮᎵᏍᏗ – черокски")
  * [Tsetsêhestâhese](https://chy.wikipedia.org/wiki/Va%27ohtama "Va'ohtama – шайенски")
  * [کوردی](https://ckb.wikipedia.org/wiki/%D8%AF%DB%95%D8%B3%D8%AA%D9%BE%DB%8E%DA%A9 "دەستپێک – кюрдски \(централен\)")
  * [Corsu](https://co.wikipedia.org/wiki/Pagina_maestra "Pagina maestra – корсикански")
  * [Nēhiyawēwin / ᓀᐦᐃᔭᐍᐏᐣ](https://cr.wikipedia.org/wiki/%E1%93%83%E1%94%A5%E1%91%95%E1%92%BB%E1%90%B9%E1%94%85%E1%91%8C%E1%92%8B%E1%93%82%E1%91%B2%E1%93%90 "ᓃᔥᑕᒻᐹᔅᑌᒋᓂᑲᓐ – крии")
  * [Qırımtatarca](https://crh.wikipedia.org/wiki/Ba%C5%9F_Saife "Baş Saife – кримскотатарски")
  * [Čeština](https://cs.wikipedia.org/wiki/Hlavn%C3%AD_strana "Hlavní strana – чешки")
  * [Kaszëbsczi](https://csb.wikipedia.org/wiki/Prz%C3%A9dn%C3%B4_starna "Przédnô starna – кашубски")
  * [Словѣньскъ / ⰔⰎⰑⰂⰡⰐⰠⰔⰍⰟ](https://cu.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D1%8C%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главьна страница – църковнославянски")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/%D0%A2%C4%95%D0%BF_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Тĕп страница – чувашки")
  * [Cymraeg](https://cy.wikipedia.org/wiki/Hafan "Hafan – уелски")
  * [Dansk](https://da.wikipedia.org/wiki/Forside "Forside – датски")
  * [Dagbanli](https://dag.wikipedia.org/wiki/Sol%C9%94%C9%A3u "Solɔɣu – Dagbani")
  * [Deutsch](https://de.wikipedia.org/wiki/Wikipedia:Hauptseite "Wikipedia:Hauptseite – немски")
  * [Dagaare](https://dga.wikipedia.org/wiki/A_Gamp%C9%9Bl%C9%9B_zu "A Gampɛlɛ zu – Southern Dagaare")
  * [Thuɔŋjäŋ](https://din.wikipedia.org/wiki/Apam_k%C3%ABd%C3%AFt "Apam këdït – динка")
  * [Zazaki](https://diq.wikipedia.org/wiki/Pela_Seri "Pela Seri – Dimli")
  * [Dolnoserbski](https://dsb.wikipedia.org/wiki/G%C5%82owny_bok "Głowny bok – долнолужишки")
  * [Kadazandusun](https://dtp.wikipedia.org/wiki/Natad_Tagayo "Natad Tagayo – Central Dusun")
  * [डोटेली](https://dty.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "मुख्य पन्ना – Doteli")
  * [ދިވެހިބަސް](https://dv.wikipedia.org/wiki/%DE%89%DE%A6%DE%87%DE%A8_%DE%9E%DE%A6%DE%8A%DE%B0%DE%99%DE%A7 "މައި ޞަފްޙާ – дивехи")
  * [ཇོང་ཁ](https://dz.wikipedia.org/wiki/%E0%BD%98%E0%BC%8B%E0%BD%A4%E0%BD%BC%E0%BD%82%E0%BC%8D "མ་ཤོག། – дзонгкха")
  * [Eʋegbe](https://ee.wikipedia.org/wiki/Axa_do_%C5%8Ag%C9%94 "Axa do Ŋgɔ – еве")
  * [Ελληνικά](https://el.wikipedia.org/wiki/%CE%A0%CF%8D%CE%BB%CE%B7:%CE%9A%CF%8D%CF%81%CE%B9%CE%B1 "Πύλη:Κύρια – гръцки")
  * [Emiliàn e rumagnòl](https://eml.wikipedia.org/wiki/PP "PP – Emiliano-Romagnolo")
  * [English](https://en.wikipedia.org/wiki/Main_Page "Main Page – английски")
  * [Esperanto](https://eo.wikipedia.org/wiki/Vikipedio:%C4%88efpa%C4%9Do "Vikipedio:Ĉefpaĝo – есперанто")
  * [Español](https://es.wikipedia.org/wiki/Wikipedia:Portada "Wikipedia:Portada – испански")
  * [Eesti](https://et.wikipedia.org/wiki/Vikipeedia:Esileht "Vikipeedia:Esileht – естонски")
  * [Euskara](https://eu.wikipedia.org/wiki/Azala "Azala – баски")
  * [Estremeñu](https://ext.wikipedia.org/wiki/Port%C3%A1_antigua "Portá antigua – Extremaduran")
  * [فارسی](https://fa.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C "صفحهٔ اصلی – персийски")
  * [Mfantse](https://fat.wikipedia.org/wiki/Kratafa_Tsitsir "Kratafa Tsitsir – фанти")
  * [Fulfulde](https://ff.wikipedia.org/wiki/Hello_ja%C9%93%C9%93orgo "Hello jaɓɓorgo – фула")
  * [Suomi](https://fi.wikipedia.org/wiki/Wikipedia:Etusivu "Wikipedia:Etusivu – фински")
  * [Võro](https://fiu-vro.wikipedia.org/wiki/Wikipedia:P%C3%A4%C3%A4leht "Wikipedia:Pääleht – Võro")
  * [Na Vosa Vakaviti](https://fj.wikipedia.org/wiki/Tabana_levu "Tabana levu – фиджийски")
  * [Føroyskt](https://fo.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – фарьорски")
  * [Fɔ̀ngbè](https://fon.wikipedia.org/wiki/W%C3%A9m%C3%A1_Nuk%C9%94nt%C9%94n "Wémá Nukɔntɔn – фон")
  * [Français](https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal "Wikipédia:Accueil principal – френски")
  * [Arpetan](https://frp.wikipedia.org/wiki/Vouiquip%C3%A8dia:Re%C3%A7ua_princip%C3%A2la "Vouiquipèdia:Reçua principâla – Arpitan")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/Wikipedia:Hoodsid "Wikipedia:Hoodsid – северен фризийски")
  * [Furlan](https://fur.wikipedia.org/wiki/Pagjine_princip%C3%A2l "Pagjine principâl – фриулски")
  * [Frysk](https://fy.wikipedia.org/wiki/Haadside "Haadside – западнофризийски")
  * [Gaeilge](https://ga.wikipedia.org/wiki/Pr%C3%ADomhleathanach "Príomhleathanach – ирландски")
  * [Gagauz](https://gag.wikipedia.org/wiki/Ba%C5%9F_yaprak "Baş yaprak – гагаузки")
  * [贛語](https://gan.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – Gan")
  * [Kriyòl gwiyannen](https://gcr.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – Guianan Creole")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/Pr%C3%AComh-Dhuilleag "Prìomh-Dhuilleag – шотландски келтски")
  * [Galego](https://gl.wikipedia.org/wiki/Portada "Portada – галисийски")
  * [گیلکی](https://glk.wikipedia.org/wiki/%DA%AF%D8%AA%CB%87_%D9%88%D9%84%DA%AF "گتˇ ولگ – Gilaki")
  * [Avañe'ẽ](https://gn.wikipedia.org/wiki/Kuatia_%C3%91epyr%C5%A9ha "Kuatia Ñepyrũha – гуарани")
  * [गोंयची कोंकणी / Gõychi Konknni](https://gom.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%87%E0%A4%B2_%E0%A4%AA%E0%A4%BE%E0%A4%A8 "मुखेल पान – Goan Konkani")
  * [Bahasa Hulontalo](https://gor.wikipedia.org/wiki/Halaman_Bungaliyo "Halaman Bungaliyo – горонтало")
  * [𐌲𐌿𐍄𐌹𐍃𐌺](https://got.wikipedia.org/wiki/%F0%90%8C%B0%F0%90%8C%BD%F0%90%8C%B0%F0%90%8D%83%F0%90%8D%84%F0%90%8D%89%F0%90%8C%B3%F0%90%8C%B4%F0%90%8C%B9%F0%90%8C%BD%F0%90%8C%B9%F0%90%8C%BB%F0%90%8C%B0%F0%90%8C%BF%F0%90%8D%86%F0%90%8D%83 "𐌰𐌽𐌰𐍃𐍄𐍉𐌳𐌴𐌹𐌽𐌹𐌻𐌰𐌿𐍆𐍃 – готически")
  * [Ghanaian Pidgin](https://gpe.wikipedia.org/wiki/Main_Page "Main Page – Ghanaian Pidgin")
  * [ગુજરાતી](https://gu.wikipedia.org/wiki/%E0%AA%AE%E0%AB%81%E0%AA%96%E0%AA%AA%E0%AB%83%E0%AA%B7%E0%AB%8D%E0%AA%A0 "મુખપૃષ્ઠ – гуджарати")
  * [Wayuunaiki](https://guc.wikipedia.org/wiki/Ee%27iyalaaya_a%27la%C3%BClaas%C3%BC "Ee'iyalaaya a'laülaasü – Wayuu")
  * [Farefare](https://gur.wikipedia.org/wiki/P%C9%9Bgezure "Pɛgezure – Frafra")
  * [Gungbe](https://guw.wikipedia.org/wiki/Weda_Tangan "Weda Tangan – Gun")
  * [Gaelg](https://gv.wikipedia.org/wiki/Ard-ghuillag "Ard-ghuillag – манкски")
  * [Hausa](https://ha.wikipedia.org/wiki/Babban_shafi "Babban shafi – хауса")
  * [客家語 / Hak-kâ-ngî](https://hak.wikipedia.org/wiki/Th%C3%A8u-Ya%CC%8Dp "Thèu-Ya̍p – Hakka Chinese")
  * [Hawaiʻi](https://haw.wikipedia.org/wiki/Ka_papa_kinohi "Ka papa kinohi – хавайски")
  * [עברית](https://he.wikipedia.org/wiki/%D7%A2%D7%9E%D7%95%D7%93_%D7%A8%D7%90%D7%A9%D7%99 "עמוד ראשי – иврит")
  * [हिन्दी](https://hi.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – хинди")
  * [Fiji Hindi](https://hif.wikipedia.org/wiki/Pahila_Panna "Pahila Panna – Fiji Hindi")
  * [Hiri Motu](https://ho.wikipedia.org/wiki/Main_Page "Main Page – хири моту")
  * [Hrvatski](https://hr.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – хърватски")
  * [Hornjoserbsce](https://hsb.wikipedia.org/wiki/H%C5%82owna_strona "Hłowna strona – горнолужишки")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/Paj_Prensipal "Paj Prensipal – хаитянски креолски")
  * [Magyar](https://hu.wikipedia.org/wiki/Kezd%C5%91lap "Kezdőlap – унгарски")
  * [Հայերեն](https://hy.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D5%BE%D5%B8%D6%80_%D5%A7%D5%BB "Գլխավոր էջ – арменски")
  * [Արեւմտահայերէն](https://hyw.wikipedia.org/wiki/%D4%B3%D5%AC%D5%AD%D5%A1%D6%82%D5%B8%D6%80_%D4%B7%D5%BB "Գլխաւոր Էջ – Western Armenian")
  * [Otsiherero](https://hz.wikipedia.org/wiki/Main_Page "Main Page – хереро")
  * [Interlingua](https://ia.wikipedia.org/wiki/Pagina_principal "Pagina principal – интерлингва")
  * [Jaku Iban](https://iba.wikipedia.org/wiki/Lambar_Keterubah "Lambar Keterubah – ибан")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/Halaman_Utama "Halaman Utama – индонезийски")
  * [Interlingue](https://ie.wikipedia.org/wiki/Principal_p%C3%A1gine "Principal págine – интерлингве")
  * [Igbo](https://ig.wikipedia.org/wiki/Ihu_m%CC%80b%E1%BB%A5 "Ihu m̀bụ – игбо")
  * [Igala](https://igl.wikipedia.org/wiki/Ogb%C3%A1_ogbolo "Ogbá ogbolo – Igala")
  * [Iñupiatun](https://ik.wikipedia.org/wiki/Aulla%C4%A1niisaa%C4%A1vik "Aullaġniisaaġvik – инупиак")
  * [Ilokano](https://ilo.wikipedia.org/wiki/Umuna_a_Panid "Umuna a Panid – илоко")
  * [ГӀалгӀай](https://inh.wikipedia.org/wiki/%D0%9A%D0%B5%D1%80%D1%82%D1%82%D0%B5%D1%80%D0%B0_%D0%BE%D0%B0%D0%B3%D3%80%D1%83%D0%B2 "Керттера оагӀув – ингушетски")
  * [Ido](https://io.wikipedia.org/wiki/Frontispico "Frontispico – идо")
  * [Íslenska](https://is.wikipedia.org/wiki/Fors%C3%AD%C3%B0a "Forsíða – исландски")
  * [Italiano](https://it.wikipedia.org/wiki/Pagina_principale "Pagina principale – италиански")
  * [ᐃᓄᒃᑎᑐᑦ / inuktitut](https://iu.wikipedia.org/wiki/%E1%90%8A%E1%92%A5%E1%96%85 "ᐊᒥᖅ – инуктитут")
  * [日本語](https://ja.wikipedia.org/wiki/%E3%83%A1%E3%82%A4%E3%83%B3%E3%83%9A%E3%83%BC%E3%82%B8 "メインページ – японски")
  * [Patois](https://jam.wikipedia.org/wiki/Mien_Piej "Mien Piej – Jamaican Creole English")
  * [La .lojban.](https://jbo.wikipedia.org/wiki/uikipedi%27as:ralju "uikipedi'as:ralju – ложбан")
  * [Jawa](https://jv.wikipedia.org/wiki/Wikip%C3%A9dia:Pendhapa "Wikipédia:Pendhapa – явански")
  * [ქართული](https://ka.wikipedia.org/wiki/%E1%83%9B%E1%83%97%E1%83%90%E1%83%95%E1%83%90%E1%83%A0%E1%83%98_%E1%83%92%E1%83%95%E1%83%94%E1%83%A0%E1%83%93%E1%83%98 "მთავარი გვერდი – грузински")
  * [Qaraqalpaqsha](https://kaa.wikipedia.org/wiki/Bas_bet "Bas bet – каракалпашки")
  * [Taqbaylit](https://kab.wikipedia.org/wiki/Asebter_agejdan "Asebter agejdan – кабилски")
  * [Адыгэбзэ](https://kbd.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D1%8D%D0%BA%D3%80%D1%83%D1%8D%D1%86%D3%80_%D0%BD%D1%8D%D1%85%D1%8A%D1%8B%D1%89%D1%85%D1%8C%D1%8D "НапэкӀуэцӀ нэхъыщхьэ – кабардски")
  * [Kabɩyɛ](https://kbp.wikipedia.org/wiki/Tal%C9%A9_%C9%96eu "Talɩ ɖeu – Kabiye")
  * [Tyap](https://kcg.wikipedia.org/wiki/A%CC%B1tsak_Wat_Wu "A̱tsak Wat Wu – туап")
  * [Kongo](https://kg.wikipedia.org/wiki/Muk%C3%A2nda_ya_ngudi "Mukânda ya ngudi – конгоански")
  * [Kumoring](https://kge.wikipedia.org/wiki/Wikipidiya:Garang "Wikipidiya:Garang – Komering")
  * [Gĩkũyũ](https://ki.wikipedia.org/wiki/Main_Page "Main Page – кикую")
  * [Kwanyama](https://kj.wikipedia.org/wiki/Main_Page "Main Page – кваняма")
  * [Қазақша](https://kk.wikipedia.org/wiki/%D0%91%D0%B0%D1%81%D1%82%D1%8B_%D0%B1%D0%B5%D1%82 "Басты бет – казахски")
  * [Kalaallisut](https://kl.wikipedia.org/wiki/Saqqaa "Saqqaa – гренландски")
  * [ភាសាខ្មែរ](https://km.wikipedia.org/wiki/%E1%9E%91%E1%9F%86%E1%9E%96%E1%9F%90%E1%9E%9A%E1%9E%8A%E1%9E%BE%E1%9E%98 "ទំព័រដើម – кхмерски")
  * [ಕನ್ನಡ](https://kn.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – каннада")
  * [Yerwa Kanuri](https://knc.wikipedia.org/wiki/Wikipedia:Shafi_kura "Wikipedia:Shafi kura – Central Kanuri")
  * [한국어](https://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:%EB%8C%80%EB%AC%B8 "위키백과:대문 – корейски")
  * [Перем коми](https://koi.wikipedia.org/wiki/%D0%9F%D0%BE%D0%BD%D0%B4%D3%A7%D1%82%D1%87%D0%B0%D0%BD_%D0%BB%D0%B8%D1%81%D1%82%D0%B1%D0%BE%D0%BA "Пондӧтчан листбок – коми-пермякски")
  * [Kanuri](https://kr.wikipedia.org/wiki/Main_Page "Main Page – канури")
  * [Къарачай-малкъар](https://krc.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B5%D1%82 "Баш бет – карачай-балкарски")
  * [کٲشُر](https://ks.wikipedia.org/wiki/%D8%A7%D9%8E%DB%81%D9%8E%D9%85_%D8%B5%D9%8E%D9%81%DB%81%D9%95 "اَہَم صَفہٕ – кашмирски")
  * [Ripoarisch](https://ksh.wikipedia.org/wiki/Wikipedia:Houpsigk "Wikipedia:Houpsigk – кьолнски")
  * [Kurdî](https://ku.wikipedia.org/wiki/Destp%C3%AAk "Destpêk – кюрдски")
  * [Kʋsaal](https://kus.wikipedia.org/wiki/Zug_lakir "Zug lakir – Kusaal")
  * [Коми](https://kv.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B4%D1%88%D3%A7%D1%80_%D0%BB%D0%B8%D1%81%D1%82_%D0%B1%D0%BE%D0%BA "Медшӧр лист бок – коми")
  * [Kernowek](https://kw.wikipedia.org/wiki/Folen_dre "Folen dre – корнуолски")
  * [Кыргызча](https://ky.wikipedia.org/wiki/%D0%91%D0%B0%D1%88%D0%BA%D1%8B_%D0%B1%D0%B0%D1%80%D0%B0%D0%BA "Башкы барак – киргизки")
  * [Latina](https://la.wikipedia.org/wiki/Vicipaedia:Pagina_prima "Vicipaedia:Pagina prima – латински")
  * [Ladino](https://lad.wikipedia.org/wiki/La_Primera_Oja "La Primera Oja – ладино")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/Haapts%C3%A4it "Haaptsäit – люксембургски")
  * [Лакку](https://lbe.wikipedia.org/wiki/%D0%90%D0%B3%D1%8C%D0%B0%D0%BC%D0%BC%D1%83%D1%80_%D0%BB%D0%B0%D0%B6%D0%B8%D0%BD "Агьаммур лажин – Lak")
  * [Лезги](https://lez.wikipedia.org/wiki/%D0%9A%D1%8C%D0%B8%D0%BB%D0%B8%D0%BD_%D1%87%D1%87%D0%B8%D0%BD "Кьилин ччин – лезгински")
  * [Lingua Franca Nova](https://lfn.wikipedia.org/wiki/Paje_xef "Paje xef – Lingua Franca Nova")
  * [Luganda](https://lg.wikipedia.org/wiki/Olupapula_Olusooka "Olupapula Olusooka – ганда")
  * [Limburgs](https://li.wikipedia.org/wiki/Veurblaad "Veurblaad – лимбургски")
  * [Ligure](https://lij.wikipedia.org/wiki/Pagina_prin%C3%A7ip%C3%A2 "Pagina prinçipâ – лигурски")
  * [Ladin](https://lld.wikipedia.org/wiki/Plata_prinzipala "Plata prinzipala – Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/Pagina_principala "Pagina principala – ломбардски")
  * [Lingála](https://ln.wikipedia.org/wiki/Lok%C3%A1s%C3%A1_ya_libos%C3%B3 "Lokásá ya libosó – лингала")
  * [ລາວ](https://lo.wikipedia.org/wiki/%E0%BB%9C%E0%BB%89%E0%BA%B2%E0%BA%AB%E0%BA%BC%E0%BA%B1%E0%BA%81 "ໜ້າຫຼັກ – лаоски")
  * [لۊری شومالی](https://lrc.wikipedia.org/wiki/%D8%B3%D8%B1%D8%A2%D8%B3%D9%88%D9%86%D9%B1 "سرآسونٱ – северен лури")
  * [Lietuvių](https://lt.wikipedia.org/wiki/Pagrindinis_puslapis "Pagrindinis puslapis – литовски")
  * [Latgaļu](https://ltg.wikipedia.org/wiki/Suoku_puslopa "Suoku puslopa – Latgalian")
  * [Latviešu](https://lv.wikipedia.org/wiki/S%C4%81kumlapa "Sākumlapa – латвийски")
  * [Madhurâ](https://mad.wikipedia.org/wiki/Tan%C3%A8yan "Tanèyan – мадурски")
  * [मैथिली](https://mai.wikipedia.org/wiki/%E0%A4%B8%E0%A4%AE%E0%A5%8D%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A8%E0%A5%8D%E0%A4%A8%E0%A4%BE "सम्मुख पन्ना – майтхили")
  * [Basa Banyumasan](https://map-bms.wikipedia.org/wiki/Kaca_Utama "Kaca Utama – Banyumasan")
  * [Мокшень](https://mdf.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F_%D0%BB%D0%BE%D0%BF%D0%B0 "Пря лопа – мокша")
  * [Malagasy](https://mg.wikipedia.org/wiki/Wikipedia:Fandraisana "Wikipedia:Fandraisana – малгашки")
  * [Ebon](https://mh.wikipedia.org/wiki/Main_Page "Main Page – маршалезе")
  * [Олык марий](https://mhr.wikipedia.org/wiki/%D0%A2%D3%B1%D2%A5_%D0%BB%D0%B0%D1%88%D1%82%D1%8B%D0%BA "Тӱҥ лаштык – Eastern Mari")
  * [Māori](https://mi.wikipedia.org/wiki/Hau_K%C4%81inga "Hau Kāinga – маорски")
  * [Minangkabau](https://min.wikipedia.org/wiki/Laman_Utamo "Laman Utamo – минангкабау")
  * [Македонски](https://mk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Главна страница – македонски")
  * [മലയാളം](https://ml.wikipedia.org/wiki/%E0%B4%AA%E0%B5%8D%E0%B4%B0%E0%B4%A7%E0%B4%BE%E0%B4%A8_%E0%B4%A4%E0%B4%BE%E0%B5%BE "പ്രധാന താൾ – малаялам")
  * [Монгол](https://mn.wikipedia.org/wiki/%D0%9D%D2%AF%D2%AF%D1%80_%D1%85%D1%83%D1%83%D0%B4%D0%B0%D1%81 "Нүүр хуудас – монголски")
  * [ꯃꯤꯇꯩ ꯂꯣꯟ](https://mni.wikipedia.org/wiki/%EA%AF%83%EA%AF%94%EA%AF%A8%EA%AF%91%EA%AF%A3%EA%AF%8F%EA%AF%95_%EA%AF%82%EA%AF%83%EA%AF%A5%EA%AF%8F "ꯃꯔꯨꯑꯣꯏꯕ ꯂꯃꯥꯏ – манипурски")
  * [ဘာသာမန်](https://mnw.wikipedia.org/wiki/%E1%80%99%E1%80%AF%E1%80%80%E1%80%BA%E1%80%9C%E1%80%AD%E1%80%80%E1%80%BA%E1%80%90%E1%80%99%E1%80%BA "မုက်လိက်တမ် – Mon")
  * [Moore](https://mos.wikipedia.org/wiki/Soraogo "Soraogo – моси")
  * [मराठी](https://mr.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुखपृष्ठ – марати")
  * [Кырык мары](https://mrj.wikipedia.org/wiki/%D0%A2%D3%B9%D0%BD%D0%B3_%D3%B9%D0%BB%D3%B9%D1%88%D1%82%D3%93%D1%88 "Тӹнг ӹлӹштӓш – Western Mari")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/Laman_Utama "Laman Utama – малайски")
  * [Malti](https://mt.wikipedia.org/wiki/Il-Pa%C4%A1na_prin%C4%8Bipali "Il-Paġna prinċipali – малтийски")
  * [Mvskoke](https://mus.wikipedia.org/wiki/Main_Page "Main Page – мускогски")
  * [Mirandés](https://mwl.wikipedia.org/wiki/Biquip%C3%A9dia:P%C3%A1igina_percipal "Biquipédia:Páigina percipal – мирандийски")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/%E1%80%97%E1%80%9F%E1%80%AD%E1%80%AF%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "ဗဟိုစာမျက်နှာ – бирмански")
  * [Эрзянь](https://myv.wikipedia.org/wiki/%D0%9F%D1%80%D1%8F%D0%B2%D1%82%D0%BB%D0%BE%D0%BF%D0%B0 "Прявтлопа – ерзиа")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/%DA%AF%D8%AA_%D8%B5%D9%81%D8%AD%D9%87 "گت صفحه – мазандерански")
  * [Nāhuatl](https://nah.wikipedia.org/wiki/Cal%C4%ABxatl "Calīxatl – Nahuatl")
  * [Napulitano](https://nap.wikipedia.org/wiki/Paggena_prencepale "Paggena prencepale – неаполитански")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/Wikipedia:H%C3%B6%C3%B6ftsiet "Wikipedia:Hööftsiet – долнонемски")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/V%C3%B6%C3%A4rblad "Vöärblad – долносаксонски")
  * [नेपाली](https://ne.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF_%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0 "मुख्य पृष्ठ – непалски")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/%E0%A4%AE%E0%A5%82_%E0%A4%AA%E0%A5%8C "मू पौ – неварски")
  * [Oshiwambo](https://ng.wikipedia.org/wiki/Hambili_Tarkerazu "Hambili Tarkerazu – ндонга")
  * [Li Niha](https://nia.wikipedia.org/wiki/Wikipedia:Olayama "Wikipedia:Olayama – ниас")
  * [Nederlands](https://nl.wikipedia.org/wiki/Hoofdpagina "Hoofdpagina – нидерландски")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/Hovudside "Hovudside – норвежки \(нюношк\)")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/Forside "Forside – норвежки \(букмол\)")
  * [Novial](https://nov.wikipedia.org/wiki/Chefi_pagine "Chefi pagine – Novial")
  * [ߒߞߏ](https://nqo.wikipedia.org/wiki/%DF%93%DF%8F%DF%AC%DF%9F%DF%8F%DF%B2%DF%AC%DF%98%DF%8A "ߓߏ߬ߟߏ߲߬ߘߊ – нко")
  * [IsiNdebele seSewula](https://nr.wikipedia.org/wiki/Main_Page "Main Page – южен ндебеле")
  * [Nouormand](https://nrm.wikipedia.org/wiki/Page_d%C3%A9_garde "Page dé garde – Norman")
  * [Sesotho sa Leboa](https://nso.wikipedia.org/wiki/Letlakala_la_pele "Letlakala la pele – северен сото")
  * [Nupe](https://nup.wikipedia.org/wiki/Kpataki_Kperegi "Kpataki Kperegi – Nupe")
  * [Diné bizaad](https://nv.wikipedia.org/wiki/%C3%8Diyis%C3%AD%C3%AD_Naaltsoos "Íiyisíí Naaltsoos – навахо")
  * [Chi-Chewa](https://ny.wikipedia.org/wiki/Tsamba_Lalikulu "Tsamba Lalikulu – нянджа")
  * [Occitan](https://oc.wikipedia.org/wiki/Acu%C3%A8lh "Acuèlh – окситански")
  * [Livvinkarjala](https://olo.wikipedia.org/wiki/Pi%C3%A4sivu "Piäsivu – Livvi-Karelian")
  * [Oromoo](https://om.wikipedia.org/wiki/Fuula_Dura "Fuula Dura – оромо")
  * [ଓଡ଼ିଆ](https://or.wikipedia.org/wiki/%E0%AC%AA%E0%AD%8D%E0%AC%B0%E0%AC%A7%E0%AC%BE%E0%AC%A8_%E0%AC%AA%E0%AD%83%E0%AC%B7%E0%AD%8D%E0%AC%A0%E0%AC%BE "ପ୍ରଧାନ ପୃଷ୍ଠା – ория")
  * [Ирон](https://os.wikipedia.org/wiki/%D0%A1%C3%A6%D0%B9%D1%80%D0%B0%D0%B3_%D1%84%D0%B0%D1%80%D1%81 "Сæйраг фарс – осетински")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/%E0%A8%AE%E0%A9%81%E0%A9%B1%E0%A8%96_%E0%A8%B8%E0%A8%AB%E0%A8%BC%E0%A8%BE "ਮੁੱਖ ਸਫ਼ਾ – пенджабски")
  * [Pangasinan](https://pag.wikipedia.org/wiki/Arapan_ya_Bolong "Arapan ya Bolong – пангасинан")
  * [Kapampangan](https://pam.wikipedia.org/wiki/Pun_Bulung "Pun Bulung – пампанга")
  * [Papiamentu](https://pap.wikipedia.org/wiki/P%C3%A1gina_Prinsipal "Página Prinsipal – папиаменто")
  * [Picard](https://pcd.wikipedia.org/wiki/Accueul "Accueul – Picard")
  * [Naijá](https://pcm.wikipedia.org/wiki/Main_Pej "Main Pej – нигерийски пиджин")
  * [Deitsch](https://pdc.wikipedia.org/wiki/Haaptblatt "Haaptblatt – Pennsylvania German")
  * [Pälzisch](https://pfl.wikipedia.org/wiki/Wikipedia:Haubdsaid "Wikipedia:Haubdsaid – Palatine German")
  * [पालि](https://pi.wikipedia.org/wiki/%E0%A4%AA%E0%A4%AE%E0%A5%81%E0%A4%96_%E0%A4%AA%E0%A4%A4%E0%A5%8D%E0%A4%A4_Pamukha_patta "पमुख पत्त Pamukha patta – пали")
  * [Norfuk / Pitkern](https://pih.wikipedia.org/wiki/Mien_Paij "Mien Paij – Pitcairn-Norfolk")
  * [Polski](https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna "Wikipedia:Strona główna – полски")
  * [Piemontèis](https://pms.wikipedia.org/wiki/Intrada "Intrada – Piedmontese")
  * [پنجابی](https://pnb.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D8%B5%D9%81%DB%81 "پہلا صفہ – Western Punjabi")
  * [Ποντιακά](https://pnt.wikipedia.org/wiki/%CE%91%CF%81%CF%87%CE%B9%CE%BA%CF%8C%CE%BD_%CF%83%CE%B5%CE%BB%CE%AF%CE%B4%CE%B1 "Αρχικόν σελίδα – Pontic")
  * [پښتو](https://ps.wikipedia.org/wiki/%D9%84%D9%88%D9%85%DA%93%DB%8C_%D9%85%D8%AE "لومړی مخ – пущу")
  * [Português](https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal "Wikipédia:Página principal – португалски")
  * [Pinayuanan](https://pwn.wikipedia.org/wiki/sitjumaq_na_sapitj "sitjumaq na sapitj – Paiwan")
  * [Runa Simi](https://qu.wikipedia.org/wiki/Qhapaq_p%27anqa "Qhapaq p'anqa – кечуа")
  * [ရခိုင်](https://rki.wikipedia.org/wiki/%E1%80%A1%E1%80%93%E1%80%AD%E1%80%80%E1%80%85%E1%80%AC%E1%80%99%E1%80%BB%E1%80%80%E1%80%BA%E1%80%94%E1%80%BE%E1%80%AC "အဓိကစာမျက်နှာ – Arakanese")
  * [Rumantsch](https://rm.wikipedia.org/wiki/Wikipedia:Pagina_principala "Wikipedia:Pagina principala – реторомански")
  * [Romani čhib](https://rmy.wikipedia.org/wiki/Sherutni_patrin "Sherutni patrin – Vlax Romani")
  * [Ikirundi](https://rn.wikipedia.org/wiki/Urupapuro_nyamukuru "Urupapuro nyamukuru – рунди")
  * [Română](https://ro.wikipedia.org/wiki/Pagina_principal%C4%83 "Pagina principală – румънски")
  * [Armãneashti](https://roa-rup.wikipedia.org/wiki/Prota_fr%C3%A3ndz%C3%A3 "Prota frãndzã – арумънски")
  * [Tarandíne](https://roa-tara.wikipedia.org/wiki/Pagene_Prengep%C3%A1le "Pagene Prengepále – Tarantino")
  * [Руски](https://rsk.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B8_%D0%B1%D0%BE%D0%BA "Главни бок – Pannonian Rusyn")
  * [Русский](https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0 "Заглавная страница – руски")
  * [Русиньскый](https://rue.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – Rusyn")
  * [Ikinyarwanda](https://rw.wikipedia.org/wiki/Intangiriro "Intangiriro – киняруанда")
  * [संस्कृतम्](https://sa.wikipedia.org/wiki/%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A5%8D%E0%A4%AF%E0%A4%AA%E0%A5%83%E0%A4%B7%E0%A5%8D%E0%A4%A0%E0%A4%AE%E0%A5%8D "मुख्यपृष्ठम् – санскрит")
  * [Саха тыла](https://sah.wikipedia.org/wiki/%D0%A1%D2%AF%D1%80%D2%AF%D0%BD_%D1%81%D0%B8%D1%80%D1%8D%D0%B9 "Сүрүн сирэй – саха")
  * [ᱥᱟᱱᱛᱟᱲᱤ](https://sat.wikipedia.org/wiki/%E1%B1%A2%E1%B1%A9%E1%B1%AC%E1%B1%A9%E1%B1%9B_%E1%B1%A5%E1%B1%9F%E1%B1%A6%E1%B1%B4%E1%B1%9F "ᱢᱩᱬᱩᱛ ᱥᱟᱦᱴᱟ – сантали")
  * [Sardu](https://sc.wikipedia.org/wiki/P%C3%A0gina_printzipale "Pàgina printzipale – сардински")
  * [Sicilianu](https://scn.wikipedia.org/wiki/P%C3%A0ggina_principali "Pàggina principali – сицилиански")
  * [Scots](https://sco.wikipedia.org/wiki/Main_Page "Main Page – шотландски")
  * [سنڌي](https://sd.wikipedia.org/wiki/%D9%85%D9%8F%DA%A9_%D8%B5%D9%81%D8%AD%D9%88 "مُک صفحو – синдхи")
  * [Davvisámegiella](https://se.wikipedia.org/wiki/Port%C3%A1la:Ovdasiidu "Portála:Ovdasiidu – северносаамски")
  * [Sängö](https://sg.wikipedia.org/wiki/G%C3%A4_nz%C3%B6n%C3%AE "Gä nzönî – санго")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/Glavna_stranica "Glavna stranica – сърбохърватски")
  * [Taclḥit](https://shi.wikipedia.org/wiki/Tasna_Tamzwarut "Tasna Tamzwarut – ташелхит")
  * [တႆး](https://shn.wikipedia.org/wiki/%E1%81%BC%E1%82%83%E1%82%88%E1%82%81%E1%80%B0%E1%80%9D%E1%80%BA%E1%82%81%E1%82%85%E1%81%B5%E1%80%BA%E1%82%88 "ၼႃႈႁူဝ်ႁႅၵ်ႈ – шан")
  * [සිංහල](https://si.wikipedia.org/wiki/%E0%B6%B8%E0%B7%94%E0%B6%BD%E0%B7%8A_%E0%B6%B4%E0%B7%92%E0%B6%A7%E0%B7%94%E0%B7%80 "මුල් පිටුව – синхалски")
  * [Simple English](https://simple.wikipedia.org/wiki/Main_Page "Main Page – Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/Hlavn%C3%A1_str%C3%A1nka "Hlavná stránka – словашки")
  * [سرائیکی](https://skr.wikipedia.org/wiki/%D9%BE%DB%81%D9%84%D8%A7_%D9%BE%D8%B1%D8%AA "پہلا پرت – Saraiki")
  * [Slovenščina](https://sl.wikipedia.org/wiki/Glavna_stran "Glavna stran – словенски")
  * [Gagana Samoa](https://sm.wikipedia.org/wiki/It%C5%ABlau_Muamua "Itūlau Muamua – самоански")
  * [Anarâškielâ](https://smn.wikipedia.org/wiki/Ovd%C3%A2sij%C4%91o "Ovdâsijđo – инари-саамски")
  * [ChiShona](https://sn.wikipedia.org/wiki/Peji_Rekutanga "Peji Rekutanga – шона")
  * [Soomaaliga](https://so.wikipedia.org/wiki/Bogga_Hore "Bogga Hore – сомалийски")
  * [Shqip](https://sq.wikipedia.org/wiki/Faqja_kryesore "Faqja kryesore – албански")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B0 "Главна страна – сръбски")
  * [Sranantongo](https://srn.wikipedia.org/wiki/Fesipapira "Fesipapira – сранан тонго")
  * [SiSwati](https://ss.wikipedia.org/wiki/Likhasi_Lelikhulu "Likhasi Lelikhulu – свати")
  * [Sesotho](https://st.wikipedia.org/wiki/Leqephe_la_pele "Leqephe la pele – сото")
  * [Seeltersk](https://stq.wikipedia.org/wiki/Haudsiede "Haudsiede – Saterland Frisian")
  * [Sunda](https://su.wikipedia.org/wiki/Tepas "Tepas – сундански")
  * [Svenska](https://sv.wikipedia.org/wiki/Portal:Huvudsida "Portal:Huvudsida – шведски")
  * [Kiswahili](https://sw.wikipedia.org/wiki/Mwanzo "Mwanzo – суахили")
  * [ꠍꠤꠟꠐꠤ](https://syl.wikipedia.org/wiki/%EA%A0%9D%EA%A0%A5%EA%A0%9F_%EA%A0%9A%EA%A0%A3%EA%A0%94%EA%A0%A3 "ꠝꠥꠟ ꠚꠣꠔꠣ – Sylheti")
  * [Ślůnski](https://szl.wikipedia.org/wiki/Przodni%C5%8F_zajta "Przodniŏ zajta – силезийски")
  * [Sakizaya](https://szy.wikipedia.org/wiki/saayaway_a_belih "saayaway a belih – Sakizaya")
  * [தமிழ்](https://ta.wikipedia.org/wiki/%E0%AE%AE%E0%AF%81%E0%AE%A4%E0%AE%B1%E0%AF%8D_%E0%AE%AA%E0%AE%95%E0%AF%8D%E0%AE%95%E0%AE%AE%E0%AF%8D "முதற் பக்கம் – тамилски")
  * [Tayal](https://tay.wikipedia.org/wiki/T%E2%80%99ringan_na_zzngayan "T’ringan na zzngayan – Atayal")
  * [ತುಳು](https://tcy.wikipedia.org/wiki/%E0%B2%AE%E0%B3%81%E0%B2%96%E0%B3%8D%E0%B2%AF_%E0%B2%AA%E0%B3%81%E0%B2%9F "ಮುಖ್ಯ ಪುಟ – Tulu")
  * [ᥖᥭᥰ ᥖᥬᥲ ᥑᥨᥒᥰ](https://tdd.wikipedia.org/wiki/%E1%A5%9E%E1%A5%A8%E1%A5%9D%E1%A5%B4_%E1%A5%98%E1%A5%A3%E1%A5%B2_%E1%A5%96%E1%A5%A5%E1%A5%B0 "ᥞᥨᥝᥴ ᥘᥣᥲ ᥖᥥᥰ – Tai Nuea")
  * [తెలుగు](https://te.wikipedia.org/wiki/%E0%B0%AE%E0%B1%8A%E0%B0%A6%E0%B0%9F%E0%B0%BF_%E0%B0%AA%E0%B1%87%E0%B0%9C%E0%B1%80 "మొదటి పేజీ – телугу")
  * [Tetun](https://tet.wikipedia.org/wiki/P%C3%A1jina_Mahuluk "Pájina Mahuluk – тетум")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/%D0%A1%D0%B0%D2%B3%D0%B8%D1%84%D0%B0%D0%B8_%D0%B0%D1%81%D0%BB%D3%A3 "Саҳифаи аслӣ – таджикски")
  * [ไทย](https://th.wikipedia.org/wiki/%E0%B8%AB%E0%B8%99%E0%B9%89%E0%B8%B2%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81 "หน้าหลัก – тайски")
  * [ትግርኛ](https://ti.wikipedia.org/wiki/%E1%88%98%E1%89%A0%E1%8C%88%E1%88%B2_%E1%8C%88%E1%8C%BD "መበገሲ ገጽ – тигриня")
  * [ትግሬ](https://tig.wikipedia.org/wiki/%E1%8A%A0%E1%8C%8D%E1%8B%B3_%E1%8C%88%E1%8C%BD "አግዳ ገጽ – тигре")
  * [Türkmençe](https://tk.wikipedia.org/wiki/Ba%C5%9F_Sahypa "Baş Sahypa – туркменски")
  * [Tagalog](https://tl.wikipedia.org/wiki/Unang_Pahina "Unang Pahina – тагалог")
  * [Tolışi](https://tly.wikipedia.org/wiki/S%C9%99rlovh%C9%99 "Sərlovhə – Talysh")
  * [Setswana](https://tn.wikipedia.org/wiki/Tsebe_ya_konokono "Tsebe ya konokono – тсвана")
  * [Lea faka-Tonga](https://to.wikipedia.org/wiki/Peesi_tali_fiefia "Peesi tali fiefia – тонгански")
  * [Tok Pisin](https://tpi.wikipedia.org/wiki/Fran_pes "Fran pes – ток писин")
  * [Türkçe](https://tr.wikipedia.org/wiki/Anasayfa "Anasayfa – турски")
  * [Seediq](https://trv.wikipedia.org/wiki/Ruwahan_patas "Ruwahan patas – тароко")
  * [Xitsonga](https://ts.wikipedia.org/wiki/Tlukankulu "Tlukankulu – цонга")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/%D0%91%D0%B0%D1%88_%D0%B1%D0%B8%D1%82 "Баш бит – татарски")
  * [ChiTumbuka](https://tum.wikipedia.org/wiki/Jani_likulu "Jani likulu – тумбука")
  * [Twi](https://tw.wikipedia.org/wiki/Kratafa_Titiriw "Kratafa Titiriw – туи")
  * [Reo tahiti](https://ty.wikipedia.org/wiki/Fa%E2%80%99ari%E2%80%99ira%E2%80%99a "Fa’ari’ira’a – таитянски")
  * [Тыва дыл](https://tyv.wikipedia.org/wiki/%D0%9A%D0%BE%D0%BB_%D0%B0%D1%80%D1%8B%D0%BD "Кол арын – тувински")
  * [Удмурт](https://udm.wikipedia.org/wiki/%D0%9A%D1%83%D1%82%D1%81%D0%BA%D0%BE%D0%BD_%D0%B1%D0%B0%D0%BC "Кутскон бам – удмуртски")
  * [ئۇيغۇرچە / Uyghurche](https://ug.wikipedia.org/wiki/%D8%A8%D8%A7%D8%B4_%D8%A8%DB%95%D8%AA "باش بەت – уйгурски")
  * [Українська](https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0 "Головна сторінка – украински")
  * [اردو](https://ur.wikipedia.org/wiki/%D8%B5%D9%81%D8%AD%DB%82_%D8%A7%D9%88%D9%84 "صفحۂ اول – урду")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/Bosh_Sahifa "Bosh Sahifa – узбекски")
  * [Tshivenda](https://ve.wikipedia.org/wiki/Hayani "Hayani – венда")
  * [Vèneto](https://vec.wikipedia.org/wiki/Wikipedia:Prinsipio "Wikipedia:Prinsipio – венециански")
  * [Vepsän kel’](https://vep.wikipedia.org/wiki/P%C3%A4lehtpol%E2%80%99 "Pälehtpol’ – Veps")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/Trang_Ch%C3%ADnh "Trang Chính – виетнамски")
  * [West-Vlams](https://vls.wikipedia.org/wiki/Voorblad "Voorblad – West Flemish")
  * [Volapük](https://vo.wikipedia.org/wiki/Cifapad "Cifapad – волапюк")
  * [Walon](https://wa.wikipedia.org/wiki/Mwaisse_p%C3%A5dje "Mwaisse pådje – валонски")
  * [Winaray](https://war.wikipedia.org/wiki/Syahan_nga_Pakli "Syahan nga Pakli – варай")
  * [Wolof](https://wo.wikipedia.org/wiki/X%C3%ABt_wu_nj%C3%ABkk "Xët wu njëkk – волоф")
  * [吴语](https://wuu.wikipedia.org/wiki/%E5%B0%81%E9%9D%A2 "封面 – ву китайски")
  * [Хальмг](https://xal.wikipedia.org/wiki/%D0%9D%D2%AF%D1%80_%D1%85%D0%B0%D0%BB%D1%85 "Нүр халх – калмик")
  * [IsiXhosa](https://xh.wikipedia.org/wiki/Iphepha_Elingundoqo "Iphepha Elingundoqo – кхоса")
  * [მარგალური](https://xmf.wikipedia.org/wiki/%E1%83%93%E1%83%A3%E1%83%93%E1%83%AE%E1%83%90%E1%83%A1%E1%83%B7%E1%83%9A%E1%83%90 "დუდხასჷლა – Mingrelian")
  * [ייִדיש](https://yi.wikipedia.org/wiki/%D7%94%D7%95%D7%99%D7%A4%D7%98_%D7%96%D7%99%D7%99%D7%98 "הויפט זייט – идиш")
  * [Yorùbá](https://yo.wikipedia.org/wiki/Oj%C3%BAew%C3%A9_%C3%80k%E1%BB%8D%CC%81k%E1%BB%8D%CC%81 "Ojúewé Àkọ́kọ́ – йоруба")
  * [Vahcuengh](https://za.wikipedia.org/wiki/Yiebdaeuz "Yiebdaeuz – зуанг")
  * [Zeêuws](https://zea.wikipedia.org/wiki/V%C3%B2blad "Vòblad – Zeelandic")
  * [ⵜⴰⵎⴰⵣⵉⵖⵜ ⵜⴰⵏⴰⵡⴰⵢⵜ](https://zgh.wikipedia.org/wiki/%E2%B5%9C%E2%B4%B0%E2%B5%99%E2%B5%8F%E2%B4%B0_%E2%B5%8F_%E2%B5%93%E2%B5%99%E2%B5%8F%E2%B5%93%E2%B4%B1%E2%B4%B3 "ⵜⴰⵙⵏⴰ ⵏ ⵓⵙⵏⵓⴱⴳ – стандартен марокански тамазигт")
  * [中文](https://zh.wikipedia.org/wiki/Wikipedia:%E9%A6%96%E9%A1%B5 "Wikipedia:首页 – китайски")
  * [文言](https://zh-classical.wikipedia.org/wiki/%E7%B6%AD%E5%9F%BA%E5%A4%A7%E5%85%B8:%E5%8D%B7%E9%A6%96 "維基大典:卷首 – Literary Chinese")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/Th%C3%A2u-ia%CC%8Dh "Thâu-ia̍h – Minnan")
  * [粵語](https://zh-yue.wikipedia.org/wiki/%E9%A0%AD%E7%89%88 "頭版 – кантонски")
  * [IsiZulu](https://zu.wikipedia.org/wiki/Ikhasi_Elikhulu "Ikhasi Elikhulu – зулуски")


[Редактиране](https://www.wikidata.org/wiki/Special:EntityPage/Q5296#sitelinks-wikipedia "Редактиране на междуезиковите препратки")
  * Последната промяна на страницата е извършена на 25 януари 2023 г. в 16:26 ч.
  * Текстът е достъпен под лиценза [Creative Commons Признание-Споделяне на споделеното](https://creativecommons.org/licenses/by-sa/4.0/deed.bg); може да са приложени допълнителни условия. За подробности вижте [Условия за ползване](https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/bg).


  * [Поверителност](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [За контакт с Уикипедия](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%97%D0%B0_%D0%BA%D0%BE%D0%BD%D1%82%D0%B0%D0%BA%D1%82%D0%B8)
  * [Предупреждение](https://bg.wikipedia.org/wiki/%D0%A3%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%9F%D1%80%D0%B5%D0%B4%D1%83%D0%BF%D1%80%D0%B5%D0%B6%D0%B4%D0%B5%D0%BD%D0%B8%D0%B5)
  * [Кодекс на поведение](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [За разработчици](https://developer.wikimedia.org)
  * [Статистика](https://stats.wikimedia.org/#/bg.wikipedia.org)
  * [Използване на „бисквитки“](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Мобилен изглед](https://bg.m.wikipedia.org/w/index.php?title=%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0&mobileaction=toggle_view_mobile)
  * [Редактиране на настройките за преглеждане](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)


  * [![Wikimedia Foundation](https://bg.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://bg.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Търсене
Търсене
Начална страница
[](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0) [](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0) [](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0) [](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0) [](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0) [](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0) [](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0) [](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
353 езика [Добавяне на тема ](https://bg.wikipedia.org/wiki/%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BD%D0%B0_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0)
