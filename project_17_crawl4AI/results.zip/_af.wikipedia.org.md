[Gaan na inhoud](https://af.wikipedia.org/wiki/Tuisblad#bodyContent)
Hoofkieslys
Hoofkieslys
skuif na kantbalk versteek
Navigasie 
  * [Tuisblad](https://af.wikipedia.org/wiki/Tuisblad "Gaan na die tuisblad \[z\]")
  * [Geselshoekie](https://af.wikipedia.org/wiki/Wikipedia:Geselshoekie "Agtergrondinligting oor aktuele sake")
  * [Onlangse wysigings](https://af.wikipedia.org/wiki/Spesiaal:Onlangse_wysigings "'n Lys van onlangse wysigings \[r\]")
  * [Inligting oor Wikipedia](https://af.wikipedia.org/wiki/Wikipedia:About)
  * [Kontakblad](https://af.wikipedia.org/wiki/Contact-url)
  * [Sandput](https://af.wikipedia.org/wiki/Wikipedia:Sandput)


SEARCH <!-- doen dit iets? -->
Interaksie 
  * [Hulp](https://af.wikipedia.org/wiki/Wikipedia:Hulp)
  * [Leer hoe om te wysig](https://af.wikipedia.org/wiki/Wikipedia:Welkom_nuwelinge)
  * [Gebruikersportaal](https://af.wikipedia.org/wiki/Wikipedia:Gebruikersportaal "Meer oor die projek, wat jy kan doen, nuttige skakels")
  * [Laai lêer](https://af.wikipedia.org/wiki/Wikipedia:File_upload_wizard)
  * [Lukrake bladsy](https://af.wikipedia.org/wiki/Spesiaal:Lukraak "Laai 'n lukrake bladsye \[x\]")
  * [Spesiale bladsye](https://af.wikipedia.org/wiki/Spesiaal:Spesiale_bladsye)


TOOLBOX <!-- doen dit iets? -->
[ ![](https://af.wikipedia.org/static/images/icons/wikipedia.png) ![Wikipedia](https://af.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![](https://af.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-af.svg) ](https://af.wikipedia.org/wiki/Tuisblad)
[Soek ](https://af.wikipedia.org/wiki/Spesiaal:Soek "Deursoek Wikipedia \[f\]")
Soek
Voorkoms
  * [Skenkings](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=af.wikipedia.org&uselang=af)
  * [Skep gebruiker](https://af.wikipedia.org/w/index.php?title=Spesiaal:SkepRekening&returnto=Tuisblad "U word aangemoedig om 'n gebruiker te skep en aan te meld, hoewel dit nie verpligtend is nie.")
  * [Meld aan](https://af.wikipedia.org/w/index.php?title=Spesiaal:Teken_in&returnto=Tuisblad "U word aangemoedig om aan te meld. Dit is egter nie verpligtend nie. \[o\]")


Persoonlike gereedskap
  * [Skenkings](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=af.wikipedia.org&uselang=af)
  * [Skep gebruiker](https://af.wikipedia.org/w/index.php?title=Spesiaal:SkepRekening&returnto=Tuisblad "U word aangemoedig om 'n gebruiker te skep en aan te meld, hoewel dit nie verpligtend is nie.")
  * [Meld aan](https://af.wikipedia.org/w/index.php?title=Spesiaal:Teken_in&returnto=Tuisblad "U word aangemoedig om aan te meld. Dit is egter nie verpligtend nie. \[o\]")


# Tuisblad
  * [Tuisblad](https://af.wikipedia.org/wiki/Tuisblad "Bekyk die inhoudbladsy \[c\]")
  * [Bespreking](https://af.wikipedia.org/wiki/Bespreking:Tuisblad "Bespreking oor die inhoudbladsy \[t\]")


Afrikaans
  * [Lees](https://af.wikipedia.org/wiki/Tuisblad)
  * [Wys bronteks](https://af.wikipedia.org/w/index.php?title=Tuisblad&action=edit "Hierdie bladsy is beskerm. U kan die bronteks besigtig. \[e\]")
  * [Wys geskiedenis](https://af.wikipedia.org/w/index.php?title=Tuisblad&action=history "Ouer weergawes van hierdie bladsy \[h\]")


Gereedskap
Gereedskap
skuif na kantbalk versteek
Aksies 
  * [Lees](https://af.wikipedia.org/wiki/Tuisblad)
  * [Wys bronteks](https://af.wikipedia.org/w/index.php?title=Tuisblad&action=edit)
  * [Wys geskiedenis](https://af.wikipedia.org/w/index.php?title=Tuisblad&action=history)


Algemeen 
  * [Skakels hierheen](https://af.wikipedia.org/wiki/Spesiaal:Skakels_hierheen/Tuisblad "'n Lys bladsye wat hierheen skakel \[j\]")
  * [Verwante veranderings](https://af.wikipedia.org/wiki/Spesiaal:OnlangseVeranderingsMetSkakels/Tuisblad "Onlangse wysigings aan bladsye wat vanaf hierdie bladsy geskakel is \[k\]")
  * [Permanente skakel](https://af.wikipedia.org/w/index.php?title=Tuisblad&oldid=2774431 "'n Permanente skakel na hierdie weergawe van die bladsy")
  * [Bladinligting](https://af.wikipedia.org/w/index.php?title=Tuisblad&action=info "More information about this page")
  * [Haal dié blad aan](https://af.wikipedia.org/w/index.php?title=Spesiaal:CiteThisPage&page=Tuisblad&id=2774431&wpFormIdentifier=titleform "Inligting oor hoe u hierdie bladsy kan verwys")
  * [Kry verkorte URL](https://af.wikipedia.org/w/index.php?title=Spesiaal:UrlShortener&url=https%3A%2F%2Faf.wikipedia.org%2Fwiki%2FTuisblad)
  * [Laai QR-kode af](https://af.wikipedia.org/w/index.php?title=Spesiaal:QrCode&url=https%3A%2F%2Faf.wikipedia.org%2Fwiki%2FTuisblad)


Druk/uitvoer 
  * [Skep boek](https://af.wikipedia.org/w/index.php?title=Spesiaal:Boek&bookcmd=book_creator&referer=Tuisblad)
  * [Laai af as PDF](https://af.wikipedia.org/w/index.php?title=Spesiaal:DownloadAsPdf&page=Tuisblad&action=show-download-screen)
  * [Drukbare weergawe](https://af.wikipedia.org/w/index.php?title=Tuisblad&printable=yes "Drukbare weergawe van hierdie bladsy \[p\]")


Ander projekte 
  * [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Foundation](https://foundation.wikimedia.org/wiki/Home)
  * [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
  * [Meta-Wiki](https://meta.wikimedia.org/wiki/Main_Page)
  * [Wikimedia Outreach](https://outreach.wikimedia.org/wiki/Main_Page)
  * [Multilingual Wikisource](https://wikisource.org/wiki/Main_Page)
  * [Wikispesies](https://species.wikimedia.org/wiki/Main_Page)
  * [Wikiboeke](https://af.wikibooks.org/wiki/Tuisblad)
  * [Wikidata](https://www.wikidata.org/wiki/Wikidata:Main_Page)
  * [Wikifunctions](https://www.wikifunctions.org/wiki/Wikifunctions:Main_Page)
  * [Wikiaanhaling](https://af.wikiquote.org/wiki/Tuisblad)
  * [Wiktionary](https://af.wiktionary.org/wiki/Tuisblad)
  * [Wikidata-item](https://www.wikidata.org/wiki/Special:EntityPage/Q5296 "Skakel na gekonnekteerde databank item \[g\]")


Voorkoms
skuif na kantbalk versteek
in Wikipedia, die vrye ensiklopedie
[Welkom](https://af.wikipedia.org/wiki/Wikipedia:Welkom_nuwelinge "Wikipedia:Welkom nuwelinge") by [Wikipedia](https://af.wikipedia.org/wiki/Wikipedia "Wikipedia"), die **vrye ensiklopedie** wat **[deur enigiemand verbeter en uitgebrei kan word](https://af.wikipedia.org/wiki/Wikipedia:Gebruikersportaal "Wikipedia:Gebruikersportaal").** |  Donderdag, 2 Oktober 2025  
Hier is tans [126 504](https://af.wikipedia.org/wiki/Spesiaal:Statistiek "Spesiaal:Statistiek") artikels in [Afrikaans](https://af.wikipedia.org/wiki/Afrikaans "Afrikaans").  
---|---  
[Help ons om ’n wêreldklas-ensiklopedie in Afrikaans te skep.](https://af.wikipedia.org/wiki/Wikipedia:Hoe_kan_ek_help%3F "Wikipedia:Hoe kan ek help?")  
[Inleiding](https://af.wikipedia.org/wiki/Wikipedia:Welkom_nuwelinge "Wikipedia:Welkom nuwelinge") **•** [Hulp](https://af.wikipedia.org/wiki/Wikipedia:Hulp "Wikipedia:Hulp") **•** [Kontak](https://af.wikipedia.org/wiki/Wikipedia:Kontak "Wikipedia:Kontak") |  [Gebruikersportaal](https://af.wikipedia.org/wiki/Wikipedia:Gebruikersportaal "Wikipedia:Gebruikersportaal") **•** [Voorbladartikels](https://af.wikipedia.org/wiki/Wikipedia:Voorbladartikel "Wikipedia:Voorbladartikel") **•** [Kategorieë](https://af.wikipedia.org/wiki/Kategorie:Alles "Kategorie:Alles") **•** [Stel ’n vraag](https://af.wikipedia.org/wiki/Wikipedia:Navraagafdeling "Wikipedia:Navraagafdeling")  
---|---  
![](https://upload.wikimedia.org/wikipedia/commons/9/97/Bluebg.png) [![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Cscr-featured_with_ring.svg/40px-Cscr-featured_with_ring.svg.png)](https://af.wikipedia.org/wiki/Wikipedia:Voorbladartikel "Wikipedia:Voorbladartikel") **Voorbladartikel** [![Die nasionale vlag van België.](https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Flag_of_Belgium.svg/250px-Flag_of_Belgium.svg.png)](https://af.wikipedia.org/wiki/L%C3%AAer:Flag_of_Belgium.svg "Die nasionale vlag van België.") Die **[nasionale vlag van België](https://af.wikipedia.org/wiki/Vlag_van_Belgi%C3%AB "Vlag van België")** ([Nederlands](https://af.wikipedia.org/wiki/Nederlands "Nederlands"): _Vlag van België_ ; [Frans](https://af.wikipedia.org/wiki/Frans "Frans"): _Drapeau de la Belgique_ ; [Duits](https://af.wikipedia.org/wiki/Duits "Duits"): _Flagge Belgiens_) is ’n driekleur van drie ewe wye vertikale bane in die nasionale kleure van [België](https://af.wikipedia.org/wiki/Belgi%C3%AB "België"): [swart](https://af.wikipedia.org/wiki/Swart "Swart") (vlagpaalkant), [geel](https://af.wikipedia.org/wiki/Geel "Geel") en [rooi](https://af.wikipedia.org/wiki/Rooi "Rooi"). Die kleure is afgelei van die wapen van [Brabant](https://af.wikipedia.org/wiki/Brabant "Brabant") en die vertikale ontwerp is dalk gebaseer op die [vlag van Frankryk](https://af.wikipedia.org/wiki/Vlag_van_Frankryk "Vlag van Frankryk"). Wanneer die vlag wapper is die swart baan aan die vlagpaalkant. Die vlag het ’n ongewone verhouding van 13:15.  Artikel 193 van die grondwet noem die kleure, die wapen en die nasionale leuse:  |  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Cquote1.svg/20px-Cquote1.svg.png)](https://af.wikipedia.org/wiki/L%C3%AAer:Cquote1.svg) | De Belgische Natie kiest als kleuren rood, geel en zwart, en als rijkswapen de Belgische Leeuw met de kenspreuk EENDRACHT MAAKT MACHT.  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Cquote2.svg/20px-Cquote2.svg.png)](https://af.wikipedia.org/wiki/L%C3%AAer:Cquote2.svg)  
---|---|---  
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Cquote1.svg/20px-Cquote1.svg.png)](https://af.wikipedia.org/wiki/L%C3%AAer:Cquote1.svg) | Die Belgiese nasie neem die kleure rooi, geel en swart aan, en vir die wapen van die Koninkryk die Belgiese Leeu met die leuse: eenheid maak krag.  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Cquote2.svg/20px-Cquote2.svg.png)](https://af.wikipedia.org/wiki/L%C3%AAer:Cquote2.svg)  
---|---|---  
In 1830 het die destyds nieamptelike vlag van drie horisontale bane in die kleure rooi, geel en swart bestaan. Op 30 September 1830 het die voorlopige regering die nasionale vlag amptelik goedgekeur wat aanvanklik horisontale bane getoon het. Die vertikale uitleg en die swart baan aan die vlagpaalkant is op 12 Oktober 1831 definitief aangeneem. Op 23 Januarie 1831 het die Nasionale Kongres die driekleur in die Grondwet ingeskryf, maar nie die rigting en volgorde van die kleurbane bepaal nie. Gevolglik het die “amptelike” vlag vertikale bane gekry in die kleure swart, geel en rooi. Die afmetings van die vlag is bepaal as 2,60 m hoog by 3 m wyd wat oorspronklik die proporsie van die ou bane gegee het, wat die wapenhouer verteenwoordig.      _[...lees verder](https://af.wikipedia.org/wiki/Vlag_van_Belgi%C3%AB "Vlag van België")_
![](https://upload.wikimedia.org/wikipedia/commons/9/97/Bluebg.png)
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/HSAktuell.svg/40px-HSAktuell.svg.png)](https://af.wikipedia.org/wiki/Sjabloon:Aktueel "Sjabloon:Aktueel")
**In die nuus**
[![Die nasionale vlag van Palestina](https://upload.wikimedia.org/wikipedia/commons/thumb/0/00/Flag_of_Palestine.svg/250px-Flag_of_Palestine.svg.png)](https://af.wikipedia.org/wiki/L%C3%AAer:Flag_of_Palestine.svg "Die nasionale vlag van Palestina")Die nasionale vlag van Palestina
  * Die [13de Vrouekrieketwêreldbekertoernooi](https://af.wikipedia.org/wiki/Vrouekrieketw%C3%AAreldbeker_2025 "Vrouekrieketwêreldbeker 2025") duur voort met groepwedstryde in verskeie stede van [Indië](https://af.wikipedia.org/wiki/Indi%C3%AB "Indië") en [Sri Lanka](https://af.wikipedia.org/wiki/Sri_Lanka "Sri Lanka"), die twee gasheerlande.
  * In [Engeland](https://af.wikipedia.org/wiki/Engeland "Engeland") klop die gasvroue [Engeland](https://af.wikipedia.org/wiki/Engelse_nasionale_vrouerugbyspan "Engelse nasionale vrouerugbyspan") tydens die eindstryd van die [tiende Vrouerugbywêreldbekertoernooi](https://af.wikipedia.org/wiki/Vrouerugbyw%C3%AAreldbeker_2025 "Vrouerugbywêreldbeker 2025") [Kanada](https://af.wikipedia.org/wiki/Kanadese_nasionale_vrouerugbyspan "Kanadese nasionale vrouerugbyspan") met 33–13 en palm sodoende ná [1994](https://af.wikipedia.org/wiki/Vrouerugbyw%C3%AAreldbeker_1994 "Vrouerugbywêreldbeker 1994") en [2014](https://af.wikipedia.org/wiki/Vrouerugbyw%C3%AAreldbeker_2014 "Vrouerugbywêreldbeker 2014") hul derde titel in. [Nieu-Seeland](https://af.wikipedia.org/wiki/Black_Ferns "Black Ferns") eindig in die derde en [Frankryk](https://af.wikipedia.org/wiki/Franse_nasionale_vrouerugbyspan "Franse nasionale vrouerugbyspan") in die vierde plek.
  * [Australië](https://af.wikipedia.org/wiki/Australi%C3%AB "Australië"), [Frankryk](https://af.wikipedia.org/wiki/Frankryk "Frankryk"), [Kanada](https://af.wikipedia.org/wiki/Kanada "Kanada"), [Portugal](https://af.wikipedia.org/wiki/Portugal "Portugal") en die [Verenigde Koninkryk](https://af.wikipedia.org/wiki/Verenigde_Koninkryk "Verenigde Koninkryk") erken die **[Staat Palestina](https://af.wikipedia.org/wiki/Staat_Palestina "Staat Palestina")** as 'n [onafhanklike](https://af.wikipedia.org/wiki/Onafhanklikheid "Onafhanklikheid") [land](https://af.wikipedia.org/wiki/Land "Land") volgens [internasionale reg](https://af.wikipedia.org/wiki/Internasionale_reg "Internasionale reg").
  * Op [Ellispark](https://af.wikipedia.org/wiki/Ellispark-stadion "Ellispark-stadion") in [Johannesburg](https://af.wikipedia.org/wiki/Johannesburg "Johannesburg") klop die [Griekwas](https://af.wikipedia.org/wiki/Griekwas_\(rugbyspan\) "Griekwas \(rugbyspan\)") tydens die eindstryd van die [Curriebeker 2025](https://af.wikipedia.org/wiki/Curriebeker "Curriebeker") die [Goue Leeus](https://af.wikipedia.org/wiki/Goue_Leeus "Goue Leeus") met 27–25 en palm sodoende hul vierde titel in.
  * [Chile](https://af.wikipedia.org/wiki/Chileense_nasionale_rugbyspan "Chileense nasionale rugbyspan"), [Kanada](https://af.wikipedia.org/wiki/Kanadese_nasionale_rugbyspan "Kanadese nasionale rugbyspan"), [Tonga](https://af.wikipedia.org/wiki/Tongaanse_nasionale_rugbyspan "Tongaanse nasionale rugbyspan"), [Uruguay](https://af.wikipedia.org/wiki/Uruguaanse_nasionale_rugbyspan "Uruguaanse nasionale rugbyspan") en die [Verenigde State](https://af.wikipedia.org/wiki/Verenigde_State_se_nasionale_rugbyspan "Verenigde State se nasionale rugbyspan") kwalifiseer vir die [Rugbywêreldbeker 2027](https://af.wikipedia.org/wiki/Rugbyw%C3%AAreldbeker_2027 "Rugbywêreldbeker 2027") in [Australië](https://af.wikipedia.org/wiki/Australi%C3%AB "Australië"); [Italië](https://af.wikipedia.org/wiki/Italiaanse_nasionale_krieketspan "Italiaanse nasionale krieketspan") en [Nederland](https://af.wikipedia.org/wiki/Nederlandse_nasionale_krieketspan "Nederlandse nasionale krieketspan") bespreek die Europese kwalifiseringsplekke vir die [T20I-wêreldbeker 2026](https://af.wikipedia.org/wiki/T20I-w%C3%AAreldbeker_2026 "T20I-wêreldbeker 2026") in [Indië](https://af.wikipedia.org/wiki/Indi%C3%AB "Indië") en [Sri Lanka](https://af.wikipedia.org/wiki/Sri_Lanka "Sri Lanka"), vir Italië is dit hul eerste deelname aan ’n krieket- of T20I-wêreldbekertoernooi ooit.


**Voortdurend:** [Russiese inval in Oekraïne sedert 2022](https://af.wikipedia.org/wiki/Russiese_inval_in_Oekra%C3%AFne_sedert_2022 "Russiese inval in Oekraïne sedert 2022") • [Israel-Hamas-oorlog](https://af.wikipedia.org/wiki/Israel-Hamas-oorlog "Israel-Hamas-oorlog")  
**[Onlangs oorlede](https://af.wikipedia.org/wiki/Kategorie:Sterftes_in_2025 "Kategorie:Sterftes in 2025"):** [Maxi Schoeman](https://af.wikipedia.org/wiki/Maxi_Schoeman "Maxi Schoeman") • [Robert Redford](https://af.wikipedia.org/wiki/Robert_Redford "Robert Redford") • [John Searle](https://af.wikipedia.org/wiki/John_Searle "John Searle") • [Nathi Mthethwa](https://af.wikipedia.org/wiki/Nathi_Mthethwa "Nathi Mthethwa") • [Jane Goodall](https://af.wikipedia.org/wiki/Jane_Goodall "Jane Goodall")
![](https://upload.wikimedia.org/wikipedia/commons/9/97/Bluebg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/HSVissteduatt.svg/40px-HSVissteduatt.svg.png)
**Het u geweet...**
... dat die [Kasteel die Goeie Hoop](https://af.wikipedia.org/wiki/Kasteel_die_Goeie_Hoop "Kasteel die Goeie Hoop") in [Kaapstad](https://af.wikipedia.org/wiki/Kaapstad "Kaapstad"), wat tussen [1666](https://af.wikipedia.org/wiki/1666 "1666") en [1679](https://af.wikipedia.org/wiki/1679 "1679") deur die [VOC](https://af.wikipedia.org/wiki/VOC "VOC") gebou is, die oudste gebou in [Suid-Afrika](https://af.wikipedia.org/wiki/Suid-Afrika "Suid-Afrika") is?  
  
... dat [Edmund Hillary](https://af.wikipedia.org/wiki/Edmund_Hillary "Edmund Hillary") oorspronklik 'n [byeboer](https://af.wikipedia.org/wiki/Byeboerdery "Byeboerdery") was? Dit was 'n somerwerk wat hom tyd gegee het om in die winter berg te klim.  
  
... dat die [Lae Lande](https://af.wikipedia.org/wiki/Lae_Lande "Lae Lande") deur 'n kaart wat soos 'n [leeu](https://af.wikipedia.org/wiki/Leeu "Leeu") lyk voorgestel kan word? Die [Leo Belgicus](https://af.wikipedia.org/wiki/Leo_Belgicus "Leo Belgicus") is 'n gestileerde kaart van wat die Nederlande in die vorm van 'n leeu uitbeeld en die eerste weergawe is reeds in [1583](https://af.wikipedia.org/wiki/1583 "1583") geskep.  
  
... dat byna die hele [Kaapse Skiereiland](https://af.wikipedia.org/wiki/Kaapse_Skiereiland "Kaapse Skiereiland") deel is van die [Tafelberg- Nasionale Park](https://af.wikipedia.org/wiki/Tafelberg-_Nasionale_Park "Tafelberg- Nasionale Park")? Dié natuurreservaat is in [1998](https://af.wikipedia.org/wiki/1998 "1998") gestig en beslaan die [Tafelberg](https://af.wikipedia.org/wiki/Tafelberg "Tafelberg")-bergreeks.  
  
... dat [Elisha Gray](https://af.wikipedia.org/wiki/Elisha_Gray "Elisha Gray") sy [patent](https://af.wikipedia.org/wiki/Patent "Patent") vir die [telefoon](https://af.wikipedia.org/wiki/Telefoon "Telefoon") 'n uur vóór [Alexander Graham Bell](https://af.wikipedia.org/wiki/Alexander_Graham_Bell "Alexander Graham Bell") geregistreer het? Na jare van regsgedinge het Bell die patent gekry. 
![](https://upload.wikimedia.org/wikipedia/commons/9/97/Bluebg.png)
![](https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/HSDagensdatum.svg/40px-HSDagensdatum.svg.png)
**Vandag in die geskiedenis**
**[2 Oktober](https://af.wikipedia.org/wiki/2_Oktober "2 Oktober")** : Internasionale Dag van Geweldloosheid. 
[![Gandhi in 1929](https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/Gandhi_1929.jpg/125px-Gandhi_1929.jpg)](https://af.wikipedia.org/wiki/L%C3%AAer:Gandhi_1929.jpg "Gandhi in 1929")Gandhi in 1929
  * [1835](https://af.wikipedia.org/wiki/1835 "1835") – Die [Texaanse Onafhanklikheidsoorlog](https://af.wikipedia.org/wiki/Texaanse_Onafhanklikheidsoorlog "Texaanse Onafhanklikheidsoorlog") begin as [rewolusie](https://af.wikipedia.org/wiki/Rewolusie "Rewolusie") van die [Republiek van Texas](https://af.wikipedia.org/wiki/Republiek_van_Texas "Republiek van Texas") teen die [Meksikaanse](https://af.wikipedia.org/wiki/Meksiko "Meksiko") heerskappy.
  * [1867](https://af.wikipedia.org/wiki/1867 "1867") – Gebore: Majoor [James Stevenson-Hamilton](https://af.wikipedia.org/wiki/James_Stevenson-Hamilton "James Stevenson-Hamilton") in [Skotland](https://af.wikipedia.org/wiki/Skotland "Skotland"), ook beskou as die vader van die [Krugerwildtuin](https://af.wikipedia.org/wiki/Krugerwildtuin "Krugerwildtuin").
  * [1869](https://af.wikipedia.org/wiki/1869 "1869") – Gebore: **[Mahatma Gandhi](https://af.wikipedia.org/wiki/Mahatma_Gandhi "Mahatma Gandhi")** , charismatiese massabewegingsleier wat die saak van [Brits](https://af.wikipedia.org/wiki/Verenigde_Koninkryk "Verenigde Koninkryk")-koloniale [Indië](https://af.wikipedia.org/wiki/Indi%C3%AB "Indië") onder die wêreld se aandag gebring het.
  * [1958](https://af.wikipedia.org/wiki/1958 "1958") – [Guinee](https://af.wikipedia.org/wiki/Guinee "Guinee") word onafhanklik van [Frankryk](https://af.wikipedia.org/wiki/Frankryk "Frankryk").
  * [1990](https://af.wikipedia.org/wiki/1990 "1990") – Die [Duitse Demokratiese Republiek](https://af.wikipedia.org/wiki/Duitse_Demokratiese_Republiek "Duitse Demokratiese Republiek") (DDR) wat sedert 7 Oktober 1949 op die grondgebied van die voormalige [Sowjet](https://af.wikipedia.org/wiki/Sowjetunie "Sowjetunie")-besettingsone in Oos-[Duitsland](https://af.wikipedia.org/wiki/Duitsland "Duitsland") en die Sowjet-sektor van Oos-[Berlyn](https://af.wikipedia.org/wiki/Berlyn "Berlyn") bestaan het, kom tot 'n einde.


![](https://upload.wikimedia.org/wikipedia/commons/9/97/Bluebg.png)
[![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/HSBild.svg/40px-HSBild.svg.png)](https://af.wikipedia.org/wiki/Wikipedia:Beeld_van_die_week "Wikipedia:Beeld van die week")
**Voorbladbeeld**
'n Portret van die [Franse](https://af.wikipedia.org/wiki/Frankryk "Frankryk") [chemikus](https://af.wikipedia.org/wiki/Chemie "Chemie") [Louis Pasteur](https://af.wikipedia.org/wiki/Louis_Pasteur "Louis Pasteur") (1822–1895) deur die Franse fotograaf Paul Nadar, voor 1895. 
[!['n Portret van die Franse chemikus Louis Pasteur \(1822–1895\) deur die Franse fotograaf Paul Nadar, voor 1895.](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Louis_Pasteur%2C_foto_av_Paul_Nadar%2C_Crisco_edit.jpg/500px-Louis_Pasteur%2C_foto_av_Paul_Nadar%2C_Crisco_edit.jpg)](https://af.wikipedia.org/wiki/L%C3%AAer:Louis_Pasteur,_foto_av_Paul_Nadar,_Crisco_edit.jpg "'n Portret van die Franse chemikus Louis Pasteur \(1822–1895\) deur die Franse fotograaf Paul Nadar, voor 1895.")
![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Bluebg_right.png/330px-Bluebg_right.png) **Vind artikels** ![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Vista-xmag.png/40px-Vista-xmag.png)  
  
[Soekhulp](https://af.wikipedia.org/wiki/Wikipedia:Soek "Wikipedia:Soek")  
**[Geografie](https://af.wikipedia.org/wiki/Portaal:Geografie "Portaal:Geografie")** - **[Geologie](https://af.wikipedia.org/wiki/Portaal:Geologie "Portaal:Geologie")**  
[Suid-Afrika](https://af.wikipedia.org/wiki/Portaal:Suid-Afrika "Portaal:Suid-Afrika") **•** [Namibië](https://af.wikipedia.org/wiki/Kategorie:Namibi%C3%AB "Kategorie:Namibië") **•** [Botswana](https://af.wikipedia.org/wiki/Kategorie:Botswana "Kategorie:Botswana") **•** [Eswatini](https://af.wikipedia.org/wiki/Kategorie:Eswatini "Kategorie:Eswatini") **•** [Lesotho](https://af.wikipedia.org/wiki/Kategorie:Lesotho "Kategorie:Lesotho") **•** [Mosambiek](https://af.wikipedia.org/wiki/Kategorie:Mosambiek "Kategorie:Mosambiek") **•** [Zimbabwe](https://af.wikipedia.org/wiki/Kategorie:Zimbabwe "Kategorie:Zimbabwe") [Afrika](https://af.wikipedia.org/wiki/Kategorie:Geografie_van_Afrika "Kategorie:Geografie van Afrika") **•** [Suider-Afrika](https://af.wikipedia.org/wiki/Suider-Afrika "Suider-Afrika") **•** [Amerika](https://af.wikipedia.org/wiki/Kategorie:Geografie_van_Amerika "Kategorie:Geografie van Amerika") **•** [Antarktika](https://af.wikipedia.org/wiki/Kategorie:Geografie_van_Antarktika "Kategorie:Geografie van Antarktika") **•** [Asië](https://af.wikipedia.org/wiki/Kategorie:Geografie_van_Asi%C3%AB "Kategorie:Geografie van Asië") **•** [Europa](https://af.wikipedia.org/wiki/Kategorie:Geografie_van_Europa "Kategorie:Geografie van Europa") **•** [Oseanië](https://af.wikipedia.org/wiki/Kategorie:Geografie_van_Oseani%C3%AB "Kategorie:Geografie van Oseanië") [Rusland](https://af.wikipedia.org/wiki/Portaal:Rusland "Portaal:Rusland") **•** [Turkye](https://af.wikipedia.org/wiki/Portaal:Turkye "Portaal:Turkye") **•** [Verenigde State van Amerika](https://af.wikipedia.org/wiki/Kategorie:Verenigde_State_van_Amerika "Kategorie:Verenigde State van Amerika") [Lande](https://af.wikipedia.org/wiki/Kategorie:Lande "Kategorie:Lande") **•** [Baaie](https://af.wikipedia.org/wiki/Kategorie:Baaie "Kategorie:Baaie") **•** [Berge](https://af.wikipedia.org/wiki/Kategorie:Berge "Kategorie:Berge") **•** [Eilande](https://af.wikipedia.org/wiki/Kategorie:Eilande "Kategorie:Eilande") **•** [Mere](https://af.wikipedia.org/wiki/Kategorie:Mere "Kategorie:Mere") **•** [Oseane](https://af.wikipedia.org/wiki/Kategorie:Oseane "Kategorie:Oseane") **•** [Riviere](https://af.wikipedia.org/wiki/Kategorie:Riviere "Kategorie:Riviere") **•** [Woestyne](https://af.wikipedia.org/wiki/Kategorie:Woestyne "Kategorie:Woestyne")  
**[Geskiedenis](https://af.wikipedia.org/wiki/Portaal:Geskiedenis "Portaal:Geskiedenis")**  
[Argeologie](https://af.wikipedia.org/wiki/Kategorie:Argeologie "Kategorie:Argeologie") **•** [Datums](https://af.wikipedia.org/wiki/Kategorie:Datum "Kategorie:Datum") **•** [Kulturele geskiedenis](https://af.wikipedia.org/wiki/Kategorie:Kulturele_geskiedenis "Kategorie:Kulturele geskiedenis") **•** [Oorloë](https://af.wikipedia.org/wiki/Kategorie:Oorlo%C3%AB "Kategorie:Oorloë") **•** [Religieuse geskiedenis](https://af.wikipedia.org/wiki/Kategorie:Religieuse_geskiedenis "Kategorie:Religieuse geskiedenis") **•** [Rewolusies](https://af.wikipedia.org/wiki/Kategorie:Rewolusies "Kategorie:Rewolusies") **•** [Vroeë beskawings](https://af.wikipedia.org/wiki/Kategorie:Vroe%C3%AB_beskawings "Kategorie:Vroeë beskawings") **•** [Antieke Egipte](https://af.wikipedia.org/wiki/Portaal:Antieke_Egipte "Portaal:Antieke Egipte")  
**[Kultuur](https://af.wikipedia.org/wiki/Kategorie:Kultuur "Kategorie:Kultuur")**  
[Akteurs](https://af.wikipedia.org/wiki/Kategorie:Akteurs "Kategorie:Akteurs") **•** [Argitektuur](https://af.wikipedia.org/wiki/Kategorie:Argitektuur "Kategorie:Argitektuur") **•** [Dans](https://af.wikipedia.org/wiki/Kategorie:Dans "Kategorie:Dans") **•** [Letterkunde](https://af.wikipedia.org/wiki/Portaal:Letterkunde "Portaal:Letterkunde") **•** [Mitologie](https://af.wikipedia.org/wiki/Kategorie:Mitologie "Kategorie:Mitologie") **•** [Griekse mitologie](https://af.wikipedia.org/wiki/Portaal:Griekse_mitologie "Portaal:Griekse mitologie") **•** [Mode](https://af.wikipedia.org/wiki/Kategorie:Mode "Kategorie:Mode") **•** [Museums](https://af.wikipedia.org/wiki/Kategorie:Museums "Kategorie:Museums") **•** [Musiek](https://af.wikipedia.org/wiki/Portaal:Musiek "Portaal:Musiek") **•** [Rolprente](https://af.wikipedia.org/wiki/Kategorie:Rolprente "Kategorie:Rolprente") **•** [Taal](https://af.wikipedia.org/wiki/Kategorie:Taal "Kategorie:Taal") **•** [Vermaak](https://af.wikipedia.org/wiki/Kategorie:Vermaak "Kategorie:Vermaak")  
**[Natuur](https://af.wikipedia.org/wiki/Kategorie:Natuur "Kategorie:Natuur")**  
[Bewaringsgebiede](https://af.wikipedia.org/wiki/Kategorie:Bewaringsgebiede "Kategorie:Bewaringsgebiede") **•** [Diere](https://af.wikipedia.org/wiki/Kategorie:Diere "Kategorie:Diere") **•** [Plante](https://af.wikipedia.org/wiki/Kategorie:Plante "Kategorie:Plante")  
**[Religie](https://af.wikipedia.org/wiki/Kategorie:Religie "Kategorie:Religie")**  
[Agnostisisme](https://af.wikipedia.org/wiki/Kategorie:Agnostisisme "Kategorie:Agnostisisme") **•** [Baha'i](https://af.wikipedia.org/wiki/Kategorie:Baha%27i "Kategorie:Baha'i") **•** [Boeddhisme](https://af.wikipedia.org/wiki/Kategorie:Boeddhisme "Kategorie:Boeddhisme") **•** [Christendom](https://af.wikipedia.org/wiki/Kategorie:Christendom "Kategorie:Christendom") **•** [Gnostisisme](https://af.wikipedia.org/wiki/Kategorie:Gnostisisme "Kategorie:Gnostisisme") **•** [Hindoeïsme](https://af.wikipedia.org/wiki/Kategorie:Hindoe%C3%AFsme "Kategorie:Hindoeïsme") **•** [Islam](https://af.wikipedia.org/wiki/Kategorie:Islam "Kategorie:Islam") **•** [Judaïsme](https://af.wikipedia.org/wiki/Kategorie:Juda%C3%AFsme "Kategorie:Judaïsme") **•** [Mitologie](https://af.wikipedia.org/wiki/Kategorie:Mitologie "Kategorie:Mitologie") **•** [New Age](https://af.wikipedia.org/wiki/Kategorie:New_Age-beweging "Kategorie:New Age-beweging") **•** [Paganisme](https://af.wikipedia.org/wiki/Kategorie:Paganisme "Kategorie:Paganisme") **•** [Politeïsme](https://af.wikipedia.org/wiki/Kategorie:Polite%C3%AFsme "Kategorie:Politeïsme") **•** [Satanisme](https://af.wikipedia.org/wiki/Kategorie:Satanisme "Kategorie:Satanisme") **•** [Sikhisme](https://af.wikipedia.org/wiki/Kategorie:Sikhisme "Kategorie:Sikhisme") **•** [Zoroastrisme](https://af.wikipedia.org/wiki/Kategorie:Zoroastrisme "Kategorie:Zoroastrisme")  
**[Samelewing](https://af.wikipedia.org/wiki/Kategorie:Samelewing "Kategorie:Samelewing")**  
[Besigheid](https://af.wikipedia.org/wiki/Kategorie:Besigheid "Kategorie:Besigheid") **•** [Ekonomie](https://af.wikipedia.org/wiki/Kategorie:Ekonomie "Kategorie:Ekonomie") **•** [Krieket](https://af.wikipedia.org/wiki/Portaal:Krieket "Portaal:Krieket") **•** [Politiek](https://af.wikipedia.org/wiki/Kategorie:Politiek "Kategorie:Politiek") **•** [Rugby](https://af.wikipedia.org/wiki/Portaal:Rugby "Portaal:Rugby") **•** [Sport](https://af.wikipedia.org/wiki/Portaal:Sport "Portaal:Sport") **•** [Vlae en wapens](https://af.wikipedia.org/wiki/Portaal:Vlae_en_wapens "Portaal:Vlae en wapens") **•** [Vervoer](https://af.wikipedia.org/wiki/Kategorie:Vervoer "Kategorie:Vervoer")  
**[Taal](https://af.wikipedia.org/wiki/Kategorie:Taal "Kategorie:Taal")**  
[Kunsmatige taal](https://af.wikipedia.org/wiki/Kategorie:Kunsmatige_taal "Kategorie:Kunsmatige taal") **•** [Natuurlike taal](https://af.wikipedia.org/wiki/Kategorie:Natuurlike_taal "Kategorie:Natuurlike taal") **•** [Taalfamilies](https://af.wikipedia.org/wiki/Kategorie:Taalfamilies "Kategorie:Taalfamilies") **•** [Skryfstelsels](https://af.wikipedia.org/wiki/Portaal:Skryfstelsels "Portaal:Skryfstelsels")  
**[Tegnologie](https://af.wikipedia.org/wiki/Kategorie:Tegnologie "Kategorie:Tegnologie")**  
[Elektronika](https://af.wikipedia.org/wiki/Kategorie:Elektronika "Kategorie:Elektronika") **•** [Fotografie](https://af.wikipedia.org/wiki/Kategorie:Fotografie "Kategorie:Fotografie") **•** [Inligtingstegnologie](https://af.wikipedia.org/wiki/Kategorie:Inligtingstegnologie "Kategorie:Inligtingstegnologie") **•** [Klanktegnologie](https://af.wikipedia.org/wiki/Kategorie:Klanktegnologie "Kategorie:Klanktegnologie") **•** [Voertuigtegnologie](https://af.wikipedia.org/wiki/Kategorie:Voertuigtegnologie "Kategorie:Voertuigtegnologie")  
**[Wetenskap](https://af.wikipedia.org/wiki/Kategorie:Wetenskap "Kategorie:Wetenskap")**  
[Biologie](https://af.wikipedia.org/wiki/Portaal:Biologie "Portaal:Biologie") **•** [Chemie](https://af.wikipedia.org/wiki/Portaal:Chemie "Portaal:Chemie") **•** [Filosofie](https://af.wikipedia.org/wiki/Kategorie:Filosofie "Kategorie:Filosofie") **•** [Fisika](https://af.wikipedia.org/wiki/Portaal:Fisika "Portaal:Fisika") **•** [Natuurwetenskap](https://af.wikipedia.org/wiki/Kategorie:Natuurwetenskap "Kategorie:Natuurwetenskap") **•** [Sielkunde](https://af.wikipedia.org/wiki/Kategorie:Sielkunde "Kategorie:Sielkunde") **•** [Sosiologie](https://af.wikipedia.org/wiki/Kategorie:Sosiologie "Kategorie:Sosiologie") **•** [Sterrekunde](https://af.wikipedia.org/wiki/Portaal:Sterrekunde "Portaal:Sterrekunde") **•** [Wiskunde](https://af.wikipedia.org/wiki/Kategorie:Wiskunde "Kategorie:Wiskunde")  
[Artikelindeks](https://af.wikipedia.org/wiki/Spesiaal:Alle_bladsye "Spesiaal:Alle bladsye") **•** [Kategorieboom](https://af.wikipedia.org/wiki/Spesiaal:KategorieBoom "Spesiaal:KategorieBoom") **•** [Lyste](https://af.wikipedia.org/wiki/Kategorie:Lyste "Kategorie:Lyste") **•** [Hoe soek ek?](https://af.wikipedia.org/wiki/Wikipedia:Soek "Wikipedia:Soek")  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Bluebg_right.png/330px-Bluebg_right.png) **Wikipedia in ander tale** ![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Gnome-globe.svg/40px-Gnome-globe.svg.png)   
  
**Weergawes met meer as 1 000 000 artikels**  
[ العربية](https://ar.wikipedia.org/wiki/ "ar:") • [مصرى](https://arz.wikipedia.org/wiki/ "arz:") • [Cebuano](https://ceb.wikipedia.org/wiki/ "ceb:") • [Deutsch](https://de.wikipedia.org/wiki/ "de:") • [English](https://en.wikipedia.org/wiki/ "en:") • [Español](https://es.wikipedia.org/wiki/ "es:") • [فارسی](https://fa.wikipedia.org/wiki/ "fa:") • [Français](https://fr.wikipedia.org/wiki/ "fr:") • [Italiano](https://it.wikipedia.org/wiki/ "it:") • [日本語](https://ja.wikipedia.org/wiki/ "ja:") • [Nederlands](https://nl.wikipedia.org/wiki/ "nl:") • [Polski](https://pl.wikipedia.org/wiki/ "pl:") • [Português](https://pt.wikipedia.org/wiki/ "pt:") • [Русский](https://ru.wikipedia.org/wiki/ "ru:") • [Svenska](https://sv.wikipedia.org/wiki/ "sv:") • [Українська](https://uk.wikipedia.org/wiki/ "uk:") • [Tiếng Việt](https://vi.wikipedia.org/wiki/ "vi:") • [Winaray](https://war.wikipedia.org/wiki/ "war:") • [中文](https://zh.wikipedia.org/wiki/ "zh:")  
**Weergawes met meer as 750 000 artikels**  
[ Català](https://ca.wikipedia.org/wiki/ "ca:")  
**Weergawes met meer as 500 000 artikels**  
[ تۆرکجه](https://azb.wikipedia.org/wiki/ "azb:") • [Нохчийн](https://ce.wikipedia.org/wiki/ "ce:") • [Čeština](https://cs.wikipedia.org/wiki/ "cs:") • [Suomi](https://fi.wikipedia.org/wiki/ "fi:") • [Magyar](https://hu.wikipedia.org/wiki/ "hu:") • [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "id:") • [한국어](https://ko.wikipedia.org/wiki/ "ko:") • [Norsk (bokmål)‬](https://no.wikipedia.org/wiki/ "no:") • [Română](https://ro.wikipedia.org/wiki/ "ro:") • [Српски / srpski](https://sr.wikipedia.org/wiki/ "sr:") • [Türkçe](https://tr.wikipedia.org/wiki/ "tr:") • [Татарча / tatarça](https://tt.wikipedia.org/wiki/ "tt:")  
**Weergawes met meer as 250 000 artikels**  
[ Беларуская](https://be.wikipedia.org/wiki/ "be:") • [Български](https://bg.wikipedia.org/wiki/ "bg:") • [Cymraeg](https://cy.wikipedia.org/wiki/ "cy:") • [Dansk](https://da.wikipedia.org/wiki/ "da:") • [Ελληνικά](https://el.wikipedia.org/wiki/ "el:") • [Esperanto](https://eo.wikipedia.org/wiki/ "eo:") • [Eesti](https://et.wikipedia.org/wiki/ "et:") • [Euskara](https://eu.wikipedia.org/wiki/ "eu:") • [עברית](https://he.wikipedia.org/wiki/ "he:") • [Հայերեն](https://hy.wikipedia.org/wiki/ "hy:") • [Қазақша](https://kk.wikipedia.org/wiki/ "kk:") • [Baso Minangkabau](https://min.wikipedia.org/wiki/ "min:") • [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "ms:") • [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "sh:") • [Simple English](https://simple.wikipedia.org/wiki/ "simple:") • [Slovenčina](https://sk.wikipedia.org/wiki/ "sk:") • [Oʻzbekcha](https://uz.wikipedia.org/wiki/ "uz:") • [Bân-lâm-gú](https://zh-min-nan.wikipedia.org/wiki/ "zh-min-nan:")  
**Weergawes met meer as 100 000 artikels**  
Afrikaans • [Asturianu](https://ast.wikipedia.org/wiki/ "ast:") • [Azərbaycanca](https://az.wikipedia.org/wiki/ "az:") • [বাংলা](https://bn.wikipedia.org/wiki/ "bn:") • [Bosanski](https://bs.wikipedia.org/wiki/ "bs:") • [Galego](https://gl.wikipedia.org/wiki/ "gl:") • [हिन्दी](https://hi.wikipedia.org/wiki/ "hi:") • [Hrvatski](https://hr.wikipedia.org/wiki/ "hr:") • [ქართული](https://ka.wikipedia.org/wiki/ "ka:") • [Latina](https://la.wikipedia.org/wiki/ "la:") • [Ladin](https://lld.wikipedia.org/wiki/ "lld:") • [Lietuvių](https://lt.wikipedia.org/wiki/ "lt:") • [Latviešu](https://lv.wikipedia.org/wiki/ "lv:") • [Malagasy](https://mg.wikipedia.org/wiki/ "mg:") • [Македонски](https://mk.wikipedia.org/wiki/ "mk:") • [मराठी](https://mr.wikipedia.org/wiki/ "mr:") • [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/ "my:") • [Norsk (nynorsk)‬](https://nn.wikipedia.org/wiki/ "nn:") • [Occitan](https://oc.wikipedia.org/wiki/ "oc:") • [Slovenščina](https://sl.wikipedia.org/wiki/ "sl:") • [Shqip](https://sq.wikipedia.org/wiki/ "sq:") • [Kiswahili](https://sw.wikipedia.org/wiki/ "sw:") • [தமிழ்](https://ta.wikipedia.org/wiki/ "ta:") • [తెలుగు](https://te.wikipedia.org/wiki/ "te:") • [Тоҷикӣ](https://tg.wikipedia.org/wiki/ "tg:") • [ไทย](https://th.wikipedia.org/wiki/ "th:") • [اردو](https://ur.wikipedia.org/wiki/ "ur:") • [粵語](https://zh-yue.wikipedia.org/wiki/ "zh-yue:")  
**Weergawes met meer as 50 000 artikels**  
[ aragonés](https://an.wikipedia.org/wiki/ "an:") • [Башҡорт](https://ba.wikipedia.org/wiki/ "ba:") • [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/ "be-tarask:") • [Brezhoneg](https://br.wikipedia.org/wiki/ "br:") • [کوردی](https://ckb.wikipedia.org/wiki/ "ckb:") • [чӑвашла](https://cv.wikipedia.org/wiki/ "cv:") • [Frysk](https://fy.wikipedia.org/wiki/ "fy:") • [Gaeilge](https://ga.wikipedia.org/wiki/ "ga:") • [گیلکی](https://glk.wikipedia.org/wiki/ "glk:") • [Hausa](https://ha.wikipedia.org/wiki/ "ha:") • [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/ "ht:") • [Ido](https://io.wikipedia.org/wiki/ "io:") • [Íslenska](https://is.wikipedia.org/wiki/ "is:") • [Basa Jawa](https://jv.wikipedia.org/wiki/ "jv:") • [Kurdî / كوردی](https://ku.wikipedia.org/wiki/ "ku:") • [Кыргызча](https://ky.wikipedia.org/wiki/ "ky:") • [Lëtzebuergesch](https://lb.wikipedia.org/wiki/ "lb:") • [lombard](https://lmo.wikipedia.org/wiki/ "lmo:") • [മലയാളം](https://ml.wikipedia.org/wiki/ "ml:") • [مازِرونی](https://mzn.wikipedia.org/wiki/ "mzn:") • [Plattdüütsch](https://nds.wikipedia.org/wiki/ "nds:") • [नेपाल भाषा](https://new.wikipedia.org/wiki/ "new:") • [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/ "pa:") • [Piemontèis](https://pms.wikipedia.org/wiki/ "pms:") • [شاہ مکھی پنجابی (Shāhmukhī Pañjābī)](https://pnb.wikipedia.org/wiki/ "pnb:") • [Basa Sunda](https://su.wikipedia.org/wiki/ "su:") • [Ślůnski](https://szl.wikipedia.org/wiki/ "szl:") • [Tagalog](https://tl.wikipedia.org/wiki/ "tl:") • [Vèneto](https://vec.wikipedia.org/wiki/ "vec:")  
**[Lys van alle taalweergawes van Wikipedia](https://meta.wikimedia.org/wiki/List_of_Wikipedias "meta:List of Wikipedias")**   
  
![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Bluebg_right.png/330px-Bluebg_right.png) **Susterprojekte** ![](https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Wikimedia-logo.svg/40px-Wikimedia-logo.svg.png)  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/20px-Commons-logo.svg.png)](https://commons.wikimedia.org/wiki/Tuisblad "commons:Tuisblad") |  [**Commons**](https://commons.wikimedia.org/wiki/Tuisblad "commons:Tuisblad")   
Vrye media   
---|---  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Wiktionary_small.svg/40px-Wiktionary_small.svg.png)](https://af.wiktionary.org/wiki/ "wikt:") |  [**Wikiwoordeboek**](https://af.wiktionary.org/wiki/ "wikt:")   
Vrye woordeboek   
---|---  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/40px-Wikinews-logo.svg.png)](https://af.wikinews.org/wiki/ "n:") |  [**Wikinews**](https://af.wikinews.org/wiki/ "n:")   
Vrye nuusbron   
---|---  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/40px-Wikisource-logo.svg.png)](https://af.wikipedia.org/wiki/Src: "Src:") |  **[Wikisource](https://wikisource.org/wiki/Tuisblad "oldwikisource:Tuisblad")**   
Die vrye biblioteek   
---|---  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/40px-Wikibooks-logo.svg.png)](https://af.wikibooks.org/wiki/ "b:") |  [**Wikibooks**](https://af.wikibooks.org/wiki/ "b:")   
Vrye boeke   
---|---  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/40px-Wikiquote-logo.svg.png)](https://af.wikiquote.org/wiki/ "q:") |  [**Wikiquote**](https://af.wikiquote.org/wiki/ "q:")   
Aanhalings   
---|---  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Wikispecies-logo.svg/40px-Wikispecies-logo.svg.png)](https://species.wikimedia.org/wiki/Huvudsida "wikispecies:Huvudsida") |  [**Wikispecies**](https://species.wikimedia.org/wiki/Tuisblad "wikispecies:Tuisblad")   
Spesie-indeks   
---|---  
|  [![](https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)](https://meta.wikimedia.org/wiki/Tuisblad "m:Tuisblad") |  [**Meta-Wiki**](https://meta.wikimedia.org/wiki/Tuisblad "m:Tuisblad")   
Projekkoördinering   
---|---  
Indien u die verkeerde datum sien of sjablone opgedateer het, moet u die [voorblad verfris](https://af.wikipedia.org/w/index.php?title=Tuisblad&action=purge).  
---  
Ontsluit van "[https://af.wikipedia.org/w/index.php?title=Tuisblad&oldid=2774431](https://af.wikipedia.org/w/index.php?title=Tuisblad&oldid=2774431)"
[Kategorie](https://af.wikipedia.org/wiki/Spesiaal:Kategorie%C3%AB "Spesiaal:Kategorieë"): 
  * [Voorblad](https://af.wikipedia.org/wiki/Kategorie:Voorblad "Kategorie:Voorblad")


127 tale
  * [Alemannisch](https://als.wikipedia.org/wiki/ "Switserse Duits")
  * [አማርኛ](https://am.wikipedia.org/wiki/ "Amharies")
  * [Aragonés](https://an.wikipedia.org/wiki/ "Aragonees")
  * [Ænglisc](https://ang.wikipedia.org/wiki/ "Old English")
  * [العربية](https://ar.wikipedia.org/wiki/ "Arabies")
  * [مصرى](https://arz.wikipedia.org/wiki/ "Egyptian Arabic")
  * [Asturianu](https://ast.wikipedia.org/wiki/ "Asturies")
  * [Azərbaycanca](https://az.wikipedia.org/wiki/ "Azerbeidjans")
  * [تۆرکجه](https://azb.wikipedia.org/wiki/ "South Azerbaijani")
  * [Башҡортса](https://ba.wikipedia.org/wiki/ "Baskir")
  * [Boarisch](https://bar.wikipedia.org/wiki/ "Bavarian")
  * [Беларуская](https://be.wikipedia.org/wiki/ "Belarussies")
  * [Беларуская (тарашкевіца)](https://be-tarask.wikipedia.org/wiki/ "Belarusian \(Taraškievica orthography\)")
  * [Български](https://bg.wikipedia.org/wiki/ "Bulgaars")
  * [বাংলা](https://bn.wikipedia.org/wiki/ "Bengaals")
  * [Brezhoneg](https://br.wikipedia.org/wiki/ "Bretons")
  * [Bosanski](https://bs.wikipedia.org/wiki/ "Bosnies")
  * [Català](https://ca.wikipedia.org/wiki/ "Katalaans")
  * [Нохчийн](https://ce.wikipedia.org/wiki/ "Tsjetsjeens")
  * [Cebuano](https://ceb.wikipedia.org/wiki/ "Cebuano")
  * [کوردی](https://ckb.wikipedia.org/wiki/ "Sorani")
  * [Čeština](https://cs.wikipedia.org/wiki/ "Tsjeggies")
  * [Чӑвашла](https://cv.wikipedia.org/wiki/ "Chuvash")
  * [Cymraeg](https://cy.wikipedia.org/wiki/ "Wallies")
  * [Dansk](https://da.wikipedia.org/wiki/ "Deens")
  * [Deutsch](https://de.wikipedia.org/wiki/ "Duits")
  * [Ελληνικά](https://el.wikipedia.org/wiki/ "Grieks")
  * [English](https://en.wikipedia.org/wiki/ "Engels")
  * [Esperanto](https://eo.wikipedia.org/wiki/ "Esperanto")
  * [Español](https://es.wikipedia.org/wiki/ "Spaans")
  * [Eesti](https://et.wikipedia.org/wiki/ "Estnies")
  * [Euskara](https://eu.wikipedia.org/wiki/ "Baskies")
  * [فارسی](https://fa.wikipedia.org/wiki/ "Persies")
  * [Suomi](https://fi.wikipedia.org/wiki/ "Fins")
  * [Føroyskt](https://fo.wikipedia.org/wiki/ "Faroëes")
  * [Français](https://fr.wikipedia.org/wiki/ "Frans")
  * [Nordfriisk](https://frr.wikipedia.org/wiki/ "Noord-Fries")
  * [Frysk](https://fy.wikipedia.org/wiki/ "Fries")
  * [Gaeilge](https://ga.wikipedia.org/wiki/ "Iers")
  * [Gàidhlig](https://gd.wikipedia.org/wiki/ "Skotse Gallies")
  * [Galego](https://gl.wikipedia.org/wiki/ "Galisies")
  * [گیلکی](https://glk.wikipedia.org/wiki/ "Gilaki")
  * [Gaelg](https://gv.wikipedia.org/wiki/ "Manx")
  * [Hausa](https://ha.wikipedia.org/wiki/ "Hausa")
  * [עברית](https://he.wikipedia.org/wiki/ "Hebreeus")
  * [हिन्दी](https://hi.wikipedia.org/wiki/ "Hindi")
  * [Hrvatski](https://hr.wikipedia.org/wiki/ "Kroaties")
  * [Kreyòl ayisyen](https://ht.wikipedia.org/wiki/ "Haïtiaans")
  * [Magyar](https://hu.wikipedia.org/wiki/ "Hongaars")
  * [Հայերեն](https://hy.wikipedia.org/wiki/ "Armeens")
  * [Bahasa Indonesia](https://id.wikipedia.org/wiki/ "Indonesies")
  * [Ido](https://io.wikipedia.org/wiki/ "Ido")
  * [Íslenska](https://is.wikipedia.org/wiki/ "Yslands")
  * [Italiano](https://it.wikipedia.org/wiki/ "Italiaans")
  * [日本語](https://ja.wikipedia.org/wiki/ "Japannees")
  * [Jawa](https://jv.wikipedia.org/wiki/ "Javaans")
  * [ქართული](https://ka.wikipedia.org/wiki/ "Georgies")
  * [Қазақша](https://kk.wikipedia.org/wiki/ "Kazaks")
  * [한국어](https://ko.wikipedia.org/wiki/ "Koreaans")
  * [Kurdî](https://ku.wikipedia.org/wiki/ "Koerdies")
  * [Kernowek](https://kw.wikipedia.org/wiki/ "Kornies")
  * [Кыргызча](https://ky.wikipedia.org/wiki/ "Kirgisies")
  * [Latina](https://la.wikipedia.org/wiki/ "Latyn")
  * [Ladino](https://lad.wikipedia.org/wiki/ "Ladino")
  * [Lëtzebuergesch](https://lb.wikipedia.org/wiki/ "Luxemburgs")
  * [Limburgs](https://li.wikipedia.org/wiki/ "Limburgs")
  * [Ladin](https://lld.wikipedia.org/wiki/ "Ladin")
  * [Lombard](https://lmo.wikipedia.org/wiki/ "Lombardies")
  * [Lietuvių](https://lt.wikipedia.org/wiki/ "Litaus")
  * [Latviešu](https://lv.wikipedia.org/wiki/ "Letties")
  * [Malagasy](https://mg.wikipedia.org/wiki/ "Malgassies")
  * [Minangkabau](https://min.wikipedia.org/wiki/ "Minangkabaus")
  * [Македонски](https://mk.wikipedia.org/wiki/ "Masedonies")
  * [മലയാളം](https://ml.wikipedia.org/wiki/ "Malabaars")
  * [मराठी](https://mr.wikipedia.org/wiki/ "Marathi")
  * [Bahasa Melayu](https://ms.wikipedia.org/wiki/ "Maleis")
  * [မြန်မာဘာသာ](https://my.wikipedia.org/wiki/ "Birmaans")
  * [مازِرونی](https://mzn.wikipedia.org/wiki/ "Masanderani")
  * [Plattdüütsch](https://nds.wikipedia.org/wiki/ "Nederduits")
  * [Nedersaksies](https://nds-nl.wikipedia.org/wiki/ "Nedersaksies")
  * [नेपाल भाषा](https://new.wikipedia.org/wiki/ "Newari")
  * [Nederlands](https://nl.wikipedia.org/wiki/ "Nederlands")
  * [Norsk nynorsk](https://nn.wikipedia.org/wiki/ "Nuwe Noors")
  * [Norsk bokmål](https://no.wikipedia.org/wiki/ "Boeknoors")
  * [Occitan](https://oc.wikipedia.org/wiki/ "Oksitaans")
  * [ਪੰਜਾਬੀ](https://pa.wikipedia.org/wiki/ "Pandjabi")
  * [Polski](https://pl.wikipedia.org/wiki/ "Pools")
  * [Piemontèis](https://pms.wikipedia.org/wiki/ "Piedmontese")
  * [پنجابی](https://pnb.wikipedia.org/wiki/ "Western Punjabi")
  * [Português](https://pt.wikipedia.org/wiki/ "Portugees")
  * [Română](https://ro.wikipedia.org/wiki/ "Roemeens")
  * [Русский](https://ru.wikipedia.org/wiki/ "Russies")
  * [Sicilianu](https://scn.wikipedia.org/wiki/ "Sisiliaans")
  * [Scots](https://sco.wikipedia.org/wiki/ "Skots")
  * [Srpskohrvatski / српскохрватски](https://sh.wikipedia.org/wiki/ "Serwo-Kroaties")
  * [Simple English](https://simple.wikipedia.org/wiki/ "Simple English")
  * [Slovenčina](https://sk.wikipedia.org/wiki/ "Slowaaks")
  * [Slovenščina](https://sl.wikipedia.org/wiki/ "Sloweens")
  * [Shqip](https://sq.wikipedia.org/wiki/ "Albanees")
  * [Српски / srpski](https://sr.wikipedia.org/wiki/ "Serwies")
  * [Seeltersk](https://stq.wikipedia.org/wiki/ "Saterland Frisian")
  * [Sunda](https://su.wikipedia.org/wiki/ "Sundanees")
  * [Svenska](https://sv.wikipedia.org/wiki/ "Sweeds")
  * [Kiswahili](https://sw.wikipedia.org/wiki/ "Swahili")
  * [Ślůnski](https://szl.wikipedia.org/wiki/ "Silesies")
  * [தமிழ்](https://ta.wikipedia.org/wiki/ "Tamil")
  * [తెలుగు](https://te.wikipedia.org/wiki/ "Teloegoe")
  * [Тоҷикӣ](https://tg.wikipedia.org/wiki/ "Tadjiks")
  * [ไทย](https://th.wikipedia.org/wiki/ "Thai")
  * [Tagalog](https://tl.wikipedia.org/wiki/ "Tagalog")
  * [Türkçe](https://tr.wikipedia.org/wiki/ "Turks")
  * [Татарча / tatarça](https://tt.wikipedia.org/wiki/ "Tataars")
  * [Українська](https://uk.wikipedia.org/wiki/ "Oekraïens")
  * [اردو](https://ur.wikipedia.org/wiki/ "Oerdoe")
  * [Oʻzbekcha / ўзбекча](https://uz.wikipedia.org/wiki/ "Oesbekies")
  * [Vèneto](https://vec.wikipedia.org/wiki/ "Venesiaans")
  * [Tiếng Việt](https://vi.wikipedia.org/wiki/ "Viëtnamees")
  * [West-Vlams](https://vls.wikipedia.org/wiki/ "West Flemish")
  * [Volapük](https://vo.wikipedia.org/wiki/ "Volapük")
  * [Walon](https://wa.wikipedia.org/wiki/ "Walloon")
  * [Winaray](https://war.wikipedia.org/wiki/ "Waray")
  * [ייִדיש](https://yi.wikipedia.org/wiki/ "Jiddisj")
  * [Yorùbá](https://yo.wikipedia.org/wiki/ "Joroeba")
  * [Zeêuws](https://zea.wikipedia.org/wiki/ "Zeelandic")
  * [中文](https://zh.wikipedia.org/wiki/ "Chinees")
  * [閩南語 / Bân-lâm-gí](https://zh-min-nan.wikipedia.org/wiki/ "Min Nan-Sjinees")
  * [粵語](https://zh-yue.wikipedia.org/wiki/ "Kantonees")


  * Die bladsy is laas op 23 Mei 2025 om 20:59 bygewerk.
  * Die teks is beskikbaar onder die lisensie [Creative Commons Erkenning-Insgelyks Deel](https://creativecommons.org/licenses/by-sa/4.0/). Aanvullende voorwaardes kan moontlik ook van toepassing wees. Sien die [Algemene Voorwaardes](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms_of_Use) vir meer inligting.


  * [Privaatheidsbeleid](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
  * [Inligting oor Wikipedia](https://af.wikipedia.org/wiki/Wikipedia:Oor)
  * [Vrywaring](https://af.wikipedia.org/wiki/Wikipedia:Voorwaardes)
  * [Gedragskode](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
  * [Ontwikkelaars](https://developer.wikimedia.org)
  * [Statistieke](https://stats.wikimedia.org/#/af.wikipedia.org)
  * [Koekieverklaring](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
  * [Selfoonweergawe](https://af.m.wikipedia.org/w/index.php?title=Tuisblad&mobileaction=toggle_view_mobile)


  * [![Wikimedia Foundation](https://af.wikipedia.org/static/images/footer/wikimedia.svg)](https://www.wikimedia.org/)
  * [![Powered by MediaWiki](https://af.wikipedia.org/w/resources/assets/mediawiki_compact.svg)](https://www.mediawiki.org/)


Soek
Soek
Tuisblad
[](https://af.wikipedia.org/wiki/Tuisblad) [](https://af.wikipedia.org/wiki/Tuisblad) [](https://af.wikipedia.org/wiki/Tuisblad) [](https://af.wikipedia.org/wiki/Tuisblad) [](https://af.wikipedia.org/wiki/Tuisblad) [](https://af.wikipedia.org/wiki/Tuisblad) [](https://af.wikipedia.org/wiki/Tuisblad) [](https://af.wikipedia.org/wiki/Tuisblad)
127 tale [Nuwe onderwerp ](https://af.wikipedia.org/wiki/Tuisblad)
